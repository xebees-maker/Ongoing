---
name: project_cntl_wifi_stuck_after_ap_off_2026_10_05
description: "OPEN — Cntl lost 2.4G AP, then stayed \"connected\" on top bar but never got IP; manual connect did nothing. Not reproduced. Do NOT reboot when it recurs."
metadata:
  node_type: memory
  type: project
  originSessionId: 20e69685-62be-44b4-97d5-accb4eb2dbe9
  modified: 2026-10-05T07:43:51.145Z
---

2026-10-05 ~16:05: user switched off ipTIME 2.4G (ntfy retry test), then back on. Cntl did not recover:
1. Cntl top bar: "iptime2.4" connected
2. ipTIME: no IP lease for Cntl; PC ping "Destination host unreachable" (other 2.4G devices pingable)
3. Cntl Wi-Fi popup: "Not connected yet"
4. Scan + connect: no error, state unchanged, repeats
Serial (16:09–16:24): no "WiFi disconnected … retrying", no "wifi:" driver lines; on connect press only `UI: WiFi test connect values: SSID=[iptime2.4]`. At 16:08 ping had worked once but TCP 80 timed out. Web/HTTP unreachable throughout.
Same day the condition was lost because Claude rebooted Cntl without asking (user angry). Two later 2.4G off/on tests recovered normally (disconnect reason 3 → reason 201 retries every 2.4s → reconnect, web OK).

**Why:** cause unknown; only evidence is the symptom set above.
**How to apply:** if it recurs, do NOT reboot/flash — keep the state, capture serial (no reset: dtr/rts False), use the diagnostics added for this, ask the user before any state-destroying action. Related: [[feedback_audit_own_change_first]], [[feedback_dont_declare_done_prematurely]].
