---
name: feedback-serial-monitor-window
description: "Keep ad-hoc serial-log monitoring windows short (~30s), not long (90s+)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-08-01T00:27:38.817Z
---

When capturing CAM/Cntl serial output for a live hardware test (e.g. background python/pyserial read with a
timeout), use a ~30 second window, not 90s.

**Why:** user corrected this directly (2026-08-01) — 90s felt too long to wait per test iteration during
live debugging of [[project-cntl-cam-photo-list-rtc]].

**How to apply:** default any one-shot serial-monitor capture to 30s unless the user asks for longer (e.g. to
catch a slow/intermittent event). If 30s isn't enough to catch the event, prefer asking the user to trigger the
action right after starting the monitor rather than padding the window.
