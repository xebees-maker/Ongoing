---
name: project-cntl-cam-todo-2026-08-02
description: "Cntl/CAM pending to-do list dictated by user at end of 2026-08-01 session, to pick up next session"
metadata:
  type: project
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-08-01T14:41:22.781Z
---

At the end of the 2026-08-01 session the user explicitly stopped work and dictated a 3-item to-do list
for the next session ("내일 할일" — tomorrow's tasks), confirmed complete via AskUserQuestion.

1. **Fix capture-now not fetching the photo.** After "지금촬영" (capture now), the photo list correctly
   refreshes and the newly-captured item shows as selected, but the photo itself never actually gets
   fetched/displayed — the user noticed this right after the [[project_cntl_cam_file_id_redesign]] change
   landed and isn't sure yet whether that's the cause ("일단 잘 들어... 마지막 고친 것 때문인지 지금촬영은
   실패해" — not sure if it's from the last fix, but capture-now fails). Start by checking whether
   `cb_capture_now`'s post-capture list-sync path (`capture_popup_tick_fn` → `sync_photo_list_tick(0)` in
   `ui_main.c`) still correctly triggers `display_photo()` for the new item now that list entries carry
   `file_id`/`kind`/`capture_time` instead of a bare timestamp — likely an ordering/index assumption that
   silently broke.

2. **Finish the UI for running two CAM devices simultaneously.** Not yet started/scoped — needs design
   work for how the dashboard/list/settings distinguish and address two paired CAM nodes at once.

3. **Add an auto-capture-interval setting under Settings → Camera (설정-카메라).** The wire protocol
   already has `esp_now_cam_config_t` (`CAM/main` + `Common/components/esp_now_link/include/esp_now_link.h`)
   with `capture_interval_sec` and `wb_mode`, but nothing in Cntl's Option-tab UI exposes it yet — this is
   a pure Cntl UI addition (CAM already honors the config message per its existing Kconfig-preset design).

**How to apply:** treat this as the active work queue at the start of the next session — don't re-derive
from scratch, start directly on item 1 unless the user says otherwise.
