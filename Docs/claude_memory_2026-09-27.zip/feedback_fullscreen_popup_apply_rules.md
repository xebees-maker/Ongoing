---
name: fullscreen-popup-apply-rules
description: "CNTL full-screen popup convention (user, 2026-09-27): when a control needs an Apply button vs applies immediately, grouping rule, X-only close, no applied/pending status labels, lists show set values"
metadata:
  type: feedback
---

Scope: CNTL **full-screen popups** only (create_page_popup). Other UI types are decided separately — do not generalize.

1. Close only via the top-right X. Apply never closes the popup.
2. Apply button NEEDED: control whose change is executed immediately over communication; text input (textarea).
3. Apply NOT needed (change = saved/applied immediately): value stored in Cntl and delivered on the next
   communication (e.g. CAM capture interval/AGC/AEC/XCLK via CASK CONFIG, Sens measure interval, response interval);
   Cntl-local values (language, auto-connect, view settings).
4. Grouped apply: put the grouped controls in a visible group (panel/group box), Apply at the group's top-right.
   Accepted exception: SR/Power relay condition (many fields form one rule → gray panel + top-right Apply) — keep.
5. No "(applied/pending)" status suffixes on labels — ambiguous because some settings apply to all nodes and some to
   one node.
6. No developer info in lists (e.g. CASK queue "대기 N"); instead show the values as set, e.g. camera row: interval/AGC/AEC.

**Why:** 2026-09-27 I refactored the camera settings popup into one bottom Apply that closed the popup, with status
suffixes — the user said it broke the established convention and laid out these rules.

**How to apply:** when building/editing any full-screen popup, classify each control by rules 2–3 first. This refines
[[model-view-dirty-pattern]] (whose "Apply closes the popup" step is superseded by rule 1). Related:
[[project_cntl_popup_close_vs_action_buttons]].
