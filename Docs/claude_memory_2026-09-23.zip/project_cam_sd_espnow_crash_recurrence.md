---
name: project-cam-sd-espnow-crash-recurrence
description: "OPEN, next up 2026-08-27: CAM's known SD-capture+ESP-NOW LoadProhibited panic/reboot (first found 2026-08-08, mitigated with 30min+ interval, reproduced again 2026-08-24) — user flagged it as the next thing to fix, deferred to the next session"
metadata:
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-26T14:27:58.846Z
---

During a long (4-minute, but device uptime was actually ~30 minutes at the crash point) live serial
capture on CAM (COM5), captured a real crash unrelated to the ESP-NOW pairing/sound investigation that
was the main focus of the session:

```
카메라 초기화 완료 (auto-capture kicked in)
캡처 저장: T000D.jpg (204387 bytes)
Guru Meditation Error: Core 0 panic'ed (LoadProhibited)
EXCVADDR: 0x00000414  (near-NULL pointer dereference)
Backtrace: 0x4038645e:0x3fcb9d30 0x40387aab:0x3fcb9db0 0x403856e6:0x3fcb9dd0 0x420b6bae:0x3fcb9e00
→ full reboot
```

This is the same class of bug documented in `project_cam_esp_now_production` / the 2026-08-08 session:
SD card capture (`camera_capture_one` → `cam_storage_save_capture`) racing with concurrent ESP-NOW
activity corrupts the heap → LoadProhibited panic. At the time, the root cause was not fixed — instead
CAM_CAPTURE_INTERVAL_MIN_SAFE_SEC was clamped to 1800s (30 min) as a mitigation ("그때까지는 실기로
오래 검증된 프로덕션 주기(30분+)만 허용"), on the belief that spacing captures out far enough made the
race rare enough to tolerate.

This crash reproduced again, right around the 30-minute mark, during today's (2026-08-24) session —
meaning the underlying race is still present, and the 30-minute spacing only reduces frequency, doesn't
eliminate it. Given PING now runs continuously forever even while paired (per today's design), and other
ESP-NOW traffic patterns have changed significantly since 2026-08-08, the actual collision probability
per auto-capture event may now be different (higher or lower) than originally measured.

**How to apply:** explicitly deferred by user ("이 버그는 기억했다가 나중에 고치기로 하고") — do not
start fixing this unprompted. When picked back up, the real fix is almost certainly serializing SD
access and ESP-NOW callback/task activity (a mutex around the SD read/write path that also excludes
concurrent ESP-NOW recv/send handling, or moving SD I/O off whatever task/core races with the WiFi
driver) rather than further interval tuning — interval tuning is exactly the kind of "manage the
timing instead of fixing the root cause" band-aid this session's user has been explicitly rejecting for
other bugs today (see [[feedback_nyquist_retry_span]] and the CNTL pairing redesign work same day).

**Re-flagged 2026-08-26**, right after the CASK protocol redesign was fully live-verified (see
[[project_cam_cntl_known_hub_direct_wake_protocol]] — all of it now working, including power-log
fields): user named this as the next thing to fix — "이제 주기적 사진 촬영에 의한 리셋만 잡으면
되겠네. 이건 내일 하자." (now we just need to catch the reset from periodic photo capture; let's do it
tomorrow) — i.e. explicitly the next session's starting task, still deferred, not started today. Worth
noting the ESP-NOW traffic pattern has changed significantly since this bug was last touched (2026-08-24
predates today's CASK redesign — WAKE_HELLO/CASK sequence replaces the old PING/PONG-plus-scattered-push
model entirely), so the actual collision timing/probability against SD capture may differ from prior
investigations; re-verify current behavior rather than assuming the 2026-08-24 capture/backtrace details
still apply exactly as-is.
