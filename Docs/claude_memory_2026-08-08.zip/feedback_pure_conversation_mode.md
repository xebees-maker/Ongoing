---
name: feedback-pure-conversation-mode
description: "when user says \"대화에 충실해/집중해\" or is laying out a multi-part plan, hold ALL tool calls (including read-only research) until they finish and ask for action"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e3f8c71a-ac79-4876-8f90-c89bb024de69
  modified: 2026-08-08T14:01:28.412Z
---

When the user says things like "대화에 충실해", "대화에 집중해", or "계획을 쭉 말할테니" (I'll lay out the plan in full) — this means stop ALL tool use, including read-only Read/Grep verification, not just edits/decisions. Just listen and respond in plain text until they've finished presenting and explicitly ask for something to be checked or done.

**Why:** Corrected twice in the same session (2026-08-08). The second time, a read-only Grep+Read done purely to verify my understanding of `rtc_sync.c` before responding was still flagged ("또 뭘 하고있네. 이건 학습이 안되나?" — frustrated, "doing it again, can't this be learned?"). This is stricter than [[feedback_confirm_before_editing]] (which is about not self-proposing edits) and [[feedback_confirm_understanding_before_acting]] (about not jumping to edits) — those still permit read-only investigation. This rule says: when explicitly told to just converse, don't even do read-only tool calls.

**How to apply:** During a stretch the user has marked as conversation-only (explicit phrase, or mid-way through them enumerating a numbered plan), respond using only what's already known from context — no Read/Grep/Bash, even to "make sure I understand correctly." If verification genuinely feels necessary, ask in plain text whether it's okay to go check, rather than silently calling a tool. Resume normal tool use once they explicitly ask for something to be implemented or checked.

**Explicit convention agreed 2026-08-08**: user asked for a standing on/off switch — when they open with "대화에 집중해" (focus on conversation), that starts a zero-tool-call stretch; it lasts until they say "진행해" (go ahead / proceed) or an equivalently explicit go-ahead. Don't infer an early exit from a technical-sounding question — wait for the actual go-ahead word.
