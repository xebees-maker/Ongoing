---
name: reference-cntl-cam-com-ports
description: "Which COM port maps to which board (Cntl vs CAM) when both are plugged in — volatile, re-verify each session"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-08-08T08:03:22.621Z
---

Current mapping (as of 2026-08-08, back on the original PC): **Cntl = COM18, CAM = COM5**, confirmed by the
user. (Other machine, 2026-08-05: Cntl=COM12, CAM=COM13. Earlier on this same PC, 2026-08-01: Cntl=COM18,
CAM=COM5 — same as now, but still re-confirmed rather than assumed.)

**Why this needs re-checking, not blind reuse:** the user explicitly warned this can change between sessions
("또 바뀔 수 있지만, 현재 session에서는 그대로야") — Windows reassigns COM numbers based on USB port/hub and
plug order, not board identity. Both boards enumerate identically (`USB Serial Device`, `VID_303A&PID_1001`,
ESP32-S3 USB-Serial-JTAG) — `esptool.py --port COMx chip_id` can't disambiguate them either since both projects
target the same chip ([[reference-espidf-manual-build-env]] confirms both are esp32s3).

**How to apply:** at the start of a session that needs to flash/monitor either board, list ports
(`Get-CimInstance -ClassName Win32_PnPEntity | Where-Object { $_.Name -match 'COM\d+' }`) and ask the user
to confirm which is which if more than one Espressif device shows up — don't assume this session's mapping
carries over. Once confirmed for the session, it's safe to reuse for subsequent commands in that same session.
