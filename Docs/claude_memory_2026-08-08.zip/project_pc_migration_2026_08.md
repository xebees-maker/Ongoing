---
name: project-pc-migration-2026-08
description: "RESOLVED 2026-08-08: round-trip PC migration complete — dev moved out 2026-08-03, back to this original PC 2026-08-08, git/memory both re-synced"
metadata:
  type: project
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-08-08T08:03:43.747Z
---

On 2026-08-03 the user moved their whole dev environment to a different PC and network mid-session
(interrupting an in-progress ESP-NOW chunk-transfer reliability investigation). Work continued there across
several sessions (2026-08-04, 2026-08-05), then on 2026-08-08 the user returned to this original PC. This
memory folder was re-synced from `Docs/claude_memory_2026-08-05.zip` (the last backup made on the other PC) —
all `.md` files were copied over, overwriting older versions here. `git pull --ff-only` brought `origin/main`
from `9c9603e` up to `483b954` (14 commits) with no local changes to reconcile (clean fast-forward).

**Why:** stated directly by user each time — round-trip between two PCs, git + a manually-zipped memory
backup were the sync mechanism (no automatic memory sync between machines).

**How to apply:**
- Full detail of everything done on the other PC (Selective Repeat chunk transfer, ESP-NOW reliability
  layers 0-2, multi-CAM selector UI, capture-now race fix, folder reorg promoting `cntl_incremental_test` →
  `Cntl` with old custom-BSP code preserved at `Cntl_old/`) is in `Docs/handoff_2026-08-04.md` and
  `Docs/handoff_2026-08-05.md` — read those before assuming anything about current Cntl/CAM state.
- Confirmed with the user on 2026-08-08: **COM ports** are Cntl=COM18, CAM=COM5 on this PC (see
  [[reference_cntl_cam_com_ports]] — still re-verify each future session, Windows can reassign). **CAM sensor**
  on this PC's board is OV5640, so `CAM/sdkconfig.defaults` was changed from `CONFIG_CAM_SENSOR_OV3660` (left
  over from the other PC's board) to `CONFIG_CAM_SENSOR_OV5640` — not yet committed as of this writing.
  Both Cntl and CAM still need a fresh build/flash on this PC (last binaries only existed on the other PC's
  `build/` dirs, not in git) — pairing will need to happen again after that.
- `Cntl_backup_20260730_224030/` (abandoned custom-BSP snapshot, 59MB mostly regenerable font binaries) is
  still untracked/local-only in this PC's working tree — never made it into git, low-value, was and is safe
  to ignore or delete.
- If a *third* migration happens later, repeat this pattern: commit+push everything, zip the memory folder
  to `Docs/`, write a dated handoff doc summarizing in-progress state and open questions.
