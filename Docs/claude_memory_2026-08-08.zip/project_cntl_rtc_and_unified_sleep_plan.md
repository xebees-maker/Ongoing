---
name: project-cntl-rtc-and-unified-sleep-plan
description: "2026-08-08 plan (for a following day) — RTC boot-time reliability fix + unifying CAM's power model with SENS's periodic-wake/deep-sleep pattern"
metadata: 
  node_type: memory
  type: project
  originSessionId: e3f8c71a-ac79-4876-8f90-c89bb024de69
  modified: 2026-08-08T14:17:26.483Z
---

Planning session 2026-08-08 (marked by the user as "tomorrow's work," not to be acted on same-day). Two items:

**1. RTC time reliability.** Cntl's `rtc_sync.c` seeds the PCF85063A RTC from build-compile-time if invalid, then advances it further if `/assets/time_sync.txt` (PC time written at flash time) is newer. Problem: this single flash-time injection can itself be wrong (PC clock wrong, or device never gets reflashed/reconnected to a PC again), with no way to correct it afterward. Live symptom observed twice: device boots showing an early-morning time (02:17 in one boot log vs compile-time 17:07; 02:37 in a later live check) — same suspicious pattern both times, suggesting a possible systematic bug (e.g. `gmtime_r` vs `mktime` timezone-handling mismatch between the two seed paths in `rtc_sync.c`), not just staleness. Needed: (a) investigate/fix the actual boot-time seeding bug, (b) a System-settings UI for manual time-set, (c) future internet time sync — UI to be designed/discussed before implementation.

**2. Unify CAM's power model with SENS's.** Trigger: CAM board runs very hot under current always-on/modem-sleep-only operation — real power problem, not cosmetic. User's core correction mid-discussion: don't treat CAM (assumed "must always respond instantly") and SENS (already periodic wake/deep-sleep) as fundamentally different — the "응답성"(responsiveness) system setting built earlier this session already encodes "instant response is not guaranteed," so CAM can adopt the same wake-do-task-sleep cycle as SENS, cycle length = the responsiveness interval. Extreme case explicitly accepted by the user: CAM can fully reset on each wake (re-associate WiFi/ESP-NOW etc. from scratch each cycle) — that's fine.

Approach ordering stated by user: try to make ESP-IDF's Automatic Light Sleep work first, but only if solid reference/prior-art justifies it (two prior attempts this session broke the USB-Serial-JTAG console — see [[project_cntl_cam_esp_now_reliability_layers]] history and Light Sleep abandonment). If no good reference exists, fall back to manually-controlled Deep Sleep.

Open problem flagged, unresolved: while a device is asleep, Cntl has no way to push a config change (e.g. a new wake interval) to it — the earliest it can land is the device's next scheduled wake, so worst case a setting change takes one full sleep cycle to take effect. No solution decided yet.

**Research done 2026-08-08** (assigned by user mid-session, "네가 할꺼는 Light sleep의 성공 사례, Deep sleep을 CNTL이 벗어나게 할 수 있는 방법을 찾는 것"):
- Light Sleep: Espressif's own docs confirm the USB-Serial-JTAG-goes-unresponsive symptom is documented/expected (APB+USB PHY clock gated during sleep). Official mitigation exists and was never tried: `CONFIG_USJ_NO_AUTO_LS_ON_CONNECTION` — blocks automatic light-sleep entry only while a host is actually connected to the console; costs extra power only during that connected window, free to sleep normally once unplugged (i.e. in real standalone/production operation). This reopens Option A as viable.
- Deep Sleep remote-wake: confirmed structurally impossible — ESP32 deep-sleep wake sources are only timer/ext0/ext1 GPIO/touch/ULP; WiFi/ESP-NOW radio is fully powered off, so Cntl cannot push a wake. Workaround (secondary always-listening RF chip like nRF24L01 wired to a wake GPIO) requires extra hardware, out of scope.
- User's reaction: accepted that a short enough responsiveness interval (e.g. 10s) makes periodic Deep Sleep wake functionally equivalent to remote wake, so true push-wake isn't actually required. Reframed the real concern as reliability, not latency: what if a bug causes a device to never wake from Deep Sleep again (RTC timer wake source misconfigured/not armed before sleep entry, etc.)?

**Next research item, explicitly deferred ("네가 찾아, 지금 말고" — you research it, but not now)**: how to guarantee Deep Sleep's RTC timer wake source is always reliably armed before entering sleep, so CAM/SENS can never get stuck permanently asleep from a software bug. Not started yet.

**Priority decision (user, 2026-08-08): "Light sleep으로 성공한다면 deep sleep은 안할꺼야."** Deep Sleep (and the whole CAM/SENS unified periodic-wake redesign) is a fallback only — try `CONFIG_USJ_NO_AUTO_LS_ON_CONNECTION` + Automatic Light Sleep first; if that proves stable, stop there and skip the Deep Sleep work entirely.

**How to apply:** Next session, resume by confirming these two items are still the priority before doing anything else — this was explicitly framed as a plan, not yet approved for implementation.
