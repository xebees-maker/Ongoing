---
name: reference-cam-speaker-event-table
description: "CAM's 13-event speaker diagnostic sound table (cam_speaker component) + console commands, multi-select solo — updated 2026-08-26, PING/PONG removed, CASK messages (WAKE_HELLO..SLEEP_NOW_ACK) added"
metadata:
  type: reference
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-25T23:29:30.960Z
---

CAM has an onboard-speaker (ES8311 codec + NS4150B amp) diagnostic tool, `CAM/components/cam_speaker/`,
ported from CAML on 2026-08-23, then redesigned same day (6->7 events, single-solo->multi-select) after
live testing showed the original scheme couldn't tell "channel scan" apart from "advertise send", and
"advertise" apart from "ping" once both were tuned to the same note. Plays one distinct tone per
tracked event so Deep Sleep timing can be audited by ear without a live serial connection (USB-Serial-
JTAG powers off during actual Deep Sleep, so logs alone can't show what happens right up to sleep entry).
**2026-08-25**: expanded 7->10 events, adding the pairing-handshake steps (ADVERTISE_ACK/PAIR_REQUESTED/
PAIR_ACK) so the full handshake — not just scan/advertise/ping — is audible; this is also what proved,
by ear, that PONG genuinely wasn't arriving (see [[project_cam_cntl_pairing_state_machine]] and
[[project_cam_cntl_ping_pong_redesign_proposal]]). **2026-08-25/26**: PING/PONG (events 9-10) removed
outright as part of the CASK protocol redesign (see [[project_cam_cntl_known_hub_direct_wake_protocol]])
— the whole standing heartbeat concept they served is gone, not replaced. Truncated back down to 8
events (clean truncation, no renumbering of 1-8 since 9-10 were the last two values). **2026-08-26**:
the actual CASK messages got their own sounds too — 5 new events (9-13) added for WAKE_HELLO through
SLEEP_NOW_ACK, dictated directly by the user (note+duration for each), bringing the total to 13.

**Event table** (`cam_speaker_event_t` in `cam_speaker.h`, console number = enum value + 1):

| # | Enum | Tone | Fires when |
|---|------|------|------------|
| 1 | SPK_EVT_POWERON_BATTERY | 도(C4) 1s | Fresh boot, reset reason = POWERON |
| 2 | SPK_EVT_POWERON_USB | 솔(G4) 1s | Fresh boot, reset reason = USB reconnect |
| 3 | SPK_EVT_SCAN_CHANNEL | 미(E4) 0.1s | Every channel hop during unpaired scan (~every 300ms) |
| 4 | SPK_EVT_SWEEP_DONE | 미(E4) 0.5s | Unpaired scan completes one full 13-channel wraparound |
| 5 | SPK_EVT_ADVERTISE_SENT | 솔(G4) 0.1s | Each ADVERTISE broadcast (fires right after SCAN_CHANNEL, same tick) |
| 6 | SPK_EVT_ADVERTISE_ACK | 시(B4) 0.2s | ADVERTISE_ACK received (channel sync confirmed) |
| 7 | SPK_EVT_PAIR_REQUESTED | 도(C4) 0.1s | PAIR_REQUEST received from CNTL |
| 8 | SPK_EVT_PAIR_ACK | 시(B4) 0.3s | PAIR_ACK sent back to CNTL |
| 9 | SPK_EVT_WAKE_HELLO | 미(E4) 0.1s | WAKE_HELLO sent (fast-path check-in, right before `esp_now_reliable_request()`) |
| 10 | SPK_EVT_WAKE_HELLO_ACK | 솔(G4) 0.2s | WAKE_HELLO_ACK confirmed (fast-path succeeded) |
| 11 | SPK_EVT_CAM_CONFIG | 레(D4) 0.1s | CAM_CONFIG_SET received |
| 12 | SPK_EVT_SLEEP_NOW | 파(F4) 0.1s | SLEEP_NOW received |
| 13 | SPK_EVT_SLEEP_NOW_ACK | 시(B4) 0.2s | SLEEP_NOW_ACK sent back to CNTL |

Note frequencies added for 11/12: 레(D4)=293.66Hz, 파(F4)=349.23Hz (`NOTE_RE`/`NOTE_FA` in
`cam_speaker.c`, same equal-tempered convention as the existing 도/미/솔/시 constants).

**Current default (2026-08-26, RTC_DATA_ATTR, persists until user changes it again):** `s_enabled=true`
(sound on by default, changed from the original off-by-default on 2026-08-24), `s_solo_mask=0x1FFC`
(events 3-13 all play, only the two POWERON tones 1-2 are muted — extended from `0xFC` when events
9-13 were added, following the same "everything except POWERON" default pattern as before) — set
directly in `cam_speaker.c` source (not via console) per established convention, so it survives even a
reflash (the RTC default itself was changed, not just a runtime console command).

**Console commands** (`dev_console.c`, `cmd_soundlog`):
- `soundlog on` / `soundlog off` — master enable; default changed to ON on 2026-08-24 (was OFF originally)
- `soundlog solo <N[,N...]>` — e.g. `soundlog solo 3,4,5` plays only those events, mutes the rest.
  Internally a bitmask (`cam_speaker_set_solo_mask`, bit = enum value 0-12, 13 events now), not a single
  int — added 2026-08-23 after the user asked to hear combinations ("소리를 여러개 지정할 수 있게 해")
  instead of only ever one event at a time.
- `soundlog solo off` — clear solo (mask=0), all enabled events play

**Persistence:** `s_enabled` and `s_solo_mask` are both `RTC_DATA_ATTR`, so they survive normal Deep
Sleep wake cycles (CAM fully reboots every cycle, but RTC slow memory persists) — but reset to default
(off / no solo) on a genuine hard reset: flashing via esptool's RTS-pin hard-reset, or a real EN/power-on
reset. So after every `python -m esptool ... write-flash`, `soundlog on` (+ solo, if wanted) has to be
re-sent via the console before sound plays again — expected, not a bug.

**Known gotchas found 2026-08-23 (both fixed):**
1. `cam_speaker_notify()` only enqueues — playback is async in `speaker_task`. If CAM enters Deep Sleep
   immediately after firing a hook, it can call `esp_deep_sleep_start()` before the speaker task ever
   drives the I2S/codec — sound gets queued but never audibly plays. Fixed by `cam_speaker_wait_idle()`,
   called right before `esp_deep_sleep_start()` in `cam_node.c` (bounded 2s cap, instant return if sound
   is off).
2. A channel-sync success arriving *mid-sweep* (CNTL responds before a full 13-channel wraparound) was
   initially treated as satisfying the "awake time = task done" gate the instant sync landed — before
   CNTL's PAIR_REQUEST retry burst (500ms cadence) had any chance to arrive. This let CAM sleep before
   pairing could ever complete, in some cases forever. Still being corrected as of this writing — see
   [[project_cntl_rtc_and_unified_sleep_plan]] for the live status; don't assume "sync succeeded" alone
   means "safe to sleep" without checking the current code.

**How to apply:** when debugging CAM Deep Sleep timing live, connect via a retry-loop serial script
(CAM's USB port disappears during actual sleep — see [[reference_pyserial_dtr_reset_bug]]), send
`soundlog on` + `soundlog solo <N,...>` for the events under investigation, re-send after every reflash.
For precise timing questions (not just "does X happen"), capture serial output with host-side wall-clock
timestamps per read chunk rather than comparing device-relative log timestamps across separate boot
cycles — device clocks reset to 0 each boot. **Never change `solo`/`on`/`off` state on your own
initiative** — even though it's "just a console command, not a code edit," the user has explicitly and
sharply corrected this multiple times same session; treat runtime device-state changes with the same
confirm-before-acting gate as code edits (see [[feedback_confirm_before_editing]]).
