---
name: project-cntl-xclk-preset-ui
description: "Cntl camera settings panel XCLK (pixel clock) preset dropdown — 5/10/20/24MHz, shipped and flashed 2026-08-21"
metadata: 
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-21T06:24:31.870Z
---

Added an XCLK preset dropdown (5/10/20/24 MHz) to Cntl's camera settings panel, following the same
Apply-button pattern as capture_interval/response_interval (not the AGC/AEC immediate-apply switch
pattern) — explicit user request: "CNTL 설정 패널에서 바꾸고 싶어서 그래. 5M / 10M / 20M / 24M".

**Why:** Diagnostic tool for tuning image quality/noise — XCLK affects sensor timing and was already
adjustable via CAM's dev_console `xclk` command at runtime, but the user wanted it reachable from
Cntl's UI like the other camera settings, without a full reflash each time.

**How it works:** New field `xclk_mhz` in `esp_now_cam_config_t` (esp_now_link.h), pushed via
`CAM_CONFIG_SET` on every pairing (same as agc_enable/aec_enable/capture_interval). CAM applies it
immediately via `sensor_t::set_xclk()` if the camera is already initialized this wake cycle, otherwise
it's used as the init value at next lazy `esp_camera_init()`. Cntl side: `device_config` getter/setter
(`device_config_get/set_xclk_mhz`), `esp_now_hub_apply_cam_xclk_mhz()`, and a UI row in
`ui_main.c`'s camera_group_box using the shared `config_apply_tick_fn`/`show_config_apply_popup`
ACK-confirmation infrastructure (`CONFIG_APPLY_TARGET_XCLK`).

**Status:** Both boards built clean and flashed 2026-08-21 (Cntl app-only @ COM18 offset 0x10000, CAM
full flash @ COM5). `DEVICE_CONFIG_VERSION` bumped 3→4 for this field — same fallback-to-default +
E5007 pattern as the earlier AGC/AEC version bump, see [[feedback_settings_as_files_not_nvs]] for the
persisted-settings-file convention this follows.

**Note:** CAM's COM5 was flaky during this flash (USB connection dropping in/out every ~1-2s,
confirmed by polling `Get-PnpDevice`) — needed 6 retry attempts before a flash succeeded and verified.
Not a code issue; likely a physical cable/connector problem worth checking if it recurs.
