---
name: feedback-thorough-investigation-before-large-refactor
description: "Confirmed approach 2026-09-08: for a large multi-function UI refactor, deep pre-implementation investigation + picking the lowest-risk technique produced a first-try working result"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-08T14:01:16.836Z
---

User confirmed ("잘 되네. 한번에 잘한건 처음 같은데?" — "works, this might be the first time you got it right in one shot") after the CNTL camera-panel-to-popup extraction landed correctly on the first build+flash, no follow-up fixes needed.

What made this one work, worth repeating on similarly large refactors:

1. **Investigated thoroughly before writing any code.** Before touching `ui_main.c`'s camera panel, grepped every call site of the ~15 camera-related widget statics, checked whether `on_photo_result_event`/`on_list_result_event` fire asynchronously regardless of UI state (they do — ESP-NOW driven), and checked whether a planned variable name (`s_camera_list`) already existed for a different purpose (it did — Settings tab's camera pairing list) before writing a single line. Caught a real naming collision that would have silently broken an unrelated existing feature.

2. **Checked a real hardware/architecture constraint before committing to a design.** Before adding "camera model display," traced whether CAM's camera sensor is initialized at pairing time — found it deliberately isn't (`cam_node.c:734`, lazy-init-on-capture for battery life), meaning PID is unknown when the pairing ACK is sent. Reported this concretely (not a guess) and let the user choose to skip that part rather than build something that couldn't work as first imagined.

3. **Picked the lowest-risk implementation technique for the codebase's actual shape, not the most "proper" one.** Stats/Settings/Log popups use a build-from-scratch/teardown pattern (cheap because they're pure display, no live async wiring). The camera panel's toolbar/list/preview have live ESP-NOW event callbacks wired to specific widget pointers. Rather than reproduce the destroy/recreate pattern (which would have required NULL-guarding ~15 functions against a popup-closed state), reused the *existing* live widgets and just `lv_obj_set_parent()`'d them into the popup on open and back on close — zero changes needed to any of the existing camera event-handling code.

**Why this matters:** the difference between this and prior rounds in the same session (which needed several correction cycles) was spending the up-front investigation time to find the collisions/constraints *before* writing code, then choosing the technique that minimized touched surface area, rather than defaulting to "match the pattern already used elsewhere" when that pattern doesn't fit the new case's actual dependencies.

**How to apply:** before a refactor that touches many call sites of existing statics/functions, grep every touch point first and check for (a) naming collisions with unrelated features, (b) async/event-driven code paths that don't follow the same lifecycle as the UI trigger, (c) hardware/protocol constraints that change the intended design. Then pick the technique (reparent/reuse vs. destroy/rebuild) that minimizes how much existing working code needs to change, even if it's less "clean" than mirroring a nearby pattern.
