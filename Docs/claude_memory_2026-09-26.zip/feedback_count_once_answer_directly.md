---
name: feedback-count-once-answer-directly
description: "When user says 세봐/카운트 세 (\"count it\"), capture exactly once and state the number directly and immediately — no repeated captures, no waiting to be asked again"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-23T07:58:15.279Z
---

When the user asks to count something via a live capture (e.g. "카운트 세봐" — count it), run exactly
ONE capture that stops as soon as it has the number, then state that number directly as the primary
content of the response — don't report a batch of repeated measurements, and don't just perform the
capture and wait for them to ask "how many?" as a separate follow-up.

**Why:** During CAM's live speaker-diagnostic session (2026-08-23), I first ran a capture script that
kept listening for 40+ seconds and collected 5 repeated counts ("14, 14, 14, 14, 14"), then summarized
it. User: "여러번 하지 말고 1번만 세" (don't do it multiple times, count once). I then ran another
capture but still just reported the result passively. User, sharper: "한번만 세고, 묻기전에 얼마라고 답해.
내가 세라고 하면" (count once, and state the number before I have to ask — whenever I say count). The
underlying complaint: repeated/batched measurements when one was asked for is noise, and making the
user ask "so what's the number?" after I already have it wastes a turn.

**How to apply:** for any "세봐"/"카운트" request — (1) write or reuse a capture script that exits the
moment it has ONE valid reading (see `scan_count_once.py` pattern: regex-match inside the read loop,
`raise SystemExit` the instant a match is found, not a fixed-duration window), (2) the very next message
back to the user leads with the number itself ("14입니다"), not a description of the capture process.
This generalizes beyond this specific SCAN_CHANNEL counter — applies to any live-hardware "how many/how
long/what value" measurement request during diagnostic sessions.
