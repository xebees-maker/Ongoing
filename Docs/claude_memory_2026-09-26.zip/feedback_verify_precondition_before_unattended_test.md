---
name: feedback-verify-precondition-before-unattended-test
description: "Before launching any unattended/background capture or long test, verify the system is actually in the state needed for it to produce data — don't assume"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 53810285-98f9-4ede-9939-9816c41aeab1
  modified: 2026-08-11T04:00:32.995Z
---

Before kicking off any unattended background test (serial capture, long-running monitor, etc.),
verify the precondition that makes it meaningful is actually true right now — don't assume it
carries over from earlier in the session.

**Why**: 2026-08-11, Cntl/CAM project. I launched a 3x20-minute (1-hour total) background serial
capture to diagnose a CAM/Cntl pairing log issue, timed to run while the user stepped away to eat.
It captured zero useful data for the entire hour. Root cause: pairing auto-reconnect
([[project_cntl_rtc_and_unified_sleep_plan]]'s `ever_paired` mechanism) only applies to nodes that
already paired successfully *within the current Cntl boot session* — it is pure RAM state, not
persisted. I had reflashed Cntl multiple times earlier in the same session (for unrelated fixes),
so by the time the background capture started, Cntl had no paired nodes. The very first pairing
after any reflash requires a **physical tap on Cntl's touchscreen** to approve — something I
cannot do remotely, and nobody was there to do it while the user was away. The whole hour was
therefore guaranteed to produce nothing, and I didn't check for that before starting it. The user
called this out directly: "캠을 네가 연결할 수도 없으면서 뭘 혼자 백그라운드 테스트 한다는 거냐고."

**How to apply**: before starting any long/unattended capture, do a short (~10-15s) foreground
smoke-test first and confirm real data is flowing (not just "the process ran without error").
If the test depends on some prerequisite state (a device being paired/connected, a service being
up, a file existing), explicitly verify that state is true *right now*, not "was true earlier this
session" — especially after any reset/reflash/restart happened in between. If a precondition
requires a physical/human action you can't perform (a screen tap, a button press), say so and ask
before scheduling unattended work around it — don't let a long background run mask a hard
dependency on user presence.
