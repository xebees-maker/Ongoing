---
name: feedback-pure-conversation-mode
description: "when user says \"대화에 충실해/집중해\" or is laying out a multi-part plan, hold ALL tool calls (including read-only research) until they finish and ask for action"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e3f8c71a-ac79-4876-8f90-c89bb024de69
  modified: 2026-09-21T14:06:57.629Z
---

When the user says things like "대화에 충실해", "대화에 집중해", or "계획을 쭉 말할테니" (I'll lay out the plan in full) — this means stop ALL tool use, including read-only Read/Grep verification, not just edits/decisions. Just listen and respond in plain text until they've finished presenting and explicitly ask for something to be checked or done.

**Why:** Corrected twice in the same session (2026-08-08). The second time, a read-only Grep+Read done purely to verify my understanding of `rtc_sync.c` before responding was still flagged ("또 뭘 하고있네. 이건 학습이 안되나?" — frustrated, "doing it again, can't this be learned?"). This is stricter than [[feedback_confirm_before_editing]] (which is about not self-proposing edits) and [[feedback_confirm_understanding_before_acting]] (about not jumping to edits) — those still permit read-only investigation. This rule says: when explicitly told to just converse, don't even do read-only tool calls.

**How to apply:** During a stretch the user has marked as conversation-only (explicit phrase, or mid-way through them enumerating a numbered plan), respond using only what's already known from context — no Read/Grep/Bash, even to "make sure I understand correctly." If verification genuinely feels necessary, ask in plain text whether it's okay to go check, rather than silently calling a tool. Resume normal tool use once they explicitly ask for something to be implemented or checked.

**Explicit convention agreed 2026-08-08**: user asked for a standing on/off switch — when they open with "대화에 집중해" (focus on conversation), that starts a zero-tool-call stretch; it lasts until they say "진행해" (go ahead / proceed) or an equivalently explicit go-ahead. Don't infer an early exit from a technical-sounding question — wait for the actual go-ahead word.

**2026-09-11 addition — the restriction is textual too, not just tool calls.** Mid-conversation (still "아직 대화 중이야", triggered by "들어봐" continuing into a multi-turn design discussion, not necessarily the literal phrase "대화에 집중해"), I asked "지금 같이 만들까요, 아니면 나중에 필요해지면 그때 추가할까요?" — offering to schedule/propose doing something. The user corrected: "내가 대화를 요청하면 뭐 하겠다고도 하지말고, 뭘 하지도 말고 대화에만 집중해." Even a pure-text scheduling question ("do it now or later?") is itself an action-oriented framing and violates conversation-only mode — not just literal tool calls. During conversation-only stretches, responses should only reflect/paraphrase understanding back, never propose a next step, timing, or "should I do X" framing, even rhetorically.

**The user's explicit stated end-to-end workflow** (repeated verbatim 2026-09-11, treat as the standing default for any non-trivial request): 대화 (user lays out the design, I listen/reflect only) → 요약해 (user explicitly asks for a summary) → I summarize → user confirms or corrects → 질문 있어? (user explicitly invites questions) → I ask real remaining questions only → user answers → 진행해 (explicit go-ahead) → only then do I act. Don't skip straight to a summary or a question unprompted — wait for the user to ask for each stage ("요약해", "질문 있어?") rather than volunteering it, per [[feedback_dont_unilaterally_defer_scope]]'s sibling principle of not deciding the process on your own.

**Scope of "진행해" clarified 2026-09-21**: one "진행해" said after a 요약해→질문해 cycle
approves *everything listed in that summary* at once — not just one line item. User: "요약한 걸
내가 진행해 라고 하면 다 승인한 거 아니야?" Don't ask for a second, per-item "진행해" for each
individual pending task once the batch as a whole has been summarized, questioned, and approved —
that defeats the purpose of the summary step. (Build/flash sequencing across the approved items
can still be one-at-a-time per [[feedback_change_one_variable_per_test]] — that's about test
isolation, not about needing repeated authorization.)

**Re-stated formally 2026-09-21** (during the CNTL I2C bridge design/implementation session,
[[project_cntl_i2c_bridge_design_2026_09_21]]): "지금까지도 이렇게 했고, 앞으로도 계속 이렇게
할꺼야. 1. 대화를 해 2. 요약해 3. 질문해 4. 진행해 알았니?" — same four-step cycle, now given as
a permanent numbered standing rule rather than a one-off instruction. This followed several
repeat violations in the SAME session: jumping into Edit calls right after the user's own detailed
technical requirements (not the literal trigger word), and separately misreading a message that
merely *started* with "그래" as an affirmative answer to "진행할까요?" when the rest of the
sentence was actually a rebuke ("이렇게 접근하면 10초만에 되는 걸 네가 시간 얼마나 끌었니?") —
see [[feedback_confirm_before_editing]] for that specific "그래/ㅇㅇ" failure mode. Lesson: detailed
requirements, corrections, or answers to sub-questions are not the same as "진행해" — even a long,
information-dense user message authorizes nothing by itself unless it contains the literal word.
