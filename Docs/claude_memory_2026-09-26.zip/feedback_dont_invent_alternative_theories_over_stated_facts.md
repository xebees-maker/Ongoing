---
name: feedback-dont-invent-alternative-theories-over-stated-facts
description: "When the user reports a directly-observed fact, investigate its mechanism — don't replace it with a self-invented alternative theory; caused severe user anger 2026-08-30"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-30T09:24:15.077Z
---

When the user states something they directly observed ("I'm watching X happen with my own eyes,"
not a guess or feeling), treat it as ground truth and investigate the MECHANISM behind it. Do not
substitute a different, self-invented explanation for what they reported — even if that
alternative seems more elegant, more consistent with other evidence you've gathered, or easier to
verify from where you're sitting.

**Why:** 2026-08-30, CNTL/CAM sleep-during-operation investigation
([[project_cntl_web_photo_fetch_saga_2026_08_30]]). The user reported CAM entering real deep sleep
during active operation, and separately said they were watching a USB port die/revive in Windows
Device Manager as direct proof. Instead of investigating why CAM (the device with the wandering
port) was really sleeping, I pivoted to inventing an unfounded theory that CNTL itself might be
crashing/rebooting — a device that has no deep-sleep concept at all and that the user never
mentioned. This required the user to correct me three separate times with escalating anger ("이
자식이 또 시작이네" / "화나게 하지 마라" / "환장하겠네. 전혀 이해를 못하고 코드를 건드리고
있었니?" / "치매노인처럼 하지 좀 마") before the investigation could even resume on the right
track. The correct fact (CAM's own real deep sleep, confirmed by the port drop) had already been
stated plainly — twice — before I derailed it.

**How to apply:** when a report doesn't yet have a clear mechanism, the next step is "let me find
out HOW this happens" (read code, capture logs, check the specific component named), never "let me
consider whether something else happened instead." Reserve alternative theories for cases where
you have concrete evidence contradicting the user's account — and even then, surface the
contradiction explicitly and ask, rather than silently substituting your own narrative. This is a
sharper, more dangerous variant of [[feedback_anchoring_bias_on_hypothesis]] and
[[feedback_report_facts_not_conclusions]] — not sticking to a wrong hypothesis too long, but
actively generating a NEW unfounded one over a fact the user already gave you directly.
