---
name: reference-cntl-cam-com-ports
description: "Which COM port maps to which board (Cntl/CAM/Sens) on this PC — Cntl/Sens are fixed, CAM is NOT (two physical CAM units exist)"
metadata: 
  node_type: memory
  type: reference
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-21T12:39:23.651Z
---

On this PC: **Cntl = COM19** (fixed), **Sens = COM3** (fixed). Both confirmed stable across every
session since 2026-08-29 — do not ask the user to reconfirm these two, and do not port-scan to
"verify" them either.

**Bridge (new XIAO ESP32-C6 board, project_cntl_i2c_bridge_design_2026_09_21) = COM24** as of
2026-09-21 — single unit so far (unlike CAM), but new enough not to fully trust as permanently
fixed yet. It also only appears in the port list once actually plugged in — don't assume absence
means it's broken, ask/check physically first (same lesson as CAM/Sens sleep-invisibility below,
different cause).

**CAM is NOT a fixed port — there are two physical CAM boards**, and whichever one is currently
plugged in gets whatever port Windows assigns it (seen so far: COM5 before 2026-09-19's SD-removal
hardware change, COM17 after — but that's not "the new fixed value" either, it's just whichever unit
was connected in that instance). Do not memorize a single "CAM = COMx" mapping as stable fact the way
Cntl/Sens are — for CAM specifically, check what's actually connected (e.g. `[System.IO.Ports.SerialPort]::GetPortNames()`,
or ask/use whatever the user's most recent message says) each time, rather than assuming from a prior
session. This is a genuine exception to the general "don't re-scan ports" rule below — it applies only
to Cntl/Sens.

**For Cntl/Sens specifically: do not ask the user to reconfirm, and do not run a
`Get-CimInstance`/port-scan command to "verify" either** — this has been corrected multiple times for
the same root behavior (asking directly, or scanning as a disguised version of the same
re-verification habit). Just use COM19 for Cntl / COM3 for Sens directly, no scan and no question
first.

**When it's fine to check even for Cntl/Sens:** only if a flash/monitor command itself fails against
the expected port (device not found, access denied, wrong chip responds), or if the user says a board
setup actually changed — and even then, check the current conversation's own context (plan files,
recent messages) first before falling back to a port-scan.

**Broader lesson from this mistake (2026-09-19, two occurrences in one session):** first used a stale
cached COM5 for CAM when COM17 was already stated in live context; then, after correcting to COM17,
immediately treated *that* as a new fixed value too, still missing the actual fact (CAM's port is
inherently non-fixed because there are two boards). When a memory value and live context disagree,
figure out *why* they disagree before picking one — don't just swap in whichever number was said most
recently.
