---
name: project-rs485-experimental-project
description: "C:\Projects\RS485 — separate experimental project validating RS485 link before applying it to Ongoing CNTL/CAM; CNTL RX-never-works bug RESOLVED 2026-08-28 (console Kconfig channel), CNTL-CNTL raw-byte harness 'batched RX' bug also RESOLVED 2026-08-28 (uart_read_bytes length=1, see [[reference_espidf_uart_read_bytes_blocking]])"
metadata:
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-28T01:00:00.000Z
---

`C:\Projects\RS485` is a sibling project to `C:\Projects\Ongoing`, created 2026-08-27 to validate
RS485 as a communication link (protocol + hardware) before committing to using it as the fix for
Ongoing CNTL↔CAM's steel-obstruction WiFi problem (see [[project_cntl_cam_steel_obstruction_relay]]).
It is deliberately kept separate from Ongoing — no shared code, no shared build.

**Why:** the real production change is gated behind a separate, explicit future authorization (the
[["시작해"-only gate]] in [[feedback_confirm_before_editing]]) — this project exists purely to prove
the RS485 link works on real hardware first.

**Full design/status doc — always check this first, it's the actual source of truth:**
`C:\Projects\RS485\Docs\design.md`. It's kept current after every meaningful change specifically so
a session-loss doesn't lose progress; re-read it before assuming any status claim in this memory is
still accurate.

**Structure:** 콘(CNTL, spare Waveshare 4.3B, COM19) ↔ RS485 ↔ 변(RS485-TTL module) ↔ UART ↔
중(Arbiter, Waveshare ESP32-S3-Touch-LCD-1.47, COM4). Shared components in
`Common/components/rs485_link` (framing protocol) and `rs485_ui` (checkbox/list/text sync UI).

**Status as of 2026-08-28:** CNTL flashes/boots clean and stable. Arbiter's display is stable, but
touch is **intermittent, not resolved** — it works for a while, then goes unresponsive, then
sometimes works again, with no code change in between some of those transitions. A real bug was
found and fixed (`touch_axs5106_i2c_read()` was discarding the write-transaction's return value,
masking failures), and I2C speed was dropped to 100kHz, but the user explicitly said not to
generalize a single good test window as "fixed" — the on/off pattern continued after that fix too.
User's directive: stop proactively testing; wait for the user to report the next hang before
re-diagnosing. See [[feedback_audit_own_change_first]]'s 2026-08-28 entry for a costly
touch-debugging detour on the Arbiter side (real root-cause fixes applied, but stability still
unconfirmed) — the working touch config (polling mode + two-step I2C read, both return values now
checked, in `esp_lcd_touch_axs5106.c`) is fragile-looking vendor code; don't
"clean it up" without re-testing on hardware.

**How to apply:** before doing anything else in this project, read `Docs/design.md` in full. Don't
trust this memory's status line once it's more than a few days old — the doc is updated far more
frequently than this memory will be.

**Console-log-into-RS485-RX leak — practically resolved 2026-08-28, root mechanism still unknown.**
Arbiter's console log output was somehow arriving as phantom bytes on RS485 UART1's RX (GPIO10)
even with nothing connected. Ruled out via code/register inspection: GPIO43/44-to-10/11 code link,
shared UART0/UART1 registers, missing console Kconfig option. Isolated via a custom
`esp_log_set_vprintf()` override that routes UART0 and USB-Serial-JTAG independently: **UART0
output alone reproduces the leak; USB-Serial-JTAG output alone (UART0 off) is completely clean.**
Root cause (why UART0 TX activity affects a fully separate UART1 RX register block) was never
found — per [[feedback_no_hardware_blame_cntl_arbiter]] this investigation stayed entirely in
software/register space and still came up empty. User's pragmatic call: since this board is a
throwaway RS485 validation rig (will be replaced later), adopt the working combination (UART0
physical output off, console only via USB-Serial-JTAG) as final rather than keep chasing root
cause. Full detail in `Docs/design.md`'s dedicated section — read that before touching this area
again. **Conditional reopen (user, 2026-08-28): if this same UART0-output-leaks-into-a-separate-
UART's-RX phenomenon shows up again on the actual board that eventually gets deployed for real
(not this throwaway Arbiter rig), commit to digging into the UART0 root cause properly at that
point — the "don't chase root cause" call was specific to this board's disposable/prototype status,
not a permanent close on the question.**

**CNTL "RX never works" bug — RESOLVED 2026-08-28.** Separate from the above: 콘(CNTL) could always
TX successfully (confirmed via log + peer receiving it) but never received a single byte on RX,
reproduced across two independent physical CNTL units wired directly together (변/Arbiter not
involved), immune to ~10 tested fixes (pin pull-ups both ways, RXD line-inversion, baud rate
9600/115200, `uart_read_bytes` timeout 20ms/1000ms, task priority, GND connection, RS485 termination
resistor switch, manually replicating v5.5.2's exact `gpio_input_enable()`+
`esp_rom_gpio_connect_in_signal()` pin-setup calls). **Actual fix: match Waveshare's own
`examples/ESP-IDF/02_RS485_Test/sdkconfig.defaults` console Kconfig exactly —
`CONFIG_ESP_CONSOLE_USB_SERIAL_JTAG=y`, i.e. primary console channel = USB-Serial-JTAG only, not
this project's default of primary=UART0 + secondary=USB-JTAG.** Confirmed working via direct
CNTL-to-CNTL RS485 link (valid SYNC-byte frame received and checksummed correctly, byte-for-byte
matching what the other unit sent). Waveshare's own FAQ (docs.waveshare.com/ESP32-S3-Touch-LCD-4.3B/FAQ)
documents this exact symptom ("RS485_Test example can only send data but cannot receive") as an
"IDF version problem," recommending IDF v5.5.2 — this project stayed on v6.0.2 and found the console
Kconfig match resolves it without downgrading. See [[feedback_diff_config_not_just_source]] for the
methodology lesson (a source-only diff against the vendor example missed this; only the
sdkconfig.defaults diff caught it). Root *mechanism* (why UART0-as-primary-console specifically
breaks a *different* UART's RX capability) still not understood — this is a confirmed *workaround*,
not a root-cause explanation.

**콘-콘 직결, raw 카운터 harness "받는 쪽 값 뭉쳐서 나옴" — RESOLVED 2026-08-28.** 콘의
`uart_rx_task()`가 `uart_read_bytes(buf, 64, 1000ms)`로 호출하고 있었는데, 원인 규명 후
`length`를 1로 바꿔서 해결(도착 즉시 리턴). 근본 메커니즘은 이번엔 확인됨 — 일반적인
ESP-IDF gotcha라 [[reference_espidf_uart_read_bytes_blocking]]에 별도 기록. TX/RX 텍스트창도
좌우로 분리(각각 라벨+누적표시). 사용자 확인: "이제야 정상이군" → "아주 정상이야". 콘 2대
(COM19/COM18) 반영·검증 완료. 중(Arbiter)은 아직 동일 수정 미반영(현재 시험 범위가 콘-콘이라
보류) — 변/중 포함한 3자 구성 재개 시 먼저 적용할 것.

**중(Arbiter) code is a reusable test rig, not RS485-only** (user's explicit instruction, 2026-08-28:
"이 코드는 앞으로도 테스트 할 때 사용 가능하니까, 잘 기억해 둬"). `C:\Projects\RS485\Arbiter` is now a
hardware-verified, working bring-up (SPI display via `esp_lcd_jd9853` + I2C touch via
`esp_lcd_touch_axs5106`, both vendored locally under `Arbiter/components/`, wired through
`esp_lv_adapter`'s SPI profile) for the Waveshare ESP32-S3-Touch-LCD-1.47 board specifically. Treat
this as a general-purpose starting point for *any* future test/experiment that needs a small
touchscreen ESP32-S3 board — not something scoped only to the RS485 project. When a future task
calls for exactly that kind of rig, point to this code first instead of re-deriving pin mappings or
bring-up sequence from scratch (the 1st-folder manufacturer demo zip and the pin/gap/touch-mode
findings that made this work are already captured above and in `Docs/design.md`).
