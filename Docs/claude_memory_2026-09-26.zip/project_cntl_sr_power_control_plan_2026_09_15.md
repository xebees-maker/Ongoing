---
name: cntl-sr-power-control-plan
description: "CNTL SR(relay) threshold/hysteresis control — designed 2026-09-15, FIRST IMPLEMENTATION shipped+HW-verified 2026-09-16 (power_relay.c/.h, main-screen panel, config popup); popup UX redesigned same day (sentence-skeleton + AI toggle), several follow-up refinements queued for 2026-09-17"
metadata: 
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-16T15:02:33.289Z
---

Design-only conversation 2026-09-15 (no code written yet) for adding SR (relay) output control to CNTL — user said "내일은 SR을 붙일꺼야" the day after this was discussed, so implementation is a near-term next session, not this one.

**Why:** user wants CNTL to automatically switch physical relays (heater, AC, etc.) on/off based on sensor thresholds, instead of manual control.

**Decided design, from direct Q&A this session:**
- **SR count**: user wants up to 3, but CNTL's GPIO/enclosure port budget likely only allows 2 (matches existing [[project_cntl_physical_relay_output]] constraint) — start with 2.
- **Channel mapping is per-SR, not per-measurement-type**: the same source channel (e.g. temp) can drive two DIFFERENT SRs with opposite direction/thresholds simultaneously — e.g. a heater SR (On below a low threshold, Off above it) and an AC SR (On above a high threshold, Off below it) both watching temperature. So each SR independently configures its own source + direction + thresholds; it's not "one SR per channel type."
- **Direction is user-configurable per SR**: On-above-threshold or On-below-threshold, not a fixed convention.
- **Source value is user-configurable per SR**, and richer than first assumed: either (a) a group+precision series (e.g. Air-Fine temp, matching the [[project_cntl_stats_graph_redesign_2026_09_10]] site/precision classification) with a selectable statistic (avg/max/min), OR (b) one specific individual device's live/raw value — not just group blends.
- **Hysteresis + minimum hold time + trend**: On/Off threshold pair alone isn't enough (chattering at the boundary) — needs a minimum on/off hold time too, AND the user wants recent trend (rate of change) to factor into the decision ("fuzzy" — his word, likely meaning trend-aware, not literal fuzzy-logic control). Exact trend algorithm not designed yet — to be worked out during implementation.
- **Stale-source handling**: if the source sensor has been silent longer than the SR's own normal operating cadence, stop (force Off) — a brief/transient gap should NOT immediately stop it. Conceptually similar to the existing adaptive per-node timeout (`esp_now_hub_node_timeout_ms()`). User floated a possible future extension (2nd/3rd priority fallback source sensors) but explicitly deferred that as optional complexity, not needed now.
- **Alias**: SR channels get a user-assignable Alias, same pattern as Sens/CAM devices (`device_config_get_alias`).
- **New "Power control" panel** in Settings, holding the SR configuration UI (per-SR: alias, source, statistic, thresholds, direction).
- **Settings panel reordering**: during active SR development, temporarily reorder to Power-System-Camera-CNTL (Power first, for dev convenience); once SR work is done, reorder back to System-Power-Camera-CNTL (the "real" final order).
- **CNTL group box also gets Log nested into it** at the same time (button to view Log, in-place content swap — same pattern the earlier majestic-churning-pancake.md plan already specified for Settings/Log).
- **Staged hardware rollout**: before wiring any physical relay, show the software's computed SR On/Off decision on the main-screen Summary panel first, and verify the decision logic behaves correctly purely in software. Only after that's confirmed, wire the physical SR and verify the real relay follows the displayed state.
- **Open/undecided**: whether SR should get its own dedicated row/panel on the main screen (like Sensor/Camera panels each have), separate from just a value shown in Summary — user was still "고민 중" (undecided) on this, not resolved.
- **Scope for the next session**: primarily software — data model, Power control panel UI, threshold+hysteresis+trend logic, main-screen indicator. Physical GPIO wiring is explicitly optional/time-permitting ("물리 배선할 시간이 될 지 모르겠어"), not committed scope.

**Update 2026-09-16 — implemented, then substantially UX-redesigned same day. Read this section
before touching this feature again; it supersedes parts of the plan above.**

- **Main-screen row question resolved: YES.** New "Power Control" panel added on the main
  screen between Summary and Sensor, fixed 2 rows (Relay 1/Relay 2 + Alias), same tap-row-to-
  open-popup UX as Sensor/Camera. The earlier "Settings > Power control group box" plan was
  explicitly dropped by the user ("어제가 틀렸어... 캠이나 센스처럼 UX를 주려고 해") — no
  Settings-panel reordering work was ever done, that part of the original plan is moot.
- **Data model built**: `Cntl/main/power_relay.h/.c` — `power_relay_config_t` per relay (alias,
  ai_mode, source_kind/group/precise/stat/device_mac/chan_type, direction, on_threshold/
  off_threshold, min_hold_sec, trend_enable, trend_window_sec), file-backed persistence
  (`power_relay.bin`), GPIO driver (pins still placeholder `GPIO_NUM_NC` — real pins not yet
  chosen, physical wiring never happened 2026-09-16 as anticipated), 15s-interval FreeRTOS
  control task (priority 15, the reserved "SR제어" slot). Trend algorithm implemented as
  designed: `on_eval = max/min(raw, predicted)` (never suppresses a genuine raw crossing),
  `off_eval = predicted` (extends hold when trend still favors on, shortens when trend agrees
  with going off) — `predicted = raw + slope*window`, window and lookahead unified into one
  field (`trend_window_sec`, "본 만큼만 내다본다").
- **Popup redesigned mid-session** after user feedback "공학 관점에선 좋은데 사용자 관점에선
  너무 쓰기 힘들어" — abandoned the flat list of 9 labeled fields for a sentence-skeleton +
  "AI" toggle: "(Channel▾)(Rises/Falls▾) → (Turns On/Off▾)" plus Center/Margin threshold
  fields, with an AI On/Off switch that hides/shows the advanced fields (Based on Group/
  Device, group-choice Air-Basic/Air-Fine/Agar, stat, trend, min-hold) — AI On auto-fills them
  with smart defaults (precision-if-available, group=channel-derived, avg, trend on) when
  Apply is pressed. **This redesign is itself still mid-flight** — see the 2026-09-17 to-do
  list in [[project_cntl_signal_color_active_window_2026_09_15]]'s sibling handoff doc
  (Docs/한일_2026-09-16.txt) for the finalized wording ("Turn On if Temperature Up to [30.0]
  +/- [2.0] C", no "Center:"/"Margin:" labels) and layout (one-line Based-on row, roller
  controls instead of textareas, gray panel + top-right Apply) that were AGREED but NOT YET
  CODED as of end of day 2026-09-16.
- **Real crash found+fixed on real hardware** (Guru Meditation InstrFetchProhibited, reproducible
  reboot loop): `power_relay_set_config()` unconditionally setting `configured=true` regardless
  of caller meant the Alias-only Apply path activated an otherwise-blank (chan_type=NONE)
  config into the live control loop. Fixed by moving `configured=true` to the caller
  (full-settings Apply only) plus a defensive `chan_type==SENSOR_CHAN_NONE` skip in
  `evaluate_relay()`. Also fixed: the control task's 8192B stack was allocated from internal
  RAM by plain `xTaskCreate` (measured cost when moved to `xTaskCreateStatic`+PSRAM: 0 bytes,
  vs the internal-RAM version that drove free RAM down to ~35-40K) — see
  [[feedback_lvgl_dropdown_default_width]] for the separate dropdown-arrow-overlap lesson from
  the same debugging pass.
- **Not yet done, explicitly queued for next session** (full list in Docs/한일_2026-09-16.txt):
  trend window → measurement-count based instead of wall-clock seconds (current design can see
  zero samples in the window if the sensor's own report interval is longer than the window);
  Center/Margin/other numeric entry → `lv_roller` instead of textarea (temp/humidity 1 decimal,
  CO2 integer 4-digit), optionally popped up on tap rather than always inline; one-line
  Based-on+choice+stat row with no "Statistic:" label; disable Trend-window field when Trend
  switch is off; finalize the sentence wording as above; Apply button needs change-detection
  (currently always enabled regardless of whether anything changed) and should move to the
  top-right of a light-gray panel that visually groups everything it applies to (Turn On/Off
  through the last field); main-screen Power Control panel rows should show a condensed summary
  of each relay's configured rule (same idea as the Sensor panel's per-device T/H/C/A values) —
  specifically the sentence up through "Up to [value]", excluding the margin.

**How to apply:** when resuming this feature, read the 2026-09-16 update above first — the
popup's field layout described in the original 2026-09-15 section below is superseded by the
sentence-skeleton design. The 2026-09-15 decisions about SR count/direction/source-richness/
stale-handling/alias are all still valid and already implemented; don't re-ask them.
