---
name: project-cntl-web-full-ui-injection-design-2026-09-04
description: "2026-09-04 design session refining '웹기생' to literal PC-remote-control-style UI event injection; scoped to redoing connect/disconnect+list-fetch+photo-fetch (already-built web features), not new features"
metadata:
  type: project
  originSessionId: (new session, follow-up to b17b2f51-3975-463b-a8ec-56dde400e638)
  modified: 2026-09-05T02:39:22.897Z
---

Follow-up design session to the deferred to-do in
[[project_cntl_web_photo_fetch_saga_2026_08_30]] (redo MVC properly; apply "웹기생" to every
web-controllable action, not just photo-fetch). Before implementing, the user asked to re-examine
whether "웹기생" itself was even the right approach — this memory captures where that landed.

## Refined principle: literal UI-event injection ("PC 원격제어처럼")

Considered and rejected a command-queue refinement (web pushes commands to a FreeRTOS queue
instead of a shared mutable "selected" variable) — rejected because the precondition "웹과 앱이
동시 작업하지 않아" (web and on-device are never used concurrently) means the race the queue would
prevent can't actually happen; it would have been unneeded complexity.

The principle actually adopted, extending "웹기생" to its full/literal form: **web input should
synthesize the exact same LVGL UI event sequence a physical touch would** (tap the row → the
resulting popup appears → tap its confirm button), rather than the web handler calling underlying
functions (`esp_now_hub_request_pair`, `esp_now_photo_list_request`, etc.) directly. If reaching
the target widget requires a different on-device tab to be active, the web action switches that
tab too — the user was explicit about this ("탭도 바꿔야지 사용자 입력처럼 만들어서 발생시켜야지"),
including the visible side-effect on CNTL's own screen.

**Why this is better, not just more "pure":** both real bugs from the 2026-08-30 saga (duplicate
list-request, the "할일없음" regression) came from the web REIMPLEMENTING logic in a parallel path
that drifted from the on-device original. Full UI injection removes the possibility of that drift
by construction — there is only one code path (the on-device one), and the web just drives it. This
was the user's own stated goal in raising the question: "타당성을 묻는 거야. 개발 분량보다도, 꼬이는
상황을 막고 싶은 건데" (asking about feasibility — more than dev effort, I want to prevent things
from getting tangled).

## Failure handling

Synthesizing a multi-step sequence (row-tap → popup → confirm-tap) has no network round-trip
between steps — popup creation is synchronous LVGL work. So each step's target widget either
exists right after the previous synthetic event fires, or it doesn't:
1. Fire synthetic tap on the target row. Not found → fail immediately ("that device isn't in the
   current list" — it can genuinely disappear between when the web decided to act and when the
   synthetic event fires).
2. Found → in the same pass, look for the resulting popup's confirm button, fire a synthetic tap
   on it. Not found → fail immediately (should be rare).
3. Only past this point does the REAL async part begin — waiting for the actual network result
   (pairing success/fail, list arrived, photo arrived) — reuse the existing non-destructive
   cache/generation-counter polling pattern from the 2026-08-30 fix (up to 25s), not a
   consume-once ack flag.

## Messaging: reuse ui_strings, don't hand-write web text

Web-displayed progress/success/error text must come from the same `ui_str()` table CNTL's own
screen uses for the equivalent state — never hardcoded separately in the web's JS/HTML (this is
the web-specific extension of [[feedback_ui_strings_i18n_hardcode]]). Concretely: server-side
handlers resolve `ui_str(...)` and embed the already-translated string in the JSON response; the
web JS only renders what the server sent, never invents its own wording. This keeps on-device and
web wording from drifting apart, and future ui_strings edits automatically apply to web too.

## Status

Implemented and shipped 2026-09-04 (RSSI signal bars too, same session). Rollout on 2026-09-05
surfaced 3 regressions from the event-driven rebuild — see [[project_cntl_cam_wake_hello_no_mem_desync]]
for the fixes (popup self-consumption race, wait_cached per-file_id bug). User-confirmed working
after ~10 test rounds as of 2026-09-05.

## Scope for this session (explicit)

**Not** the full SPA — that stays deferred to "모든 기능 완료 후" per the standing plan in
[[project_cntl_web_spa_plan]]. This session is scoped to converting the three ALREADY-BUILT web
features to the injection+ui_strings principles above — no new web features:
1. 연결/끊기 (device connect/disconnect)
2. 목록 가져오기 (photo list fetch)
3. 사진가져오기 (single photo fetch)
