---
name: feedback-default-to-reliable-messaging
description: "Standing rule for CAM/Sens<->Cntl protocol design: every status/handshake message defaults to the reliable (ACK+retry) stack unless there's a concrete technical reason it can't be"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-21T08:12:35.729Z
---

For any new CAM/Sens<->Cntl protocol message, default to sending it through the reliable stack
(`esp_now_reliable_request`/`esp_now_tx_enqueue`, ACK + retry) rather than a raw fire-and-forget
`esp_now_send()`. Only make an exception when there's a concrete technical constraint that prevents
it (e.g., sending from inside `recv_cb` — the ESP-NOW driver's receive callback context — where
blocking on an ACK-wait would stall the WiFi task).

**Why:** Stated explicitly 2026-08-21 while designing a multi-stage capture-now handshake
(RECEIVED -> [INIT_NEEDED -> INIT_DONE] -> CAPTURING -> SUCCESS/FAILED): "특별한 경우가 아니면 모두
reliable이야" (unless it's a special case, everything should be reliable). This generalizes what had
already been happening piecemeal this session — SET_TIME was converted from raw send to reliable
earlier the same day specifically because raw fire-and-forget messages have no delivery guarantee,
and every "silently dropped status message" bug found this session (delete-all's missing
RECEIVED/WAIT_DONE split, the NACK-round off-by-one, this capture-status handshake gap) traces back
to a step that had no real confirmation that the peer actually got the message.

**How to apply:** When adding a new CAM/Sens->Cntl or Cntl->CAM message that represents a state
transition either side needs to react to, wrap it in the reliable stack by default. Only fall back to
raw `esp_now_send()` when the call site is in a context that cannot block (recv_cb) — and when doing
so, document the specific reason in a comment, the same way `CAPTURE_STATUS(RECEIVED)` is deliberately
fire-and-forget from `recv_cb` (esp_now_cam.c) to avoid stalling the WiFi driver task while the
dedicated request-processing task hasn't dequeued the request yet. See
[[feedback_cntl_owns_mutually_judged_values]] for the related rule about which numeric protocol
constants CNTL must own vs. leave local to one side.
