---
name: reference-schematic-documents-folder
description: "Where hardware schematic PDFs live on disk (C:\projects\documents\) so they don't need re-uploading every session"
metadata:
  type: reference
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-22T12:00:00.000Z
---

User saves board schematic PDFs to `C:\projects\documents\` (not inside any project repo). As of
2026-09-22 this holds `ESP32-S3-Touch-LCD-4.3B-Sch.pdf` (CNTL) and
`XIAO-ESP32-C6_v1.0_SCH_PDF_24028.pdf` (Bridge board). Check here first before asking the user to
paste a schematic again — a file may already exist. `Sens/hardware/` inside the repo is a
separate, older convention for Sens's own schematic only.

**Why this exists**: Claude cannot persist a pasted-in-chat PDF/image's raw bytes to disk — this
was hit repeatedly (documented in
[[project_cntl_i2c_bridge_design_2026_09_21]]) before the user got frustrated at re-uploading the
same files every session and picked this folder as the fixed save location.

**Reading these files**: Claude's `Read` tool needs `pdftoppm` (poppler-utils) installed to render
PDF pages. Installed 2026-09-22 via `winget install --id oschwartz10612.Poppler`, but the
already-running session's PATH didn't pick it up until a session/PC restart — if `Read` on a PDF
in this folder still errors with "pdftoppm is not installed", that's a stale-PATH symptom, not a
missing install; a restart should fix it, not a reinstall.

**How to apply**: when a hardware/electrical question comes up for CNTL, Bridge, or any board with
a schematic, check this folder via `Read` before asking the user to paste it into chat again.
