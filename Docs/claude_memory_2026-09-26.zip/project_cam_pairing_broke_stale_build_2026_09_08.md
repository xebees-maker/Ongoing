---
name: project-cam-pairing-broke-stale-build-2026-09-08
description: "RESOLVED 2026-09-08: CAM (COM5) stopped pairing/connecting because Common/esp_now_link.h's shared esp_now_pair_ack_t struct grew during the Sens CASK port and CAM's flashed binary predated that change"
metadata: 
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-08T13:44:38.129Z
---

CAM (COM5) stopped connecting/pairing to Cntl. Root cause: `Common/components/esp_now_link/include/esp_now_link.h`'s `esp_now_pair_ack_t` struct — shared between CAM and Sens — grew by 3 fields (`sensor_kind`/`chan_count`/`chan_type[]`) in commit `da83afe` (2026-09-05 21:00:41, the Sens CASK port). `Cntl/main/esp_now_hub.c:441` has `if (len < sizeof(esp_now_pair_ack_t)) return;` — a strict minimum-length gate on the pairing ACK. CAM's flashed binary (`CAM/build/cam-node.bin`, built 2026-09-05 20:52:00 — 8 minutes *before* the struct change) was still sending the old, smaller struct, so Cntl silently dropped every PAIR_ACK from CAM.

CAM's source itself needed no fix — `esp_now_cam.c:1177` already builds the ack via `esp_now_pair_ack_t ack = { .version=..., .msg_type=... }` (unlisted fields zero-init) and sends `sizeof(ack)` dynamically, so a plain rebuild+reflash automatically picked up the new larger struct with the new fields zero-filled. Fix was rebuild (`ninja -C CAM/build`) + flash app partition only (`0x10000`) to COM5 — no code change.

**Diagnostic technique used (worth reusing):** compared the build artifact's file mtime (`CAM/build/cam-node.bin`) against the git commit date of the shared-header change (`git log -1 --format=%ci <commit> -- Common/...`). The binary predating the header change by minutes was the smoking gun — confirmed the board was running stale code without needing a hardware/serial round first, in line with [[feedback_dont_use_user_as_test_oracle]].

**Why this matters / how to apply:** any time a struct in `Common/` (shared by Cntl/CAM/Sens) changes size or layout, **every board that includes that header needs a rebuild+reflash**, not just the board actively being worked on — a partial rebuild silently breaks the boards left behind, and the failure mode (pairing/connect just stops working, no crash, no obvious log) looks like a protocol or hardware bug rather than a stale-binary issue. When a board mysteriously stops connecting after unrelated work elsewhere in the repo, check whether a `Common/` shared header changed recently and whether that board's last build predates it, before assuming a logic bug.
