---
name: project-cntl-connection-mgmt-main-screen-2026-09-09
description: "IMPLEMENTED (unverified on-device) 2026-09-09: moved CAM/Sens connect/disconnect from Settings to main-screen panels, added Alias + auto-connect + per-device settings popup + Summary live-values redesign"
metadata: 
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-08T15:09:10.495Z
---

Overnight session (user went to sleep, said "묻지 말고 할 수 있는 건 다 해놔" — do whatever can
be done without asking) implemented a large, fully-designed feature set for `Cntl/main/ui_main.c`
(+`device_config.c/.h`, `esp_now_hub.c`, `ui_strings.c/.h`). Committed as `a1ac639` on
`cntl-tabs-lazy-construct` (pushed). **Builds clean, boots clean on hardware (verified via serial
log — no panic, no crash-loop, heap steady ~88KB), but the interactive UI itself (popups, new
lists, toggles) has NOT been tapped/verified on the touchscreen yet** — that needs the user.

**What changed (design came from an extended back-and-forth with the user same session, not my
own invention):**

1. **Sensor/Camera main-screen panels** each now show two lists instead of Settings owning
   connection management: **연결됨(Connected)** — name/Alias + status + signal + battery, and for
   Sensor only, the per-device measure interval — and **대기중(Pending)** — discovered-but-unpaired,
   tap to confirm (reuses the existing pair-confirm popup unchanged). Settings' old
   `sensor_group_box`/`camera_group_box` connection lists are gone entirely (group box removed for
   sensor; camera keeps AGC/AEC/XCLK/capture-interval as *shared* settings — user confirmed camera
   capture interval is also common across units, not per-device, unlike Sens measure interval).

2. **Per-device settings popup** (`build_device_popup()`/`teardown_device_popup()`) — tapping a
   Connected row opens it: Alias text field (+ on-screen keyboard, new pattern for this app,
   mirrors the existing WiFi-password textarea+keyboard), measure-interval editor (Sens only,
   literally relocated the old Settings widgets/callbacks unchanged), and a disconnect button that
   goes through the existing confirm-popup flow. This replaces the old row-tap-always-shows-
   unpair-confirm behavior that the user identified as broken ("지금도 안되잖아" — picking a
   different device to configure was never actually usable once >1 device existed).

3. **Alias** — new persisted per-MAC display name (`device_config_get/set_alias`,
   `DEVICE_CONFIG_ALIAS_MAX_LEN=32`), mirrors the existing `sens_interval` MAC-keyed slot-array
   pattern (8 slots). The same slot's mere existence also marks a MAC as "previously known"
   (`device_config_is_known_device`/`device_config_mark_known_device`, called from
   `esp_now_hub.c`'s PAIR_ACK handler on first successful pairing this boot).

4. **Auto-connect** — two new Settings toggles (`STR_LABEL_AUTO_CONNECT_KNOWN`/`_NEW`,
   `device_config_get/set_auto_connect_known/new`, default both `false`). Wired into
   `esp_now_hub.c`'s `ESP_NOW_MSG_ADVERTISE` handler as an added OR-condition on the existing
   auto-reconnect trigger (`was_paired || (ever_paired && !was_user_unpaired) || user_pair_wanted
   || auto_connect_wanted`). UI encodes "new implies known" (user's own point): turning on
   "auto-connect new" force-checks and disables the "auto-connect known" switch.

5. **Summary panel** — dropped its per-device row list entirely (device rows now live on
   Sensor/Camera panels instead — redundant otherwise). Replaced with a live instantaneous
   temp/humidity/CO2/NH3 readout (`refresh_summary_live_values()`), same 4 channels as the
   Statistics Overview panel but *without* scale/min/max/avg — just "label: current value". User's
   framing: "Summary는 시스템이 잘 돌고 있는지 보여주려는 의도, 통계는 과거 이력".

**Two real bugs found and fixed while relocating existing code** (worth remembering the pattern,
not just the specific fix — see [[feedback_thorough_investigation_before_large_refactor]]):
- `refresh_camera_list`/`refresh_sensor_list` (now filtered to WAITING-only for the Pending list)
  were about to set row `user_data` pointers into a stack-local per-tick filtered snapshot array —
  dangling the instant the function returned. Fixed by pointing at the persistent
  `s_camera_nodes_prev`/`s_sensor_nodes_prev` PSRAM arrays instead (which the code already
  `memcpy`'d the same filtered data into one line earlier).
- The web-injection disconnect helper (`ui_main_inject_disconnect` / `inject_fn_disconnect`) used
  to search the camera row cache that is now Pending-only — a connected device (the only kind you
  can disconnect) can never appear there, so it always silently failed. Fixed to search the new
  Connected-list row cache and simulate the new row→popup→disconnect-button→confirm tap sequence
  instead of the old row→confirm-directly sequence.

**Not done / explicitly deferred by the user this session:**
- Camera model (OVxxx) display on rows — user said do the structural work only, skip this; CAM
  doesn't init its camera sensor at boot (`cam_node.c:734`, battery-life design) so the PID isn't
  even known at pairing time regardless.
- Alias-at-connect-time prompt / "assign a name when first pairing" flow — user called this an
  "expansion" of the connection feature to discuss *separately* from moving connection management
  itself to the main screen (which IS done). Don't assume it's wanted without asking again.

**How to apply:** when the user is next active, this whole feature needs real on-device
touchscreen verification (per [[feedback_cntl_verify_on_device_screen]]) — tap through: a pending
device's confirm popup, a connected device's settings popup (Alias save + reload after
reconnect, measure-interval apply for Sens, disconnect), both auto-connect toggles' actual
reconnect behavior, and Summary's live-value readout with a real sensor. Don't assume it works
just because it booted clean.
