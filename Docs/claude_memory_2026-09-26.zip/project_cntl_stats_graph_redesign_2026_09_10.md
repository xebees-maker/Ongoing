---
name: project-cntl-stats-graph-redesign-2026-09-10
description: "IMPLEMENTED+built+flashed+boot-verified 2026-09-11 (NOT yet visually/touch-confirmed on screen): fixed 60pt, per-scale pre-aggregated storage, swipe-to-page, relative X-axis labels, gap-dots (superseded the original text-label design for insufficient data)"
metadata:
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-11T12:14:49.878Z
---

**Status: fully designed and agreed with the user 2026-09-10, ZERO code written yet** (beyond the
already-shipped NH3 color change and the temporary 60/120/240/480 debug dropdown from earlier the
same day, which itself now needs removing — see item 1). This supersedes the original graph spec in
[[project_cntl_stats_graph_2026_09_10]] (that memory's "unilateral choices" — Y-axis normalization,
skipped always-visible labels — were reviewed on-device and superseded by this new design; the
normalization approach itself is unaffected and stays).

**Why this redesign (root motivation, established via live measurement):** the existing
`stats_store_read_since()`-based graph does a full two-pass scan of the ENTIRE matched period on
every refresh — measured to cost ~9.84MiB of scan for a full 1-week window at current logging rate
(30s/4ch), and confirmed via direct extrapolation from real hardware data (3549 records / 7.39h
measured, scaled ×22.7 to a true 1-week's 80,640 records) that a genuinely full week would make a
single stats-tab refresh tick take an estimated 26+ seconds — completely unworkable. The fix is
pre-aggregating at write time instead of re-scanning at read time.

**Full agreed design (all items confirmed, in `Cntl/main/ui_main.c` + `stats_store.c`/`.h`):**

1. **Fixed 60 points, remove the debug tooling.** `STATS_GRAPH_POINT_COUNT` stays 60, permanently —
   no runtime-selectable point count. Remove the temporary 60/120/240/480 dropdown
   (`s_stats_point_count_dd`), the "I = xxxKB" memory label (`s_stats_graph_mem_label`), and
   `resize_stats_graph_buffers()`'s resize-on-demand machinery (added earlier the same day purely to
   let the user empirically measure memory cost per point count — that measurement is done, decision
   made, tooling no longer needed).
2. **New storage: per-scale pre-aggregated series, written alongside the raw log.** Whenever a new
   sensor value is stored (i.e. every `stats_store_append()` call), ALSO update pre-aggregated
   "bucket" data for each of the 5 scale tiers (1H/12H/1D/3D/1W) — not computed on read, computed
   incrementally on write.
3. **Each stored point = an aggregate (avg/convolution) of at least 2 raw values, never a single
   picked sample** — this replaces the current stride-based "pick every Nth record" downsampling
   (which could miss spikes entirely) with real averaging within each bucket's time window.
4. **Swipe navigation — page through history one scale-width at a time.** Left/right swipe on the
   graph moves the viewed window backward/forward by exactly one full scale-width (not a partial
   scroll) — e.g. on the 12H scale, default view is offset-0 (now-12h to now); one left swipe jumps
   to offset-1 (-24h to -12h), not a smooth/partial pan. **No future direction** — swiping right
   (forward) stops hard at offset-0 (now); there is no offset<0 / "future" state.
5. **X-axis uses relative "-N[unit]" labels, not absolute clock time** — consistent with the
   swipeable/offsettable window (an absolute-time X-axis would be confusing once you've paged back).
6. **Swipe position is a relative offset (integer count of scale-widths back from "now"), not a
   frozen absolute time range.** On every periodic refresh, re-resolve "now" fresh and recompute the
   window from the CURRENT offset — so a parked view at "-1 scale-width" keeps sliding forward with
   real time (always showing "the period ending 1 scale-width ago", not a fixed historical snapshot
   that stops updating). Confirmed explicitly: "이 때도 그래프가 갱신되잖아? ... 12시간 전을 보고
   있는데 갱신이 되면, 다시 12시간 전 창을 보여줘야 한다는 말이야."
7. **Refresh interval: derive from measurement, not a guess.** Don't keep the current hardcoded 6s
   (3×2s LVGL-timer throttle) — measure how long reading the NEW pre-aggregated per-scale data
   actually costs (should be cheap: small fixed-size structures, no full-log scan) and pick an
   interval comfortably larger than that. User's rough suggestion pending measurement: 30s-1min.
8. **Insufficient-data display.** When the current scale window has less real data than its full
   width (e.g. only a few hours logged but viewing the 1-week scale): show only the real portion,
   right-anchored (most recent data at the right/"now" edge), leaving the earlier/nonexistent portion
   blank rather than stretching sparse data across the full width. In that blank region, show
   "데이터 부족" (insufficient data) text in each series' own color, fixed position just to the
   right of the Y-axis, stacked at roughly 7/10 (temp), 6/10 (humidity), 5/10 (CO2), 4/10 (ammonia)
   of the axis height — exact spacing adjusted to the actual font's line height so the 4 lines don't
   overlap, not literally pinned to those fractions if the font makes that crowd.
9. **Pre-aggregated per-scale data has the SAME LIFECYCLE as the raw log — not a bounded ring
   buffer.** "측정값을 저장할 때마다 스케일별 값을 계산해 넣는 거니까, 측정값과 같은 생명주기야."
   It grows over time and gets trimmed together with the raw data (same policy as
   `stats_store_trim_to()`'s existing 90%→80% cleanup on the SD storage budget), NOT capped at 60
   entries per scale. This means swiping arbitrarily far into the past is always answered by a
   direct read from that scale's own store — no fallback to re-scanning the raw log ever needed,
   at any swipe depth (as long as the underlying raw data itself hasn't been trimmed away).
10. **A still-filling (not yet closed) bucket is never shown on the graph** — only fully-closed
    buckets are ever displayed; the live/current view's rightmost point is always the last COMPLETE
    bucket, never a live-partial-average of an in-progress one. ("다 채워진 후" — chosen because
    "특별히 안 중요"/implementation-simplicity default answer to the corresponding question, but
    stated as the actual choice, not deferred.)
11. **Bucket boundaries are wall-clock aligned** (e.g. every real minute/hour boundary, computed as
    `unix_time / bucket_width_seconds` — no stored reference/epoch needed) — chosen explicitly for
    implementation simplicity over anchoring to first-measurement-time, per the user ("구현하기
    편한 쪽으로 — 안 중요해").
12. **Batched writes** — when one raw value triggers updates across multiple scale tiers' buckets,
    collect and write them together rather than 5 separate open/write/close cycles. Shared principle
    with [[project_cntl_sd_reliability_redesign_2026_09_10]] item 5 — same session, same rationale
    (fewer SD open/close cycles, smaller corruption-risk windows).

**Carried forward from the earlier (pre-SD-crisis) graph design conversation, still valid, not yet
re-confirmed in this later session but not contradicted either — apply unless the user says
otherwise when this is picked up:**
- NH3 series color: dark yellow (`lv_palette_darken(LV_PALETTE_YELLOW, 2)`) — already shipped.
- Y-axis colored min/max legend per series — optional, only for currently-checked/visible series,
  "어려우면 생략" (skip if hard).
- Tap-value overlay: pale-yellow background box with the value, drawn directly on the chart at the
  tap position; disappears on (a) tapping elsewhere (new tap becomes the new centered position),
  (b) Scale dropdown change, (c) unchecking that series' checkbox; must NOT intercept taps meant for
  the chart underneath it (event passthrough — don't make the box `LV_OBJ_FLAG_CLICKABLE`).

**How to apply when resuming:** this whole plan was fully designed via an extended live Socratic/
design session and explicitly confirmed complete by the user. Do not re-derive or re-litigate; just
implement items 1-12 above, in the order they naturally depend on each other (storage layer [2,3,9,
10,11,12] before the swipe/render layer [1,4,5,6,7,8] that consumes it).

**2026-09-11 — IMPLEMENTED, build/flash/boot-stability confirmed, visual/touch NOT yet confirmed.**
Resumed same-day after the whole SD-reliability detour (user: "그래프 하다가 SD 안되서 이런
거잖아" — this session's graph work was interrupted by the SD crisis, not a separate later
session as the original memory assumed).

**Item 8 (insufficient-data) superseded by a live design refinement before coding** — the original
text-label design ("데이터 부족" at fixed Y fractions) was replaced by the user mid-session with a
simpler, more general mechanism that also handles mid-window gaps (not just the "haven't logged
long enough" edge case) — discovered when the user asked "지금처럼 어제 측정값과 오늘 측정값
사이에 시간 공백이 하루 있을 때 어떻게 처리해?" (today's real gap, from the SD outage during the
troubleshooting saga, made this a live concrete case, not hypothetical): **every slot with no data
(anywhere in the window, not just the left edge) gets a plain dot (no text) at that channel's own
fixed reference height** (temp=70/100, humidity=60/100, CO2=50/100, NH3=40/100 on the normalized
0-100 axis — same fractions as the original text-label design, 7/10·6/10·5/10·4/10). Also decided
in the same pass: real data now renders as **line only** (point markers off), so the gap-dots read
as visually distinct from real data automatically.

**Implementation** (`Cntl/main/stats_store.h/.c`, `ui_main.c`):
- `stats_store.h` is now the authoritative source for `STATS_SCALE_COUNT`/`STATS_SCALE_SECONDS`
  (3600/43200/86400/259200/604800) and `STATS_AGG_POINTS_PER_SCALE`(60) — `ui_main.c`'s
  `STATS_GRAPH_POINT_COUNT` is now just `#define`'d to that, and its old local copy of the scale
  array was deleted to avoid drift.
- New `stats_bucket_t` (10 bytes: bucket_start_unix, chan_type, sample_count, avg_value) written to
  5 separate per-scale files (`/sdcard/stats/agg_1h.bin` .. `agg_1w.bin`) — kept separate (not one
  combined file) so each stays purely time-ordered for real binary-search reads, unlike a merged
  file where only one scale's own subsequence would be sorted.
- `stats_agg_update()` (static, called from inside `stats_store_append_batch()` right after the raw
  write succeeds, once per record) maintains a tiny in-RAM accumulator per (scale, chan_type) —
  closes/flushes a bucket to its file when a new raw value's wall-clock-aligned bucket_start differs
  from the currently-open one. Buckets with <2 samples are silently dropped (item 3: "절대 단일
  샘플 아님"). Accumulator state does NOT persist across reboot (item 10 already means an
  in-progress bucket is never shown anyway, so losing it on reboot costs nothing visible).
- `stats_agg_read_window(scale_idx, chan_type, window_start, window_end, out, out_cap)` —
  binary-search + linear scan, same pattern as the existing raw-log reader. Caller maps each
  returned bucket to its slot via `(bucket_start - window_start) / bucket_width`; slots with no
  returned record are gaps (rendered as fixed-height dots, not blank).
- `ui_main.c`: `s_stats_graph_offset` (int, 0 = current window) replaces the old
  always-anchored-to-now cutoff; recomputed fresh from real "now" every refresh (item 6). Min/max
  normalization is now computed directly from each fetched window's own bucket values (NOT the
  overview panel's cache, which is always anchored to "now" and would be wrong once offset != 0).
  A second `lv_chart` (`s_stats_gap_chart`) is parented INSIDE the main chart object (auto-overlays
  at the same position/size, `LV_OBJ_FLAG_CLICKABLE` removed so taps pass through to the real
  chart) — LVGL has no per-series line/point-visibility override, so achieving "real data = line
  only" + "gaps = dots only" simultaneously required two separate chart widgets, main chart with
  `LV_PART_INDICATOR` width/height 0 (hides point markers), gap chart with `LV_PART_ITEMS` line
  width 0 (hides connecting lines) and nonzero indicator size.
- Relative X-axis labels (item 5, using the interval table from an earlier design pass — 1H→10min,
  12H→1H, 1D→2H, 3D→12H, 1W→1D) implemented as a fixed pool of pre-created label objects positioned
  via `lv_obj_set_pos` against the chart's measured pixel width (same technique as the existing
  tap-value-box placement) — NOT LVGL's built-in axis tick system (not flexible enough for custom
  text). Labels always read relative-to-the-viewed-window's own right edge (0 at right, -scale at
  left) regardless of swipe offset — so they don't need to change meaning when paging back.
- **Swipe gesture conflict resolved**: the original design said "left/right swipe" for time paging,
  but the graph view already used right-swipe to switch to the table view (from an earlier,
  separate 2026-09-07 design). User clarified live that the existing table↔graph swipe switching
  isn't actually used/relied on ("테이블 그래프 스와이프 안쓰는데?", and separately that the
  table's own up/down-swipe-for-paging handler is also dead code — scroll consumes the gesture
  first) — so left/right on the graph were freed up for time-offset paging as originally spec'd;
  table↔graph switching now relies solely on the existing "<<"/">>" buttons.
- Refresh interval (item 7): moved from 3-tick(~6s) to 5-tick(~10s) given the read is now a small
  bucket-store lookup instead of a full raw-log scan — not rigorously measured/tuned, a reasonable
  default given the now-much-cheaper read. A `s_stats_graph_force_refresh` flag bypasses the tick
  throttle immediately after a swipe or when switching from table to graph view, so those feel
  responsive rather than waiting up to ~10s.

**NOT yet done/verified:**
- No visual/touch confirmation on the physical screen at all yet (dot rendering, swipe feel, label
  positions, whether the two overlaid charts actually align pixel-perfect) — per
  [[feedback_dont_declare_done_prematurely]], explicitly flagging this: only "builds clean, boots
  without crashing, and a real WAKE_HELLO-triggered write went through `stats_agg_update()` without
  crashing" is confirmed, nothing about whether it LOOKS right.
- Y-axis colored min/max legend and the tap-value overlay box were both already-shipped/carried-
  forward items from the earlier design pass, not touched in this implementation pass — should
  still be present (untouched code) but not re-verified either.
- Refresh interval not actually measured against real hardware timing (item 7 says "derive from
  measurement, not a guess" — the 10s figure IS still a guess, just a more informed one than the
  old 6s).
