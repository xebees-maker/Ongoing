---
name: cntl-modal-popup-width-convention
description: "CNTL project-wide modal popup convention (2026-09-18): create_modal() width=2/3 screen (height stays content-based), plus title bar/color/button rules - flush title bar via create_modal_title(), Warning(yellow)/Normal(blue) color independent of OK-Cancel/Yes-No/Close-only button structure"
metadata:
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-18T05:04:43.460Z
---

User (2026-09-18, while designing the Manual Override warning dialog): "그러고보니, 전에 팝업
컨벤션 정할 때 크기도 정한 거 같은데? 폭을 화면 2/3으로... 높이도 화면 2/3으로 하려고 했었는데
그때 네가 가변 높이라고 해서 지정하지 않았어" (Now that I think of it, we'd also decided a size
when setting the popup convention before — width = 2/3 of screen. We wanted height at 2/3 too, but
you pointed out it's a variable/content-based height, so we left it unspecified.)

**The convention:** `create_modal()`'s dialog box (currently `lv_obj_set_size(box, 420,
LV_SIZE_CONTENT)`, a hardcoded 420px on this 800px-wide display) should use `LV_PCT(67)` for width
instead of a fixed pixel value — resolves to 2/3 of the screen regardless of exact resolution.
Height stays `LV_SIZE_CONTENT` (auto-sized to content) — NOT a fixed 2/3, per the earlier
clarification that a content-driven dialog doesn't have a meaningful fixed height to set.

**Why:** [[project_cntl_popup_close_vs_action_buttons]] already covers *which* close affordance a
modal uses (X vs bottom buttons); this is the companion sizing rule for the same `create_modal()`
dialog family — declared project-wide ("컨벤션으로 저장해"), not scoped to one popup.

**How to apply:** any new or existing `create_modal()`-based dialog should use `LV_PCT(67)` width,
content-based height. If `create_modal()` itself is updated to this default, every caller inherits
it automatically — check that existing dialogs still look reasonable at the new width when doing so,
since some may have been tuned around the old 420px assumption.

---

## Title bar / color / button convention (added 2026-09-18, same design conversation)

User wanted a real Windows-style title bar on every `create_modal()` popup, not just colored text —
worked out via extended back-and-forth (rounded corners stay project-wide, user dislikes them but
"이미 둥근 모서리로 다 만들어서 그냥 둥근 모서리로 쓸래" — not worth redoing). Implemented as
`create_modal_title(box, title_id, kind)` in `ui_main.c` (helper added right after `create_modal()`):
title bar is flush to the box's top edge and full width (escapes the box's own padding via negative
top/left/right margin, queried at runtime via `lv_obj_get_style_pad_top/left/right()` rather than a
hardcoded pixel guess) and `lv_obj_set_style_clip_corner(box, true, 0)` makes the title bar's top
corners automatically follow the box's existing rounded-corner radius — no manual radius matching
needed. Must be called immediately after `create_modal()`, before any other child is added, so it
lands as the first child (= top of the popup).

**Two axes, independent of each other:**
1. **Color** (`modal_kind_t`: `MODAL_KIND_WARNING` yellow bg/black text, `MODAL_KIND_NORMAL` blue
   bg/white text) — severity of the content (destructive/consequential = Warning, everything else =
   Normal). Blue matches the existing button accent color (`LV_PALETTE_BLUE`) already used
   elsewhere in the app.
2. **Button structure** — determined by the title word/purpose, not by color. A Warning-colored
   popup can still have a Notice-style single-Close button (e.g. SD reconnect/format failure alerts
   are Warning-colored but are a one-way notification, not a decision) — same idea as Windows
   notification dialogs varying icon/color while keeping one OK button. Rule:
   - Title "확인"(Confirm) or "설정"(Setting) → real decision, buttons OK/Cancel
   - Title "경고"(Warning) → real decision, buttons default Yes/No; rare exception OK/Cancel only
     when the message truly can't be phrased as a yes/no question
   - Title "알림"(Notice) or "진행 중"(In Progress) → not a decision, buttons = Close only or
     Cancel only (no confirm/OK button)

**Full classification of the 16 `create_modal()`-based popups in `ui_main.c`** (as of commit
ccbf20f): Warning+Yes/No — override confirm, SD format confirm, photo delete confirm, delete-all
confirm, stats delete confirm, restart confirm, network mode switch confirm. Warning+Close-only
(Notice structure, Warning color) — SD reconnect/format failure alerts, stats-blocked-by-SD-fail
alert. Normal+OK/Cancel — pairing allow confirm, connection-disconnect confirm (both call sites),
WiFi password entry (kept "Connect"/"Cancel" instead of literal OK/Cancel — Connect is the
semantic OK here), value roller (numeric picker). Normal+Close-only — QR popup, storage cleanup
result. Normal+Cancel-only — progress popup (unchanged, was already Cancel-only).

`show_confirm_popup()` and `show_alert_popup()` are shared across many call sites with mixed
severity, so both gained a `modal_kind_t kind` parameter — every call site was updated individually
to classify itself (see commit ccbf20f for the full list). This was a deliberate signature change,
not an oversight — don't "simplify" it back to a single fixed kind.

**How to apply:** any NEW `create_modal()`-based popup should call `create_modal_title()` right
after `create_modal()`, pick the right `modal_kind_t`, and pick its button set per the title-word
rule above — this is now the standard shape for every popup in the app, not just the ones already
converted.
