---
name: feedback-trailing-and-wait-for-continuation
description: "If the user's message ends with '그리고' (and...) or otherwise trails off, stop and wait — don't keep acting/investigating, they're not done typing"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 53810285-98f9-4ede-9939-9816c41aeab1
  modified: 2026-08-11T00:29:35.308Z
---

If a user message ends with "그리고" (or otherwise reads as cut off / trailing
mid-thought), that means they are not finished typing — it is not a complete
instruction to act on. Stop and wait for them to continue, rather than
continuing to run tool calls or investigate.

**Why**: 2026-08-11, mid-debugging-session, the user's frustrated message ended
with "...그리고" (trailing off). Instead of pausing, I kept going — ran another
grep/investigation tool call — which the user then had to interrupt with "멈춰"
(stop). They explicitly said not to make them repeat this correction every
time.

**How to apply**: treat a trailing "그리고" (or similar dangling conjunction/
incomplete sentence) the same as an explicit "wait" signal — zero further tool
calls until they send the rest of their thought. This is a specific case of
the broader pattern in [[feedback_confirm_understanding_before_acting]] and
[[feedback_pure_conversation_mode]]: when in doubt about whether the user is
done talking, don't act.
