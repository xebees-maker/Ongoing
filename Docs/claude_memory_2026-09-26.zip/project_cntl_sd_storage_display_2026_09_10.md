---
name: project-cntl-sd-storage-display-2026-09-10
description: "CNTL SD Storage capacity display + 90%->80% auto-cleanup feature, built and self-tested 2026-09-10 while user was asleep"
metadata:
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-09T16:40:27.292Z
---

**Status: IMPLEMENTED + self-tested PASS, both autonomously while user asleep. NOT yet visually
confirmed on the physical screen** (no camera/screenshot access) — worth a quick on-device glance
next session per [[feedback_cntl_verify_on_device_screen]].

**Spec (user-designed, 2026-09-09/10 conversation):**
- New Summary-panel row directly below Memory: `Storage[%(Remain MB)]: Picture xx(yy) / Measure
  zz(kk) / Total aa(bb)` — unit legend stated once in the bracket, bare numbers after that.
- Total = SD card's real raw total capacity (auto-detected via `esp_vfs_fat_info()`, not hardcoded;
  currently ~4000MB on this card but must not assume that number).
- Budget split 9:1 (Picture:Measure) of that same Total, always — no user-configurable setting.
- Each category's %/Remain-MB is against its OWN budget slice, not the raw SD total.
- Cleanup trigger: a category hitting 90% of its own budget triggers deleting its oldest records
  until it's back to <=80% of that budget, then a popup announces what was deleted (not the usual
  ui_log_add_err toast — a dedicated info popup, "Storage cleanup: Measure - deleted N oldest
  records to free space"). Web-side equivalent explicitly deferred by user ("나중에").
- Picture (CAM photo storage on CNTL's SD) is itself still 미정/deferred — actual photo files
  aren't landing on the SD yet, so Picture always reports 0 used / full budget remaining for now.
  Folder structure already decided (`Photo/<per-cam-folder>/`, mirrors CAM's own filename
  convention) but naming details + implementation timing are open.

**Files touched:**
- `Cntl/main/sd_storage.h/.c` — added `sd_storage_get_capacity()` wrapping `esp_vfs_fat_info()`.
- `Cntl/main/stats_store.h/.c` — added `stats_store_get_used_bytes()` and `stats_store_trim_to()`
  (rewrites the SD file keeping only the newest records, via a temp-file + rename swap since
  records are fixed 16-byte and chronologically ordered).
- `Cntl/main/ui_main.c` — new `s_storage_status_label`, a 5-second-gated check block inside
  `refresh_dashboard()` (SD queries are too costly for every 1s tick), and
  `show_storage_cleanup_popup()` (reuses the QR-popup's single-button info-modal pattern, not
  `show_confirm_popup()`'s Yes/Cancel).
- `Cntl/main/ui_strings.h/.c` — `STR_LABEL_STORAGE/PICTURE/TOTAL`, `STR_MSG_STORAGE_CLEANUP`
  (reused existing `STR_LABEL_MEASURE_SHORT` = "Measure" rather than adding a duplicate). Watch
  out if editing `STR_MSG_STORAGE_CLEANUP` again: the KO/EN format strings must keep identical
  `%s`/`%u` argument order — printf-style i18n tables here have no positional-arg escape hatch.

**Self-test performed (both temporary, added then fully removed before the final flash):**
1. `stats_store_trim_to()` correctness — filled 200 synthetic records (dummy MAC, chan_type 0),
   trimmed to a 1600-byte target, verified via serial log: before_count=200, deleted=100,
   after_count=100, after_bytes=1600, and read back all 100 survivors to confirm min/max unix_time
   exactly matched the expected 100..199 index range (i.e. confirmed by *content*, not just count,
   that the oldest half was dropped and the newest half survived in order) -> PASS. Store emptied
   afterward so no synthetic data pollutes real use.
2. tx_task priority fix stress test (5->17, see [[project_cntl_tx_queue_full_2026_09_09]]) — a
   temporary `lv_timer` called `build_device_popup()`/`teardown_device_popup()` directly (no touch
   needed) every 3s using whichever real connected node was live, for ~54 minutes (539 open/close
   cycles). Result: zero TX_QUEUE_FULL, zero crashes/watchdog resets, internal free RAM stayed
   stable in the 78-86KB band throughout -> PASS, though the earlier root-cause note stands:
   absence of recurrence over one run doesn't retroactively prove the fix for every future
   condition, just that this specific reproduction path no longer triggers it.

**Gotcha hit during testing, worth remembering:** a pyserial capture script with no `ser.timeout`
set will block forever on `ser.read()` during any quiet stretch where the device just isn't
logging anything — this looks exactly like a hung/crashed board from the outside (empty output
file, task never completes) but isn't. Always set `ser.timeout = 1.0` (or similar) on capture
scripts so the check-duration loop can actually re-evaluate periodically; confirmed by adding the
timeout and immediately getting clean output showing the device had been fine the whole time.

**Not yet done / explicitly deferred by user:**
- Actual CAM photo storage on CNTL's SD (Picture category will read 0 until this lands).
- Web-side equivalent of the cleanup notification popup.
- Graph feature itself (`lv_chart` LINE, 4 series, per-series checkboxes, tap-for-nearest-value,
  10 always-visible evenly-spaced points) — this SD Storage work was a detour that came up while
  discussing the graph's memory budget; the graph implementation itself hasn't started.
