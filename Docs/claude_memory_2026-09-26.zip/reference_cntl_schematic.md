---
name: reference-cntl-schematic
description: "CNTL board = Waveshare ESP32-S3-Touch-LCD-4.3B. Schematic PDF is saved at C:\projects\documents\ESP32-S3-Touch-LCD-4.3B-Sch.pdf — key pin facts extracted here so they aren't lost again."
metadata: 
  node_type: memory
  type: reference
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-22T12:00:00.000Z
---

Board: **Waveshare ESP32-S3-Touch-LCD-4.3B** (800x480, ESP32-S3-WROOM-1-N16R8). The user pasted the
full schematic PDF directly into a chat message on 2026-09-06 — **Claude has no mechanism to write
a pasted-in-chat PDF's raw bytes back to disk itself** (confirmed again 2026-09-22, see
[[project_cntl_i2c_bridge_design_2026_09_21]]). The user has since saved it themselves at
`C:\projects\documents\ESP32-S3-Touch-LCD-4.3B-Sch.pdf` (see
[[reference_schematic_documents_folder]] for the general convention/folder) — `Read` it directly
from there instead of asking for a re-paste. Reading PDFs needs `pdftoppm`(poppler-utils), which
was only installed 2026-09-22 and may need a session/PC restart to be visible to `Read`.

**SD card interface (confirmed from schematic, SD1 connector + WROOM-1 net list)**:
- Uses **SPI mode**, not SDMMC — signals are named MOSI/MISO/SCK/SDCS on the silkscreen, not
  CLK/CMD/D0.
- `IO11` = MOSI, `IO12` = SCK, `IO13` = MISO (direct ESP32-S3 GPIOs, confirmed via net labels
  `NLIO11 NLMOSI`, `NLIO12 NLSCK`, `NLIO13 NLMISO`).
- **SD_CS is NOT a direct GPIO** — the net label is `NLEXIO4 NLSDCS`, meaning chip-select is routed
  through **EXIO4 on the CH422G I2C GPIO expander** (U11), the same expander CNTL's existing
  `components/waveshare_rgb_lcd_port.c` already uses for LCD_RST/CTP_RST/backlight (I2C addr 0x24
  = mode register, 0x38 = data/output register, both handles already created in that file as
  `s_ch422g_mode_dev`/`s_ch422g_data_dev`).
- **RESOLVED 2026-09-06, HW-verified**: found a complete, working CH422G driver
  (`_Archive/Cntl_backup_20260730_224030/bsp_ws_4_3b/ch422g.c/.h`) from an earlier abandoned custom-BSP
  attempt (superseded by the current `waveshare_rgb_lcd_port.c`-based approach, but this driver file
  itself is independent/reusable) — it documents the FULL bit map, sourced from Waveshare's official
  demo: `IO0=DI0, IO1=TouchRST, IO2=Backlight, IO3=LCD_RST, IO4=SD_CS(active-low), IO5=DI1`. Copied
  into `Cntl/components/ch422g.c/.h`; migrated `waveshare_rgb_lcd_port.c`'s two ad-hoc magic-byte
  writes (touch-reset 0x2C/0x2E, backlight-on 0x1E) onto this driver via `ch422g_set_io_raw()`
  (reproduces the exact same physical bytes, no behavior change) so there's one shared shadow-state
  owner instead of two independently-tracked copies that could stomp each other. Display+touch
  confirmed still working after the migration ("다 잘돼"), then `Cntl/main/sd_storage.c` mounts the
  SD card via `esp_vfs_fat_sdspi_mount()` with `gpio_cs=SDSPI_SLOT_NO_CS` (driver skips GPIO CS
  entirely — official ESP-IDF pattern, confirmed in `esp_driver_sdspi/src/sdspi_host.c`) and CS
  asserted once via `ch422g_set_io(CH422G_IO_SD_CS, false)` before mounting, held low permanently
  (SD is the sole device on this SPI bus — user confirmed no RS485/I2C/CAN sharing it). **Mounted
  successfully on first real-hardware attempt** ("보여 성공이래"), confirmed via new on-screen log
  tab message (`ui_log_add`/`UI_ERR_SD_MOUNT_FAILED`), not just serial.

**How to apply**: SD mounting for [[project_cam_cntl_storage_unification_2026_09_06]] is done and
working — `sd_storage_init()` (`Cntl/main/sd_storage.c`) mounts at `/sdcard` with `/sdcard/stats/`
and `/sdcard/photos/<cam_mac>/` folders pre-created. Next work (stats time-series file format) can
just open files under `/sdcard/stats/` directly.
