---
name: cntl-signal-color-active-window
description: CNTL Sensor-panel WiFi signal icon blue/green transition bug — resolved 2026-09-15
metadata: 
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-15T10:25:13.879Z
---

RESOLVED + user-confirmed on-device 2026-09-15: Sensor-panel signal icon stayed blue (Active) continuously even while a Sens node was asleep, instead of turning green (Paired/sleeping) between communication bursts.

Root cause: `esp_now_hub_get_conn_state()` (Cntl/main/esp_now_hub.c) derived ACTIVE from `n->conn_state == NODE_CONN_PAIRED`, which stays true continuously from pairing until the slow periodic sweep clears it after the full adaptive timeout (response_interval × 6, e.g. ~60s for a 10s node). So ACTIVE (blue) never reflected "communicating right now" — it reflected "paired and not yet orphaned."

Fix: added `HUB_NODE_ACTIVE_WINDOW_MS = 3000` and changed the ACTIVE condition to `radio_paired && (now_ms - n->last_seen_ms < HUB_NODE_ACTIVE_WINDOW_MS)`. Justified by live log capture: actual WAKE_HELLO-to-SLEEP_NOW-완료 communication bursts are under 1s (worst case ~900ms with retries), while the rest of a 10-15s cycle is pure sleep. So now: blue only during the short post-communication window, green the rest of the time while still paired, red still reserved for near-orphan (unchanged, 80%-of-timeout threshold logic in ui_main.c's `update_signal_widget` call site).

**Why this took a full investigation:** user's recollection of the OLD 2-color code (`is_active ? blue : red`, pre-3-color redesign) was that it turned red immediately on sleep — this contradicted a code-read showing conn_state persists ~60s. Turned out the user's real point (clarified after) was simpler: whatever state means "not actively communicating right now" should render as a *healthy* color (green now that 3 colors exist) rather than trying to literally reproduce the old code's red-on-idle behavior. The fix that resolved it was redefining what "ACTIVE" measures (a short recency window), not chasing an exact old-behavior reproduction.

**How to apply:** if a similar "why did the old code do X" contradiction comes up again, don't over-invest in reconciling old behavior byte-for-byte — check whether the user's actual ask has since simplified (as it did here: "that state can just be green").
