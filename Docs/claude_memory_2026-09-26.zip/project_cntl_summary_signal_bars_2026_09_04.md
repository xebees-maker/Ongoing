---
name: project-cntl-summary-signal-bars-2026-09-04
description: "CNTL dashboard summary-panel per-device RSSI signal bars, right-aligned, shipped and verified on hardware 2026-09-04"
metadata: 
  node_type: memory
  type: project
  modified: 2026-09-04T01:22:51.202Z
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
---

Shipped and user-verified working ("잘 동작해"). `esp_now_hub_node_t` gained `int8_t rssi` /
`bool has_rssi`, updated in `recv_cb()`'s common entry point (before message-type dispatch, using
`info->rx_ctrl->rssi`) so it's fresh regardless of which message type arrives, not just
WAKE_HELLO. `esp_now_hub_get_nodes()` already does a full struct copy, so no extra plumbing needed
for callers.

UI: the summary panel's per-node row changed from a single `lv_label` to a flex-row container
(label left, signal widget right, `LV_FLEX_ALIGN_SPACE_BETWEEN`) — this restructuring is contained
to the summary panel's own row-building code, does not affect other panels (camera/sensor). The
signal widget (`create_signal_widget`/`update_signal_widget`) is 5 vertical bars of increasing
height (4/7/10/13/16px), filled left-to-right by RSSI thresholds (-45/-55/-65/-75/-85 dBm cutoffs
for 5/4/3/2/1 bars), grey when unfilled or no RSSI yet, blue when filled — chosen over a numeric
dBm readout per explicit user request ("숫자보다 막대기나 일반적인 와이파이 표시형태로").
`SIGNAL_BAR_COUNT` started at 4, user asked "더 많이" (more), 10 was floated but rejected after
being told RSSI's natural few-dB jitter would make that many tiers visibly flicker at boundaries —
settled on 5.
