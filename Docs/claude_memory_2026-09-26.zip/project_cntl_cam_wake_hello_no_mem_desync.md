---
name: project-cntl-cam-wake-hello-no-mem-desync
description: "RESOLVED 2026-09-05: photo/list progress-popup races from the 2026-09-04 event rebuild, plus a real WAKE_HELLO_ACK/NO_MEM desync bug found via live serial capture"
metadata:
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-05T02:39:49.272Z
---

Follow-up bugfix session to [[project_cntl_web_full_ui_injection_design_2026_09_04]]'s rollout.
Three distinct bugs, found and fixed in order.

## Bug 1+2: progress popups racing the new event-driven consumers

The 2026-09-04 event rebuild added `cb_async_photo_result`/`cb_async_list_result` (fired via
`lv_async_call` almost instantly on completion) alongside the PRE-EXISTING per-popup 200ms
`tick_fn` polling (`fetch_popup_tick_fn`, `renew_list_tick_fn`) that was already independently
watching the same state. Whichever consumer wins the race can starve or short-circuit the other:
- `renew_list_tick_fn` already self-consumed (ack+refresh) on READY — the new event consumer
  beat it to the punch, so the popup's next tick saw nothing and false-STALLed (3007).
- `fetch_popup_tick_fn` did NOT self-consume (just set label text, assumed something else — the
  old 1s dashboard poll — would ack it) — once the new event consumer was told to defer to the
  popup (first fix attempt), nothing consumed READY at all, surfacing later as a mismatched
  re-fetch (3008, [[feedback_dont_encode_metadata_in_ids]]-adjacent selection-stale logic).

**Fix**: both popups made fully self-sufficient (`fetch_popup_tick_fn` now calls
`consume_ready_photo_if_current()` itself on READY, matching `renew_list_tick_fn`'s existing
pattern), and both event consumers gained an `is_active()` guard
(`fetch_popup_is_active()`/`list_popup_is_active()`, comparing `s_progress_tick_fn` against the
popup's own tick fn pointer) so they defer entirely whenever the corresponding popup is open.
Event consumers only act when NO popup is watching.

**Lesson**: any new event-driven consumer of shared single-slot state must check for an existing
poll-based consumer of the SAME state before assuming it's the only one — the old poll was slow
enough (1s vs 200ms) that this race was latent but never manifested before.

## Bug 3: WAKE_HELLO/NO_MEM/desync storm right after photo transfers

Found via a live serial capture (not guessing — see [[feedback_dont_use_user_as_test_oracle]]'s
2026-09-05 entry) right after a real photo fetch:
1. `esp_now_hub_note_user_action()` fires on photo fetch (one of 5 action sites) → adaptive
   threshold keeps CAM told to stay awake (`sleep_sec=0`) for ~10s after.
2. CAM's `CASK_LIVE_PACE_MS=1000` re-check-in pacing (cam_node.c) is real and correct — NOT the
   bug (an earlier hypothesis this session, corrected by the user).
3. The actual cause: WAKE_HELLO is sent via `esp_now_reliable_request()` with only a **100ms**
   timeout (esp_now_cam.c, `esp_now_cam_try_wake_hello_fast_path`). CNTL's WAKE_HELLO_ACK reply is
   a bare, non-retried `esp_now_send()` (esp_now_hub.c) with **zero return-value check** — if the
   radio TX queue is briefly full (e.g., right after a 137-chunk photo transfer's tail traffic),
   this send silently fails and nothing resends it.
4. CAM, hearing nothing in 100ms, resends WAKE_HELLO — CNTL doesn't dedupe, treats it as a brand
   new cycle, redoes the full 4-message CASK reply (ACK+CONFIG+할일+SLEEP_NOW) — compounding queue
   pressure. Confirmed in the capture: 3 WAKE_HELLO cycles ~95-100ms apart, then
   `esp_now_send 실패(시도 1/3): ESP_ERR_ESPNOW_NO_MEM`, then CAM re-advertised believing pairing
   lost, then a several-second reconnection storm before recovery.

**Fix (both sides, matched pair)**:
- CNTL (esp_now_hub.c): WAKE_HELLO_ACK send wrapped in a 3-attempt retry loop checking the return
  value, instead of fire-and-forget.
- CAM (esp_now_cam.c): WAKE_HELLO's reliable_request timeout raised 100ms → 200ms, extra margin
  against CNTL being momentarily busy.

## Bug 4 (found alongside): esp_now_photo_wait_cached() global-not-per-file ERROR check

`esp_now_photo_wait_cached(file_id, ...)` (web's blocking wait for a specific photo) checked only
`s_state == ERROR` globally, not whether that error actually belonged to `file_id`. Any unrelated
error (e.g. transient state during the desync storm above) made an UNRELATED web fetch request
fail instantly, even though the real transfer for that file kept going and succeeded moments later
(app showed success, web showed instant failure — this was the "다른 사진 요청이 순간 실패한다"
symptom). Fixed by comparing the single-slot `s_file_id` against the awaited `file_id` before
treating ERROR as this wait's own failure.

## How to apply

All 4 fixes are narrow, single-purpose patches — no design change needed. If a similar
"success on app, instant/spurious failure on web" report recurs, check first whether it's this
same global-state-vs-per-target-id class of bug elsewhere in esp_now_photo.c/esp_now_hub.c's
web-facing wait functions.
