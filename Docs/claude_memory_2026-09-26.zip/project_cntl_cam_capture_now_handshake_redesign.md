---
name: project-cntl-cam-capture-now-handshake-redesign
description: "Design for replacing capture-now's single blind timer with a multi-stage reliable handshake (RECEIVED -> [INIT_NEEDED -> INIT_DONE] -> CAPTURING -> SUCCESS/FAILED), designed 2026-08-21"
metadata: 
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-22T01:46:43.108Z
---

User called out (2026-08-21) that the 4004 (capture-now no-response) bug is a recurring symptom of a
general code-style problem: reusing one generic timeout (`cam_response_timeout_ms()`, designed for
wireless wake/pairing latency) to gate a fundamentally different kind of wait (actual camera hardware
operation time), with zero handshake in between — CAM sends RECEIVED immediately, then nothing at all
until the final SUCCESS/FAILED, however long the real capture takes.

**Design agreed with user, mirroring the delete-all RECEIVED/WAIT_DONE split but with one more
conditional branch:**

1. Cntl -> CAM: PHOTO_REQUEST(mode=CAPTURE_NOW) — unchanged.
2. CAM -> Cntl: CAPTURE_STATUS(RECEIVED) — stays fire-and-forget from `recv_cb`, the deliberate
   exception to [[feedback_default_to_reliable_messaging]] (recv_cb can't block on an ACK-wait; this
   is what hides the queueing delay before the dedicated task even dequeues the request).
3. Dedicated task checks whether the camera needs init this wake cycle:
   - If it does: CAM -> Cntl CAPTURE_STATUS(INIT_NEEDED) [reliable] -> runs `ensure_camera_ready()`
     -> CAM -> Cntl CAPTURE_STATUS(INIT_DONE) [reliable].
   - If it doesn't: skip both messages/stages entirely — the popup shouldn't show or wait on them.
4. CAM -> Cntl CAPTURE_STATUS(CAPTURING) [reliable] — sent right before the actual blocking
   warmup+shot capture call begins (the "나 찍을거야" signal the user asked for).
5. CAM -> Cntl CAPTURE_STATUS(SUCCESS/FAILED) [reliable] — existing final step, unchanged.

**Key rules from the user, verbatim intent:**
- "에러 체크는 각 스텝별로 따로 해야지" — each stage transition gets its own timeout/budget, not one
  shared blind timer. RECEIVED/branch-selection stays network-latency-bound (reuse
  `cam_response_timeout_ms()`); the init and capturing stages need their own budgets sized for actual
  hardware work, decoupled from the "응답성" wireless-tier concept entirely.
- "초기화를 안하는 경우는 바로 넘어가야지" — the popup must not display or wait on the INIT_NEEDED/
  INIT_DONE stages when the camera was already initialized this wake cycle; skip straight from
  RECEIVED to CAPTURING in that case.
- "특별한 경우가 아니면 모두 reliable" — every new intermediate status message goes through the
  reliable stack (ACK + retry), see [[feedback_default_to_reliable_messaging]].

**Implemented and committed 2026-08-22** (commit 3169d1b, bundled with several other fixes from the
same uncommitted session span) — `esp_now_link.h` enum extended, CAM-side stage-send helper added in
`esp_now_cam.c`/`cam_node.c` (`cam_node_is_camera_ready()`/`cam_node_ensure_camera_ready()` wrappers),
Cntl-side `esp_now_photo.c`/`ui_main.c` popup stage handling rewritten (`capture_popup_tick_fn`,
per-stage timeout via `capture_stage_timeout_ms()`). Build passed; **not specifically re-verified on
real hardware this session** — testing that session focused on pairing/5005/RAM and the stats-tab log
work, not a dedicated capture-now run-through. Worth a real capture-now test next session.

**Separately confirmed same session (no code change needed):**
- XCLK build-time default changed 24MHz -> 10MHz per user's own fixed-camera/same-brightness still-cut
  comparison test (10MHz best quality, 20MHz+ noticeably noisier) — see [[project_cntl_xclk_preset_ui]].
  UI dropdown unchanged (5/10/20/24MHz still all selectable).
- `CAM_WARMUP_FRAME_COUNT=2` confirmed correct via the same test (frame 1 clearly bad, frame 2
  borderline-insufficient) — no change needed, current value already matches what 2 discarded frames
  should be.
- The old "20MHz didn't work" data point from an earlier session was based on a streaming/video-mode
  source, not a still-cut capture, and had confounding issues at the time — user explicitly said not
  to treat it as reliable evidence against 20MHz; this session's controlled still-cut test supersedes
  it.
