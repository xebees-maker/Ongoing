---
name: project-cntl-sd-reliability-redesign-2026-09-10
description: "ALL of items 1-8 IMPLEMENTED+build/flash/HW-verified 2026-09-11 against the real corrupted card; item 9 (user actually pressing 포맷 on the corrupted card) not yet done; popup UI itself not yet visually confirmed on the physical touchscreen"
metadata:
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-11T11:47:34.511Z
---

**IMPLEMENTATION STATUS (2026-09-11 update):** Items 1 (task-isolation removal), 2 (default SD
timeout kept), 3 (fail circuit-breaker), 6 (main-screen-reachable notification), 7 (재연결 버튼),
8 (포맷 버튼) are DONE in `Cntl/main/ui_main.c`/`sd_storage.c`/`sd_storage.h`/`stats_store.c`/
`stats_store.h`, built clean, app-only flashed to COM19, and HW-verified via two serial captures
across a reflash: with the real corrupted card still failing at block 8256 (`error 0x107`), the
circuit-breaker was confirmed to stop repeated SD probing after the first detected fail (no more
periodic `diskio_sdmmc` error spam on later ticks), and the firmware stayed alive/responsive
throughout (no crash, no watchdog). Found+fixed one real gap while verifying: the main-screen
`refresh_storage_status_label()` (the 5-tick periodic label refresh) itself calls
`stats_store_get_used_bytes()`, which can independently trip a real I/O fail — that path wasn't
checking `stats_store_had_io_error()` and would silently show stale/wrong numbers. Fixed by
checking it there too, via a `mark_sd_io_fail()` helper split out from `report_sd_io_fail()` to
avoid a recursion trap (the label-refresh function can't call `report_sd_io_fail()` since that
function itself calls the label refresh).

**2026-09-11 follow-up — items 4+5 also DONE+HW-verified**, after the user pushed back
("아니 뭔 네 맘대로 계획대로 미루니" / "다 해라 이 자식아") on me unilaterally declaring these
"still open" without asking first — see [[feedback_dont_unilaterally_defer_scope]]. What shipped:
- **Item 5 (batch writes):** `stats_store_append()` (single-record, one fopen/fwrite/fclose per
  channel) replaced with `stats_store_append_batch(records[], count)` — one fopen/fwrite-loop/
  fclose per WAKE_HELLO_SENS event instead of up to `ESP_NOW_MAX_CHANNELS`(5) separate opens.
  Caller (`esp_now_hub.c`'s WAKE_HELLO_SENS handler) now builds a small `stats_record_t recs[]`
  array first, then makes one batch call. HW-confirmed via serial log:
  `stats_store_append #1(레코드 3개): ...` — a single call handled 3 channels.
- **Item 4 (write-path audit):** confirmed the existing `if (!f) {...; return;}` fail-check was
  already correct (no crash/hang), but found a real gap — write failures were invisible to the
  user (only a serial log, no UI signal). Fixed by adding a dedicated cross-task flag in
  `stats_store.c`: `s_write_io_error_pending` (set by `stats_store_append_batch()` on fopen fail,
  since that runs in ESP-NOW's `recv_cb` task context, NOT the LVGL task) +
  `stats_store_take_write_io_error()` (test-and-clear, called from `ui_main.c`'s 1s
  `refresh_dashboard()` LVGL timer, which then safely calls `mark_sd_io_fail()` +
  `refresh_storage_status_label()` — both LVGL-safe since that timer runs on the LVGL task).
  Deliberately NOT reusing the existing `s_last_io_error`/`stats_store_had_io_error()` flag for
  this cross-task signal, since that flag gets reset at the start of every read function too —
  a write failure's signal could get silently clobbered by an unrelated read before the write's
  own task-hop had a chance to consume it. HW-confirmed: a later write failure at t=35809ms
  (after the read-side breaker had already tripped at t=17800ms) correctly did NOT re-log a
  duplicate breaker message — the two paths share one consistent breaker state without spamming.

**2026-09-11 follow-up #2 — format kept failing, root-caused + fixed, plus a full error-popup
redesign.** User tested format via the (then-existing) label popup: confirm→Yes→"SD format failed"
every time. Live serial capture caught the real error: `f_mkfs failed (3)` = FatFs `FR_NOT_READY`.
Traced through actual ESP-IDF source (`ff.c` line ~5958, `diskio_sdmmc.c`'s `ff_sdmmc_initialize`):
`f_mkfs()` calls `disk_initialize()` first, which for this SD driver means `sdmmc_get_status()`
(CMD13) — after hours of accumulated read timeouts (0x107) against the bad card, even this trivial
status command was failing, so `f_mkfs()` aborted before attempting anything. Root cause is
plausibly the SD card's own protocol state staying wedged across ESP32 reboots/reflashes (only the
chip resets, not the card's power/silicon, since CS is a fixed CH422G GPIO not toggled per
transaction). **Fix:** `sd_storage_format()` now calls `sd_storage_reconnect()` (full SPI bus
reinit + fresh CMD0 card reset) immediately before attempting the format, giving the card a clean
protocol state first. NOT yet confirmed to actually fix the real corrupted card (needs the user to
retest — the OLD UI that let them test was itself broken, see below).

While diagnosing, the user separately caught a real logic bug via the error-code popup: 5008
(`UI_ERR_SD_MOUNT_FAILED`, boot-time mount-failed) and 5009 (`UI_ERR_SD_IO_FAIL`, runtime I/O
fail) were showing simultaneously, which shouldn't be possible if 5008 truly means "never mounted"
— the user's own diagnosis: "마운트가 안됬는데 왜 리드/라이트를 시도했지?" (if unmounted, why did
the code even attempt read/write?). Root cause: `stats_store.c`'s read/write functions
(`stats_store_get_count()`, `stats_store_append_batch()`) called `fopen()` unconditionally,
regardless of `sd_storage_is_mounted()` — so an unmounted card's fopen failure got misclassified
as a 5009 I/O failure on top of the already-correct 5008. **Fixed**: both functions now check
`sd_storage_is_mounted()` first and return immediately (without touching `s_last_io_error`) if not
mounted — since all other stats_store functions funnel through `stats_store_get_count()`, this one
change protects the whole module.

**Full error/warning popup redesign** (triggered by the layout bug found when 재연결+포맷 buttons
were first added to the bottom row — the 630px-worth of buttons didn't fit the old 420px
`create_modal()` width, clipping "재연결 시도"). Extensive live design conversation produced a new
project-wide convention, see [[project_cntl_popup_close_vs_action_buttons]] — plain-dismiss popups
close via top-right X, popups where the *button itself* commits a decision keep bottom
confirm/cancel buttons. The error/warning list popup is the first (X-closed) case: content has
per-item actionable buttons now (`cb_logo_warning_tap` rebuilt in `ui_main.c`), so:
- Popup rebuilt as a custom `LV_PCT(80)`-wide overlay (not `create_modal()`'s fixed 420px — user
  wants screen-relative sizing going forward, though the *global* `create_modal()` policy change
  itself is explicitly deferred until after this bug is fully fixed).
- Header uses the existing `add_page_popup_header()` (X, top-right, red bg/white X) instead of a
  bottom "확인" button.
- Each error/warning row is now its own flex-row container: description label (left) + exactly one
  action button (right). Mapping (user's own words): "5008이면 리마운트, 5009면 포맷... 통신
  에러인데 지우고 싶으면 에러끄기" — `UI_ERR_SD_MOUNT_FAILED`→재연결, `UI_ERR_SD_IO_FAIL`→포맷,
  everything else (including ALL warnings)→새 "지우기"(Dismiss) button.
- The old asymmetric policy ("워닝은 확인 시 전체삭제, 에러는 영구") is retired — user: "앞으로
  경고, 에러를 같은 방식으로 처리하면 되지". New `ui_log_clear_one_error()`/
  `ui_log_clear_one_warn()` (in `ui_log.c`) remove exactly one code from history; the row's
  "지우기" button deletes just its own row widget and calls a new
  `sync_error_warn_active_from_history()` (recomputes `s_error_active`/`s_warn_active` from
  live history counts — replaces the old one-way "sticky latch" that never reset).
  **Exception**: SD codes (5008/5009) do NOT get a manual "지우기" — user: "SD는 검증 후
  지워야 해" — they only clear via `clear_sd_io_fail()`, called after a 재연결/포맷 attempt
  succeeds AND a follow-up `sd_verify_healthy()` (a real `stats_store_get_count()` probe) also
  passes; that function now also calls `ui_log_clear_one_error()` for both 5008 and 5009 (whichever
  is present) since a verified-healthy card means neither is still true, regardless of which
  button was pressed.
- Storage label text coloring: `s_storage_status_label` now has `lv_label_set_recolor(..., true)`
  enabled (this was the exact thing missing in an EARLIER Claude attempt at this — see
  [[feedback_lvgl_no_percent_f]]'s sibling gotcha, user: "네가 한 거야" — forgetting
  `lv_label_set_recolor()` made `#RRGGBB text#` print as literal text before). Text is now built as
  `"SD: #ff0000 <message>#"` — "SD:" stays default color, only the message is red (user: "SD:
  빼고만 빨간 색으로 해").
- Also surfaced but NOT yet built: the time-set popup violates the same X-vs-bottom-button
  convention (has both "닫기" and "OK", but "OK" actually applies/commits the RTC write, so it
  should be labeled "적용" not "OK") — flagged as a known other violation, not fixed this pass.

Build+flash+30s boot capture (2026-09-11) confirmed no crash/regression, but the popup redesign's
actual on-screen rendering (rows, buttons, X close, SD: color split) and whether format now
actually succeeds against the real card are BOTH still unconfirmed — need the user's own
touchscreen test next.

**2026-09-11 follow-up #4 — ACTUAL ROOT CAUSE FOUND AND FIXED, card was never bad.** User replaced
the (previously assumed "dead") card with a new one while CNTL stayed powered — reconnect still
failed with the same `esp_vfs_fat_sdspi_sdcard_init failed (0x107)`. A full reboot with the new card
DID mount successfully. User's own diagnosis ("코드에 문제가 있다는 거 같은데") was correct — see
[[feedback_no_hardware_blame_cntl_arbiter]]'s 4th documented occurrence for the full story of how I
wrongly concluded physical card failure. Real bug, found by re-reading `sd_storage.c`: CS (via the
CH422G I2C expander, `CH422G_IO_SD_CS`) is asserted LOW once at first use and **never deasserted
anywhere in the codebase** — `sd_storage_reconnect()` re-inits the SPI bus and re-probes the card,
but CS had already been continuously LOW since boot, so the standard SD SPI-mode-entry edge (CS HIGH
during power-up/dummy-clock preamble, THEN CS LOW before CMD0) never actually happened for a newly
inserted card during a software-only reconnect. Only a true power-cycle (full reboot resets CH422G's
own output state) produced that edge implicitly, which is why "reboot works, reconnect doesn't" was
the exact symptom. **Fix**: `sd_storage_init()` (shared by both the boot path and
`sd_storage_reconnect()`) now does an explicit CS HIGH → `spi_bus_initialize()` → 100ms delay (also
covers the ESP32-S3 power/signal-stabilization mitigation found via web research on the same 0x107
error, e.g. https://github.com/espressif/esp-idf/issues/11438) → CS LOW → mount, instead of the old
single unconditional CS-LOW-only call. **Confirmed working**: user pulled the card, verified it reads
perfectly in a different PC's reader (proving the card was always healthy), reinserted it into CNTL
running the fixed firmware, and it read fine. Also fixed in the same pass: a toast showing garbled
text because `mark_sd_io_fail()`'s context strings (fed into `ui_log_add_err()`, which drives the
bitmap-font-rendered toast) were in Korean — changed to English, matching this project's established
"English logs, bitmap font has no Hangul glyphs" convention. Also fixed: reconnect/format failure
used to close ALL popups back to the main screen instead of returning to the Resolve-choice popup —
`cb_sd_reconnect_tap`/`cb_sd_format_tap`/`cb_sd_format_confirmed` now only close the Resolve popup on
SUCCESS, leaving it open (with the alternate action still available) on failure. Also renamed the
Resolve popup's reconnect button from "재연결 시도"/"Try Reconnect" to "재마운트"/"Remount" per user
request.

**2026-09-11 follow-up #3 — further live design pass, all implemented+built+flashed:**
- User caught the recolor fix wasn't actually broken — they were looking at the "not mounted"
  (5008) branch, which was never colored (only the "SD 오류"/I-O-fail branch was). Root cause of
  the confusion, not a code bug.
- User then spotted real duplication: the "SD: <message>" text was hardcoded separately in two
  places, with mismatched titles ("Storage" for the normal-capacity text vs "SD:" for the new
  error text). Fixed: new `set_storage_label_text(const char *detail, bool is_error)` in
  `ui_main.c` is now the ONE place that builds `"SD: <detail>"` (red via recolor if `is_error`),
  called from all three label states (normal capacity breakdown, unmounted, I/O-fail) — title
  unified on "SD:" per user's choice ("SD: 가 짧아서 좋아"). Unmounted state is now ALSO shown in
  red (it maps to 5008, which is an error condition) — this wasn't explicit before but follows
  from user's normal-vs-error binary framing.
- Popup title changed: "Error code list"/"에러 코드 목록" → "Error / Warning status"/"에러/워닝
  상태".
- **Big change to the SD action buttons**: the earlier 5008→재연결-only / 5009→포맷-only mapping
  is GONE. User's reasoning: blindly retrying the same action (reconnect) when the root cause
  persists is just an infinite loop, AND the old mapping made it impossible to reach 포맷 when
  only 5008 was showing (no format button on that row) even if the user wanted to skip straight
  to format. New design: both 5008 and 5009 rows now show one shared "해결"/"Resolve" button
  (`cb_sd_resolve_tap`). Tapping it closes the error-list popup and opens a new small popup
  (title "SD 조치 선택"/"Resolve SD Issue") with BOTH "재연결 시도" and "포맷" buttons always
  available side by side, regardless of which code triggered it — confirmed explicitly: "현재로선
  이 두가지 뿐이지? (디스크 도구 같은 거 없으니까)" — yes, only these two recovery mechanisms
  exist, no disk-repair/diagnostic tool. This resolve-choice popup is X-closed (not bottom-button
  only) per the user's own classification: "행위가 있는 팝업이니까" (it has actionable content —
  the format/reconnect buttons — same category as the error-list popup itself).
- All of the above is built, compiles clean, flashed to COM19, boots without crash (confirmed via
  serial). Visual/interactive confirmation on the physical screen is still the user's to do next.

**Status: fully designed and agreed with the user 2026-09-10.** This
supersedes/corrects the task-isolation work described in
[[project_cntl_tx_queue_full_root_cause_2026_09_10]]'s SD-crisis follow-up — that work is now
judged to have been built on a wrong diagnosis and should be REMOVED, not built upon.

**The wrong turn (important context, don't repeat):** Earlier the same day, a real SD card fault
was found (block 8256 repeatedly failing with `error 0x107`), causing multi-second stalls and an
IDLE0 task-watchdog trigger when the stats popup was open. I diagnosed this as a "hang" (안돌아와)
problem and built an elaborate fix: moved all stats-popup SD I/O to a dedicated `stats_io_worker_task`
in `ui_main.c`, with two mutexes (`s_stats_io_mutex` for snapshot handoff, `s_stats_graph_buf_mutex`
for the graph debug-dropdown's buffer), a `kick_stats_io_worker()` notify pattern, an exited-semaphore
for safe teardown, and careful priority tuning (had to fix 10→3 after it starved LVGL/input entirely
by outranking the LVGL task's priority 6). Each fix revealed a new bug (teardown blocking 1.5s,
input dropped, "개떡" — a mess) until the user walked me through a Socratic three-way failure
taxonomy that revealed the actual root cause was simpler and my whole architecture was solving the
wrong problem.

**The corrected diagnosis (the three-way failure taxonomy, keep applying this framework generally):**
1. **Fail** (즉시 또는 유한시간 내 리턴, 에러코드로 알림) — handle by checking the return value.
   The actual observed SD error IS this class: `sdmmc_send_cmd` returns `0x107` cleanly, bounded by
   `command_timeout_ms` (ESP-IDF default 1000ms per command) — never truly infinite.
2. **행/Hang** (무한히 안 돌아옴, 사실상 죽음과 동급) — return-value checks and try/catch cannot
   help (nothing is ever returned/thrown); the only real defense is isolating the call onto its own
   task/thread so nothing else waits on it, set up BEFORE the call, since once inside a hang there's
   nothing to do from outside. Timers/timeouts are irrelevant here except as bounding a task's own
   wait-for-signal from another task.
3. **죽음/Die** (crash/hard-fault) — split into **crash** (unrecoverable at task level; ESP32/FreeRTOS
   has no per-task MPU isolation, so a hard fault in ANY task typically panics/reboots the WHOLE
   chip regardless of task separation — task isolation gives zero protection here) vs. **exception**
   (a language-level catchable throw, protectable via try/catch — not really present in this
   codebase's plain-C SD/FatFs call chain, so not directly actionable here). Crucially: **dying is
   instantaneous, not a duration — timers/timeouts are conceptually meaningless as a defense against
   it** ("이걸 타이머 걸고 죽을 때까지 기다려?" — user's own words, calling out the absurdity).

**What the real bug actually was:** the stats-tab refresh did 4 overview channels +
1 table page + 4 graph channels×2 passes of SD I/O per tick, ALL fail-class, but the calling code
never checked "did the last one already fail" before trying the next — so many ~200ms-1000ms
individual fails accumulated sequentially into multi-second stalls that looked like a hang from the
outside (watchdog trigger) but were structurally just unhandled repeated fails. **"제일 바보같은
코딩은 fail인 결과를 무시하다가 프로그램을 먹통만들거나 죽이는 거"** — user's own summary of the
actual bug class. General principle also stated: try/catch-style broad protection is a
development-time safety net; mature/production code should convert known failure modes into
explicit return-value branches instead — which is exactly what was missing here.

**Also established: try/catch (or task isolation, its no-exceptions equivalent) only matters for the
행/hang and 죽음/die classes, never for fail** — and the observed problem was pure fail. This is why
today's task-isolation architecture, while functioning, was solving a non-existent problem at real
cost (complexity, several new bugs, and — per a separate live memory-cost investigation earlier the
same day — the stats popup's OWN baseline memory usage already drops free internal RAM to ~40KB even
at minimum settings, so adding a ~5-10KB permanent-while-popup-open task made an already-tight moment
tighter for no real benefit).

**Root cause of the SD corruption itself:** most likely a CNTL hard-reset (there were many today,
each app-only reflash does `--after hard-reset`) landing mid-`stats_store_append()` write (the write
happens synchronously inside `recv_cb`, ESP-NOW's own callback context, under `s_nodes_mutex`, very
frequently — every WAKE_HELLO_SENS cycle). FAT is not crash-safe by design (no journaling); a reset
mid-write (specifically mid the internal multi-step FAT-chain-extend operation, not just the visible
`fwrite()` call) can leave the FAT table/directory entry inconsistent, which later reads then trip
over as a reproducible hardware-level read failure at a fixed LBA. No card reader is available on
this PC, so no way to inspect/repair the card externally; the actual current card (as of 2026-09-10)
has this corruption and reformatting (not "repair") is the accepted fix for it specifically — see
"immediate action" section below.

**Full agreed design (everything needs implementing, in `Cntl/main/`):**

1. **Remove today's task isolation** — delete `stats_io_worker_task`, `s_stats_io_mutex`,
   `s_stats_graph_buf_mutex`, `s_stats_io_exited_sem`, `s_stats_io_task`, `s_stats_io_stop`,
   `kick_stats_io_worker()`, `stats_io_compute_*`/`stats_io_render_*` split, the `worker_ready`
   orphan-handling in `build_stats_tab()`, and the corresponding teardown logic in
   `teardown_stats_tab()`. Go back to a single set of refresh functions running directly on the
   LVGL task via the existing 2s `s_stats_page_timer` — but with proper fail-handling this time
   (below), not the original always-blindly-loop-through-everything version either.
2. **SD command timeout stays at ESP-IDF default (1000ms)** — do NOT shorten
   `sdmmc_host_t.command_timeout_ms` (a `= 200` change was tried and explicitly reverted). Reasoning:
   the default is already bounded (fail, not hang); the actual fix needed was fail-handling in the
   caller, not a faster per-command failure. Also: `open()` doesn't modify the file, so it being slow
   carries zero corruption risk even across a crash — no reason to rush it.
3. **Fail circuit-breaker, confirmed explicit design** — "SD 조회 fail이면, 다른 값도 믿을 수 없어.
   즉시 중단이지." On the FIRST fail encountered anywhere in one stats-tab refresh tick (any of the
   4 overview channels, the table page read, any of the 4 graph channels), abort the ENTIRE REST of
   that tick immediately — don't keep trying the other channels/table/graph, since if SD has a
   problem, nothing else read this tick can be trusted either. This alone bounds worst-case per-tick
   SD time to roughly one command's timeout instead of accumulating across ~10+ operations.
4. **SD write path also needs fail-handling audit** — `stats_store_append()` (called from
   `esp_now_hub.c`'s WAKE_HELLO_SENS handler, inside `recv_cb`, under `s_nodes_mutex`) already does
   a clean `if (!f) {...; return;}` check (already correct per the fail-handling principle) but has
   NOT been reviewed as thoroughly as the read path — audit it and everything else touching SD for
   proper fail-checking. This is explicitly still open/not done.
5. **Batch multiple writes into one open-write-close instead of separate ones** — general principle
   stated by the user ("쓸 것들이 여러 개면 모아서 한 번에") — applies both to the SD-corruption-
   prevention angle (fewer separate risk windows) and specifically to the new graph per-scale
   pre-aggregated writes (item 6 in the graph plan below): don't do 5 separate file
   open/write/close cycles for the 5 scale tiers when one raw value arrives, collect and write them
   together.
6. **UI notification on fail — mandatory, and must be reachable even if the stats popup itself
   can't open.** Design: "fail이면: 통계 팝업에 'SD 이상으로 저장이 안되고 표시에 오류가 있다'고
   알려주고 통계 팝업 띄우든지, 상태에 따라 통계 팝업을 띄울 수 없다고 알려주든지." Because the
   popup itself may become un-openable in a bad-enough SD state, **the SD status indicator and
   recovery actions must live on the main screen (주화면), not only inside the stats popup** —
   confirmed explicitly after I pointed out the contradiction of a popup-only notification when the
   popup itself might refuse to open.
7. **"SD 재연결 시도" (reconnect) button, main-screen-reachable.** Verified technically feasible:
   ESP-IDF provides `esp_vfs_fat_sdcard_unmount(base_path, sdmmc_card_t *card)` (in
   `vfs_fat_sdmmc.c`) which cleanly does `f_mount(0,...)` + `ff_diskio_unregister()` +
   host-deinit + `free(card)` + `esp_vfs_fat_unregister_path()`. Pair with `spi_bus_free(SD_SPI_HOST)`
   (already called in `sd_storage.c`'s existing mount-failure path) then re-run the exact
   `sd_storage_init()` sequence (CS assert via CH422G, `spi_bus_initialize()`, `esp_vfs_fat_sdspi_mount()`,
   `mkdir()` stats/photos — already EEXIST-tolerant). This covers BOTH "same card recovered
   externally then reinserted" and "brand new card inserted" — no hardware card-detect signal needed
   (none confirmed present in the schematic — CS is CH422G EXIO4, no separate detect line seen),
   since this is a user-triggered software unmount+remount, not automatic hot-swap detection.
8. **"포맷" (format) button, main-screen-reachable.** Verified feasible: `f_mkfs()` capability is
   already present in this build (`format_if_mount_failed` config option exists in
   `esp_vfs_fat_mount_config_t`, confirming the underlying formatting code is linked in). Needs a
   confirm popup ("모든 데이터가 삭제됩니다") — destructive, matches the existing confirm-popup
   pattern used for "전체삭제"(delete-all-stats) etc.
9. **Immediate practical action (once code above ships), separate from the code work:** the
   currently-installed SD card is corrupted (block 8256) — accepted fix is **reformat it** (not
   "recover" — no card reader available on this PC to inspect/repair externally, and the data
   (~7h of sensor readings) isn't precious at this dev stage). No code change needed for folder
   recreation — `sd_storage_init()` already does EEXIST-tolerant `mkdir()` for `/stats` and
   `/photos` on every boot.

**How to apply when resuming:** this whole plan was fully designed via an extended live Socratic
session and explicitly confirmed complete by the user ("더 없습니다... 설계가 잡힌 것 같습니다") —
do not re-derive or re-litigate the design, just implement items 1-8 above directly. See
[[project_cntl_stats_graph_redesign_2026_09_10]] for the companion graph-storage plan that shares
principle 5 (batched writes) with this one.
