---
name: project-cntl-dashboard-web-mem-display
description: "Cntl dashboard summary panel now shows the web dashboard URL (line 1) and live internal/PSRAM free memory (line 2), shipped 2026-08-22"
metadata: 
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-22T01:47:40.563Z
---

Summary panel (`summary_box` in `ui_main.c`) gained two always-updated lines above the paired-device
list, both user-requested and user-placed ("Summary 판넬 둘째줄에 넣어야겠군"):

- **Line 1** (`s_web_url_label`): `"{웹/Web} http://<ip>:80"`, hidden until an IP is actually held.
  `esp_now_hub.c`'s WiFi/IP event handlers now track `s_own_ip_str` (cleared on disconnect, set on
  `IP_EVENT_STA_GOT_IP`) with a public getter `esp_now_hub_get_own_ip_str()`.
- **Line 2** (`s_mem_status_label`): `"{메모리/Memory} : I = <internal> / P = <psram>"`, refreshed every
  tick via `heap_caps_get_free_size(MALLOC_CAP_INTERNAL)` / `(MALLOC_CAP_SPIRAM)`.

Both values go through a new helper, `format_bytes_human()` (`ui_main.c`) — auto-scales a byte count to
B/KB/MB/GB and picks decimal precision so the mantissa always shows ~4 significant digits (e.g.
`12345` -> `12.34KB`, `56789012` -> `56.78MB`; whole bytes show with no decimal). General technique:
divide by 1024 while >=1024 (max 3 times), then decimals = 3/2/1/0 for mantissa <10/<100/<1000/>=1000.

**Repeat mistake caught here (4th time this session's user has had to correct it):** initially
hardcoded the literal string `"웹(Web) http://..."` directly into the label instead of adding proper
`ui_strings.h` entries. This user's convention — writing `"웹(Web)"` in an instruction — means "add a
`{ko, en}` pair to the `ui_strings` table," not "display both languages concatenated on screen." Fixed
by adding `STR_LABEL_WEB`/`STR_LABEL_MEMORY` (`{"웹","Web"}` / `{"메모리","Memory"}`) and using
`ui_str(...)` in the format string. See [[feedback_confirm_understanding_before_acting]] for the
broader pattern-recognition failure this session, and check `ui_strings.h`/`ui_strings.c` for the
established pair-table pattern before ever hardcoding user-facing text in this codebase again.

Committed 2026-08-22 (commit 3169d1b) together with several other pending fixes — see
`Docs/한일_2026-08-22.txt`.
