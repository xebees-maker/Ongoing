---
name: project-cam-cntl-ping-pong-redesign-proposal
description: "IMPLEMENTED 2026-08-25/26 as part of the CASK protocol redesign — PING/PONG removed entirely from esp_now_channelsync, both CAM/CNTL build clean"
metadata:
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-25T22:43:15.268Z
---

**Status: IMPLEMENTED.** The proposal below was fully carried out as part of the larger CASK redesign
— see [[project_cam_cntl_known_hub_direct_wake_protocol]] (also now implemented) for the complete
protocol that replaced this. `ESP_NOW_MSG_CHANNEL_PING`/`_PONG` + structs removed from
`esp_now_link.h`; `esp_now_channelsync.c/.h` had all ping-timer/pong-tracking code deleted (no more
`s_ping_timer`, `s_pong_pending`, `s_ping_fail_count`, `esp_now_channelsync_notify_alive()`,
`esp_now_channelsync_set_ping_interval_ms()`); `cam_speaker`'s `SPK_EVT_PING`/`SPK_EVT_PONG` sounds
removed (see [[reference_cam_speaker_event_table]], now 8 events not 10). CAM and CNTL both build
zero-warnings/zero-errors with this removed. Not yet hardware-flashed/live-tested as of this writing.

The reasoning below is kept as the historical record of *why* — still useful if this direction is ever
questioned again.

**Immediate context this came out of**: investigating [[project_cam_cntl_pairing_state_machine]]'s
open "PING never gets PONG" item. Live testing that day (after restoring the previously-`#if 0`'d
PING-fail→re-scan reaction) showed the reaction working, but also surfaced live confusion about what
CNTL's "Active"/"Paired"/"Waiting" labels actually mean (`hub_conn_state_t` in esp_now_hub.c:166-170 —
counterintuitively, "Active" = raw `conn_state==NODE_CONN_PAIRED` right now, "Paired" = was paired this
boot session but not raw-PAIRED at this instant, e.g. mid deep-sleep gap — this reassurance-label
behavior is itself by design, confirmed normal).

**The reasoning chain, built turn-by-turn with the user (Socratic, not dictated by either side alone)**:
1. CHANNEL_PING/PONG (`esp_now_channelsync`, part of the Layer 0 component) and the `esp_now_reliable`
   ARQ stack were both added in the same commit (`4661958`, 2026-08-05, confirmed via `git log
   --diff-filter=A`) — so PING/PONG predating "reliable messaging existing" is NOT the reason it's a
   raw fire-and-forget message; that's a deliberate design choice (avoiding circular dependency —
   liveness-detection can't depend on a retry stack whose own retry logic would need liveness
   info) documented in the component header.
2. PING/PONG DOES predate CAM's Deep Sleep architecture: channelsync 2026-08-04/05, Deep Sleep
   transition 2026-08-10. It was designed for a continuously-awake (or light-sleep) CAM that needed
   ongoing in-session monitoring of whether CNTL/router had changed channel (see the channelsync
   header's original hkhome-router-CSA rationale).
3. PING's actual direction is CAM checking CNTL's liveness (CAM sends CHANNEL_PING, CNTL replies
   CHANNEL_PONG unconditionally, CAM counts consecutive failures) — not mutual/two-way. CNTL has no
   proactive "is CAM alive" mechanism at all; confirmed via full read of esp_now_hub.c that
   `last_seen_ms` is only ever read passively (list-timeout filter in `esp_now_hub_get_nodes()`,
   status-label calc in `esp_now_hub_is_reconnect_stuck()`) — never drives any active behavior
   (no peer deletion, no state reset, no message sent) purely from CAM's silence.
4. Under CAM's actual Deep Sleep model, `s_conn_state` (esp_now_cam.c) is plain RAM, NOT
   `RTC_DATA_ATTR` — confirmed via grep (only `s_last_synced_channel`, a channel-hint, persists via
   RTC memory; `s_hub_mac` is also plain RAM, forgotten every reboot). So **every wake is a full reset
   to ORPHAN and will naturally re-advertise from scratch regardless of whether PING/PONG detected
   anything** — the PING-fail→re-scan reaction's outcome (resume advertising) is already guaranteed to
   happen on the very next scheduled wake anyway, with or without it.
5. CNTL already gets a periodic liveness signal for free every response_interval_sec from
   `DEEP_SLEEP_STATS` (sent once after config-set, then repeating at the response-interval cadence
   while PAIRED — see esp_now_cam.c `stats_timer_cb`) — no CHANNEL_PING needed for CNTL's side of the
   liveness question either.
6. **Conclusion**: PING/PONG's only case with genuine, non-redundant value is when CAM stays
   continuously awake without a sleep/reboot boundary to fall back on — i.e., Live mode
   (`response_interval_sec == 0`), or an abnormally long single wake window. In the normal
   periodic-deep-sleep case, the continuously-running heartbeat is likely pure overhead (radio/CPU use
   for no behavioral benefit) and was implicated as the source of the whole "PONG never arrives" bug
   hunt that day.

**The proposal, corrected (2026-08-25, same session, user caught my mischaracterization)**: remove
PING/PONG entirely — NOT "keep it but scope to Live-mode-only" (my first summary got this wrong and the
user corrected it immediately: "핑퐁 없애기지... live모드 전용이 아니고"). For normal periodic-sleep
operation, rely on the natural full-reboot-per-wake cycle (already guarantees re-discovery) plus
DEEP_SLEEP_STATS (already guarantees CNTL-side liveness signal) instead of PING/PONG. Live mode
(`response_interval_sec == 0`) is explicitly NOT covered by "just keep running the current PING/PONG
mechanism for that case" — the user flagged that Live mode admits "또 다른 해석"(another/different
interpretation) of how to handle liveness there.

**Live-mode question now resolved** (see [[project_cam_cntl_known_hub_direct_wake_protocol]] for full
detail): no separate mechanism needed after all — Live mode reuses the exact same wake/CONFIG/work/
SLEEP_NOW sequence, with `SLEEP_NOW(0)` meaning "loop instead of deep-sleeping" and a fixed 1-second
self-paced check-in cadence (work-time-aware: wait out the remainder of 1s if work finished early,
resend immediately if work already took >=1s) standing in for `response_interval_sec` as both the pacing
value and CNTL's liveness-judgment window for that node.

**Follow-up, same session**: the "skip broadcast-ADVERTISE, persist s_hub_mac/channel" idea that was
bracketed out here got fully fleshed into a complete protocol skeleton later the same session — see
[[project_cam_cntl_known_hub_direct_wake_protocol]] for the whole thing (known-hub unicast wake message,
retry/fallback rules, CNTL-side active liveness judgment, unified CONFIG->...->SLEEP_NOW command
sequence). That file is now the authoritative one for this direction; this file stays authoritative for
the narrower PING/PONG-removal reasoning specifically.

**How to apply**: when resuming CAM/CNTL protocol work, treat this file as the authoritative record of
the reasoning if the user references "핑퐁 없애는 거" or similar — do not re-derive from scratch, but
also do not implement until they explicitly say to proceed. Cross-reference
[[project_cam_cntl_pairing_state_machine]] for the still-open, never-actually-diagnosed root cause of
why PONG concretely fails to arrive (this proposal sidesteps that question rather than answering it —
if PING/PONG is scoped out of non-Live mode, the original mystery becomes moot for normal operation but
would still apply to Live mode).
