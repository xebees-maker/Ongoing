---
name: project-caml-bat-en-latch-missing-resolved
description: "CAML/CAM battery-mode 'dies right after boot' mystery RESOLVED 2026-08-23 — root cause was missing BAT_EN latch GPIO, not WiFi/light-sleep/RTOS"
metadata:
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-23T01:24:52.163Z
---

RESOLVED 2026-08-23: the multi-hour mystery of CAM (Waveshare ESP32-S3-CAM-OVxxxx board,
experimental CAML fork) failing to stay alive on battery power — appearing in CNTL's "대기 중"
list only briefly at power-on, then going completely silent (no ADVERTISE/PING/PONG at all,
not just sync loss) — had nothing to do with WiFi modem sleep, ESP-IDF Automatic Light Sleep,
FreeRTOS tickless idle, or SD/SDMMC PM-lock interactions. All of that investigation (see
[[project_cam_dvp_corruption_investigation]] session context) was chasing a red herring.

**Actual root cause**: the board's schematic (Waveshare ESP32-S3-CAM-OVxxxx) has a CH32V003
I/O-expander pin **EXIO5 = BAT_EN** that must be driven HIGH by firmware early in boot to
*self-latch* battery power on. The physical PWR button only connects the battery to the
regulator *momentarily*; releasing it cuts power entirely unless software has already asserted
BAT_EN. CAML's `bsp_esp32s3_cam_init()` never touched this pin (only the two SD_ENABLE expander
pins were set) — so the board only stayed powered while a finger physically held the PWR
button down, and died the instant it was released. This exactly explained every earlier symptom:
"works right at power-on then goes silent within seconds," "USB always works" (USB itself
supplies power independent of the latch), "PWR+BOOT tap didn't reliably power on," etc.

**How it was found**: user proposed replacing unreliable SD-card logging with an onboard-speaker
audio-log (ES8311 codec + NS4150B amp, confirmed via schematic pinout table: I2S_MCLK=IO10,
SCLK=IO11, LRCK=IO12, DSDIN=IO14, CODEC_SCL/SDA=IO7/8 shared bus, PA_CTRL=EXIO4). With distinct
tones mapped to 6 events (power-on-battery, power-on-USB, scan-sweep-done, advertise-sent, ping,
pong — see [[project_cam_speaker_event_sounds]] if that memory exists), the user could hear in
real time that sound (and thus the whole chip) stopped the moment the PWR button was released,
and resumed the moment it was held down again — a signal no amount of log-file archaeology had
surfaced, because every prior test's log-fetch procedure implicitly involved touching the board.

**Fix**: `ch32v003_set_output(BSP_CAM_IO_EXPANDER_BAT_EN_PIN /* = CH32V003_IO_5 */, true);` added
unconditionally (not just on battery boot) as the very first step inside
`bsp_esp32s3_cam_init()`, in `CAML/components/bsp_esp32s3_cam/bsp_esp32s3_cam.c`. Confirmed fixed
2026-08-23: CAM now survives USB unplug -> continued battery operation with no reboot, and
pairing/"대기 중" stays fully normal without the button being held.

**How to apply**: (1) this fix needs to be ported to the production CAM firmware, not just the
CAML experiment — CAM and CAML share the same physical board/schematic (see [[reference_cam_cam_ovxxxx_schematic]]
if that memory exists) but this pin was never set in either. (2) The light-sleep/Automatic-Light-Sleep
work in CAML remains a separate, legitimate, still-open investigation for later — it was not the
cause of tonight's dying-on-battery symptom, but may still matter for power consumption once basic
battery operation is confirmed solid. (3) [[feedback_dont_relitigate_ruled_out_hardware]] and
[[user_experience_level]] both apply here — the user's persistent skepticism of every "confirmed"
log-based conclusion (repeatedly demanding literal documentation/evidence, catching a backwards
SD-write-cache theory, insisting on distinguishing USB vs battery test sessions rigorously) is what
eventually forced the investigation methodology (live audio feedback) that surfaced the real bug —
trust that instinct in future sessions rather than resisting the repeated corrections.
