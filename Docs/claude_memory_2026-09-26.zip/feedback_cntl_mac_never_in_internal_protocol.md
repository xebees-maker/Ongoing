---
name: feedback-cntl-mac-never-in-internal-protocol
description: "Cntl's own WiFi MAC must never appear in any Bridge/CAN/ESP-NOW internal protocol payload, now or in future additions"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 20e69685-62be-44b4-97d5-accb4eb2dbe9
  modified: 2026-09-23T05:19:21.369Z
---

콘(Cntl)의 WiFi MAC 주소는 브-콘 CAN 프로토콜이나 브-캠 ESP-NOW 프로토콜 등 어떠한 내부망
프로토콜 페이로드에도 들어가면 안 된다. 이미 구현된 코드뿐 아니라 앞으로 추가되는 모든 내부
프로토콜에도 적용되는 일반 규칙(2026-09-23 확정).

**Why:** 콘은 ESP-NOW 라디오 자체가 없고(WROOM-1 non-U, 외부 안테나 옵션 없음 —
[[project_cntl_cam_steel_obstruction_relay]] 참고), CAN 쪽은 고정 CAN ID로 주소를 정하지
MAC을 안 쓴다. 즉 콘의 WiFi MAC은 이 내부망 어디에서도 라우팅/주소 지정 목적으로 쓰일 자리가
없는 값이다. 실제로 이 원칙을 어긴 구현(esp_now_hub.c의 ADVERTISE_ACK/PAIR_REQUEST의
hub_mac 필드에 esp_wifi_get_mac()으로 콘 자신의 MAC을 채워 넣음)이 캠의 PAIR_ACK을 도달
불가능한 주소로 보내게 만들어 PAIR_REQUEST가 13/13 항상 타임아웃되는 실제 버그의 원인이었다
(코드로 확인, can_link.c/esp_now_hub.c/esp_now_cam.c 브릿지-CAN 전환 작업 중 발견).

**How to apply:** 브-콘-캠 사이에 새 메시지 필드나 프로토콜을 설계/리뷰할 때, "콘의 MAC"이
값으로 들어가는 필드가 있으면 즉시 잘못된 설계로 판단한다. 주소가 필요하면 실제 프레임의
물리적 발신지(예: ESP-NOW의 info->src_addr처럼 드라이버가 채워주는 값)를 쓰거나, CAN ID처럼
이미 확정된 고정 식별자를 쓴다. 단순히 "그 필드를 안 믿는다"로 우회하지 말고, 애초에 페이로드
구조체에서 그 필드 자체를 제거하는 것이 올바른 수정이다 — 기껏 넣어놓고 안 믿을 거면 애초에
넣지 말아야 한다는 게 사용자의 명확한 지적이었다.
