---
name: feedback-ui-strings-i18n-hardcode
description: "Never hardcode a literal user-facing string in Cntl's UI code, even a short one added on the fly — always add a ui_strings.h/.c {ko, en} pair and call ui_str(). Repeated 4 times before it stuck, caught again 2026-08-22."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-29T10:58:46.373Z
---

Cntl's UI (`ui_main.c` and friends) has one mandatory convention for **every** piece of user-facing
text: an entry in the `ui_str_id_t` enum (`ui_strings.h`) plus a `{korean, english}` pair in the table
(`ui_strings.c`), retrieved via `ui_str(STR_...)`. This is not optional for "just one small label" —
it applies even to a single quick label added mid-session.

**The specific trap, confirmed directly by the user**: when the user writes an instruction like
`"웹(Web)"`, that notation means "this is the `{ko, en}` pair to add to the table" — `웹` is the Korean
string, `Web` is the English string. It is **not** an instruction to literally print `"웹(Web)"` on
screen. Concatenating both languages into one hardcoded literal and displaying that is the exact
mistake, repeated 4 times across this session before being fully internalized — see
[[project_cntl_dashboard_web_mem_display]] for the concrete instance (the web-URL summary line).

**How to apply**: before writing any `lv_label_set_text`/`lv_label_set_text_fmt` call with a literal
string argument in Cntl's `main/` code, stop and check: does this string exist in `ui_strings.h`/`.c`
yet? If not, add the enum entry + table pair first, then call `ui_str(...)` — even for a one-off label,
even under time pressure, even if the user's own instruction was phrased as `"한글(English)"` shorthand
rather than spelling out "add this to the string table." Treat any `"한글(English)"`-style phrase in a
user instruction as shorthand for a table entry, never as literal display text.

**Repeated a 5th time, 2026-08-29 (WiFi-settings scan-list "connected" marker)**: while adding a
checkmark-style indicator for the currently-connected SSID in the scan result list
(`snprintf(label_buf, ..., is_connected ? "[연결됨] " : "", ssid, ...)`), the Korean literal was baked
directly into the format call instead of going through `ui_strings`. This time there wasn't even a
`"한글(English)"`-shorthand instruction to misread — it was a purely self-initiated string I typed
myself while implementing an unrelated fix, proving the trap isn't limited to parsing user phrasing;
it recurs any time a literal string gets typed inline as a quick fix. Caught by the user noticing
"목록에 연결됨은 영어로 해도 한글로 나온다" (the list's "connected" tag shows Korean even in English
mode). Fixed by adding `STR_TAG_WIFI_CONNECTED` to the table and calling `ui_str(...)`. **Extra
practical check**: literally search/scan your own just-written diff for any double-quoted Korean text
before considering a UI edit done — don't rely on remembering the rule in the moment of typing.
