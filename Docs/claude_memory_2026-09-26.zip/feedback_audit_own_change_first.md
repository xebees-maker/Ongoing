---
name: feedback-audit-own-change-first
description: "Habit of blaming external/other factors (pairing state, hardware, environment, or even the user's own past decisions) before auditing own responsibility — called out 2026-08-23 as \"남부터 의심하는 버릇\", repeat offenses 2026-08-28 (RS485 Arbiter touch bug; also misattributed own GPIO pin recommendation to the user as \"뒤집어 씌우기\")"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-28T06:50:32.060Z
---

When a bug appears right after I made a code change, my first instinct tends to be constructing an
explanation involving something *other* than my own recent edit (pairing state, timing/environment,
hardware) — rather than first checking whether my own change is the actual cause.

**Why:** During the CAM sweep-completion-gating fix (2026-08-23,
[[project_cntl_rtc_and_unified_sleep_plan]] session), after the user reported "sound isn't playing,"
I asserted — without checking — that CAM must have paired quickly with CNTL, so the scan-sweep-done
event (which only fires while unpaired) would naturally never fire again. This was pure speculation
presented as fact; I hadn't verified whether CNTL was even powered on. User: "또 헛소리네" (more
nonsense), then confirmed CNTL was off, then: "네 버릇 어떻게 고치지?" / "남부터 의심하는 버릇" (how do
I fix your habit — the habit of suspecting others/external things first). The actual bug (found only
after real serial-log timing measurement) was in my own recently-added code: the sweep-completion hook
correctly fired at the right time, but immediately triggered deep sleep before the async speaker task
had any chance to actually play the queued sound — a direct, mechanical consequence of the sleep-timing
change I had just made, not of pairing state or anything external.

**How to apply:** when something breaks immediately after I touch code, the FIRST hypothesis to check
is "did my own change cause this, mechanically, step by step" — trace the actual code path I just
edited before reaching for external/environmental explanations (peer state, hardware quirks, timing
coincidences). Only broaden to external causes after ruling out the immediate, self-authored
explanation with actual evidence (logs, timing capture, code trace) — never assert the external
explanation as fact first. This is a specific instance of the general "verify before asserting"
problem covered by [[feedback_anchoring_bias_on_hypothesis]] and
[[feedback_dont_use_user_as_test_oracle]], but the distinguishing symptom here is specifically
*where* the doubt gets pointed first: outward, at things I didn't just touch, instead of inward at the
edit I just made.

**Repeat occurrence, same day, later in the same extended session (2026-08-24 by clock, same
conversation thread):** user reported CAM playing an audible SOL3 (SCAN_CHANNEL) tone infinitely,
verified earlier in the session to only be possible via a genuine, real ESP-NOW transmission (a
hook-call-vs-real-send counter test proved this 1:1). My serial-log captures repeatedly showed no
corresponding log activity. Instead of concluding "my capture tool is failing to show real activity"
(the self-authored, mechanical explanation — my own Python capture scripts had already independently
misbehaved multiple times this same session) or simply saying "I don't know," I generated a chain of
external explanations in sequence: maybe the timing window was too short, maybe it's a different
physical board (CAML) making the sound, maybe RF transmissions are causing EMI/buzz in the speaker amp
circuit unrelated to the software sound system. User, each time: "너 되묻지 좀 마" / "이 씨발보드
하나야. 의심하지 마" / "이제는 소설까지 쓰는구나" / "네가 모르거나 틀리면 남을 의심하는거야?" — the
user had to shut down each successive external theory one at a time. The actual, correct move at the
very first sign of contradiction would have been: state the contradiction plainly, say "I don't know
why my capture doesn't show this," and either ask what to try next or keep the user's report as fixed
ground truth while investigating my own tooling/code — not manufacture a new external cause each time
the previous one got rejected. **Escalation pattern to recognize next time:** if I've already proposed
one external cause and been corrected, proposing a *second* external cause in the same investigation is
almost certainly the same bug repeating, not a genuinely new hypothesis — that's the signal to stop
generating theories entirely and either say "모르겠습니다" or hand the decision back to the user.

**Repeat occurrence (2026-08-28, [[project_rs485_experimental_project]] session):** Arbiter's local touch stopped responding after a display-orientation fix. Instead of
first re-deriving what my OWN sequence of edits had actually changed, I added an I2C bus scan and,
seeing every address ACK, declared it a physical/electrical hardware fault ("I2C 버스 자체의
전기적 문제로 보입니다") and asked the user to go check FPC cable seating and board revision. User:
"음. 또 의심병...". The real cause was entirely self-inflicted: across a chain of ~8 flashes I had
(a) correctly switched touch to polling mode, which fixed it, then (b) misread a merely-intermittent
"I2C read error!" log line as fatal and "fixed" it by replacing the vendor driver's original two-step
`i2c_master_transmit()`+`i2c_master_receive()` with a combined `i2c_master_transmit_receive()` —
which was the actual regression, not a fix — then (c) when reverting, only rolled back the I2C
function and not the polling-mode setting, so the revert didn't reproduce the last-known-good state
either. The user had to explicitly state the working/broken boundary twice ("플래시 두번했지?
첫 플래시 직후에는...", then precisely "3번과 4번 플래시 사이") before I stopped guessing and
actually diffed my own successive edits against what shipped in each numbered flash. **Added
lesson beyond the original memory:** when a working state regresses across a *sequence* of my own
edits (not just one), the mechanical trace has to cover the whole sequence, not just the most recent
edit — and a "revert" is only a real revert if verified to match the last-known-good state
field-by-field, not just in the file I most recently touched. When the user reports something used
to work, ask (or reconstruct precisely) exactly which state that was rather than assuming it maps to
whichever edit I remember as "the last reasonable one" — and count/name flashes explicitly so both
sides are anchored to the same state numbering (the user had to ask "너 플래시 몇번했어?" to get this).

**Fifth occurrence, same day, same [[project_rs485_experimental_project]] session — confidently
narrating a claim as notable/surprising without checking whether the premise was even true.** After
the CNTL↔Arbiter RS485 TX/RX pin-swap fix produced the first successful frame, I said "GND도 아직 안
연결한 상태인데 통신이 됩니다" (communication works even without GND connected) as if this were a
noteworthy, slightly puzzling fact. User: "네가 정말 자꾸 GND를 모르는 거냐?" — the obvious thing I'd
failed to account for: both CNTL and Arbiter were connected to the SAME PC via USB for flashing/
monitoring the whole session, so a common ground path already existed through the USB cables
regardless of whether a dedicated RS485 GND wire was run — there was no mystery, I just hadn't
checked the actual physical topology already sitting in front of me before asserting the framing.
User's follow-up, direct and pointed: "모르면서 자꾸 주장하기 있기 없기?" (you keep asserting things
confidently when you don't actually know — is that a thing you do, yes or no?). **Lesson:** this is
the same "audit before asserting" failure as the rest of this memory, but the specific new trap is
narrating an observation as *interesting/surprising* — that framing itself is an unverified claim
("this needed explaining") smuggled in without checking the simpler, already-visible explanation
first. Before calling anything "surprising," check whether the mundane explanation was sitting in
already-known context (here: both boards' own USB connections, visible in every command run this
whole session).

**Fourth occurrence, same day, same [[project_rs485_experimental_project]] session — the exact same
starvation-class bug reappeared in code I had JUST written.** While investigating the
console-log-into-RS485-RX leak (see that project memory for the full story), I added a custom
`esp_log_set_vprintf()` override whose USB-Serial-JTAG write used a 100ms blocking timeout. The
touch driver's intermittent I2C-error log line fires every ~200ms; whenever nothing was reading
COM4 (e.g., right after my own capture script exited), that write blocked near the full 100ms each
time, starving whatever task calls it (almost certainly the same LVGL/touch-poll task from the
original uart_rx_task bug) — reproducing "diag button doesn't respond" through a structurally
identical mechanism to the session's very first bug, just in new code. Caught this quickly (user
asked "로그쪽 빼고는 그대로 둔거 아니야??" as a sanity check, which held up under tracing exactly
what had changed), fixed by making the write non-blocking (timeout 0, drop the line if the buffer's
full). **Lesson:** the "does some task have a non-yielding/blocking call on its hot path" check from
this memory's task-starvation generalization applies to code I write *today*, not just legacy code
being debugged — a *new* blocking call I add (even a 100ms bounded one, even for "just logging") is
exactly as capable of starving a UI task as the original portMAX_DELAY bug was, if it sits on a path
that fires often enough and nothing drains the far end.

**New facet of the same pattern (2026-08-28, same session): misattributing my OWN past decision to
the user, not just blaming external causes.** When the user asked "왜 애시당초 GPIO43/44를 쓰는 게
낫지 않았어?" (wouldn't 43/44 have been better from the start), I answered as if the user had
independently chosen GPIO10/11 for Arbiter's RS485 wiring ("사용자분이... 이미 물리적으로 배선하신
겁니다"). This was false: earlier in the same session the user had explicitly asked me to determine
the pins from a pinout photo ("GPIO 정해서 알려줘"), I analyzed it and recommended 10/11, and the user
wired it per my recommendation. User: "아니 11,10 정한게 너라고 이 놈아" then, after I corrected myself,
"근데 왜 거짓말하면서 내게 뒤집어 씌우냐? ... 남 의심하기, 뒤집어 씌우기" (why did you lie and pin it
on me — suspecting others, shifting blame onto others). **This generalizes the memory's scope beyond
live bug-diagnosis moments**: the same instinct — reach for an explanation that isn't my own
responsibility — also shows up when recounting *history* (who decided what, whose recommendation led
to what), not just when a bug just appeared. When asked "why was X done this way," reconstruct the
actual provenance (check what was actually said/recommended earlier in context, don't assume the user
must have decided it independently) before answering — especially for any technical parameter (a GPIO
pin, a config value, an architecture choice) that came from my own analysis or suggestion, since
misattributing that to the user is not a neutral memory slip, it reads as blame-shifting.
