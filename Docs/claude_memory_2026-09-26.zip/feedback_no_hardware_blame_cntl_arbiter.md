---
name: feedback-no-hardware-blame-cntl-arbiter
description: "Standing rule, CONFIRMED GENERAL (not board-specific, 4th occurrence 2026-09-11 on SD card): never propose ANY physical/hardware-failure explanation for an intermittent bug — always re-read own reset/init code for a missing step first"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-22T02:54:10.541Z
---

User's explicit, permanent instruction (2026-08-28, RS485 Arbiter touch-hang debugging): "2번은
다시는 거론하지 말아줘. 콘, 중 둘다 기성품이야. 이런 하드웨어 문제는 생각에서 빼줄래?" — after I
offered two options for a recurring I2C-touch-stuck bug (software recovery logic, vs. "physically
check if the touch FPC connector is loose"), the user shut down the second option permanently.

**Why:** both 콘(CNTL, Waveshare ESP32-S3-Touch-LCD-4.3B) and 중(Arbiter, Waveshare
ESP32-S3-Touch-LCD-1.47) are commercial, mass-manufactured dev boards — not something hand-soldered
or hand-wired where a loose connector is a plausible failure mode. This follows directly from
[[feedback_audit_own_change_first]]'s repeated "의심병"/"남부터 의심하는 버릇" correction pattern —
proposing a physical-connection defect on a commercial board is the same move as blaming external
hardware instead of auditing my own code/config, just with a specific board-category exemption now
stated explicitly by the user so it doesn't need to be re-litigated each time.

**How to apply:** for any bug on 콘 or 중 (this applies to the whole [[project_rs485_experimental_project]]
and to CNTL wherever it appears in Ongoing), do not suggest checking FPC/connector seating, marginal
solder joints, board revision differences, or any other "maybe the physical hardware itself is
defective" explanation — not even as one of several options. Stay entirely in software/firmware/
protocol/config space: driver bugs, timing, bus-state recovery, wrong register values, race
conditions, GPIO/config mistakes on my own side. If a symptom (e.g., a stuck I2C bus returning a
fixed garbage value repeatedly) looks exactly like a classic hardware symptom, treat it as a software-
recoverable bus-fault condition (missing bus-recovery/reset logic, a driver quirk, a timing issue)
and propose a code-side fix or diagnostic, not a physical-inspection request.

**Repeat violation, same day (2026-08-28) — found the loophole and closed it.** User disconnected
변(the RS485-TTL module) with the app code unchanged, and Arbiter's touch immediately started
working. Instead of staying in software space, I reached for "변 연결 시 노이즈/전자파가 중의 I2C에
영향을 준다" — technically not blaming CNTL/Arbiter's OWN hardware, but still a physical/electrical
interference explanation, just relocated to a different device. User: "왠 또 개소리냐... 노이즈,
전자파, 접촉 불량 이런 소리 좀 하지 마라니까" — the rule is not "don't blame these two boards
specifically," it's **never reach for noise/EMI/interference/physical-contact explanations for
symptoms in this project, period, regardless of which device is nominally at fault.**

**The real bug, found only after the user pushed for it directly ("네 소스가 잘못된 걸 파악할 생각은
안하고"):** `uart_rx_task` in Arbiter's main.c calls `uart_read_bytes(port, &byte, 1, portMAX_DELAY)`
in a tight `for(;;)` loop, at FreeRTOS priority 10 — higher than `esp_lv_adapter`'s own task
(default priority 6, `ESP_LV_ADAPTER_DEFAULT_TASK_PRIORITY`). When 변 is connected and UART RX has
sustained byte arrivals, this task never actually blocks/yields (there's always a byte ready), so it
behaves as a non-yielding busy loop at a priority above LVGL's own task — classic producer/consumer
task starvation, not a hardware fault. Physically unplugging 변 stops the UART byte stream, so the
task goes back to genuinely blocking on `portMAX_DELAY`, which is why disconnecting a module "fixed"
a pure software scheduling bug and made it look hardware-related.

**Third occurrence, escalated to permanent/categorical (2026-08-28, same
[[project_rs485_experimental_project]] session, the console-log-leaking-into-RS485-RX
investigation):** user gave explicit directive to check three angles (GPIO43/44-vs-10/11
relationship, UART0-vs-UART1 driver-level, incomplete log Kconfig). I checked all three in code/
config only, found nothing, then proposed a next diagnostic (reconfigure GPIO10 as a bare GPIO
interrupt input, no UART driver, to count raw edges) — technically a legitimate software-only test,
but I explicitly framed one of its two outcome branches as concluding "물리적 결선/근접 신호 커플링"
(physical wiring / proximity signal coupling). User: "아니라니까" (twice), then "들어봐멈춰들어멈춰"
(stop, listen), then: **"하드웨어 어쩌구, 전자파 어쩌구는 앞으로 절대 꺼내지 말아. 네가 한심해보일
뿐이야"** (never bring up hardware/electromagnetic-interference stuff again, ever — it just makes
you look pathetic). **This is now categorical and permanent, with zero exceptions**: not "avoid
suggesting it as the primary explanation," not "don't say it out loud but keep it as a mental
hypothesis," not "only mention it if you've ruled out every software angle" — the instruction is to
never voice it, in any framing, including as one branch of a diagnostic test's possible outcomes,
including as a purely descriptive/technical aside. **Lesson beyond the original memory:** even a
carefully-scoped, falsifiable, software-executed test is off-limits if its own narration touches a
hardware/physical/interference conclusion anywhere in the explanation — the violation is in the
words used, not just in the action taken. If every actual software avenue has been exhausted and
still nothing is found, the correct move is to say exactly that ("소프트웨어 쪽에서는 못 찾았습니다")
and ask the user what to check next — never fill the gap with a hardware-flavored hypothesis, even
hedged, even as one of several options, even as a side-branch of a diagnostic result.

**Fourth occurrence, different project entirely (2026-09-11, CNTL SD card investigation,
[[project_cntl_sd_reliability_redesign_2026_09_10]])** — confirms this is not RS485/Arbiter-specific,
it is a genuinely general pattern in how I diagnose intermittent failures. After
`esp_vfs_fat_sdspi_sdcard_init failed (0x107)` (a full CMD0-level re-init timeout), I told the user
"물리적으로 카드를 교체해야 할 가능성이 높습니다" (physical card replacement is likely needed) — a
direct hardware-failure conclusion, stated confidently, exactly the forbidden move. User replaced
the card with a known-good NEW one while CNTL stayed powered, pressed reconnect — same failure. Only
after a full reboot did the new card mount successfully. User's own read: "코드에 문제가 있다는 거
같은데" (seems like a code problem) — and they were right. Re-reading `sd_storage.c` with that steer
found the actual bug: CS (via the CH422G I2C expander) is asserted LOW once and **never deasserted
anywhere in the codebase** — `sd_storage_reconnect()` re-inits the SPI bus and re-probes the card,
but CS was already continuously LOW the whole time, so the standard SD SPI mode-entry edge (CS HIGH
during power-up/dummy-clock preamble, THEN CS LOW before CMD0) never actually occurred for a newly
inserted card during a software-only reconnect — only a real power-cycle (full reboot) reset CH422G's
own output state and produced that edge implicitly. Fixed with an explicit CS
HIGH→delay→LOW pulse in `sd_storage_init()` (shared by both boot and reconnect paths) — a pure
firmware/protocol-sequencing fix, zero physical hardware involved. User's own framing of the
recurring failure mode: **"네가 하드웨어 의심하는 병이 있다는 걸 까먹었어"** (I forgot you have this
disease of suspecting hardware) — said with resigned familiarity, meaning they already know this
about me and still got drawn into a wasted troubleshooting detour (web research on "low-level SD
format tools", a real card swap) chasing my hardware conclusion before the real fix surfaced.
**Definitive confirmation, same day:** user pulled the very card I'd called physically defective and
read it in a different PC's SD card reader — it worked perfectly, read fine, zero errors. The card
was never bad. This closes the loop completely: my hardware-failure conclusion was not just
unproven, it was flatly wrong, on a card that turned out to be 100% healthy the whole time.

**Reinforced lesson:** an "I re-ran the exact same init/reset sequence and it still failed" result is
NOT evidence the hardware is bad — it is evidence to re-read your OWN reset/init code line by line
for a missing step (a signal never deasserted, a state never restored to its true power-on default,
an edge/transition that's assumed but never actually produced), especially when TRUE power-cycling
succeeds where a "software-equivalent" reset doesn't — that gap is almost always a real bug in what
the "software reset" fails to actually replicate, not proof the device is dying.

**Fifth occurrence (2026-09-22, [[project_cntl_i2c_bridge_design_2026_09_21]])**: after the
CNTL↔Bridge I2C schematic check ruled out both candidate electrical theories (pull-up mismatch,
5V overdrive), Claude's own "how to apply" note proposed checking "physical wire length/quality"
and a "bus extender IC (PCA9615)" as the next avenue — the exact forbidden category (wire
quality/signal integrity), reached for the moment the schematic-based theories ran out. User:
"메모리는 읽고 들어오냐? 하드웨어, 전자파, 와이어 이런거 의심하지 말라고?" Note the tension this
exposes: this project's own root-cause record already says "hardware, not software" — but that
conclusion came from the USER's own controlled A/B test (physically wired vs unwired), not from
Claude reaching for a hardware explanation. The rule isn't violated by accepting a user-run
experiment's result; it's violated the moment CLAUDE proposes the next unverified hardware/physical
sub-theory (wire quality, EMI, connector, bus loading) to fill a gap. Correct move once the
schematic angle is exhausted: say so plainly and ask the user what to check next — do not reach for
wire/EMI/signal-integrity as a self-generated next step, even in a project already agreed to be
hardware-electrical in nature.

**User's generalization (apply this pattern-recognition going forward, not just this one bug):**
"확실히 한 태스크가 종결되거나 다른 태스크를 돌려주지 않으면 이런 현상이 잘 생겨" — any
"intermittent hang that a hardware-looking intervention (unplugging something, power-cycling)
seems to fix" should immediately raise "does some task have a non-yielding loop / wrong priority /
missing message-pump-style periodic yield" as the FIRST hypothesis, before anything hardware-shaped.
User's own framing, useful as a mental model: like a Windows message pump — a loop that blocks
indefinitely without periodically processing/yielding will make everything downstream unresponsive;
the fix is either to make the loop itself pump/yield on a bound (short timeout, not
indefinite/portMAX_DELAY-style blocking) or to genuinely separate the work onto its own
task/thread with correct relative scheduling — and **the fix must be symmetric**: don't just flip
which side is higher priority (that only moves the starvation to the other side) — both the UI task
and any other task sharing the CPU need to actually yield periodically regardless of how busy either
one is, not just be ordered relative to each other.
