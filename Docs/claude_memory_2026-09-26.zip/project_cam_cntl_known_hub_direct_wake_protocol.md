---
name: project-cam-cntl-known-hub-direct-wake-protocol
description: "IMPLEMENTED + LIVE-VERIFIED 2026-08-26 as CASK (CAM+TASK): WAKE_HELLO fast-path wake protocol, CAM sleeps reliably, several post-implementation bugs found+fixed on real hardware"
metadata:
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-26T14:28:48.194Z
---

**Status: IMPLEMENTED AND LIVE-VERIFIED ON HARDWARE (2026-08-26).** User confirmed live: "완벽하게
동작한다. 지금까지는." (core sleep/wake cycle) and separately "응 이제 10으로 잘 나와" (response_interval
self-report field, after its own bugfix below). See the "Live hardware bring-up" section near the bottom
for the bugs this surfaced and how each was fixed — several were real pre-existing bugs the CASK work
exposed, not new bugs introduced by it.

**User's own end-of-session framing (2026-08-26)**, worth preserving verbatim as the canonical summary:
"오늘 한 작업을 크게 요약하면, 어제 설계한 프로토콜이 잘 동작한다는 걸 검증한거야. 불필요한 타이머,
중복된 레이어, 안 맞는 워치독 같은 거 거의 없앴고." (Today's work, broadly summarized: verified that the
protocol designed yesterday works well. Eliminated most of the unnecessary timers, redundant layers, and
mismatched watchdogs.) — i.e. today (2026-08-26) was verification + bugfixing of yesterday's
(2026-08-25) CASK design, not new design work. The concrete "removed" side of that framing: CAM's
ping timer, stats timer, `CASK_SILENCE_TIMEOUT_MS`(first try)/`effective_max_attempts` time-based retry
inflation, CNTL's adaptive-deadline timer, scattered per-feature `require_paired()` checks — see the bug
list below for the ones found+fixed specifically during today's live testing pass. The full skeleton
below was built almost exactly as specced, under the name **CASK** (user's coinage: CAM+TASK — the
deterministic `CAM_CONFIG_SET -> [queued commands] -> SLEEP_NOW` sequence CNTL sends in reply to a
WAKE_HELLO). Implemented across `esp_now_link.h`, `esp_now_channelsync.c/.h`, `esp_now_cam.c/.h`,
`cam_node.c/.h`, `cam_speaker.c/.h`, `esp_now_hub.c/.h`, `ui_main.c`, `ui_log.c/.h`. Approved via the
plan at `C:\Users\Dev\.claude\plans\majestic-churning-pancake.md` (kept as the authoritative
implementation-detail reference — exact struct layouts, function names, line-level call sites).

**What shipped, mapped to the skeleton points below**:
- Point 1 (known-hub unicast, no broadcast): `ESP_NOW_MSG_WAKE_HELLO`(46)/`_ACK`(47), new RTC fields
  `s_wake_hub_mac`/`s_wake_hub_channel`/`s_wake_hub_known` in `esp_now_cam.c`.
- Point 2/3 (retry then unified fallback): `esp_now_cam_try_wake_hello_fast_path()` via
  `esp_now_reliable_request()` (100ms x3); on exhaustion, `esp_now_cam_reconnect()` falls back to
  `esp_now_channelsync_init()`/`_resume_scan()` — one path for channel-changed/CNTL-dead/CNTL-doesn't-
  recognize-me alike, no branching by cause.
- Point 4 (handshake collapse): done — WAKE_HELLO replaces ADVERTISE_ACK->PAIR_REQUEST->PAIR_ACK for
  the fast path; that 3-step handshake is kept only for the fallback/first-ever-pairing path (also used
  independently by Sens, untouched).
- Point 5 (CNTL silent-ignore for unrecognized node): implemented exactly as specced — CNTL's
  WAKE_HELLO handler returns with no reply if `!ever_paired || user_unpaired`.
- Point 6 (CNTL-side active liveness, the "flip"): implemented as `liveness_sweep_cb()` +
  `s_liveness_sweep_timer` (1s period, no per-kind filtering — explicit user design, "모든 노드는 같은
  구조로 CNTL에 붙는다"), demoting stale PAIRED nodes to ORPHAN past `esp_now_hub_node_timeout_ms()`.
- Point 7/8 (CASK sequence, sleep-blocking): implemented in `cam_node.c`'s restructured `app_main`
  tail — explicit `for(;;)` loop, stays awake until `SLEEP_NOW` sets `s_sleep_now_requested`, plus a
  mid-CASK stall timeout, **`CASK_TIMEOUT_MS=15000`** (renamed/resized from an initial
  `CASK_SILENCE_TIMEOUT_MS=3000` — see "Live hardware bring-up" below for the full remove→reintroduce
  story) so CAM doesn't wait forever if CNTL's own reliable stack gave up mid-sequence.
- SET_TIME follow-up: resolved simpler than either original idea — `unix_time` folded directly into
  `esp_now_cam_config_t`, sent unconditionally every CASK cycle (no `has_valid_time` flag — user judged
  the flag/RTC-bool complexity not worth saving a few bytes on an already-mandatory message).
- Live mode: implemented as designed — `SLEEP_NOW.sleep_sec==0` means loop instead of deep-sleep,
  `CASK_LIVE_PACE_MS=1000` self-paced cadence, composes for free with the adaptive grace period (no
  Live-mode special case needed in `send_cask_sleep_now()`).
- Channel question (flagged as "not yet addressed" below): resolved via `s_wake_hub_channel`
  (RTC-persisted, populated at "graduation" time using `esp_wifi_get_channel()`) — a real per-hub
  channel memory, distinct from `esp_now_channelsync`'s generic scan-order hint.
- CNTL's "no unified queued-commands concept" gap: resolved by construction — the WAKE_HELLO handler
  itself IS the single dispatcher (`push_cam_config_to()` then whatever's queued then
  `send_cask_sleep_now()`), no separate queue data structure was needed.

**Also removed as part of the same implementation** (redundant once every reconnect is CAM-initiated
with its own bound): `ESP_NOW_MSG_SLEEP_NOW_REQUEST`, `ESP_NOW_MSG_HUB_RESET`, `hub_boot_id`. UNPAIR was
kept as the one deliberate exception (not replaced by silent-ignore, since it's a real-time user action)
but upgraded from raw `esp_now_send()` to the reliable stack.

**Live hardware bring-up (2026-08-26) — bugs found and fixed after the initial implementation above,
during real sleep/wake cycle testing**:

- **Core "CAM never actually sleeps" bug — an ordering bug, NOT a race condition** (user firmly corrected
  this terminology mid-session: "네가 레이스라고 해서 내가 오해했잖아" — it's deterministic, not
  timing-dependent). `cam_node_reset_sleep_now_state()` (clears `s_sleep_now_requested`/
  `s_sleep_sec_from_cntl`) was being called AFTER sending WAKE_HELLO/PAIR_ACK instead of BEFORE — a real
  SLEEP_NOW arriving in that window got silently clobbered by the reset. Fixed by moving the reset call
  to right before the send, at both the fast-path and fallback/graduation send points. This was the fix
  that produced "완벽하게 동작한다."
- **`CASK_SILENCE_TIMEOUT_MS` was removed entirely mid-session, then reintroduced as `CASK_TIMEOUT_MS`**:
  first found to be sized wrong (3000ms compared against a single message's budget, when CNTL actually
  sends messages sequentially — the correct comparison is the sum, already >3000ms). User then walked
  through Socratic reasoning concluding the whole mechanism was unneeded (WAKE_HELLO's own retry+fallback,
  esp_now_reliable's retries, and RWDT already cover every failure mode) — removed entirely. Live testing
  then surfaced a real gap: SLEEP_NOW can be silently lost with nothing left to time it out, leaving CAM
  stuck awake indefinitely. Reintroduced at **15000ms**, framed correctly per the user's correction as
  "widening WAKE_HELLO's own success judgment to cover the whole CASK sequence completing" — not a new
  timer concept. Sized as CONFIG(800ms×3) + largest work item PHOTO_LIST_REQUEST(3000ms×3) +
  SLEEP_NOW(300ms×3) ≈ 12.3s + margin. On expiry, CAM calls `esp_now_cam_reconnect()`.
- **CNTL `esp_now_tx.c`: `effective_max_attempts()` — genuine pre-existing bug, found via code reading
  after user asked "이게 왜 시간 기반이지? 횟수 기반이 아니고?"**. It inflated retry counts (up to ~44
  attempts for SLEEP_NOW at response_interval=10s) based on obsolete "CAM might be asleep" reasoning that
  CASK made moot (every `esp_now_tx_enqueue()` call now happens in direct response to CAM having just
  contacted CNTL, so CAM is provably awake at call time). Removed entirely; retries are now purely
  count-based via the caller's literal `max_attempts`.
- **CNTL `esp_now_tx.c`: silent queue-full drop — genuine pre-existing bug**, found the same way ("큐
  풀이면 최소한 에러라도 냈어야 하고, 큐 크기가 너무 작잖아"). `TX_QUEUE_LEN` raised 8→32; a full queue
  now logs `ESP_LOGE` + `ui_log_add_err(UI_ERR_TX_QUEUE_FULL, ...)` (new error code 2009) instead of
  silently dropping the request.
- **CNTL power-log AW/SLEPT fields were wrong**: AW (awake time) was reporting cumulative-since-boot
  instead of delta-since-last-report; SLEPT was echoing the commanded `sleep_sec` instead of measuring
  actual elapsed wall-clock time. Fixed in `cam_node.c`: `s_last_wake_hello_report_ms` tracks the delta
  for AW; `s_sleep_entry_unix_time` (new `RTC_DATA_ATTR time_t`) + `time(NULL)` at wake computes real
  elapsed sleep for SLEPT, and `cam_node_get_last_actual_sleep_sec()` now **consumes** (zeroes) the value
  after one report so it doesn't repeat stale numbers across multiple WAKE_HELLOs in one boot.
- **CNTL power-log "I" field (response_interval_sec self-report) alternated 0/10 every cycle** — found by
  the user's own precise live observation ("I는 초기 10초인데 오히려 10초 잠들면서는 0초로 보고하네").
  Root cause: `s_response_interval_sec` in `cam_node.c` was a plain `static uint32_t`, reset to the
  Kconfig default (0) on every full reboot (CAM reboots every deep-sleep cycle), and WAKE_HELLO is sent
  BEFORE that cycle's CONFIG message arrives to update it — so every post-reboot WAKE_HELLO reported the
  stale reset value instead of the last-applied one. Fixed by making it `RTC_DATA_ATTR`. **Confirmed
  live**: "응 이제 10으로 잘 나와."
- **Multi-device mac isolation gap, found and fixed during this same pass**: `s_capture_stage`/
  `s_delete_all_state` in `esp_now_photo.c` had no per-node mac tracking, so one CAM's capture-now/
  delete-all would incorrectly block ALL paired nodes from being sleep-eligible. Fixed by adding
  `s_capture_cam_mac`/`s_delete_all_cam_mac`, checked in the new
  `esp_now_photo_is_transacting_with(mac)` (used by `send_cask_sleep_now()`'s "통신 중엔 안 재운다" gate
  — CNTL sends `sleep_sec=0` while any transaction with that specific node is in progress).
- **A CAM-side "wait for busy before sleeping" addition was tried then explicitly reverted** — user
  corrected that the existing adaptive grace period (recent CNTL user action → sleep_sec=0) already
  covers the scenario it was defending against, and the addition wasn't justified first. Reverted;
  `esp_now_cam_is_busy()` removed again.

- **CAM-only reset (CNTL left running) confirmed to reconnect cleanly**: user tested resetting just the
  CAM board while CNTL stayed up, confirmed correct recovery: "캠만 리셋해도 정상동작하는 군. 아주 좋아."
  Validates the fast-path/fallback design (point 3 above) end-to-end on real hardware, not just the
  CNTL-restart direction.

CAM, CNTL, and Sens all build clean as of 2026-08-26 (Sens via its unrelated fallback-only path,
untouched by this redesign). Original design skeleton kept below verbatim for reference.

**Motivating fact-check that opened this**: grepped every `RTC_DATA_ATTR` in CAM and read the actual
linker map (`CAM/build/cam-node.map`) — RTC slow memory total capacity is 8KB (`rtc_slow_seg`,
0x2000), current usage from the 4 existing RTC vars (`s_last_synced_channel`,
`s_last_actual_sleep_sec`, `s_unpaired_backoff_elapsed_sec`, cam_speaker's `s_enabled`/`s_solo_mask`) is
only 52 bytes (0x34). Room is not a constraint — nothing like `s_hub_mac` (6 bytes) is currently
persisted only because the design never called for it, not because it wouldn't fit. Confirmed CAM's
current design philosophy is "remember small hints to re-discover faster," never "remember enough to
skip re-discovery."

**The protocol skeleton, built entirely Socratically (user answered each question one at a time)**:

1. **Trigger**: if CAM has a known/remembered CNTL (persisted `s_hub_mac` + last channel, new
   RTC_DATA_ATTR fields not yet added), it does NOT broadcast ADVERTISE on wake at all. It sends a new
   unicast "I'm awake" message straight to that remembered hub_mac/channel. Broadcast ADVERTISE is
   reserved for the case of no known CNTL (never paired, or forgotten).
2. **Retry**: ~3 quick retries if no response, at a fast cadence explicitly decoupled from
   `response_interval_sec` (~0.1s apart floated as a number, described as unavoidable hardcoding).
3. **Fallback, deliberately unified**: after retries exhaust, CAM falls back to full broadcast-ADVERTISE
   discovery — treated as equivalent to a full ORPHAN/reset state. This single fallback path is used for
   ALL of: CNTL's WiFi channel changed (CSA), CNTL is genuinely powered off/dead, AND (see point 6) CNTL
   is alive but no longer considers this CAM paired — no cause-specific branching, by explicit design
   principle ("채널이 바뀐거나 CNTL이 죽은거나 마찬가지야. 재연결 시퀀스를 동일하게 타야지").
4. **Handshake collapse**: on success, this replaces the current 3-step ADVERTISE_ACK→PAIR_REQUEST→
   PAIR_ACK dance with a single reliable request + ACK'd response (using the existing `esp_now_reliable`
   stack). Justification given: this is short-range communication (not long-distance/lossy), so one
   reliable round trip is sufficient confirmation — no need for the old multi-message verification
   sequence that assumed channel alignment still had to be proven.
5. **CNTL-side unrecognized-node handling**: if CNTL receives this unicast wake-message from a node it
   does NOT currently consider paired (user-unpaired, or CNTL itself lost state e.g. after its own
   reboot), CNTL should just silently ignore/drop it — no explicit rejection message. CAM's own
   retry-then-fallback timeout (points 2-3) already produces the identical outcome, so no new message
   type is needed. This elegantly reuses the SAME fallback path noted in point 3 for a third distinct
   cause ("CNTL alive but doesn't know me") — user explicitly confirmed this reasoning.
6. **CNTL-side active liveness judgment (a real behavior change from today)**: CNTL should itself watch,
   per node, whether the expected wake-communication arrived within that node's `response_interval_sec`
   window: if not, CNTL actively concludes the node is gone and updates its OWN state accordingly. This
   promotes today's entirely passive `last_seen_ms`-based mechanisms (`esp_now_hub_get_nodes()`'s list
   filter, `esp_now_hub_is_reconnect_stuck()`'s UI-label calc — see [[project_cam_cntl_pairing_state_machine]]
   for how those work today) into a real, state-mutating judgment, not just a display computation. This
   is the "flip" the user reasoned toward earlier in the same conversation: today PING/PONG makes CAM
   judge CNTL's liveness; in this design CNTL instead judges CAM's liveness, which the user argued is
   the more conventional pattern (the always-on party judges the intermittent party, not the reverse).
7. **Command delivery format — NOT a new batch/chunk wire format**: each command stays its own
   individual existing message type (CAM_CONFIG_SET, PHOTO_REQUEST, SLEEP_NOW, etc.) sent as separate
   reliable requests, exactly like today — but delivered as a defined, mandatory SEQUENCE rather than
   scattered/ad-hoc per-feature logic: **always starts with CAM_CONFIG_SET** (CAM has zero local config
   persistence — confirmed via grep, `s_capture_interval_sec`/`s_response_interval_sec` are plain RAM
   initialized from Kconfig defaults every boot — so this must be resent every single cycle to stay
   correct), whatever work-commands are actually needed in between (photo requests etc. — explicitly
   NOT special-cased, just another command in the sequence), and **always ends with SLEEP_NOW** as the
   sole terminal signal.
8. **Sleep-blocking simplified to one rule**: CAM stays awake for the entire sequence until SLEEP_NOW is
   received — no per-command "does this specific command need to block sleep" logic needed anywhere;
   SLEEP_NOW's mere absence is sufficient reason to stay awake. This resolves what the user had
   separately started to say earlier ("특정 명령이나 상태가 자면 안되는 것이 있다면...") before
   trailing off — the answer turned out to be "no special-casing needed, one universal rule covers it."

**Real, separate, currently-existing inefficiency found while discussing this (independent of whether
the bigger redesign happens)**: `SET_TIME` is resent by CNTL on every single re-pairing cycle today
(`esp_now_hub.c`, inside `if (became_paired)`, NOT gated by `first_ever_pairing` the way the
first-pairing-only reset logic is) — but ESP32 deep sleep preserves the RTC timekeeping domain, so
CAM's clock stays correct across sleep cycles and only genuinely needs setting once per power-cycle
(reset only by real power-loss/reflash, same class of event as the other RTC_DATA_ATTR resets). This is
real, currently-shippped waste, worth fixing on its own regardless of the bigger protocol redesign's fate.

**Resolved same session, after the skeleton above was agreed**:

- **DEEP_SLEEP_STATS (including battery) fully absorbs into the "I'm awake" wake message** — no
  separate message/timer. Checked the actual struct size: `esp_now_deep_sleep_stats_t` (wake_reason +
  awake_uptime_ms + sleep_interval_sec + actual_last_sleep_sec + battery_adc_raw + battery_mv, packed)
  is 19 bytes total — trivial against ESP-NOW's 250-byte payload limit, confirmed no size concern. This
  also makes battery reporting MORE reliable than today (today's DEEP_SLEEP_STATS is raw
  `esp_now_send()`, no ACK/retry at all; the new wake message uses the reliable stack).
- **Live mode does NOT need a separate protocol/interpretation** — user's proposal, confirmed sound:
  reuse the exact same `"나 왔어요"(wake) -> CONFIG -> [work commands] -> SLEEP_NOW` sequence for Live
  mode too. `SLEEP_NOW`'s duration parameter is simply whatever `response_interval_sec` already is —
  `0` in Live mode means "don't call `esp_deep_sleep_start()`, just loop back into another wake cycle"
  instead of a real sleep duration (consistent with today's existing Live-mode behavior of never
  sleeping). Pacing: CAM tracks how long the work-commands phase actually took against a fixed
  **x = 1 second** (user's chosen value) — if work took less than 1s, wait out the remainder then
  resend "나 왔어요"; if work already took 1s or more, resend immediately with no extra wait. This `x`
  interval doubles as CNTL's liveness-judgment window for Live-mode nodes (point 6 above), the same role
  `response_interval_sec` plays for normal periodic-sleep nodes — so CNTL's active-liveness-judgment
  logic doesn't need a Live-mode special case either, just needs to know which window (response_interval_sec
  vs. the fixed 1s) applies to a given node's current mode.

**Still not yet addressed / worth checking before implementing**:
- Which channel does the fast unicast "I'm awake" attempt actually use — presumably needs its own
  RTC-persisted "last known channel for this specific known hub" field (today's
  `s_last_synced_channel` is just a scan-order hint, not tied to "this is definitely CNTL's channel").
- Still interacts with the still-unresolved "why does PONG never arrive" root cause
  ([[project_cam_cntl_pairing_state_machine]]) — moot for actual future behavior once PING/PONG is
  removed per [[project_cam_cntl_ping_pong_redesign_proposal]], but worth remembering why this whole
  thread started.
- CNTL currently has no unified "queued commands for this node" concept (SLEEP_NOW/config-push/photo
  requests are each handled by separate, scattered logic) — user confirmed this needs consolidating,
  not just a CAM-side change; likely the larger half of the implementation work.

**How to apply**: this is now shipped, live-verified production behavior, not just a design to preserve.
Treat CASK as the current CAM↔CNTL wake protocol going forward — don't re-propose PING/PONG or the old
scattered per-feature push logic. The bug list above is the set of sharp edges already found and fixed;
if a similar symptom resurfaces (CAM not sleeping, stale power-log fields, one node blocking another's
sleep eligibility), check whether it's a regression of one of these specific fixes before re-diagnosing
from scratch. AW/SLEPT power-log fields also confirmed correct live by the user ("AW/SL도 정상이야",
2026-08-26) — all power-log fields (AW/SLEPT/I) are now live-verified, nothing left open on this thread.
