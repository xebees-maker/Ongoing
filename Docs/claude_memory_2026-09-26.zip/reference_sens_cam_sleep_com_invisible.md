---
name: reference-sens-cam-sleep-com-invisible
description: "Sens/CAM boards vanish from Windows COM ports entirely while deep-asleep — missing port means asleep, not disconnected"
metadata:
  node_type: memory
  type: reference
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-09T14:01:58.652Z
---

Sens and CAM are battery deep-sleep nodes (CASK wake cycle — see [[project_sens_cask_port_2026_09_05]]
and the CASK design in general). While a node is in deep sleep, its USB-serial COM port disappears from
Windows entirely — not a 1s flicker like [[reference_com5_flicker_behavior]] (that's a different,
already-documented quirk during active connection drops), but a real, sustained absence for however
long the configured sleep_sec/response-interval keeps it asleep.

**Why this matters:** User corrected 2026-09-09 ("이것도 자꾸 까먹네. 센스든 캠이든 슬립 들어가면
안보인다고") after I saw COM3 (Sens, per [[reference_cntl_cam_com_ports]]) missing from a port scan and
concluded "Sens 보드가 연결 안 되어 있습니다" (board not connected) — wrong conclusion. This is at least
the second time this specific mistake has been made.

**How to apply:** If COM3 (Sens) or COM5 (CAM) doesn't show up in a port scan, do NOT report or assume
"not connected" / "not plugged in." The correct read is "currently asleep, will reappear on its next
wake." Either wait, ask the user whether they want to trigger a wake, or just state the fact plainly
("COM3가 지금 안 보입니다 — 슬립 중일 수 있습니다") without concluding disconnection. Combine with
[[reference_cntl_cam_com_ports]]'s rule: don't preemptively scan "just to be safe" either — a scan is
only warranted when an actual flash/monitor command fails, and even then the failure's likely explanation
is sleep, not absence.

**Working technique to actually flash a short-sleep node (confirmed 2026-09-09, Sens at 10s sleep
interval):** blind retries of the full `esptool ... write-flash` command (even spaced ~1s apart) mostly
miss the awake window and just fail fast on "port doesn't exist" each time — esptool's own connect
sequence is too slow/heavy to use as the polling mechanism. Instead, tight-poll (~150ms) for the port's
existence alone via `Get-CimInstance -ClassName Win32_PnPEntity | Where-Object { $_.Name -match
'COM3\)' }` in a cheap loop, and fire the real `esptool write-flash` the instant it's seen. Once esptool
successfully connects and resets the chip into ROM bootloader/download mode, the chip is no longer
running the app's deep-sleep loop at all, so the flash can run to completion (took ~6-9s for Sens) even
though that's longer than the 10s sleep interval — the risk window is only "catching the initial
connect," not "finishing before it sleeps again."
