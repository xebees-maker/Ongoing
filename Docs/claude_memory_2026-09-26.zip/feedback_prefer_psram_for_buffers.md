---
name: feedback-prefer-psram-for-buffers
description: "CNTL design principle (2026-09-21): allocate all buffers (past and future, except LVGL-related) in PSRAM by default, even if the small variable/pointer referencing them stays in Internal RAM"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-21T10:49:30.859Z
---

User's standing principle for CNTL (2026-09-21, during the internal-RAM decline investigation):
**every buffer — existing code and anything written going forward — should be allocated in
PSRAM (`MALLOC_CAP_SPIRAM`) by default, not Internal RAM**, EXCEPT LVGL-related buffers (the
user explicitly excluded these — "이미 실패했음", referring to
[[project_cntl_stats_tab_memory_2026_09_06]] where esp_lvgl_adapter's tear-buffer turned out to
be hardcoded to internal RAM by the vendor component and not movable). The small variable/pointer
that *references* a PSRAM buffer is fine to stay in Internal RAM (its own size is negligible —
the principle is about where the bulk data lives, not the handle to it).

**Why:** this session found CNTL's main-screen internal free heap had declined from a ~57K floor
down into the 30-40K range, and root-caused two real contributors purely by grepping for `static`
buffers / dynamically-created FreeRTOS objects that defaulted to Internal RAM without an explicit
PSRAM request:
1. Two `static stats_bucket_t` working buffers in `ui_main.c` (kept `static` only to avoid
   putting large structs on the stack, per the 2026-08-03 stack-overflow rule) — converted to
   lazily-allocated `heap_caps_malloc(..., MALLOC_CAP_SPIRAM)` pointers, recovered ~5.5KB.
2. `esp_now_tx.c`'s per-connected-device TX worker: `xTaskCreate()` (4096-byte stack) +
   `xQueueCreate()`, both created lazily on a device's first communication and never torn down on
   disconnect — Internal RAM by default. Fix in progress: switch to `xTaskCreateStatic()` /
   `xQueueCreateStatic()` with the backing buffers allocated via
   `heap_caps_malloc(..., MALLOC_CAP_SPIRAM)` — this project's `CONFIG_SPIRAM_ALLOW_STACK_EXTERNAL_MEMORY=y`
   is already enabled and already used this way for the LVGL adapter task
   (`Cntl/main/main.c:674`, `adapter_config.stack_in_psram = true`), so there's a working
   in-codebase precedent for PSRAM-backed task stacks specifically.

**Status: CONFIRMED 2026-09-21.** The `esp_now_tx.c` worker fix tested well (44K→47K connected,
CASK-transient dip eliminated) and a follow-up round (queue_cb/task_tcb embedded-vs-lazy-pointer
fix, dispatcher queue/stack) pushed it to 53K — user then declared the general principle firm:
"모든 버퍼 (LVGL 제외)는 PSRAM에 최대한 넣는다." No longer conditional — apply by default,
LVGL excluded, going forward.

**How to apply:** whenever adding a new buffer (array, FreeRTOS queue/task stack, any
sizeable allocation) anywhere in CNTL app code, default to `heap_caps_malloc(size, MALLOC_CAP_SPIRAM)`
or the static-with-PSRAM-backing-buffer pattern, not plain `malloc`/`xTaskCreate`/`xQueueCreate`
— unless the object is LVGL-owned/LVGL-internal (out of scope per this principle) or there's a
concrete, stated reason it must be Internal (DMA requirement, ISR-safety, etc.). When auditing
existing code for memory issues, grep for bare `static <big-struct> name[...]`, `malloc(` without
a `MALLOC_CAP_SPIRAM` sibling nearby, and `xTaskCreate(`/`xQueueCreate(` as the concrete
grep-able signatures of this anti-pattern — this is exactly how both contributors above were
found.
