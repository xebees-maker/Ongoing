---
name: project-cntl-tx-queue-full-2026-09-09
description: "CNTL TX_QUEUE_FULL (error 2009) investigation 2026-09-09 — mutex-contention theory retracted, real cause likely LVGL starving tx_task; priority fix applied, not yet stress-tested"
metadata:
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-09T14:34:52.095Z
---

**Status: fix applied (tx_task priority 5→17), NOT yet confirmed to actually resolve the bug** — the
symptom reproduces inconsistently, so absence of recurrence isn't proof yet. User said they'd want a
stress test later ("나중에 네가 스트레스 테스트를 하든지") — not scheduled, just noted as a future option.

**Symptom:** UI toast "TX queue full, dropped: ..." (UI_ERR_TX_QUEUE_FULL / error 2009), from
`esp_now_tx.c`'s `s_tx_queue` (32 slots) overflowing when `xQueueSend(..., 0)` fails.

**Theory 1 (WRONG, retracted) — photo-transfer/CASK mutex contention.** Original hypothesis: CNTL's
`esp_now_photo.c` calls `esp_now_reliable_request()` (shared global mutex in
Common/esp_now_reliable.c) the same as `esp_now_tx.c`'s tx_task, so a concurrent photo transfer could
starve tx_task's queue-draining. **Disproven two ways:** (1) user reported the actual incident happened
with zero photo-transfer activity — CAM and Sens had simply just been connected together for the first
time that day, no photo fetch involved; (2) direct grep confirmed `esp_now_photo.c` has NO real call to
`esp_now_reliable_request(` — every match was inside Korean comments describing what the *remote CAM
device* does with that function, not CNTL's own code. tx_task is the only CNTL code that calls it.
Lesson: don't trust a grep match without checking whether it's a comment vs. real code
(see [[feedback_dont_invent_alternative_theories_over_stated_facts]]).

**Theory 2 (current best explanation, not fully proven either) — LVGL starving tx_task via FreeRTOS
priority.** Verified facts, all from source/sdkconfig, not assumption:
- `esp_lv_adapter` (LVGL managed component) default task priority = 6, no core affinity
  (ESP_LV_ADAPTER_DEFAULT_TASK_PRIORITY, not overridden in `main.c`)
- tx_task (`esp_now_tx.c`) was created at priority 5 — *lower* than LVGL
- ALL of CNTL's periodic main-screen refresh logic (clock/dashboard/sensor+camera lists/error-poll/
  stats/log/power) runs via `lv_timer_create`, i.e. inside LVGL's own task loop — so anything that
  makes the LVGL task busy for a while (e.g. constructing/tearing down the device popup: many widget
  creates, a keyboard object, `lv_obj_update_layout()` calls) can delay both LVGL's redraws AND any
  lower-priority task waiting for a CPU slot on the same core
- Neither task has FreeRTOS core affinity, so on the dual-core S3 they usually land on separate cores
  and don't contend — matching the observed "doesn't reproduce every time" behavior; the bug would only
  show up when they happen to want the same core at the same moment
- Symptom reported by user: opening/closing the device popup (Alias/settings popup) while CAM/Sens were
  connected, no other CAM action — consistent with heavy LVGL popup construction being the busy window
- User independently proposed the actual priority tiering ("통신 17 SR제어 15 파일처리 10") that led to
  fixing this — see [[project_cntl_task_priority_scheme_2026_09_09]] for the full scheme and the other
  ESP-IDF system task priorities checked along the way (lwIP=18, esp_event=20, esp_timer daemon=22,
  WiFi driver pinned to Core 0 but exact priority not found in accessible source)

**Fix applied:** `Cntl/main/esp_now_tx.c` — `xTaskCreate(tx_task, "esp_now_tx", 4096, NULL, 17, NULL)`
(was 5). Built and flashed same session. Not yet stress-tested; the bug's own irreproducibility means a
quiet period since the flash is weak evidence either way.

**How to apply:** if TX_QUEUE_FULL is reported again after this fix, the priority-starvation theory is
also wrong and a new investigation is needed — don't assume this memory's fix closed it without fresh
evidence. If asked to design a repro/stress test, the working theory to target is "many near-simultaneous
WAKE_HELLO events (CAM+Sens both checking in) while the device popup is being opened/closed repeatedly
on the UI."
