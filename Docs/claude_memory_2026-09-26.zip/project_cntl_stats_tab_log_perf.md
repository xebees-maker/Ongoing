---
name: project-cntl-stats-tab-log-perf
description: "Cntl statistics-tab log scroll was far slower than the other two tabs; root-caused to LV_LABEL_LONG_WRAP + large accumulated text + custom TTF glyph measurement, fixed 2026-08-22"
metadata: 
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-22T01:47:22.368Z
---

Symptom: 상황판/설정탭 스크롤은 부드러운데 통계탭(일반로그+전력로그)만 페이지/판넬 내부 스크롤 둘 다
심하게 느렸음. Root cause confirmed by reading code (not guessed): both logs accumulated up to several
KB of text into a single `lv_label` using `LV_LABEL_LONG_WRAP`, rendered with the app's custom runtime
TinyTTF font (NanumGothic) — WRAP forces a full re-measure/re-layout of the *entire* accumulated blob
every time the label's text is reset (every ~500ms tick when new lines arrive), and per-glyph width
measurement against a TTF font is inherently more expensive than a precompiled bitmap font. Dashboard/
option-tab labels never hit this: they don't call `lv_label_set_long_mode()` at all, hold only short
single-line strings, and are only rebuilt when the underlying node list actually changes (rare) — so
the font itself was never the differentiator, text volume + WRAP + refresh frequency was.

**Fix, per user's own 4-point design (all confirmed technically sound before implementing):**
1. Convert all `ui_log_add`/`ui_log_add_err`/`ui_log_add_warn` message strings to English (68 call
   sites across `esp_now_photo.c`(25)/`ui_main.c`(29)/`main.c`(7)/`ui_font.c`(4)/`esp_now_hub.c`(2)/
   `device_config.c`(1) — error/warning popup description tables `s_err_table`/`s_warn_table` were
   explicitly left out of scope) — this unlocks LVGL's built-in bitmap font (no glyph rasterization).
2. Unify both logs' font size to 20pt (`&lv_font_montserrat_20`, `CONFIG_LV_FONT_MONTSERRAT_20=y` was
   already enabled in `sdkconfig.defaults` — no menuconfig change needed). Previously general log was
   24pt and power log 18pt, both on the custom TTF.
3. Keep the existing byte-based cap/trim as-is — checked first and confirmed all three relevant
   buffers (`ui_log.c`'s `s_buf`, `ui_main.c`'s `s_power_log_buf`, and the log-box `snapshot` temp
   buffer) were already PSRAM-allocated from the earlier [[project_cntl_internal_ram_crunch]] fix, so
   no internal-RAM concern and no code change needed here.
4. Remove wordwrap entirely (`LV_LABEL_LONG_WRAP` -> `LV_LABEL_LONG_CLIP` on both log labels). Initial
   misunderstanding: assumed this meant restructuring to one-label-per-line + LVGL's `LONG_DOT` mode +
   a tap-to-expand popup. User corrected this — the actual, much simpler design is: **the app measures
   each line's pixel width itself** (`lv_font_get_glyph_width()`, summed byte-by-byte since content is
   now guaranteed ASCII — no UTF-8 decoding needed) and truncates the *string* with an appended "..."
   *before* display, done once per refresh in `ui_main.c` (not inside `ui_log.c`, which must stay
   LVGL/font-agnostic since it's called before UI init in some boot paths). No click handler, no popup,
   no widget-tree restructuring — the existing single-accumulated-label architecture is kept as-is.
   Implemented as `trim_to_width()`/`trim_multiline_to_width()` in `ui_main.c`, applied to a separate
   PSRAM-allocated display buffer right before `lv_label_set_text()` in both `refresh_log_box()` and
   `refresh_power_panel()` — the original accumulation buffers are never mutated.
5. (Added after the 4 points, same session) Unified timestamp formatting: new shared
   `ui_log_format_timestamp()` (`ui_log.c`/`.h`, `lv_tick_get()`-based `"[mm:ss] "`) called from
   `ui_log_add`/`_err`/`_warn` *and* from `refresh_power_panel()` (which previously built its own
   `[mm:ss]` prefix inline in two places) — one function, no err/warn-specific variant.

**Verification:** build passed clean; app-partition-only flash (0x10000, assets untouched so
`/assets/settings.bin` survived); user confirmed on real hardware "아주 다 잘 동작해" but could not
verify the "..." truncation specifically since no line long enough to trigger it occurred during the
test — **worth confirming this specifically next time a long log line appears**.

**Also clarified this session (pure Q&A, no code change):** dashboard and option tab still use the
custom TTF NanumGothic font at 18pt, unchanged — this is fine and was never the bottleneck (see root
cause above). Reverting the log labels back to the TTF font would keep almost all of the speedup (WRAP
removal is the dominant factor and is font-independent) but would be marginally slower than the
current bitmap font, since `trim_to_width()`'s per-character `lv_font_get_glyph_width()` calls hit
TTF's (potentially cache-missing) rasterization path instead of a bitmap font's flat table lookup —
not a reason to actually revert, just an accurate answer to a direct question about it.

Committed together with several other pending fixes from the same session in commit 3169d1b
(2026-08-22) — see `Docs/한일_2026-08-22.txt` and `Docs/handoff_2026-08-22.md` for the full batch.
