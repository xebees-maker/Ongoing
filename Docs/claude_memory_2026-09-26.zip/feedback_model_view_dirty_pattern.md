---
name: model-view-dirty-pattern
description: "General coding convention for this user's projects (established 2026-09-17, CNTL SR/Power Control popup): every settings-editing popup must follow global-model + deep-copy-on-open + dirty-by-struct-compare + apply-commits-all pattern, not ad-hoc widget reads"
metadata:
  node_type: memory
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-17T08:26:07.150Z
---

User walked through this pattern explicitly and step-by-step (CNTL SR/Power Control popup Apply-not-persisting
bug investigation, 2026-09-17), using an "온오프" (On/Off) example, then said: "이 체계를 잘 기억해(이건 아주
일반적인 건데)서 이전 코드들과 향후 작성할 코드들에도 항상 이런 식으로 짜야되" (remember this system well —
it's a very general pattern — and you must always write code this way, both retrofitting old code and for
everything written going forward).

**The pattern, in the user's own steps:**
1. The real value (e.g. relay On/Off direction) lives in a **static global** — the model.
2. On boot, load the model from its settings file; if the file has no value yet, just set an in-memory
   default (no need to eagerly write that default back to the file — the load path already reproduces it
   every boot until a real Apply happens).
3. The main screen/dashboard view updates **only when this global model value actually changes** — not a
   polling/recompute-and-string-diff loop (matches [[feedback_event_driven_not_polling]]).
4. When an editing popup opens, make a **deep copy** of the global model into a separate edit-buffer
   variable. All controls in the popup initialize from, and write into, this copy — never read/write the
   global directly while the popup is open.
5. **Dirty is itself a small model**, computed as: copy != original (a whole-struct comparison covering
   every field the popup can touch — "하나라도 바뀌면 Set" — any single field differing sets dirty=true).
   The Apply button's enabled/disabled state is just the **view** of this Dirty model — direct reflection,
   not independently tracked via "did some VALUE_CHANGED event fire."
6. Clicking Apply: copy the edit-buffer into the global, persist the global to file, close the popup.

**Why this matters (root cause it prevents):** the bug that triggered this explanation was Apply silently
not persisting — traced to reading scattered widget state at Apply-time instead of a real model, combined
with an "any interaction fires VALUE_CHANGED so enable Apply" dirty check that doesn't actually fire when
a control's value doesn't change from its (possibly wrong) default — leaving Apply stuck
`LV_STATE_DISABLED`, which LVGL's indev layer silently refuses to deliver click events to at all. A real
model + real struct-compare dirty check can't have this failure mode: a click is registered because Apply
is enabled exactly when copy≠original is actually true, and persisting a value is just copying the model,
never re-deriving it from live widgets that may or may not have fired an event.

**How to apply:** treat this as the standard construction for ANY settings-editing popup in CNTL (and by
extension CAM/Sens if the same shape of popup exists there) — Alias editing, Network settings, Camera
settings, per-device popups, not just SR/Power Control. When touching any of these, check whether it
already follows global-model + deep-copy + struct-compare-dirty + apply-commits-all, and if not, that's
exactly the kind of ad-hoc pattern the user wants retired — per [[feedback_confirm_before_editing]]'s
2026-09-17 entry, though, the retrofit itself still needs the user's explicit go-ahead before editing;
this memory records the *target architecture*, not standing permission to rewrite things unprompted.
