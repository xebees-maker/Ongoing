---
name: yesterday-todo-trigger-phrase
description: "CNTL session: the exact phrase '어제하기로 한일 진행해' pre-authorizes the previous day's queued to-do list end-to-end (edit+build+flash), no re-confirmation needed"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-16T15:03:48.864Z
---

User (2026-09-16, end of session, CNTL SR/Power Control popup redesign) said: "내일 내가 어제하기로 한일 진행해 라고 하면 UI 수정을 바로 진행하고 빌드플래시까지 해" (tomorrow, if I say "proceed with what we decided to do yesterday," go ahead and do the UI changes right away, all the way through build and flash).

**Why:** the previous session ended with a long list of concrete, already-agreed-upon UI to-do items (recorded in that day's `Docs/한일_YYYY-MM-DD.txt` 할일 section) — the user wants to skip re-explaining/re-confirming them the next day and just trigger execution with this one phrase.

**How to apply:** when the user's message is literally "어제하기로 한일 진행해" (or an obvious close variant referring to "yesterday's decided-to-do items"), treat it as full authorization to: (1) read the previous day's `Docs/한일_*.txt` 할일 section (or the relevant project memory) for the exact agreed items, (2) implement them directly without asking "이대로 진행할까요?" first, (3) build, (4) flash, all in the same turn — per [[feedback_no_step_confirmation]], this is exactly the kind of standing go-ahead that shouldn't need re-confirmation. Still verify the to-do list content is actually unambiguous before touching code (if an item's spec was left genuinely open/undecided, that specific item still needs a quick check — but don't block the whole batch over one ambiguous item, just flag it and proceed with the rest).
