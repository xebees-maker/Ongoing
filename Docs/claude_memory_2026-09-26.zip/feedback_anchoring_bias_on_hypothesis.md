---
name: feedback-anchoring-bias-on-hypothesis
description: "Once fixated on one explanation, tends to reinterpret all new/contradicting evidence to fit it instead of re-examining the hypothesis itself — called out 2026-08-23"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-23T01:26:06.225Z
---

Strong, recurring anchoring bias: once locked onto one direction/hypothesis, keeps bending
subsequent (even contradicting) evidence to fit that same frame instead of asking "does this new
information mean my whole hypothesis is wrong?" first.

**Why:** During the CAML battery-death investigation ([[project_caml_bat_en_latch_missing_resolved]]),
fixated for hours on WiFi modem-sleep / ESP-IDF Automatic Light Sleep / FreeRTOS tickless-idle
priority as the cause. The user had been saying since the *previous day* that this was suspicious
in a way that pointed at hardware power delivery, not software sleep states — and even after
building a live audio-log system specifically to test it, the first instinct on hearing "sound
stops the moment I let go of the PWR button" was still to keep reasoning within the light-sleep
frame rather than immediately asking "does a battery-backed board even having this behavior make
sense under ANY software-sleep theory, or does it point somewhere else entirely?" The user had to
say outright "USB 뽑으면 배터리 있는데 장치가 죽을 리가 없다고" (a device with a battery present
has no business dying just because USB was unplugged) before the actual hardware cause (missing
BAT_EN self-latch GPIO) was even considered. This is a repeat, more general instance of the
"WIFI_PS_NONE" mistake earlier the same session ([[feedback_confirm_understanding_before_acting]]
adjacent) — proposing a fix without checking it against the full picture, because the picture was
already narrowed to one theory.

**How to apply:** when the user pushes back with a *new* fact — especially something phrased as
"that doesn't make sense" / "this shouldn't happen" — treat it as a trigger to re-derive the
hypothesis space from scratch, not as one more constraint to fold into the current leading theory.
Explicitly ask "if I had no prior theory, what would this new fact alone suggest?" before trying to
reconcile it with what's already been invested in. This is distinct from
[[feedback_dont_relitigate_ruled_out_hardware]] (which is about not re-opening things the user has
already closed) — this is the opposite failure: not re-opening a *software* theory the user is
implicitly signaling is closed/wrong.
