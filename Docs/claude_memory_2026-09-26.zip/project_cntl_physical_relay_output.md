---
name: project-cntl-physical-relay-output
description: "2026-08-27: CNTL's dev plan includes driving a physical/electrical relay (load switching) via GPIO — its enclosure has a limited port/hole budget, which is why the WiFi-antenna-vs-steel-obstruction options matter (see steel-obstruction-relay memory)"
metadata:
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-27T07:57:22.079Z
---

CNTL's development plan includes attaching a physical/electrical relay (for switching some load — not
yet detailed what) via GPIO, requiring a wire routed out of CNTL's enclosure. User: "이 CNTL 장치로
RELAY도 붙여야해서, 외부로 나온 포트들이 제한적이라서 더 그런거야" — this is *why* the CNTL antenna
problem (see [[project_cntl_cam_steel_obstruction_relay]]) feels more constrained than it otherwise
would: CNTL's case has a limited hole/port budget, already partly spoken for by this relay wiring.

**Key clarification reached in the same conversation**: this constraint only matters for the "swap
CNTL's whole board for a WROOM-1U-based one" antenna option (new enclosure needed anyway, so the relay
wire and any antenna cable compete for the same design budget). It does NOT constrain the other two
antenna-workaround options (a separate wireless ESP-NOW relay node, or an RF booster) — both keep
talking to CNTL over the air exactly as today, adding zero new holes/ports to CNTL's own enclosure.

**How to apply:** when reasoning about CNTL enclosure/port tradeoffs going forward, remember the
physical relay output is a real planned feature, not hypothetical — factor its GPIO+wire-out
requirement into any CNTL hardware/enclosure discussion, not just the antenna question.
