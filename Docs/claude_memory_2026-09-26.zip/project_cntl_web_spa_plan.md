---
name: project-cntl-web-spa-plan
description: "Cntl web dashboard long-term plan: eventually a full SPA with UI matching CNTL's own touchscreen exactly; today's /app is test-only, not the final form. BPA/SPA terminology defined 2026-08-30."
metadata:
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-30T04:40:31.861Z
---

**User's explicit long-term goal, stated verbatim 2026-08-30**: "나중에 웹을 제대로 만들 때는 SPA로
CNTL과 동일한 UI를 만들꺼야" (when I properly build the web interface later, I'll make it an SPA with
a UI identical to CNTL's own [touchscreen]). Followed by: "잘 기억해서 나중에 딴 소리 하기 없기" (remember
this well, don't contradict it later) — an explicit instruction to keep this consistent across sessions.

**Terminology the user coined this session (use these terms going forward)**:
- **BPA** ("Blocking Page App"/"블로킹 MPA") — a traditional full-page-navigation response that the
  server deliberately holds open (doesn't complete) until the real work finishes, so the browser's
  *native* loading indicator (tab spinner, address-bar progress bar — confirmed visible in Safari,
  both desktop and iOS) stays active for the whole wait. This is what the original `/photos` HTML
  endpoint did (removed 2026-08-30, see below) — one full page load per action, no JS needed for
  progress display.
- **SPA** (Single-Page App, standard term) — stays on one page; JS `fetch()` calls a JSON API and
  updates the DOM in place. **Critical fact established this session**: a `fetch()` call — chunked/
  streamed or not — never triggers the browser's native loading indicator, because that indicator is
  tied only to the *document's own* navigation/load state, not to background requests the already-
  loaded page's own script makes. HTTP chunked streaming inside a `fetch()` does NOT restore the
  native indicator; it was explored and explicitly ruled out as pointless for this purpose (session
  concluded: no real benefit over a plain single-response fetch + a JS-drawn "로딩 중..." message,
  unless genuinely live-updating counters are wanted mid-wait, which wasn't judged worth the added
  complexity).

**Current state (2026-08-30), explicitly NOT the final form**: `/app` (SPA) is live — static
`app.html`/JS served from the assets LittleFS partition (uploaded via `/admin/upload?file=app.html`,
not baked into `assets_root/`), calling a small JSON API (`/api/devices`, `/api/photos`,
`/api/connect`, `/api/disconnect`, `/api/photo_fetch`, plus `/photo?id=X` for raw JPEG bytes). Blocking
waits (connect/list-fetch/photo-fetch, all up to 25s) are plain single-response `fetch()` calls with a
JS-shown "연결 시도 중...", "가져오는 중..." message before the call and cleared after — this is a
deliberately minimal placeholder, confirmed by the user as "테스트 용도로 쓰는 수준" (adequate for
testing purposes right now), not the intended final UX. See [[project_cntl_standalone_ap_todo]] for
the fuller history of how this web feature was built (WiFi/AP-mode motivation, all the bugs found and
fixed that day).

**Deeper architectural conclusion, same session, after the BPA/SPA discussion above** — this refines
(does not replace) the SPA-overall direction:

1. **Why BPA/native-loading-indicator actually matters here (not just UX taste)**: verified via
   ESP-IDF source/docs that `esp_http_server` runs everything on a *single* server task — there is no
   per-request task spawn (`httpd_stop`'s own doc says "signals a halt to the server task", singular).
   So while any handler blocks (our connect/list-fetch/photo-fetch waits, up to 25s), the *entire*
   web server is unresponsive to every other request, unrelated ones included. A SPA facade that
   looks like other buttons should still work during that wait is dishonest about what the system can
   actually do right now — user's own words: "그래서 대기하면서 웹이 완료되지 않음을 표시하려던 거야"
   (that's exactly why I wanted the page to show "not done yet" while waiting).
2. **Mental model, user's own framing**: "웹은 콘 입장에서 또다른 화면과 터치가 있다고 보면 되" (from
   CNTL's own perspective, treat the web as just another screen-plus-touch-input attached to the same
   device) — not a bolted-on, independently-designed second system.
3. **Concrete design rule that follows from #2**: "웹에 입력이 있으면, CNTL의 탭과 같은 입력 처리
   과정을 거쳐야, 나중에 CNTL이 바뀌더라도 설계가 보존되" (web input must go through the *same*
   input-handling pipeline as a physical tap — e.g. call the same `set_selected_file_id()`-style model
   functions ui_main.c's tap handlers call — not separate parallel logic in main.c that bypasses the
   model layer, which is what today's `/app` API handlers do; found via the 3008
   (`UI_ERR_PHOTO_SELECTION_STALE`) conflict: web's `esp_now_photo_fetch_by_id()` call never touches
   `s_selected_file_id`, so the on-device "is this what I'm waiting for" check sees any *stale*
   leftover on-device selection — e.g. auto-selected via `refresh_photo_list_ui()`'s select_index
   branch, not just literal finger-taps — as a mismatch and can loop/re-request against it). Routing
   web input through the same functions the tap handler uses keeps both interfaces automatically in
   sync as CNTL's own logic evolves, rather than needing parallel updates in two places forever.
4. **Result once #3 holds**: blocking on the web then produces the exact same outcome as a local
   physical interaction would (same model, same code path) — so it's correct for the web to visibly
   block (BPA-style, letting the browser's own native loading indicator show "not done yet") while
   waiting for that result, mirroring the on-device progress popup for the very same class of
   operation (`show_progress_popup`/`renew_list_tick_fn` pattern) — just using the browser's own
   built-in affordance instead of a custom LVGL popup.

So: the eventual "proper" web app is SPA in a broad sense (stays on one page, shares the on-device
model/input pipeline) but uses BPA-style blocking full responses specifically for the operations that
are inherently blocking anyway — not a blanket "always BPA" or "always fetch()+JS-indicator" choice.
This 3008 conflict itself was explicitly *not* fixed this session (deferred, same "다음 버전" bucket as
encryption) — this entry is the design conclusion for when it (and the broader migration) is tackled.

**How to apply**: when eventually building the "proper" web version, the target is full feature parity
with CNTL's own on-device LVGL UI. Don't propose a different architecture (e.g. reverting to a pure
BPA multi-page site, or a pure fetch-only SPA with no shared input pipeline) without the user explicitly
reopening this decision. The admin upload/download
endpoints (`/admin/upload?file=X`, `/admin/download?file=X`, path-traversal-guarded, no auth — accepted
low-stakes tradeoff per user: "복사해 가도 상관없어") are the mechanism for iterating on the static
frontend without app-partition rebuilds; only new API surface requires a C rebuild. Encryption of
`device_config.bin` (to protect the plaintext WiFi password it contains, now readable via
`/admin/download?file=device_config.bin`) was attempted and deliberately deferred — this ESP-IDF's
mbedtls removed the classic `aes.h` public API in favor of PSA Crypto, which was judged too much
complexity for a non-urgent nice-to-have; user's words: "암호화는 나중에(다음 버전 정도) 하는 걸로
기억하고" (remember to do encryption later, roughly next version).
