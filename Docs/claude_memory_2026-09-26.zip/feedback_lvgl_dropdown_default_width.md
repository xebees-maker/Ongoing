---
name: lvgl-dropdown-default-width
description: "LVGL lv_dropdown_create() defaults to a fixed 130px width, not auto-sized to option text — long options overlap the down-arrow unless width is set explicitly"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-16T14:33:44.448Z
---

`lv_dropdown_create()` does NOT auto-size to its option text. Verified in the vendored source (`managed_components/lvgl__lvgl/src/widgets/dropdown/lv_dropdown.c`): the widget class sets `.width_def = LV_DPI_DEF` (130px on this project's display), a fixed default. The draw code (`draw_main()`) does correctly reserve space between the text area and the down-arrow symbol when it draws — but only within whatever width the object actually has. If the object's width is left at the 130px default and the selected option's text is wider than that (minus padding and the arrow), the text overflows visually into/past the arrow.

**Why this recurred (2026-09-16, SR/Power Control popup):** added several new dropdowns with option text longer than this project's existing dropdowns typically use (e.g. "Turns Off", "Air T (Basic)") without setting an explicit width, since most of the file's existing dropdowns (response interval, XCLK, etc.) also don't set width — but their option text happens to be short enough to fit in 130px, so they never exposed the bug. User: "드랍다운은 네가 자주 실수하는데 (어디 기억하든지 좀 해봐) 글씨와 다운화살표가 겹쳐" (you often get this wrong with dropdowns — remember it somewhere — the text and the down-arrow overlap).

**How to apply:** whenever creating an `lv_dropdown` in this codebase (Cntl `ui_main.c`), check the longest option string in the list. If it's more than ~8-10 characters at the UI's 18pt font, set an explicit `lv_obj_set_width()` sized for that longest option (existing precedent: `s_camera_select_dd` uses `LV_DPI_DEF + 50` when its content was too wide). Don't assume the 130px default is safe just because other dropdowns in the file get away without setting it — check the actual text length for *this* dropdown's options, not the codebase's general pattern.
