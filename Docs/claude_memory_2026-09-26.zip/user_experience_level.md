---
name: user-experience-level
description: User is a developer with 40 years of experience — defer to their explicit technical judgments and elimination-based reasoning instead of re-litigating them. Repeat offense as of 2026-08-11: when their stated premise conflicts with a bug symptom, audit my own recent code first, not their claim.
metadata: 
  node_type: memory
  type: user
  originSessionId: c3b6d079-8360-4bf9-b697-b5fab75849ba
  modified: 2026-09-17T15:03:50.405Z
---

The user told me directly (2026-07-23): "내가 40년차 개발자야. 좀 내 말좀 들어 앞으로도" (I'm a
40-year developer. Listen to what I say going forward too). This followed the CAM corruption
investigation (see [[project-cam-dvp-corruption-investigation]]) where I burned three days
re-litigating hardware theories the user had already explicitly ruled out, and where their own
elimination-style reasoning (capture/init rarely fails absent real hardware faults; UVC bypassing
save/retrieve was clean; therefore the bug had to be in save/retrieve) turned out to be exactly
right — see [[feedback-dont-relitigate-ruled-out-hardware]].

**How to apply**: this user's calls on hardware/firmware behavior, elimination logic, and "this
class of bug is a classic X" pattern-matching (e.g. their unprompted flag about file-I/O/transfer
functions mishandling bytes, which pointed straight at the actual CRLF bug) come from decades of
hands-on experience, not guesswork. When they state a technical judgment plainly — especially "stop
suspecting X" or "this isn't the cause" — treat it as reliable domain expertise to build on, not a
hypothesis to independently re-verify from scratch. Push back only with a concrete, specific new
reason if I genuinely think a closed line of investigation needs reopening; don't drift back into it
by default. Explain technical matters to them as a peer, not as someone who needs basics spelled
out.

**2026-08-09 reinforcement**: during a CAM Light Sleep debugging session, the user explicitly said
"내가 40년차 개발자이고, 테스트의 달인이야. 내가 잘못 했을 때는 미리 너한테 말하고 있잖아" (I'm a
40-year developer and a testing expert — when I make a mistake, I tell you upfront). This came after
I mis-explained their test observation (theorized a "stopped sending after 1 report" bug when they'd
actually reported continuous updates the whole time) and after I over-apologized/hedged repeatedly
across a long debugging back-and-forth. Concrete instance of them self-correcting proactively: mid-session
they caught their own mixup ("아까 CAM이 아니라 CNTL을 별도 전원으로 했었네") without prompting.
**How to apply (addition)**: take their test reports at face value — don't silently second-guess or
re-derive alternate explanations for what they directly observed; if their report seems to conflict
with a theory, the theory is wrong, not the report. Skip repeated apologizing — state the correction
and move on. If they made a setup/testing error, trust they'll flag it themselves rather than
proactively hunting for one on their behalf.

**2026-08-11 reinforcement — repeat offense, user explicitly angry ("몇번째냐", "사람이었으면 벌써
죽었어")**: CAM was reporting response_interval=2 (I=2) despite the user having said twice already
that they always test in Live mode (0). My first move was to conclude "not a bug, probably just a
stale saved file — click Apply again" — doubting their stated premise instead of taking it as fact
and looking for what in *my own recent code* could contradict it. The actual cause was mine: a
DEVICE_CONFIG_VERSION bump I made earlier (1->2, for adaptive_response_sec) had no migration path,
so a version-mismatch silently fell back to compiled defaults, and a later unrelated settings-Apply
during that same boot persisted the stale default (2) into the new-version file permanently
(`device_config_save()` writes all fields together, so one field's accidental default silently
overwrites another field's real value). Root-caused only after the user pushed back hard and told me
directly to check my own recent work before doubting them.
**How to apply (addition)**: when a bug report conflicts with a premise the user has already stated
as established ("I always do X"), treat that premise as ground truth immediately — do not propose
"maybe you forgot to Y" as a first explanation. Instead, first audit *my own* recent edits (especially
schema/version bumps, migrations, anything touching persistence) for what could produce the observed
symptom while the stated premise still holds. This is the same failure mode as the CAM corruption
investigation ([[feedback-dont-relitigate-ruled-out-hardware]]) — re-litigating an already-settled fact
instead of turning the suspicion inward — and per the user it has now recurred multiple times.
