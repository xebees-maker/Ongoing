---
name: feedback-fix-root-cause-not-bypass
description: "Chronic pattern (user's words: '아주 많이 지적받은 하찮은 쓰레기 버릇') — when hitting a bug, Claude designs a workaround/bypass mechanism instead of fixing the root cause within the existing architecture's principles"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-19T04:16:56.712Z
---

Fix the root cause within the existing design's own principles — never bypass a broken mechanism by building a new, parallel one that routes around it.

**Why:** User states this has been pointed out "여러 번"(many times) as a chronic, named bad habit — not a one-off mistake. Concrete instance (2026-09-19, CNTL/CAM periodic capture): CAM's existing architecture cleanly separates two independent things CNTL sends each CASK cycle — CONFIG (carries values like capture_interval_sec, informational, CAM uses locally) and SLEEP_NOW (carries only the response-interval-derived sleep duration, independent of capture_interval). When periodic capture appeared broken, instead of diagnosing why CAM's own existing timer-based scheduling (using the CONFIG value) wasn't working, Claude designed an entirely new CNTL-side mechanism (queuing capture-now actions via the CASK work-item queue) that duplicates/bypasses what CAM was already supposed to do autonomously — this ignores the CONFIG/SLEEP_NOW separation and works around the symptom rather than fixing it. This is exactly why the user's standing rule is "don't modify without permission" (feedback_confirm_before_editing) — asking first is what catches architecture-bypassing workarounds before they ship, not just typos.

**How to apply:** Before implementing any fix, explicitly check: does this solution work *within* the existing architecture's stated division of responsibility, or does it add a new path that achieves the same end result a different way? If the latter, stop and ask — that's very likely a bypass, not a fix. This applies generally, not just to CASK/CAM — any time a "let's just also do X from a different angle" idea appears while debugging, treat it as a red flag requiring explicit confirmation before implementing, per [[feedback_confirm_before_editing]]. Also: verify runtime state (e.g., is the device actually in deep-sleep-reboot mode right now, or a different mode like the "Live"/sleep_sec=0 pacing loop?) before diagnosing root cause from static code reading alone — conflating two different runtime regimes was part of what led to the wrong theory here, per [[feedback_dont_invent_alternative_theories_over_stated_facts]] and [[feedback_audit_own_change_first]].
