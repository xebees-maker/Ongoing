---
name: project-cntl-cam-photo-list-first-pair-timeout
description: "OPEN BUG, NEEDS RE-VERIFICATION (as of 2026-08-11 protocol replacement): PHOTO_LIST_REQUEST failed all 5 retries right after first CAM pairing under the OLD per-file list protocol — that protocol was fully replaced same-day (COUNT/BATCH/DONE, see [[project-cntl-rtc-and-unified-sleep-plan]]), plausible this is fixed as a side effect but not confirmed on a genuine first-pairing scenario. User wants this raised repeatedly until confirmed fixed."
metadata: 
  node_type: memory
  type: project
  originSessionId: 53810285-98f9-4ede-9939-9816c41aeab1
  modified: 2026-08-11T10:48:59.514Z
---

Found via serial capture (esp_now_hub.c / esp_now_photo.c / esp_now_reliable logs) while diagnosing
the SLEEP_NOW timing redesign ([[project_cntl_rtc_and_unified_sleep_plan]]): right after the very
first CAM pairing in a Cntl boot session (auto-triggered list refresh on connect), the
`PHOTO_LIST_REQUEST` gets queued (`esp_now_photo: PHOTO_LIST_REQUEST 큐잉됨`) and then times out
completely — `esp_now_reliable: 요청 타임아웃(5회 시도 모두 무응답)` / `esp_now_tx: 목록 요청
무응답(5회 시도, 응답성예산 반영)` — all 5 retries over ~15 seconds get zero response from CAM.
Cntl then sends `PHOTO_LIST_DONE_ACK 전송(누락 0개)` as if the list were empty, ~15s after the
timeout. Not yet investigated further — unclear if CAM is busy (still processing CONFIG_SET/
SET_TIME at that exact moment?), a timing race with the just-completed pairing handshake, or
something else. Not related to today's SLEEP_NOW/adaptive-deadline redesign — that logic was
confirmed working correctly in the same capture.

**How to apply**: the user explicitly asked to be reminded of this **repeatedly, not just once** —
proactively bring it up again in future Cntl/CAM sessions until it's actually fixed, don't let it
quietly drop just because the immediate conversation moved elsewhere.
