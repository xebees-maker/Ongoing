---
name: project-sens-cask-port-2026-09-05
description: "Sens (SCD41 headless) ported onto CAM's exact CASK/deep-sleep structure; measure-period decoupled from wake cadence; protocol trimmed (sensor descriptor moved to pairing-time only). Status as of 2026-09-05."
metadata: 
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-05T12:01:54.606Z
---

Sens's SCD41 headless build was rewritten to mirror CAM's `cam_node.c`/`esp_now_cam.c` architecture
literally (not independently re-derived), per explicit user instruction across this session and
[[project_cntl_cam_wake_hello_no_mem_desync]]'s continuation. Key files: `Sens/main/esp_now_node_cask.c`
(new, mirrors `esp_now_cam.c`), `Sens/main/sens_deep_sleep_node.c` (new, mirrors `cam_node.c`),
`Sens/main/rwdt_guard.c/.h` (verbatim port). `Sens/main/sensor_node.c` reverted to serve only the
non-SCD41 headless builds (DHT22/SHT45/SHT40) — untouched by this work, per standing scope boundary.

**Root-caused via live serial capture, not guessing** (repeat-corrected during this arc when I
guessed instead): Sens's `esp_now_node_init()` deferred its known-hub fast-path attempt into
`report_reading()` rather than resolving it synchronously like CAM's `esp_now_cam_init()` ->
`esp_now_cam_reconnect()` — so the ported "wait for paired" loop was polling a condition that could
never become true before `report_reading()` was ever called, burning a dead ~25s every post-pairing
cycle. Fixed by calling `report_reading()` once synchronously right after `esp_now_node_init()`
(app_main-level, mirrors CAM's init-then-reconnect timing) — confirmed via capture: dead wait gone.

**Also found+fixed via the same capture**: moving measurement earlier (see below) put
`scd41_trigger_single_shot()` right after `scd41_stop_periodic_measurement()` with zero settle
delay, causing every measurement to fail (`ESP_ERR_INVALID_RESPONSE` on cmd 0x219D). A 1s delay
(matching `scd41_init()`'s own internal precedent) fixed it — the old 20s dead-wait bug had
accidentally been masking this the whole time.

**Design, confirmed step-by-step with the user (several of my own restatements were wrong and
corrected — see [[feedback_confirm_before_editing]] 2026-09-05 entry for the acted-without-asking
repeat)**:
- Measurement happens independent of Cntl/CASK timing (like CAM's capture timer), gated on real
  elapsed time since the last successful measurement (`s_seconds_since_last_measurement`,
  RTC-persisted) vs. the node's configured measure period — not on wake frequency. Power-hungry
  sensors must not be triggered on every wake.
- Real deep-sleep duration is still literally `SLEEP_NOW.sleep_sec` (no Sens-side special-casing,
  matches CAM exactly) — but Cntl's `send_cask_sleep_now()` (`esp_now_hub.c`) computes that value
  per-node-kind: for SENS, `MIN(response_interval_sec, that node's configured measure_period)`,
  with `response_interval_sec==0` ("즉시"/Live) as a sentinel overriding to 0 regardless (never
  sleep) — same as CAM. When response<measure, Sens wakes more often than its real measure period
  (for Cntl's control opportunity) but the measurement-gating above means it just resends the
  cached reading on those extra wakes.
- Sensor descriptor (`sensor_kind`/`chan_count`/`chan_type[]`) moved from the recurring
  `esp_now_wake_hello_sens_t` into `esp_now_pair_ack_t` (shared with CAM), sent once at pairing
  instead of every cycle — user's framing: "캐스크 주기엔 값만이어야". CAM currently sends zero for
  these fields but is planned to reuse them for camera model (OV5640/OV3006) later — not wasted.
  `measurement_id` (RTC-persisted counter, increments only on a real fresh measurement) added to
  `esp_now_wake_hello_sens_t` so Cntl can dedupe unchanged readings across repeated cycles.
- Sensor-kind auto-detection (I2C address probing) was considered and explicitly declined by the
  user in favor of keeping build-time Kconfig hardcoding — confirmed technically feasible if ever
  wanted (SCD41=0x62, SHT4x=0x44-family distinguishable; DHT22 is single-wire, would need a
  protocol-level read attempt instead of a bus scan).

**Cntl UI shipped this session**: settings-tab "측정 주기" dropdown (10s/30s/1m/5m/30m) + Apply,
targeting whichever Sens node was last tapped in the existing 측정기 connect list (no new selector
widget — reuses that list per direct user correction of my first, wrong proposal). Dashboard
측정기 panel now renders real per-node/per-channel readings: `"{node_name}: {label} xx.yy {unit}
(ID:nnn, Time: HH:MM:SS)"`, Time = Cntl's own wall clock at the moment it first saw that
measurement_id. Channel-type -> {label, unit} lookup lives entirely in Cntl (`ui_strings`, i18n) —
wire only ever carries the enum. `%f` deliberately avoided per [[feedback_lvgl_no_percent_f]] —
value formatted via manual whole/hundredths integer split, matching the existing
`format_battery_display()` precedent. Response-interval option list changed 30분->1분 (last slot),
`s_response_interval_values[]` now `{0,3,10,30,60}`.

**Verified on real hardware** (multiple live serial captures both sides): pairing succeeds, no more
dead wait, SCD41 measures successfully, measurement_id increments correctly per real measurement.
User confirmed "아니 잘 동작해" after independently checking the device. Committed `da83afe`, pushed.

**Status / open items (2026-09-05)**:
- Relay/SR output module (`relay_output.c/.h`) — the ORIGINAL point of this whole arc ("센서값에
  따라 SR을 구동") — not started at all this session; all effort went into the Sens CASK port and
  protocol refinement. SR decision logic itself remains explicitly undecided.
- CAM does not yet actually populate the new `esp_now_pair_ack_t` camera-model fields (struct
  fields exist, sending code doesn't).
- Multi-Sens-node concurrent pairing / independent per-node measure periods only verified with
  one physical Sens node so far.
- **Battery display bug, reported but not investigated**: Cntl's summary/측정기 panels show the
  Sens node's battery as "0.00 V". Not yet root-caused.
- WS2812 addressable RGB LED on the Sens board (GPIO7, see [[reference_sens_schematic]] family) —
  user wants to experiment with it later ("이따가 써보려고"), currently unused/reserved in
  `bsp_c3_pico.h`, no action taken.
