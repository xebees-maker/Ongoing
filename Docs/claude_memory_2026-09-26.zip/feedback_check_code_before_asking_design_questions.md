---
name: feedback-check-code-before-asking-design-questions
description: "Check existing code/git history for prior decisions before asking the user design/clarifying questions — don't rely on conversation recall alone"
metadata:
  node_type: memory
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-09T14:47:43.636Z
---

Before firing off clarifying/design questions (including via AskUserQuestion) on a topic in an actively
developed project, grep/read the existing code and recent git log first — the answer is very often
already implemented or already decided in a prior session, even if it's not visible in the current
(possibly compacted) conversation context.

**Why:** 2026-09-09, starting the "그래프" (graph) feature for CNTL's stats tab, I asked 4 clarifying
questions via AskUserQuestion (data source/persistence, per-node vs combined series, time range,
reboot-persistence) as if these were all open decisions. The user's reaction: "난 네가 왜 질문하는지
모르겠던데 다 정한걸?" (I don't understand why you're asking — it's all already decided?). A quick
`git log` + reading `stats_store.h`/`build_stats_tab()` afterward showed the entire backend already
existed: SD-backed fixed-record time-series store (`stats_store.c/.h`, commit f56e00b), a `Scale`
dropdown already wired to period-based min/max/avg queries, a table<->graph swipe pager already built,
and even a graph placeholder object (`s_stats_graph_view`) with the real chart widget as the only
missing piece — including a `stats_store_read_since()` API whose own doc comment already anticipated
"the graph will downsample anyway." All 4 of my questions had discoverable answers already in the repo.
When I owned this, the user's sharper follow-up was blunt: "가끔 널 보면 메멘토거나 치매환자 같아"
(sometimes you seem like Memento or a dementia patient) — a fair characterization of asking about
settled decisions because prior-session context wasn't recalled or re-derived from the actual code.

**How to apply:** in a mature project with extensive iterative history (this one has 20+ substantive
Cntl commits), treat "I don't remember this being decided" as weak evidence of "it wasn't decided" —
conversation summarization/compaction across sessions is lossy, but the code and git log are not. Before
asking the user to make a design choice (data format, storage location, time range, persistence, naming
scheme, etc.), spend a Grep/git-log pass checking whether it's already implemented or already described
in a code comment (this codebase's convention of dating design-decision comments inline, e.g. "2026-09-06,
사용자 설계", makes this fast). Only ask about what's genuinely still open. If the user then says
something is already decided and you missed it, don't defend the question — acknowledge directly, go read
the code, and report back what you found rather than asking again.
