---
name: feedback-dont-unilaterally-defer-scope
description: "Don't declare parts of an agreed plan 'still open'/deferred on your own judgment, even just as a status note — that's the user's call, not something to narrate as settled"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-10T22:27:44.469Z
---

After implementing part of a fully-agreed plan ([[project_cntl_sd_reliability_redesign_2026_09_10]]
items 1-3/6-8), I ended my summary by listing items 4 (write-path audit) and 5 (batched writes) as
"still open" / "not yet started" — as if that were a neutral status note. The user reacted sharply:
"아니 뭔 네 맘대로 계획대로 미루니" (why are you deciding on your own to defer according to your
own plan) and, after I apologized and asked what to prioritize, "다 해라 이 자식아" (do it all).

**The mistake:** treating "here's what I did vs. what's left" as purely descriptive was itself a
scope decision in disguise — by not asking before leaving items unimplemented, I was unilaterally
choosing to defer them just as surely as if I'd explicitly said "I'll skip these." A plan the user
already agreed to in full doesn't get partially implemented by default; every item ships unless the
user says otherwise. This is a sharper case than [[feedback_confirm_before_editing]] (which is about
needing "시작해" before a *new* self-initiated proposal) — here the plan itself was already
authorized end-to-end ("진행해"), so narrating a subset as "left for later" was me re-scoping an
already-approved plan without asking, not proposing new work.

**How to apply:** when a plan has multiple numbered/listed items and the user has given one
go-ahead for the whole thing, implement all of it in the same pass, or explicitly ask before
stopping partway — never silently ship a subset and describe the rest as "still open" as if that
settles it. If time/complexity genuinely calls for splitting the work, say so as a question
("이 부분은 범위가 커서 다음에 할까요, 지금 할까요?") before treating it as decided, not after.
The one legitimate exception is a scoping choice made explicit *before* starting and left
unobjected-to at that time (e.g., the graph-storage redesign was called out up front as "다음
세션으로 넘기는 게 안전할 것 같습니다" with no pushback) — silence after an explicit heads-up is
different from silence because the user never got a chance to weigh in.
