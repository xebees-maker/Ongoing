---
name: project-cntl-stats-tab-memory-2026-09-06
description: "RESOLVED 2026-09-06: CNTL internal-RAM crisis from adding stats-tab UI — root cause was esp_lvgl_adapter hardcoding its tear-avoidance partial buffer to internal RAM; fixed via buffer_height=10, ~50KB recovered, HW-verified"
metadata: 
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-15T10:41:45.162Z
---

Adding the new stats-tab widgets (lv_table + buttons + labels for [[project_cntl_stats_tab_persistence]]-style
work) pushed CNTL from a critically-thin baseline into repeated boot failure (task_wdt on LVGL's software
render task "swdraw", httpd_start failing, etc.) — user-observed internal free RAM (`I=`) dropped to
271B/587B after several retries.

**Key fact, user-stated 2026-09-06**: even BEFORE the stats tab was added, steady-state internal free RAM
was only ~7KB. The baseline was already critically fragile — the stats tab (a few KB of new lv_table/button/
label allocations) was the straw that broke it, not the sole cause.

**Measured per-boot-stage internal-RAM breakdown** (via temporary `LOG_MEM()` checkpoints in
`Cntl/main/main.c` app_main(), one-time diagnostic, since removed/to-remove):
- start: 249,275 bytes free
- after NVS+FS+config load: 245,251 (-4KB)
- after LCD/touch init (CH422G, bounce buffers): 211,799 (-33.5KB)
- after SD card mount: 209,475 (-2.3KB)
- **after `esp_lv_adapter_start()` (LVGL bring-up, display+touch registration): 103,403 (-106KB)** — biggest
  single consumer, happens BEFORE any widget is created (before `ui_init()`), so unrelated to app UI code.
  Framebuffer is already `fb_in_psram=true`, LVGL handler task stack already `stack_in_psram=true` — so this
  106KB is something else (draw-unit worker task stack? layer/compositing buffers?) — NOT YET ROOT-CAUSED,
  this is the most promising lever for recovering real headroom.
- after `ui_init()` (full widget tree — ALL panels, not just the new stats tab): 54,771 (-48.6KB total for
  the entire existing UI + new stats tab combined; the stats tab's own share of this is not isolated but is
  almost certainly only a few KB of the 48.6KB)
- after `esp_now_hub_init()` (WiFi + ESP-NOW): 1,875 (-52.9KB) — standard/expected WiFi footprint

**Dead ends already tried and reverted** (do not repeat without new information):
- `LV_USE_CUSTOM_MALLOC` routing `lv_malloc` to `heap_caps_malloc(..., MALLOC_CAP_SPIRAM)` — failed to even
  link: `lv_mem_psram.c`'s symbols (lv_malloc_core etc.) never get pulled from `libmain.a` because nothing
  references them at the point in link order where `libmain.a` is scanned (liblvgl__lvgl.a's second pass,
  which needs them, comes after main.a with no later occurrence) — reverted, file deleted.
- `CONFIG_SPIRAM_MALLOC_ALWAYSINTERNAL` global threshold tuning — tried 0 (LVGL's `lv_draw_create_task()`
  draw-task scratch, allocated fresh via `lv_malloc_zeroed()` on EVERY draw call in EVERY frame per
  `lv_draw.c`, got pushed to PSRAM too → render slow enough to trip `task_wdt` on "swdraw"); tried 2048
  (fixed swdraw, but then `sdmmc_cmd: allocate_dma_buf: not enough mem, err=0x101` — SD driver's required
  internal/DMA-capable buffer couldn't be satisfied). **Reverted to the default 16384.** The core problem:
  persistent widget-tree allocations and per-frame draw-task scratch go through the identical
  `lv_malloc_core` path and are similarly sized, so no single size threshold can separate "safe to push to
  PSRAM" from "must stay internal, touched every frame."

**Why**: user wants CNTL's internal RAM "squeezed" ("메모리 쥐어짜야겠어") since it's been fragile even
before today, and any future stats-tab/graph work needs real headroom, not just breaking even.

**RESOLVED 2026-09-06**: root cause found and fixed, HW-verified. The 106KB came from
`espressif__esp_lvgl_adapter`'s `display_manager.c` (`display_manager_setup_tear_buffers()`,
`ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_PARTIAL` branch, ~line 1095) — it calls
`display_manager_alloc_draw_buffer(cfg->draw_buf_pixels * color_size, false)` with the PSRAM flag
**hardcoded to `false`**, ignoring `disp_config.profile.use_psram = true` set in `Cntl/main/main.c`. Default
`buffer_height=50` → 800×50×2 = 78KB forced into internal RAM regardless of the use_psram setting (this is
vendored third-party code, not patched directly — instead the public `buffer_height` config knob was used).

Fix applied in `Cntl/main/main.c`: `disp_config.profile.buffer_height = 10;` (down from default 50) right
after the `ESP_LV_ADAPTER_DISPLAY_RGB_DEFAULT_CONFIG` macro call, before `esp_lv_adapter_register_display()`.
This shrinks the same internal-RAM partial buffer to 800×10×2 = 16KB instead of moving it to slower PSRAM
(avoids reproducing the swdraw-style render-stall risk below). Measured recovery: ~50KB more internal RAM
free at a comparable boot checkpoint (WiFi-got-IP point went from ~1.9KB free at the crisis point to
51,747 bytes free). User visually confirmed on the physical device screen: no flicker/tearing/incomplete
redraws at buffer_height=10 — accepted as the final value ("이 정도에서 일단 만족").

**Dead ends already tried and reverted — do not repeat without new information**:
- `LV_USE_CUSTOM_MALLOC` routing `lv_malloc` to `heap_caps_malloc(..., MALLOC_CAP_SPIRAM)` — failed to even
  link: `lv_mem_psram.c`'s symbols (lv_malloc_core etc.) never get pulled from `libmain.a` because nothing
  references them at the point in link order where `libmain.a` is scanned (liblvgl__lvgl.a's second pass,
  which needs them, comes after main.a with no later occurrence) — reverted, file deleted.
- `CONFIG_SPIRAM_MALLOC_ALWAYSINTERNAL` global threshold tuning — tried 0 (LVGL's `lv_draw_create_task()`
  draw-task scratch, allocated fresh via `lv_malloc_zeroed()` on EVERY draw call in EVERY frame per
  `lv_draw.c`, got pushed to PSRAM too → render slow enough to trip `task_wdt` on "swdraw"); tried 2048
  (fixed swdraw, but then `sdmmc_cmd: allocate_dma_buf: not enough mem, err=0x101` — SD driver's required
  internal/DMA-capable buffer couldn't be satisfied). **Left at the default 16384** — the buffer_height fix
  made the global threshold approach unnecessary. The core problem with this whole approach: persistent
  widget-tree allocations and per-frame draw-task scratch go through the identical `lv_malloc_core` path and
  are similarly sized, so no single size threshold can separate "safe to push to PSRAM" from "must stay
  internal, touched every frame."

**How to apply**: if internal RAM gets tight again, `buffer_height` can still be tuned lower (diminishing
returns below 10, and more per-frame flush overhead as it shrinks — user was told this tradeoff and chose
to stop at 10). Don't revisit the malloc-threshold/custom-allocator avenues without genuinely new evidence.
The temporary `LOG_MEM()` diagnostic macro + checkpoints added to `Cntl/main/main.c` app_main() for this
investigation have been removed (were tagged "MEMCHK" in ESP_LOGW) now that the fix is confirmed.

**Follow-up 2026-09-15**: during that day's Stats/Sensor-panel redesign session, user noticed internal RAM
had dropped ~10KB vs. the build right before, and deferred it ("이건 일단 수정 후 다시 보자") until after
that session's fix batch landed. Revisited same day after the batch (signal-color fix, Record table
resize, panel row-spacing, graph-refresh-delay fix, etc. all shipped): user observed live internal RAM now
fluctuates, peaking ~67KB and floor ~52KB — **accepted as-is** ("일단 이정도면 만족"), no further
investigation requested. Don't reopen the "~10KB decrease" question unless a NEW drop is separately
reported — this range is the accepted baseline going forward.
