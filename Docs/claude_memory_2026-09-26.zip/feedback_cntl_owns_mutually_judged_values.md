---
name: feedback-cntl-owns-mutually-judged-values
description: Precise scope rule for when CNTL must own+push a protocol-tuning constant to CAM/Sens vs when the node can keep it local — corrected 2026-08-21
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-21T07:31:06.480Z
---

CNTL only needs to own and push a protocol-tuning constant (retry round counts, timeout budgets,
etc.) to CAM/Sens when **both sides independently make a judgment/decision using the same number**.
If only one side decides using the value and simply reports the outcome to the other side each time,
the other side doesn't need to know the constant in advance — there's no drift risk because nothing
is being independently assumed.

Test to apply before making something "CNTL pushes this": does the peer make its own independent
judgment call using this exact number (drift risk — needs CNTL ownership), or does it just decide
locally and tell CNTL the result each time via the message itself (no drift risk — CNTL reads
whatever's in the message, doesn't need to pre-know the constant)?

**Why:** Refines [[feedback_cntl_owns_all_state]]-style "CAM/Sens have no intelligence" principle —
found 2026-08-21 via a real bug: `MAX_NACK_ROUNDS` (CAM, esp_now_cam.c) and `PHOTO_NACK_MAX_ROUNDS`
(Cntl, esp_now_photo.c) were independently hardcoded to the same value (3), but CAM's loop checked
its bound *after* attempting each round while Cntl's checked *before* incrementing — an off-by-one
that meant Cntl always waited for a 4th DONE message CAM would never send after exhausting its 3
rounds, surfacing as a confusing "no response" (3006) instead of "chunks permanently missing" (3002).
This is the target case for CNTL-push: both sides count rounds and must agree on the ceiling.

Contrast: `SR_WINDOW_SIZE` (CAM's chunk-transfer window batch size) looked like a similar duplicate at
first glance, but isn't — Cntl's window-status handler reads `range_start`/`range_count` directly out
of each incoming request rather than assuming a fixed window size, so CAM can pick its own window size
freely with zero drift risk. Not every same-named-sounding constant on both sides qualifies.

**How to apply:**
- Values that qualify (both sides judge, needs single CNTL-owned source pushed via the established
  `device_config` + `CAM_CONFIG_SET`-at-pairing pattern, same mechanism already used for
  capture_interval/response_interval/agc_enable/aec_enable/xclk_mhz): NACK max retry rounds is the
  first concrete case, fixed 2026-08-21.
- Values that DON'T qualify: stay local to whichever side decides them; no push needed.
- Special case — **pre-pairing constants** (e.g., `esp_now_channelsync`'s `PING_FAIL_THRESHOLD` vs
  Cntl's `HUB_NODE_TIMEOUT_MARGIN_MULT`, which is derived assuming that threshold): these run *before*
  any pairing/config-push channel exists, so CNTL can't push them at "start of communication" the
  normal way even if they qualify by the judgment-test above. These need a single shared `#define` in
  `Common/components/` that both sides `#include`, not a runtime push.
- Sens is a planned follow-up phase (explicitly, per the user: CAM is being fixed first specifically
  so the same resulting design can be applied to Sens next) — Sens currently reimplements
  channel-scanning logic independently instead of using the shared `esp_now_channelsync` component,
  which is a separate structural issue from the constant-ownership question but should be resolved
  using the same filter when that migration happens.
