---
name: project-cntl-rtc-and-unified-sleep-plan
description: "RTC (DONE) + CAM Deep Sleep/connectionless model + SLEEP_NOW full redesign (즉시/Live mode, CAM never sleeps autonomously) + photo-list protocol replaced (COUNT/BATCH/DONE, fixed the 3007 bug) — HW-verified, committed 6a4b241+7fa0c61, pushed 2026-08-11; battery-drain measurement still pending"
metadata: 
  node_type: memory
  type: project
  originSessionId: e3f8c71a-ac79-4876-8f90-c89bb024de69
  modified: 2026-08-11T10:48:52.014Z
---

**Item 1 (RTC time reliability) — DONE 2026-08-09, hardware-verified.** Root cause was NOT a
timezone bug: `Cntl/assets_root/time_sync.txt` was a static file frozen since 2026-08-01, never
regenerated at build time despite code comments claiming it was. Fixed with
`Cntl/tools/gen_time_sync.py` (new, regenerates the file every build via
`calendar.timegm(datetime.now().timetuple())`) wired into `Cntl/CMakeLists.txt` as a custom
target ahead of `littlefs_create_partition_image`. Also shipped: a System-settings manual
time-set UI (5-dropdown Y/M/D/H/Min popup in `ui_main.c`, `rtc_sync_set_datetime()` added to
`rtc_sync.c`/`.h`, writes PCF85063A + `settimeofday`). Internet/NTP sync was assessed only
("간단하면 연동까지, 복잡하면 자리만") and never implemented — still open if wanted later, but
not currently planned.

Also shipped in the same 2026-08-09 session (unrelated to RTC, opportunistic UI polish while in
`ui_main.c`): unified panel/row spacing across all tabs (screen-edge gap=5px, inter-panel
gap=5px, panel's own top padding=18px, row's own vertical padding=0px, row-to-row gap=10px),
unified all action-button widths (main screen + popups) to the widest label's natural width, and
fixed the resulting progress-popup Cancel-button text-overflow regression (moved "종료 대기
중..." to a separate status label instead of overwriting the button's own label).

---

**Item 2 (CAM power model) — Light Sleep tried and abandoned 2026-08-09; pivoted to Deep Sleep,
plan approved, implementation starting.**

**Light Sleep result**: implemented `CONFIG_USJ_NO_AUTO_LS_ON_CONNECTION` +
`esp_pm_configure`/tickless-idle per the 2026-08-08 research (see prior version of this memory
for the research trail). Added diagnostic counters (`light_sleep_count`/`light_sleep_ms`) and a
live log-style stats panel in Cntl's 통계 tab to observe it on real hardware (no USB needed).
Result across many real-hardware trials, including on a genuinely host-free power source:
**light_sleep_count stayed at 0 — Light Sleep never actually engaged.** Root cause was never
found (deep-dived ESP-IDF source + web research, including with "wake" in the search terms per
user instruction) despite ruling out every USB/lock/WiFi-driver hypothesis tested. This remains
an unresolved mystery in the codebase's history.

**Decision**: per the pre-agreed 8/8 fallback ("Light sleep으로 성공한다면 deep sleep은
안 할꺼야"), user said "그렇군. 실험해보자. Light 는 없애고" — abandon Light Sleep entirely,
switch to Deep Sleep periodic-wake, backed by an RTC Watchdog (RWDT) safety net.

**RWDT feasibility (researched, confirmed 2026-08-09)**: ESP32-S3 has the RWDT register but the
convenience API (`esp_hw_support/include/rtc_wdt.h`) is gated
`#if CONFIG_IDF_TARGET_ESP32 || CONFIG_IDF_TARGET_ESP32S2` only — S3 must use the low-level
`hal/wdt_hal.h` API directly (`wdt_hal_init`/`wdt_hal_config_stage`/`wdt_hal_enable`, stage action
`WDT_STAGE_ACTION_RESET_RTC`, must clear `RTC_CNTL_WDT_PAUSE_IN_SLP`). IDF itself uses this exact
pattern for light-sleep-exit protection (`esp_hw_support/sleep_modes.c:1524-1533`) — confirmed
working pattern on S3.

**Scope narrowing (2026-08-09, user-driven)**: an initial design ballooned to include a full
Cntl-side command-queueing/blocking/pending-banner/toast system (for when CAM is asleep and the
user tries "지금촬영" etc.) plus a "CAM/SENS push data to Cntl's SD card" architecture change.
User explicitly cut this down to **just the core mechanism**: (1) RWDT safety net, (2) Cntl
auto-re-pairing on every CAM wake (CAM fully reboots each cycle, no state). The command-queue
system and SD-card push-model are deferred, contingent on real battery results — NOT built now.

**Concrete success criterion (user-specified)**: at 10-second responsiveness ("균형모드"),
CAM's battery must last 3 months. If it doesn't, the design gets rethought from scratch (possibly
the SD-card push-model mentioned above) rather than incrementally patched.

**Responsiveness value/label redefinition (user-confirmed table)**:
| value | label | help text |
|---|---|---|
| 1s | 즉시 | 성능모드 — 즉시 반응(사실상 상시 동작) |
| 3s | 빠름 | 동작확인 모드 — Sleep이 실제로 도는지 테스트용 |
| 10s | 균형 | 균형모드 — 절전되면서도 사용성 적절 |
| 30s | 절전 | 절전모드 — 참을 수 있으면 배터리 오래감 |
| 1800s (30m) | 최대절전 | 최대절전모드 — 수동촬영은 포기, 자동촬영분만 확인 |

Dropdown shows short labels; a separate help-text line shows the fuller description for the
selected value. The 30-min tier is also supposed to shift the UI's own emphasis (away from
interactive controls, toward "already-captured photos") but that scenario change is explicitly
deferred, not designed yet.

**Three-axes clarification (user, important for not re-conflating later)**: CAM/SENS each
already have an independent always-on periodic cycle unrelated to this work — CAM's existing
auto-capture-interval dropdown (fine even at 3-10h) and SENS's existing measurement interval
(fine even at 30min). This redesign only touches **응답성** (worst-case latency for an on-demand
user command, max 30s) — the Deep Sleep cycle length is tied to responsiveness, not to the
auto-capture interval, because "how fast do you react to a command" and "how often do you take a
photo" are different questions. Don't conflate these three axes.

**Future ideas — memo only, NOT designed/built**: (a) time-of-day adaptive responsiveness
scheduling (mainly relax at night, since manual capture is an interactive/daytime action) — same
design, just auto-scheduling the responsiveness value by clock time; (b) SENS-specific: gradual
relaxation from a short post-config-change verification interval back to a long-term target
(e.g. 30min), on a smooth curve rather than a hard cutover — rationale is that SENS's short
interval is only ever needed transiently right after a settings change, unlike CAM's which is
needed on an ongoing basis for manual capture.

**Plan status: implementation DONE 2026-08-10, both projects build clean, NOT YET flashed/HW-verified**
(no boards were connected to the PC when implementation finished — `[System.IO.Ports.SerialPort]::GetPortNames()`
returned empty). Plan file: `C:\Users\Dev\.claude\plans\composed-sprouting-book.md` (title "CAM
Deep Sleep 전환 (1차: 코어 메커니즘만)"), approved 2026-08-09/10, reconciled to drop the earlier
larger-scoped command-queue/banner/toast sections before implementation (those were cut per the
scope-narrowing below). What got built, matching the plan's A/B/C sections:
- **CAM** (`CAM/main/`): removed all Light Sleep code (`cam_node.c`/`.h`, `esp_now_cam.c`/`.h`,
  `dev_console.c`'s 6 sleep-lock call sites, `sdkconfig.defaults`' PM/USJ Kconfig lines — deleted
  `CAM/sdkconfig` so it regenerates clean). New `rwdt_guard.c`/`.h` module (low-level
  `hal/wdt_hal.h` API, `esp_hal_wdt`+`esp_hw_support` added to `CMakeLists.txt` REQUIRES) — arms
  an RTC watchdog with `WDT_STAGE_ACTION_RESET_RTC`, and critically also clears
  `rwdt_ll_set_pause_in_sleep_en(..., false)` since `wdt_hal_init()` defaults that to `true`
  (paused during sleep) — found this by reading `wdt_hal_iram.c` source directly, it's not
  obvious from the header docs and the plan's original code sketch omitted it. `app_main`
  rewritten: `capture_wake_reason()` + `rwdt_guard_arm()` at the very top, then normal init, then
  (if `CONFIG_CAM_DEEPSLEEP_ENABLE`, default y) a `cam_node_wake_window_done()` poll loop before
  `esp_deep_sleep_start()`. New Kconfig options `CAM_DEEPSLEEP_ENABLE` and
  `CAM_DEEPSLEEP_AWAKE_MARGIN_SEC` (default 90) in `Kconfig.projbuild`.
- **Common** (`Common/components/esp_now_link/include/esp_now_link.h`): `ESP_NOW_MSG_POWER_STATS`
  renamed in place to `ESP_NOW_MSG_DEEP_SLEEP_STATS` (value unchanged, 33), new
  `cam_wake_reason_t` enum and `esp_now_deep_sleep_stats_t` struct, old
  `esp_now_power_stats_t` deleted.
- **Cntl** (`Cntl/main/`): `esp_now_hub_node_t` Light-Sleep fields replaced with
  `ds_cycle_count`/`ds_total_asleep_sec`/`ds_rwdt_catch_count`/`ds_last_wake_reason`/etc
  (`esp_now_hub.h`). ADVERTISE handler in `esp_now_hub.c` now auto-calls `esp_now_hub_pair()`
  when a previously-paired node re-advertises (unless the user explicitly unpaired it) — no more
  manual re-approval popup needed for CAM's per-cycle full reboot. `DEEP_SLEEP_STATS` recv handler
  accumulates cycle/sleep/RWDT-catch counters. Responsiveness dropdown values changed from
  `{1,2,5,10}` to `{1,3,10,30,1800}` seconds with short labels (즉시/빠름/균형/절전/최대절전) —
  a new help-text row (`s_response_help_label`, sibling of the dropdown row in the System group
  box) shows the fuller description per selected value, updates on dropdown-change/language-switch
  (`ui_main.c`, new strings `STR_RESPONSE_HELP_0..4` in `ui_strings.h`/`.c`). Stats-tab power panel
  (`refresh_power_panel`) simplified to diff on `ds_cycle_count` alone (monotonic, unlike the old
  multi-field Light-Sleep diff) and shows cycle#/wake-reason/awake-time/asleep-total/RWDT-count per
  line.
- Both `CAM` and `Cntl` build clean with `ninja -C build` (verified 2026-08-10).

---

**Item 2 continued — HW-verified 2026-08-10, committed as `645df84`** ("CAM/Cntl: Deep Sleep +
RWDT for CAM, connectionless 3-state model + awake-time optimization for Cntl"). Core mechanism
flashed to both boards and live-tested through many real pairing/sleep/wake cycles — 0 RWDT
catches, no crashes, auto-reconnect worked every cycle. Scope grew substantially beyond the
original plan through the same session (user drove each addition):

**1. Connectionless model correction (user, mid-session)**: ESP-NOW has no "connected/disconnected"
— user redefined it as three states: WAITING (never paired this session, or auto-reconnect stuck
past timeout) / PAIRED (`ever_paired`, sticky — CAM being mid-sleep is normal, not an error) /
ACTIVE (`paired`, momentary radio-confirmed). `esp_now_hub_get_conn_state()` in `esp_now_hub.c`
composes these; UI mostly treats PAIRED==ACTIVE (lists/panels stay stable through sleep gaps),
only the summary panel + Settings tab distinguish them in wording ("페어됨" vs "통신 중").

**2. Awake-time optimization (user-requested via full "대화 시작" design pass before coding)**:
- Channel-scan fix A+B in `Common/components/esp_now_channelsync/esp_now_channelsync.c`: send an
  immediate ADVERTISE on the starting scan channel (was previously tested last in the sweep) +
  `RTC_DATA_ATTR` remembers last-synced channel across Deep Sleep so the next wake tries it first.
  Cut channel-sync from ~7.4s to ~3.5s.
- New proactive `ESP_NOW_MSG_SLEEP_NOW` (Cntl→CAM, fire-and-forget) so CAM doesn't have to idle out
  a blind grace timer — `esp_now_hub.c`'s `adaptive_sleep_timer_cb()` sends it once per node per
  cycle (`sleep_now_sent` dedup flag, reset on each fresh PAIR_ACK) once
  `device_config_get_adaptive_response_sec()` (new setting, 10s/30s/1min, separate from "응답성")
  has elapsed since the last user action. CAM's old 2s/5s idle-grace fallback grew to 70s — now
  just a rare safety net in case SLEEP_NOW is lost, not the primary mechanism.
- "적응형 반응시간" is Cntl-only (never sent to CAM) — purely governs when Cntl sends SLEEP_NOW.
  "응답성"/"촬영주기" ARE sent to CAM (`push_cam_config_to()`'s `CAM_CONFIG_SET`, both fields in
  one message) and, critically, get re-pushed automatically on **every** wake/pairing (not just
  on Apply) — so a config-push that fails while CAM is unreachable self-heals for free at the very
  next connection; no error needs to be shown for that case (see bug list below).

**3. Bug rounds found via live hardware testing (all fixed, same session)**:
- **Stale adaptive timestamp**: `s_last_user_action_ms` only got reset by the session's first
  auto-list-fetch; since Cntl runs continuously across CAM's many reboots, every pairing after the
  first already looked "quiet past threshold" the instant it completed — SLEEP_NOW fired within
  ~1-1.5s regardless of the configured 10/30/60s, collapsing the user's reaction window to nothing.
  Fixed by also resetting the timestamp on every fresh `became_paired` transition, AND on every
  chunk/list-entry received mid-transfer (a multi-second photo/list transfer was previously
  "silently spent" from the single timestamp set at request-start, leaving near-zero grace right
  when a transfer finished — user's own diagnosis: "통신 완료 후가 아니라 통신을 시작한 입력에
  의해 카운터가 진행됨").
- **Retry/timeout budgets too short to span a legitimate sleep cycle**: `esp_now_tx.c`'s retry
  budget and `ui_main.c`'s progress-popup timeout (`cam_response_timeout_ms()`, was a fixed 8s
  macro) were both decoupled from the actual "응답성" cycle length — so a command sent while CAM
  was *legitimately* asleep (not a bug) would time out (3006 etc.) well before CAM's next natural
  wake. Both now scale to `min(response_interval_sec, 30) + 3s margin` (30-min "최대절전" tier
  intentionally excluded from blocking-wait — matches the plan's existing note that tier needs a
  different UX, not built).
- **Misattributed errors for requests that were never even sent**: when `conn_state==WAITING`, the
  request-issuing functions already silently no-op (via `require_paired()`), but the UI popups
  didn't know that and would wait the full budget before showing a misleading "무응답" toast.
  Consolidated into one `require_active_or_report(mac, what)` helper in `ui_main.c` — WAITING skips
  the request/popup entirely and shows `UI_ERR_NOT_PAIRED`(2007, reused, not a new code) *
  immediately*. All 6 CAM-facing actions in `ui_main.c` route through it (사진가져오기/삭제/
  지금촬영/목록갱신/전체삭제/촬영주기적용); `esp_now_photo.c`'s underlying `require_paired()` still
  the actual send-side gate. **Exception**: config-apply (촬영주기/응답성) does NOT show 2007 for
  WAITING — since the value is always persisted + guaranteed auto-repush on next connect (see
  point 2), that's a normal deferred-not-failed state, so it shows an info log only ("저장됨 —
  재연결 시 자동 반영"), not an error. This distinction was caught by the user mid-session after I
  initially (wrongly) wired capture-interval-apply through the same 2007 path as the other 5.
- Dead code found+removed while reviewing before commit: `ui_log_clear_err()` (unused after the
  2007 redesign made it obsolete) and a stale comment describing the old mechanism.
- Whole-Cntl-screen touch also now feeds the adaptive timer (`main.c`,
  `lv_indev_add_event_cb(touch, ..., LV_EVENT_PRESSED, ...)` calling
  `esp_now_hub_note_user_action()`) — user explicitly deferred this until the bugs above were
  fixed, then asked for it once live-verified.

**What's left**: a real multi-day/week battery-drain measurement at 10s responsiveness against the
3-month target (this is the actual point of the whole redesign — everything above is mechanism,
not yet proof it solves the original problem). CAM's manual capture-interval / camera-init ~2s
delay investigation was also raised but explicitly deferred pending real photo-quality testing on
hardware — not started. COM ports were last confirmed Cntl=COM18/CAM=COM5 but re-verify each
session (see [[reference-cntl-cam-com-ports]]).

---

**Item 2 continued further — 2026-08-10, same day, committed as `4db9d50`** ("Cntl/CAM: fix
adaptive-timer over-reset + list transfer reliability (SR), CAM idle-cycle time nearly halved"),
pushed to origin/main. This picks up right after `645df84` — same session, user kept live-testing
and found deeper issues.

**1. CAM camera init made fully lazy ("필요시 초기화", NOT just faster)**: user pointed out CAM
wakes mostly to check "got anything for me?", not to shoot — so `camera_init()` should never run
on a wake that doesn't end up capturing. Removed the unconditional call from `app_main()`; added
`ensure_camera_ready()` (cam_node.c), called only from `camera_capture_one()` (covers both auto
and manual capture) and `cam_node_capture_now_sized()` (covers the console resolution-override
path, which needs a sensor handle before `camera_capture_one()` runs). HW-confirmed: a no-capture
wake now reaches ESP-NOW-ready in <1s (previously ~3.5s+). Terminology note: user explicitly
corrected "지연 초기화"(deferred) to **"필요시 초기화"**(on-demand) — deferred implies "will
still happen eventually this cycle," but the correct semantics are "may never happen at all this
cycle if nothing needs it."

Camera warm-up frame count (replacing the old blind `vTaskDelay(2000)`, itself from earlier
645df84 work) was first set to 5 (guessed), then corrected to **2** per user's direct domain
knowledge ("버리는 프레임은 최대 2개, 보통 1개") — `CAM_WARMUP_FRAME_COUNT` in `cam_node.c`. A
diagnostic path that saved all 5 warmup frames to SD for visual QA caused a **main-task stack
overflow crash-loop** (SD/FATFS write too heavy for that task's stack at that point in boot) —
reverted to discard-only; the fb_count-loop pattern camera_capture_one() already uses for
DMA-buffer freshness was kept separate (different purpose: buffer freshness vs AEC/AGC exposure
convergence). **Not yet re-verified: actual photo quality at 2 warmup frames** (was confirmed
good at 5, not re-checked after lowering to 2) — open item.

**2. PHOTO_LIST_ENTRY given the same SR/NACK reliability chunks already had**: found via the
grand principle user re-stated mid-session — "chunk는 SR, 나머지는 reliable stack, 앱 레이어는
통신이 항상 잘 됐다고 본다." List transfer (1 request → up to 500 raw unreliable
`ESP_NOW_MSG_PHOTO_LIST_ENTRY` sends → 1 done) was the one place this was violated — its only
"reliability" was Cntl detecting a count mismatch and re-requesting the *entire* list from
scratch (up to 2x), which silently stacked its own retry budget on top of `esp_now_tx`'s, blowing
past the popup's own timeout budget (root cause of repeated live "3005+3007 together" reports).
Fix, mirroring chunks exactly: `esp_now_photo_list_entry_t` gained an `index` field;
`esp_now_photo_list_done_t` gained `missing_count`/`missing_idx[]` (reusing
`ESP_NOW_PHOTO_NACK_MAX_INDICES`=400); Cntl (`esp_now_photo.c`) tracks a bitmap and NACKs only the
gaps (`PHOTO_LIST_NACK_MAX_ROUNDS`=3, mirrors chunk's `PHOTO_NACK_MAX_ROUNDS`); CAM
(`esp_now_cam.c`) caches its `ids[]` from the original scan and `resend_list_entries()` re-sends
only what's asked. The list-refresh popup (`renew_list_tick_fn`) was also changed from a fixed
total-elapsed budget to fetch's proven stall-detection pattern (reset on any new entry via
`esp_now_photo_list_get_progress()`), since a legitimate multi-round SR exchange can now
legitimately take longer than one flat budget.

**3. "slept" stat was a straight bug, not a timing nuance**: `esp_now_deep_sleep_stats_t.sleep_interval_sec`
is (and always was) CAM's *currently configured* interval — forward-looking, not a measurement.
Cntl was accumulating it into `ds_total_asleep_sec` as if it were retrospective ("already slept"),
so a freshly-paired node with zero real sleep behind it would immediately show a nonzero "slept"
value — caught by the user noticing this ("방금 페어링됐는데 벌써 잤다고 나온다") and reasoning
through what the field could and couldn't mean. Fix: new `RTC_DATA_ATTR uint32_t
s_last_actual_sleep_sec` in `cam_node.c`, set to the interval right before `esp_deep_sleep_start()`
so it survives into the next boot as a genuine "how long did I just sleep" value (0 if
wake_reason != TIMER, i.e. RWDT/POWERON — no real sleep happened); new wire field
`actual_last_sleep_sec`; Cntl's `ds_total_asleep_sec` accumulator replaced with
`ds_last_actual_sleep_sec` (per-cycle, NOT accumulated — user explicitly said not to bother
accumulating, just show the current cycle's value).

**4. SLEEP_NOW moved onto the reliable stack**: was fire-and-forget by original design ("유실돼도
CAM의 유휴여유 타이머가 결국 재워줌, 무해"). User pushed back mid-diagnosis ("reliable stack으로
바꾸고") applying the grand principle to this message too. New `ESP_NOW_MSG_SLEEP_NOW_ACK`
(reuses `esp_now_sleep_now_t`, msg_type swap); CAM's SLEEP_NOW handler
(`esp_now_cam.c`) now replies; Cntl's `adaptive_sleep_timer_cb()` (`esp_now_hub.c`) now calls
`esp_now_tx_enqueue()` instead of a raw `esp_now_send()` — safe because enqueue is non-blocking
(the callback runs on the shared `esp_timer` task, must never block).

**5. THE actual root cause of the whole "list-refresh takes 26s / SLEEP_NOW fires oddly" saga —
adaptive timer was being reset on every routine re-pairing, not just genuine user action.**
Found through careful live -mm:ss-timestamped log analysis the user insisted on doing by hand
(explicitly rejected jumping to more live-capture attempts — "추정만으로 테스트하지 말고, 소스에
이런 여지가 있는지"). The `became_paired` reset added earlier in 645df84 (to fix "SLEEP_NOW fires
within 1s of every pairing") fires on **every** re-pairing — but CAM re-pairs every single wake
as pure routine ("나 뭐 할 거 없어?" check-in, not user action). Since that reset always wins over
any genuine staleness, the adaptive timer could never observe "truly idle for a while, relax
further" — every cycle unconditionally paid the *full* adaptive-response wait even with zero
pending work, wasting response_interval + adaptive_threshold (~20s) per cycle instead of just
response_interval (~10s). Fix: added `first_ever_pairing` (captures `!was_ever_paired` at the
same point `became_paired` is captured) and gated the reset to only fire then — a node's true
first connection this session still gets a reaction window, but routine keepalive-style
re-pairings don't reset the clock. **HW-confirmed**: steady-state cycle time dropped from ~20s to
~11-12s (user's own measurement from the -mm:ss log after flashing the fix) — matches prediction
exactly (response_interval + ~1s `ADAPTIVE_SLEEP_PAIR_SETTLE_MS` margin, no adaptive wait on
routine cycles).

**6. Stats-tab UI overhaul** (`ui_main.c`, user-directed): 통계 tab relaid vertical (was
horizontal) — power panel on top at a fixed 320px height, log panel below getting the remainder;
title row gained a pause/resume button (`cb_power_log_pause_toggle`, calls `lv_timer_pause`/
`lv_timer_resume` on the panel's own refresh timer) so values can be read without the log
scrolling out from under you; every power-panel line (both the per-cycle C report and the new
separate SLEEP_NOW send line) now carries a `-mm:ss` timestamp (`lv_tick_get()`-based) so gaps
between events are directly readable without a stopwatch. SLEEP_NOW's own line text simplified
from "조용Xms/임계값Yms" to "IdleXms" (threshold no longer meaningful now that the reset scope
changed).

**KNOWN UNRESOLVED BUG**: `lv_label_set_recolor()` + inline `#RRGGBB text#` markup (attempted to
make SLEEP_NOW lines red vs CAM-report lines black) does not render as intended — the literal
`#ff0000` text shows up unparsed and line-wrap visibly breaks/overlaps. Root cause not found
despite reading LVGL's `lv_draw_label.c` recolor state machine (syntax appears correct per
source). Left unresolved — SLEEP_NOW lines currently display with the raw markup text still
present, cosmetic issue only (does not affect the underlying fix's correctness, confirmed via the
-mm:ss timestamps regardless of the color glitch).

**Pending items enumerated at session close (2026-08-10), none started**:
- Re-verify actual photo quality at `CAM_WARMUP_FRAME_COUNT=2` (visual check, real hardware)
- Re-verify "auto list-refresh on connect" actually fires (reported broken earlier same session,
  never circled back after the deeper adaptive-timer investigation took over)
- End-to-end re-verification of list-refresh now that both the SR fix AND the adaptive-timer fix
  are in — is the ~26s/"3005+3007" symptom fully gone, or only mostly?
- Confirm `ensure_camera_ready()` produces a correct photo end-to-end on a genuine capture request
  (lazy-init path specifically, not just "doesn't run when not needed")
- Quantify CAM's full reboot-to-ready cycle time improvement as a concrete before/after number
- Fix or replace the LVGL recolor bug above
- Battery-drain measurement (the actual point of this whole project) — still not started
- Apply this session's patterns (lazy-init, adaptive-timer discipline) to SENS — not started

**How to apply**: if resuming this work, read this memory in full (not the original plan file,
which only covers the earliest "core mechanism" phase) — check `git log --oneline` from `4db9d50`
backward for the actual diffs before assuming anything here is stale.

---

**2026-08-11 session — SLEEP_NOW timing fully redesigned again, photo-list protocol replaced,
response_interval persistence bug found+fixed. Committed `6a4b241` (source) + `7fa0c61` (docs),
pushed to origin/main.** See `Docs/한일_2026-08-11.txt` for full narrative. Supersedes several
"pending items" from the 2026-08-10 section above.

**1. LVGL recolor bug (2026-08-10 KNOWN UNRESOLVED BUG above) — abandoned, not fixed.** 3 more
attempts (word-level scoping, removing underscores, whole-line no-boundary wrap) all broke
identically. Root mechanism never found. Replaced entirely with a plain-text ">>> " marker on
SLEEP_NOW lines — no recolor markup used anywhere in this codebase now.

**2. SLEEP_NOW timing redesigned from scratch (user's detailed spec)**: decision to send
SLEEP_NOW is now driven ONLY by (a) Cntl's adaptive idle-timer elapsing or (b) CAM's wake report
arriving, whichever is later — fully decoupled from CAM_CONFIG_ACK (which now only marks Cntl
busy, doesn't trigger sleep). CAM never sleeps autonomously under any circumstance — the old
"15s pairing-wait timeout" and "70s autonomous-sleep fallback" are both gone; CAM instead sends
`SLEEP_NOW_REQUEST` every 5s while awake-and-idle, forever, until Cntl actually sends SLEEP_NOW.
New responsiveness value **0 = "즉시"/Live = deep sleep disabled entirely for that cycle** (old
minimum was 1s labeled "즉시"; user: "1초=0초=즉시인거라 캠을 안재우겠다는 건데"). New WARNING
log severity (`ui_log_add_warn`, yellow, auto-clears on popup view) added alongside the existing
persistent ERROR, used for SLEEP_NOW_REQUEST re-nudges (escalates to ERROR past 3 reps).
Live dual-serial capture confirmed the exact designed sequence reproducing consistently.

**3. Photo-list fetch (3007 bug) — root-caused and fixed via full protocol replacement, not a
patch.** User's own diagnosis: CAM was doing redundant per-file `cam_storage_stat()` calls PLUS
the whole list was fundamentally unreliable (one message per file, no delivery guarantee at all
beyond the 2026-08-10 SR bolt-on). Replaced with `PHOTO_LIST_COUNT` (total count first, reliable)
-> `PHOTO_LIST_BATCH` x N (up to 64 items per batch, reliable) -> `PHOTO_LIST_DONE` — batches
being reliable means gap-recovery is structurally impossible to need, so the 2026-08-10 SR
bitmap/NACK-round machinery was deleted outright, not kept as a fallback. Two explicit error
conditions: DONE arriving with received<expected (immediate `PHOTO_LIST_ERROR` reliably notifies
CAM to reset) and DONE never arriving after expected is reached (no new code needed — the
existing UI stall-timeout in `renew_list_tick_fn` already catches it via `received` no longer
advancing). CAM's `cam_storage_list_full()` reuses the stat() already taken during the directory
scan instead of re-querying per file (raw FatFs `f_opendir`/`f_readdir` to eliminate stat()
entirely was explicitly deferred by the user — "일단 이렇게 할꺼로 기억해 두고"). HW-verified:
309 files, full COUNT->BATCH(64+64+64+64+53)->DONE round-trip in ~150ms, repeated manual+auto
fetches all clean, no 3007 recurrence.
**Naming collision found mid-implementation**: the new shared wire struct
`esp_now_photo_list_item_t` (Common/esp_now_link.h) collided with Cntl's pre-existing local
UI-display struct of the identical name (`esp_now_photo.h`) — renamed the local one to
`esp_now_photo_list_view_item_t`.

**4. Response_interval silently stuck at 2 instead of the user's actual "즉시"(0) setting —
found via a long, contentious debugging exchange; root cause was this same session's own earlier
work, not stale data.** CAM was observed sending `SLEEP_NOW_REQUEST` every 5s continuously,
which per `cam_node_wake_window_done()`'s code can ONLY happen when `response_interval_sec != 0`
— direct proof the applied value wasn't really Live. First hypothesis ("just a stale saved file,
click Apply again") was WRONG and explicitly rejected by the user, who had already stated twice
that they always test in Live mode — see [[user-experience-level]]'s 2026-08-11 reinforcement for
the behavioral lesson. **Actual root cause**: `device_config.c`'s `DEVICE_CONFIG_VERSION` bump
(1->2, done 2026-08-10 for `adaptive_response_sec`) had no migration path; a version-mismatch
fallback silently reverted to compiled defaults (response_interval=2) for that boot, and
`device_config_save()` always writes all three fields together, so applying ANY other unrelated
setting during that fallback boot permanently baked the wrong default into the new-version file.
Fixed: version-mismatch fallback now also raises a visible `UI_ERR_CONFIG_FILE_MISMATCH` (was
serial-log-only before, easy to miss). **Second bug found in the same investigation**: the
capture/response/adaptive-response Apply buttons were all unconditionally force-disabled at
widget creation (`lv_obj_add_state(..., LV_STATE_DISABLED)`, comment claimed "부팅 직후엔
표시값==저장값" — false whenever the loaded value doesn't match any current preset, exactly this
case) instead of calling `update_*_apply_enabled()` to check the real state — fixed by calling
that function right after creation for all three. Re-verified fix with a 330s (5.5 min) capture
spanning past the adaptive_response threshold (300s, user's own setting) — confirmed zero
SLEEP_NOW traffic the whole window, Live-mode guard correctly holds even after the adaptive
deadline elapses.

**5. List-refresh popup given 2-stage progress labels** (user request, mirrors
`capture_popup_tick_fn`'s stacked-label pattern exactly): "가져오기 명령 전송" /
"목록 수신 중" / success-or-failure-with-reason. New `ESP_NOW_PHOTO_LIST_STATE_ERROR` added to
the list state machine (previously failures just reset straight to IDLE with no way for the
popup to know why) and `esp_now_photo_list_count_received()` getter (distinguishes "COUNT not
yet received" from "CAM genuinely has 0 files," which a naive `total>0` check would conflate).
A temporary per-stage minimum-display-time was added, hardware-verified visually by the user
("잘 된다"), then removed per explicit instruction once confirmed — production build has no
artificial delay, stages resolve at real transfer speed (~150ms total).

**Still pending, unchanged from 2026-08-10**: battery-drain measurement (the actual point of the
whole project) — still not started. Also newly identified this session:
[[project-cntl-cam-photo-list-first-pair-timeout]] (first-pairing PHOTO_LIST_REQUEST timeout bug)
needs re-verification now that the list protocol changed entirely — plausible it's fixed as a
side effect but not confirmed.
