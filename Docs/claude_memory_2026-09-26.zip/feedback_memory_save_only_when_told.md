---
name: feedback-memory-save-only-when-told
description: "Don't proactively write/update memory files mid-session — only save when the user explicitly tells you to"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 20e69685-62be-44b4-97d5-accb4eb2dbe9
  modified: 2026-09-22T03:57:53.472Z
---

User: "메모리 저장은 내가 시킬 때만 해라" (only save to memory when I tell you to) — 2026-09-22,
after a long I2C bridge debugging session where memory files were updated after nearly every
finding without being asked.

**Why:** the user wants control over what becomes persistent, cross-session memory, rather than
Claude deciding unilaterally during a working session which findings are worth committing.

**How to apply:** hold findings, corrections, and project state in the conversation itself; do not
call Write/Edit on files under the memory directory unless the user gives an explicit instruction
to save/remember (e.g. "메모리에 저장해", "기억해", "저장해줘"). This overrides the general
auto-memory system's default "save proactively" guidance for this user. Does not apply to this
memory itself, which exists precisely to make the rule persist — the user's correction that
prompted it is the explicit trigger for this one save.
