---
name: feedback-never-put-large-data-on-stack
description: "Anything larger than a pointer must not live as a stack-local (or by-value parameter) in embedded C — allocate once (heap/PSRAM/static) and pass a pointer through the call chain instead"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-21T15:05:14.082Z
---

Caused a real, hardware-verified crash (CNTL stuck in a stack-overflow reboot loop) in
`Cntl/main/i2c_bridge.c`, part of [[project_cntl_i2c_bridge_design_2026_09_21]]. Wrote
`bridge_link_packet_t pkt = {0};` (1493 bytes — a 1470-byte payload array dominates it) as a
plain stack-local in `i2c_bridge_poll_task()` **and independently again** in `bridge_send()`,
`bridge_reliable_request()`, `i2c_bridge_set_channel()` — all of which the poll task's own call
chain reaches synchronously (`i2c_bridge_poll_task` → `deliver_incoming` → `recv_cb` (hub.c) →
sometimes → `bridge_send`), all sharing that one task's stack. Multiple ~1.5KB frames stacked
inside a 4096-byte task stack overflowed it every single boot.

**The rule, stated by the user directly:** "크기가 크면(포인터보다 크면) 비정상적인 일이야" —
anything bigger than a pointer is abnormal to place directly on the stack. "포인터보다 크면
쉘로우카피를 쓰든지, 버퍼 포인터만 파라미터로 보내면서 버퍼 1개로 해결해야지" — for anything
over pointer-size, either shallow-copy or solve it with a single buffer: allocate once, pass only
the pointer down the call chain, don't let every function independently declare its own copy of
the same large shape.

**Why this one stung particularly hard**: user called it "초보 개발자 발상" (beginner-developer
thinking) and noted they personally haven't seen a real stack overflow bug in 45 years — this is
considered one of the most basic, avoidable classes of embedded bug, not a subtle one. Don't treat
"every function call reserves its own local space" as an excuse or as making this "normal" —
reserving a *few bytes* per call frame is normal; reserving *kilobyte-sized structs* per call
frame is the specific anti-pattern, and conflating the two (as Claude did mid-conversation,
prompting "또 왜 개소리야") is itself a way of softening/euphemizing the actual mistake — see
[[feedback_dont_euphemize_own_faults]].

**How to apply**: before adding any `struct` or fixed-size array as a plain local variable or a
by-value function parameter, check its size. If it's bigger than roughly a pointer (safe rule of
thumb: a few dozen bytes, definitely anything in the hundreds+), don't — allocate it once
(`heap_caps_malloc(..., MALLOC_CAP_SPIRAM)` per [[feedback_prefer_psram_for_buffers]] if it can be
PSRAM, or `static` only if genuinely single-owner and the anti-pattern that memory itself warns
against doesn't apply) and pass a pointer through the call chain instead. This applies doubly hard
to anything invoked from a callback/message-dispatch chain (recv_cb-style), since those chains are
exactly the ones that tend to grow deep and unpredictable over a codebase's life — a stack budget
that's fine today silently becomes a live crash the next time someone adds one more call in the
chain, which is exactly what happened here.
