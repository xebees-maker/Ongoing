---
name: project-cntl-tx-queue-full-root-cause-2026-09-10
description: "TX_QUEUE_FULL(2009) root cause (reboot wipes pairing state -> WAKE_HELLO silently ignored -> re-pair storm) found 2026-09-10; fixed+HW-verified same day via dispatcher+per-device-worker TX redesign; RESOLVED/CLOSED, user ruled out a separate storm-prevention fix as unneeded"
metadata:
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-10T10:29:26.452Z
---

**This supersedes the two earlier (retracted) theories in [[project_cntl_tx_queue_full_2026_09_09]]**
(mutex contention — disproven; LVGL/graph SD I/O load — real but not the actual trigger, user
confirmed 2009 fired with the graph view never opened). Found via simultaneous serial capture of
CNTL (COM19) + CAM (COM5) + Sens (COM3) correlated by timestamp, prompted by the user's own
observation: "플래시 할 때마다 2009 뜨네" (every time you flash, 2009 shows up) and their hypothesis
about auto-connect collision.

**Confirmed mechanism:**
1. CAM and Sens each use a "fast path" WAKE_HELLO (`esp_now_cam_try_wake_hello_fast_path()` /
   Sens's CASK equivalent in `esp_now_node_cask.c`) that unicasts directly to their remembered
   "known hub" MAC/channel, with only **200ms x 3 attempts = 600ms total** budget waiting for
   CNTL's WAKE_HELLO_ACK (`esp_now_reliable_request(..., 200, 3, ...)`, both files, comment notes
   this is deliberately tight — "빠른 재시도").
2. CNTL's WAKE_HELLO handler (esp_now_hub.c) **silently ignores** a WAKE_HELLO from a MAC it does
   not currently have marked `NODE_CONN_PAIRED` in its in-RAM node table (per the existing design
   comment: "페어드로 인지하지 않으면... 조용히 무시").
3. **Every CNTL reboot (including every flash) wipes that in-RAM node table.** CAM/Sens don't know
   CNTL rebooted — they keep trying the fast path against the "known hub" they remember. CNTL,
   freshly booted, doesn't recognize them as paired yet, so it silently drops their WAKE_HELLO.
4. Both devices' fast path times out after 600ms, each independently sets itself to
   `CAM_CONN_ORPHAN` / equivalent, and falls back to full re-advertise -> `esp_now_hub_pair()` ->
   a queued `"Pairing"` PAIR_REQUEST (500ms x 13 attempts = up to 6.5s each if it also fails).
5. This repeats — observed **17 separate desync/re-advertise events across both devices within
   the first ~2.7 minutes** after a fresh boot (roughly one every ~9s), each adding PAIR_REQUEST
   traffic on top of normal CASK WAKE_HELLO traffic (CAM alone cycles roughly every ~1s in its
   current Live/즉시 response-interval test setting, itself already 3 tx_task items/sec) — enough
   combined load to overflow the 32-slot queue repeatedly during that window.
6. **Self-resolves once both devices complete a full re-pairing handshake and CNTL's table marks
   them PAIRED again** — confirmed in the capture: desync events were dense for ~2.7 minutes, then
   exactly one more isolated blip at ~4min, then *zero* for the remaining 5+ minutes of stable
   operation. This matches "한번 나면 계속나네" as "boot-triggered storm that eventually settles,"
   not a permanently-broken state.

**Why the user's auto-connect hypothesis was half right:** `auto_connect_wanted` is one of several
OR'd conditions in the ADVERTISE handler that trigger `esp_now_hub_pair()`, but `was_paired` and
`ever_paired && !was_user_unpaired` independently trigger the identical re-pairing path regardless
of that setting — so this isn't specifically an auto-connect bug, it's the boot-time
pairing-state-loss interacting with the silent-ignore-if-unpaired design choice.

**CLOSED 2026-09-10 — user explicitly ruled out doing a separate WAKE_HELLO/known-devices fix for
the storm itself** ("1번은 네 해석이 틀렸고, 완료로 처리해" — after I framed "stop the storm from
happening at all" as a still-open, still-needed item distinct from the TX redesign below). The
storm was always self-resolving within minutes of boot (see point 6 above) and the user's actual
goal was stopping 2009 recurrence, not eliminating reboot-triggered re-pair traffic as its own
objective — with the queue-overflow symptom fixed (below), that goal is met. Don't re-open this as
a pending task; if the WAKE_HELLO-silently-ignores-unrecognized-MAC behavior becomes relevant
again, treat it as a fresh ask, not a resumption of this one.

**TX-queue-overflow symptom: FIXED + HW-verified 2026-09-10.** Implemented the dispatcher +
per-device dynamic worker-task redesign in `esp_now_tx.c` (design origin: see
[[project_cntl_tx_queue_full_2026_09_09]]'s "TX architecture redesign" notes from the same
Socratic-dialogue session — single shared queue now feeds a lightweight dispatcher that never
blocks on network I/O; it routes each item to a per-mac worker task (existing or newly
`xTaskCreate`'d), and each worker independently blocks on `esp_now_reliable_request()` and
self-deletes (`vTaskDelete(NULL)`) after `TX_WORKER_IDLE_MS`(2s) idle. Race between a worker's
self-retire decision and the dispatcher routing a fresh item to it is closed by serializing both
under the same `s_workers_mutex` (worker re-checks its own queue depth under the lock before
committing to exit). Verified live on a real CNTL reboot (the exact storm scenario): Sens
PAIR_REQUEST burned its full 6.5s retry budget (`Pairing 무응답(13회 시도)` at t=8150ms) while a
CAM PAIR_REQUEST queued at t=13284ms completed in 46ms (t=13330ms) — direct evidence the two
devices' workers ran independently instead of head-of-line-blocking each other. Zero
TX_QUEUE_FULL/2009 across the whole reboot+re-pair window. Old queue-full trace/auto-reset
diagnostics ([[project_cntl_tx_queue_full_2026_09_09]]) kept as a safety net, unchanged.

**New known tradeoff from this redesign (not a bug, expected):** internal RAM now visibly swings
(user observed ~72K down to ~62K) whenever multiple devices have workers alive simultaneously —
each active worker costs roughly ~5KB (4096B stack + ~512B per-device queue + task/TCB overhead),
recovering after the 2s idle-out. Worst case with all `ESP_NOW_HUB_MAX_NODES`(8) devices
reconnecting at once is a rough estimate of ~40KB transient dip — not yet measured for real, user
explicitly deferred stress-testing this to the commercialization stage ("그건 나중에 (상용화
단계) 할께"). Worth revisiting before shipping if the device count grows.

**Won't-fix 2026-09-10 (user's explicit call — "3번도 안 할꺼야"):** `esp_now_hub_pair()`'s
no-dedup bug (no guard against enqueueing a second PAIR_REQUEST for a MAC that already has one in
flight) still exists after the redesign, but user decided not to pursue it — it's no longer
dangerous (a duplicate just lands in that device's own small worker queue and gets sent
redundantly back-to-back, doesn't touch other devices' traffic), just a minor waste-of-airtime
nit. Don't re-surface as a pending task; treat as closed.

**Secondary, independent contributing factor (does not need CAM/Sens changes):** CAM's current
response-interval test setting (~1s cycle, "Live"/즉시 mode) alone produces 3 tx_task items/sec
sustained — close to or exceeding what a single serial tx_task consumer can reliably clear within
each item's own timeout budget (300-800ms x 3 attempts). Even without any desync storm, this rate
leaves little margin. Not fixed here; worth knowing if 2009 recurs during otherwise-stable
operation with no desync log lines nearby.

**Diagnostic instrumentation now in place** (kept, not temporary): `TX_QUEUE_TRACE` log in
`esp_now_tx.c` (fires per-enqueue once depth >= 20, shows `what`/mac/depth) and automatic
`xQueueReset()` + log on overflow (user's explicit request: "이 에러가 났을 때 TX 큐를 초기화하든
하는 거야"). **Standing practice going forward: re-arm a continuous serial monitor on COM19 after
every CNTL build/flash** (user's explicit instruction) — currently also running parallel CAM
(COM5)/Sens (COM3) monitors for this investigation; the Sens capture needs the resilient
reopen-on-disconnect script (`capture_serial_resilient.py`) since deep sleep makes the plain
timeout-only script crash on `ClearCommError`.
