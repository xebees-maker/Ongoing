---
name: project-cntl-i2c-bridge-design-2026-09-21
description: "CNTL offloads its ESP-NOW radio stack to a separate XIAO ESP32-C6 bridge board over isolated I2C (physically wired via D_SDA/D_SCL through level-shifter M1, not bare GPIO8/9). 2026-09-22: TWO separate confirmed problems, not one. (1) Bridge running + wired → its I2C slave peripheral holds SDA stuck low (SCL is fine, that theory was retracted) — software/driver bug, matches espressif/esp-idf#15572-adjacent issues. (2) Bridge POWERED OFF + wired → SDA still reads 0V and CNTL still dies (SCL still fine) — a separate 'backpowering via ESD diodes' mechanism, worse because it happens whenever Bridge merely loses power, not just on a firmware bug. CNTL's M1 is a level shifter, not a galvanic isolator, so provides no protection. Solution directions: fix (1) via Arduino-ESP32/legacy driver/bitbang; fix (2) via a true I2C isolator IC (e.g. PCA9615) or diode isolation — neither implemented yet."
metadata:
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-22T04:22:15.285Z
---

**Status as of 2026-09-21, end of day: implemented, both projects build clean, NOT hardware-verified.**
User authorized unattended implementation ("구현해... 사용자 답변 뜨는거 띄우지 말고", stepping
away) after the design conversation below concluded. Commit `5903263` on branch
`cntl-tabs-lazy-construct`. See "## Implementation (2026-09-21, done same day)" near the bottom
for what shipped, what was deliberately simplified, and what's still needed before this can run
on real hardware — read that section first when resuming, then this design record for the "why"
behind each choice if needed.

## Decision: I2C bridge replaces the steel-obstruction relay plan entirely

Supersedes [[project_cntl_cam_steel_obstruction_relay]] (2 relay boards + wired UART) — user:
"기존 485, UART 건은 완전히 배제." Do not resurrect the UART relay idea.

**Background**: the XIAO Seeed board was bought ~1 month before this conversation after an
earlier discussion where Claude suggested RS485; user is going with I2C instead. Board has
nothing else connected — full pin freedom on the bridge side.

## Physical layout

CNTL + bridge share **one enclosure**, both outside a wall. I2C link between them is short
(~10cm). From the bridge, a **long antenna cable** runs through the wall to an antenna placed
inside the building. CNTL's own side of the I2C link is **isolated I2C, exactly 4 terminals**
(VCC/GND/SDA/SCL) — **no spare GPIO exists on the CNTL side for anything else** (no hardware
interrupt line, no hardware reset line to the bridge). This constrains the whole protocol design.

## Role split (settled)

- **Bridge (XIAO Seeed)**: owns everything that touches the ESP-NOW radio directly — driver
  init, peer add/del, channel sync (mirrors Common/esp_now_channelsync.c's job), raw send/recv,
  **and the reliable retry/ACK/timeout loop** (moved here, not CNTL — retries need tight RF
  timing that an I2C round-trip per attempt would wreck). Also does RF measurement (RSSI) since
  only it has the radio, and **executes** auto-connect-allow decisions (needs the
  known-device/policy list synced from CNTL to do this).
- **CNTL**: keeps everything that only needs message-in/message-out semantics — CASK state
  machine, pairing UI trigger + alias/known-device management, photo chunk reassembly
  (current esp_now_photo.c), TX routing (current esp_now_tx.c minus the reliable part). Talks to
  the bridge over I2C instead of calling the ESP-NOW driver directly. **All "intelligence"
  (protocol/version checking, deciding what to do about a mismatch) lives on CNTL** — user:
  "버전 체크 등의 인텔리전스는 모두 콘에 있어." The bridge stays dumb/minimal beyond the radio work.
- **esp_now_hub.c must be split, not moved wholesale**: peer-table-touching parts → bridge;
  "known device / alias / connection-state UI" bookkeeping → CNTL.
- User-facing: bridge is fully invisible to the end user, all UI stays on CNTL as today.
- Scope: **complete replacement** of CNTL's direct ESP-NOW usage — no coexistence period with
  a "direct" path.

## I2C bus mechanics (settled)

- **CNTL is I2C master, bridge is slave** — reasoned from "콘이 인텔리전스를 가져" (CNTL holds
  the intelligence, so it drives/controls the bus too; the two naturally align).
  Since there's no spare-pin alert line, the bridge can't spontaneously signal the master —
  CNTL's I2C driver task must periodically read a status/data-ready indicator from the bridge.
- "인터럽트로 처리" (interrupt-driven) does **NOT** mean a hardware interrupt pin — user
  corrected this explicitly: it means the I2C driver layer raises an event/notification
  upward once it has read something, not that the app polls raw I2C itself. There is no
  hardware interrupt line between the boards (no pin for it).
- **Bridge reset**: no hardware reset line exists either (same 4-pin constraint). Bridge
  liveness is checked via a PING/PONG-style control message; if unresponsive, recovery is an
  I2C-commanded self-reset (bridge calls its own esp_restart()), with the bridge's own
  independent watchdog as the last-resort fallback if it's too hung to even process that.
- **seq field likely unnecessary**: `dest_mac` itself works as the request/reply correlation
  key, since the existing per-device worker design only ever has one reliable-request in
  flight per MAC at a time (same-device follow-ups queue behind it) — a RELIABLE_RESULT for a
  given MAC unambiguously matches the one pending request for that MAC. Would only become
  necessary if a single MAC could later have multiple concurrent outstanding requests.
- **Two separate timeout layers, don't conflate them**: (a) the ESP-NOW-level reliable
  retry/ACK timeout, which lives entirely inside the bridge (per the role split above), and
  (b) CNTL's own ceiling on how long it waits for the bridge to respond to an I2C request at
  all — a fully independent, bridge-liveness-level timeout that feeds into the PING/PONG +
  self-reset recovery flow, not the ESP-NOW retry logic.

## Corollary raised by Claude, worth confirming later: removing ESP-NOW from CNTL entirely

CNTL will no longer call esp_now_init()/add_peer/send/recv at all — those move fully to the
bridge. CNTL still needs Common/esp_now_link.h's wire-format struct *definitions* (to build/
parse CASK payloads before handing raw bytes to the bridge over I2C), just not the driver calls.
Reasoned implication (not yet measured/confirmed): since CNTL's WiFi radio would then carry only
STA-to-AP traffic and never ESP-NOW peer traffic, the ~20-25K "connected+active" Internal RAM
cost this session couldn't explain or fix at the app/PSRAM level (see
[[project_cntl_memory_decline_under_pairing_churn_2026_09_18]] and the plan doc referenced
there) may disappear almost entirely under this architecture — that gap tracked ESP-NOW traffic
specifically, not the AP connection itself. Worth verifying once there's something to measure.

## Protocol structure (settled shape, not fully specified)

Two logical layers, likely split by a top-level category byte (DATA vs CONTROL) under a shared
msg_type scheme, both directions on a (MAC + MSG + CRC) skeleton:

1. **Device-relay protocol (DATA)** — bridge acts as pure transport for the existing
   Common/esp_now_link.h protocol between CNTL and Sens/CAM. Draft msg_types: RELIABLE_SEND
   (CNTL→bridge: dest_mac + payload + timeout_ms/max_attempts, since reliable now runs on
   bridge), RELIABLE_RESULT (bridge→CNTL: success/fail + reply payload), INCOMING_MSG
   (bridge→CNTL: unsolicited arrival, e.g. WAKE_HELLO, with src_mac + rssi + payload),
   PAIR_START / PAIR_RESULT.
2. **Bridge-control protocol (CONTROL)** — CNTL managing the bridge itself. Draft: 
   SYNC_KNOWN_DEVICES (CNTL→bridge, full snapshot of mac[6]+auto_connect_allowed[1B] per known
   device, pushed at boot and again on every settings change — not incremental deltas, proposed
   by Claude, not yet explicitly confirmed by user), PING/PONG (liveness), a version-report
   field the bridge exposes and CNTL validates.

## Naming convention (settled)

Strip the `esp_now_` prefix from CNTL-side file and function names once they no longer talk to
ESP-NOW directly — e.g. `esp_now_hub.c` → `hub.c`, `esp_now_hub_get_nodes()` → `hub_get_node()`.
User: "그런 식이지... 다른 게 있을 수 있지만" — apply case-by-case if a stripped name becomes
ambiguous or collides with something else; don't force it mechanically everywhere.

## Still open

None remaining as of 2026-09-21 — the last item (packet payload max length) was resolved:
since the bridge is a transparent relay, the I2C payload max just needs to be >= the largest
actual ESP-NOW frame size already used between bridge and Sens/CAM (existing
Common/esp_now_link.h limits, e.g. TX_REQ_MAX_LEN=32 for control messages) — not an
independent design choice, it's derived from the existing protocol's own limits.

**Not actually open — Claude's error, don't re-ask:** whether photo transfer (PHOTO_CHUNK, up
to ~1MB) goes through the I2C path. User corrected this (2026-09-21, "헐. 미해결 질문이 이미
답을 한거잖아. I2C밖에 없다니까?") — I2C is the *only* physical channel between CNTL and the
bridge, and the bridge is a transparent relay for all Sens/CAM traffic, so of course every byte
(including photo chunks) goes through it. There is no alternative path to even ask about. If
I2C throughput for ~1MB photo transfers turns out to matter, that's a *performance* question to
raise concretely with numbers (I2C bus speed vs current transfer time), not a routing question.
3. SYNC_KNOWN_DEVICES: full-snapshot-every-time vs incremental delta — Claude's proposal,
   not confirmed.

**How to apply (design)**: don't re-derive the settled parts above. Don't re-propose a hardware
interrupt or reset line for the CNTL↔bridge link — the 4-pin constraint is hardware fact, not a
guess. Don't re-propose RS485/UART relay boards — explicitly ruled out.

## Implementation (2026-09-21, done same day, commit `5903263`)

User's exact authorization: "이제 CNTL, SENS, CAM 레벨로 BRIDGE 프로젝트를 만들고, 지금 얘기한
걸 기반으로 구현해. CNTL 수정도 필요할꺼야. 내가 자리에 없으니 중간에 뜨는 사용자 답변 같은 거
띄우지 말고." (create a Bridge project alongside CNTL/Sens/CAM, implement from this design, CNTL
needs changes too, don't surface anything needing a user answer since I won't be here.)

**What shipped:**
- `Common/components/bridge_link/` — new header-only shared component. `bridge_link.h` defines
  a single fixed-size `bridge_link_packet_t` (msg_type, mac[6], ok, rssi, timeout_ms,
  max_attempts, accept_reply_types[4]+count, payload[1470]+payload_len, crc16) and
  `bridge_link_seal()`/`bridge_link_verify()` (CRC-16/CCITT, bit-loop, no table). Fixed-size
  chosen over variable-length framing for 1st-pass implementation simplicity — flagged in the
  header as the thing to revisit if I2C throughput for photo transfer becomes a real problem
  (ties to the "still open" performance question above).
- `Bridge/` — new ESP-IDF project, esp32c3 target (Seeed XIAO ESP32-C3). `main.c`: WiFi STA
  (radio-only, no AP join)+esp_now_init+recv_cb. `i2c_slave_link.c`: I2C slave
  (`driver/i2c_slave.h`, new-style v6.0.2 API) + 3 tasks (i2c_rx, reliable_worker, i2c_tx, all
  priority 17 matching the project's comms-layer convention). Fully transparent relay — never
  parses CASK/esp_now_link.h semantics, just relays raw frames + owns the actual ESP-NOW driver
  calls (init/add_peer/rate-config MCS0-HT20/send) and runs Common/esp_now_reliable.c's existing
  retry loop locally for RELIABLE_SEND requests from CNTL.
  Top-level `Bridge/CMakeLists.txt` had to `EXCLUDE_COMPONENTS` the LCD/touch driver components
  (esp_lcd_touch_axs5106/cst816, esp_lcd_jd9853) that Common/components/ also holds — they
  depend on managed_components that only exist in CNTL/Sens's own trees, not Bridge's (same
  class of issue as Sens's own bsp_c6 exclusion, see that project's CMakeLists.txt comment).
- `Cntl/main/i2c_bridge.c/.h` — new I2C-master module. Three signature-compatible drop-ins:
  `bridge_send()` (~esp_now_send), `bridge_reliable_request()` (~esp_now_reliable_request,
  correlates request/reply by dest_mac — no seq needed per the "still open" resolution above,
  one outstanding request per mac at a time matches esp_now_tx.c's existing per-device worker
  model), `i2c_bridge_init(recv_cb)` (~esp_now_init+register_recv_cb — reconstructs a minimal
  `esp_now_recv_info_t`/`wifi_pkt_rx_ctrl_t` with just src_addr+rssi set from each I2C-relayed
  INCOMING packet, since that's the only two fields the existing recv_cb ever reads). A
  background poll task drains the bridge's outbound queue, sends PING every 2s of silence, and
  attempts an I2C RESET command after 5s of total unresponsiveness (best-effort — see design
  section above on why there's no hardware fallback).
- **CNTL's existing hub.c/tx.c/photo.c logic is untouched** — this was the core safety decision
  of the whole implementation (see "Important scope decision" below). Only mechanical swaps:
  `esp_now_send(` → `bridge_send(` (hub.c ×4, photo.c ×7, plain sed since it's a pure rename),
  `esp_now_reliable_request(` → `bridge_reliable_request(` (tx.c ×1), the `esp_now_init()`+
  `esp_now_register_recv_cb()`+dead broadcast-peer block in `esp_now_hub_init()` →
  `i2c_bridge_init(recv_cb)` + `i2c_bridge_set_channel(esp_now_hub_get_wifi_channel())`, and
  hub.c's own `add_peer_if_needed()` → no-op (Bridge now owns peer registration, including the
  MCS0/HT20 rate-config that moved into Bridge's own add_peer_if_needed). hub.c's
  `esp_now_reliable_on_recv()` call in `recv_cb()` was deleted (would be a permanent no-op now —
  CNTL never arms that wait-state anymore, the bridge does its own matching before relaying).
  `Cntl/main/CMakeLists.txt`: added `i2c_bridge.c`, added `bridge_link`+`esp_driver_i2c`,
  removed `esp_now_reliable` (no longer a direct CNTL dependency, esp_now_tx.c was the only
  caller and it's gone).
- **Both projects build clean.** CNTL: `ninja -C build`, only pre-existing unrelated warning
  (`show_unpair_confirm_popup` unused in ui_main.c, not touched this session). Bridge: fresh
  `cmake -G Ninja -DIDF_TARGET=esp32c3` configure + full build, 1022/1022 steps,
  `bridge.bin` 0xcaa90 bytes (21% of partition free).
- Verified via grep after all edits: zero remaining live call sites of
  `esp_now_send/init/register_recv_cb/reliable_request/add_peer/is_peer_exist` in `Cntl/main/`
  — every match left is inside a comment.

**Important scope decision (Claude's judgment call, not explicitly discussed with user):**
Reading esp_now_hub.c in full (1511 lines) made clear that CASK dispatch, pairing state,
adaptive sleep timing, RSSI capture, and stats recording are all tightly interleaved inside
`recv_cb()` and its helpers — not cleanly separable into "driver part" vs "app part" by file.
Rather than risk a blind rewrite of that logic split across two unverifiable-without-hardware
chips, the implementation keeps 100% of hub.c/tx.c/photo.c's decision-making on CNTL exactly as
it is today, and moves *only* the raw ESP-NOW driver calls to the bridge. Concretely this means
auto-connect-allow decisions stay fully on CNTL (not partially executed on the bridge as one
earlier design remark suggested) and SYNC_KNOWN_DEVICES was **not implemented** — the bridge
doesn't need a known-device list at all in this simpler design, since it doesn't make any pairing
decisions itself. **This is a deviation from the design conversation above and should be
reviewed** — if the user wants auto-connect execution genuinely on the bridge, that's a
separate, larger follow-up (would require actually splitting hub.c's ADVERTISE handler logic).

## Correction + HW verification (2026-09-21, later same day, commit `79d9340`)

**The board is XIAO ESP32-**C6**, not C3** — user had been saying "C3" throughout the whole
design conversation above and corrected it once they were looking at the real board again:
"https://wiki.seeedstudio.com/xiao_esp32c6_getting_started <= 공식 홈페이지고, 내가 C6를 C3로
잘못 말했어". Retargeted the whole Bridge project (fresh `cmake -DIDF_TARGET=esp32c6`
reconfigure) — anywhere this doc or old commit messages say "C3" for the bridge board, that was
wrong, it's C6.

**Real I2C pins (user-confirmed, no longer placeholder) — Bridge side only:**
SDA=GPIO22 (labeled D4), SCL=GPIO23 (labeled D5), from Seeed's own wiki. Set in
`Bridge/main/i2c_slave_link.c`. **CNTL's own isolated-I2C GPIO numbers are still unknown/
placeholder** (`Cntl/main/i2c_bridge.c`, SDA=4/SCL=5) — nothing new learned about that side yet.

**New: RF antenna switch, user-confirmed** — XIAO C6 has GPIO3 (active-low RF enable) and
GPIO14 (low=internal PCB antenna, high=external u.FL). Added `antenna_switch_init()` in
`Bridge/main/main.c`, called before `wifi_bringup()`: GPIO3→enable, GPIO14→**external**
(non-negotiable given this whole project's premise is a long cable to a remote antenna through a
wall — internal antenna would defeat the design). Without this the radio might not transmit/
receive at all regardless of everything else being correct — this was missing from the original
implementation pass entirely, the user caught it by reviewing real hardware.

**First real hardware verification of this project** (everything before this was build-only):
flashed to the physical board on **COM24** via `esptool --chip esp32c6 write_flash` (bootloader
0x0 + partition-table 0x8000 + app 0x10000 — Bridge has no separate `flash_args` convention set
up yet, unlike CNTL/CAM's app-partition-only recipe, so this was a full 3-file flash). Boot log
captured clean: WiFi init OK, antenna switch log fired, `ESPNOW: espnow [version: 2.0] init`,
`i2c_slave_link: I2C 슬레이브 시작됨 (SDA=22 SCL=23 addr=0x42)`, `Bridge 시작됨`, no errors/
crashes/ESP_ERROR_CHECK aborts. This confirms the esp32c6 target, the real I2C pins, and the
antenna GPIOs are all valid and don't conflict with anything (console UART turned out to already
use GPIO16/17 on this chip, no clash) — but does **not** confirm actual I2C communication with
CNTL, since CNTL's side isn't wired up and its pins are still placeholder.

**Serial capture gotcha worth remembering**: this board is native-USB (USB-Serial-JTAG, not an
external CP2102/CH340 bridge) — a software RTS/DTR reset toggle on an already-open pyserial
handle produced silence (0 bytes) twice in a row, most likely because the USB CDC connection
itself drops and re-enumerates across a target reset on native-USB boards, orphaning the already-
open handle. What worked: let `esptool` itself trigger the reset (its own hard-reset-via-RTS at
the end of a flash or any command), then open a **fresh** serial connection immediately after —
don't try to reset-and-keep-reading on a handle opened before the reset.

**Power wiring — FINAL (settled 2026-09-21, after Claude got it wrong 4+ times in a row — see
below).** Standard I2C practice, confirmed by the user against an external reference: **VCC is
only wired up when the master is meant to actually power the slave. When both sides are
independently powered (true here — XIAO needs its own supply for WiFi/ESP-NOW regardless), VCC
is simply left unconnected — only GND is shared.**

Final CNTL↔Bridge wiring:
- GND → XIAO GND
- SDA → XIAO GPIO22 (D4)
- SCL → XIAO GPIO23 (D5)
- CNTL's VOUT → **not connected**. XIAO powers itself independently (USB-C during
  dev/flashing, its own supply once deployed — not derived from CNTL at all).

**Don't re-relitigate this — it's settled.** History of how Claude got here, kept only as a
lesson in [[feedback_label_guesses_explicitly]] (the actual memory to consult for the behavioral
fix): guessed VOUT→XIAO's 3V3 pin as a "safe shared logic reference" (wrong, 3V3 is
output-only); user pointed out XIAO is the slave and power can piggyback on the I2C connector,
suggesting VOUT→VBUS instead; that then collided with the fact VOUT is 3.3V, not 5V, so VBUS's
onboard regulator wouldn't get enough headroom; guessed 3V3 again with a conditional
"only-conflicts-if-USB-also-connected" justification (user: "아니네"); user then went and
checked the actual answer externally and reported it back — the correct fix was never "which
pin," it was realizing VCC didn't need to be run at all.

**NOT done / blockers before this can run end-to-end:**
1. **CNTL's real I2C GPIO pins (SDA/SCL) still unknown** — `Cntl/main/i2c_bridge.c` SDA=4/SCL=5
   remain placeholder. VOUT/GND wiring is now settled (above), just the two signal pins left.
2. **Not flashed to real CNTL** — doing so now would strip CNTL of ESP-NOW entirely with no
   bridge wired up between them yet, breaking the currently-working CAM/Sens link with no way to
   revert without a reflash. Needs the physical I2C wiring done and both sides reflashed
   together as one changeover, not flashed independently. (The Bridge board itself was safe to
   flash standalone since nothing depends on it yet.)
3. I2C slave address `0x42` is an arbitrary placeholder on both sides (must match each other,
   unverified against anything else that might share the bus).
4. `esp_now_` prefix stripping (file/function renames) — not done, deferred to avoid compounding
   a large functional change with a large mechanical rename in the same diff.
5. Dynamic channel change re-push (CSA/AP auto channel switch mid-session) — `i2c_bridge_set_channel()`
   only called once at boot in `esp_now_hub_init()`, not wired into whatever already reacts to a
   live channel change today.
6. Historical comments in esp_now_tx.c/esp_now_tx.h still say "esp_now_reliable_request()" when
   describing why the worker blocks — not factually wrong (a bridge_reliable_request() call still
   blocks the same way) but stale naming, low priority.
7. Bridge has no app-partition-only flash recipe yet (unlike CNTL/CAM's established convention)
   — today's flash was bootloader+partition-table+app all at once. Fine for now since Bridge has
   no persistent settings partition to protect yet, but worth setting up once it does.

**How to apply (implementation)**: the only hard blocker left before an end-to-end test is item 1
— get CNTL's real isolated-I2C GPIO numbers (ask the user, or check whatever documents that
isolated-I2C header if one turns up). Once that's in, wire the two boards together, flash both in
one sitting, and confirm actual I2C traffic (start simple — a PING/PONG round-trip is the easiest
first thing to check for). Read the "Important scope decision" note above before assuming
SYNC_KNOWN_DEVICES/bridge-side auto-connect was implemented — it wasn't.

**Superseded by 2026-09-22 below**: item 1's "CNTL pins unknown" was resolved later on 2026-09-21
(GPIO8/9, the CH422G/RTC/touch shared bus, reused via `waveshare_rgb_lcd_get_i2c_bus()` — see
below). Both boards were wired together and flashed. That's when the real problems started.

## Update 2026-09-22 — stack overflow fixed, protocol redesigned, then a hardware blocker found

**Stack overflow crash (found + fixed, HW-verified)**: `bridge_link_packet_t` (1493B, dominated
by a 1470B payload array) was a plain stack-local in multiple functions along a deep synchronous
call chain sharing `i2c_bridge_poll_task`'s one stack (`i2c_bridge_poll_task` →
`deliver_incoming` → `recv_cb` (hub.c) → sometimes back into `bridge_send`). Multiple ~1.5KB
frames stacking up overflowed the 4096B task stack every boot. Fixed: all such locals moved to
`heap_caps_malloc(..., MALLOC_CAP_SPIRAM)` (per-call alloc/free for concurrently-callable
functions, once-allocated-and-reused for the single-owner poll task), task stack raised to 8192.
See [[feedback_never_put_large_data_on_stack]] for the general rule this violated.

**Protocol redesigned to variable-size** (user's explicit final direction after the stack-overflow
investigation revealed the fixed-1493-byte-always-sent design was ALSO the reason plain I2C
timeouts/partial-writes were happening even for tiny messages): `Common/components/bridge_link/
include/bridge_link.h` no longer has one fixed `bridge_link_packet_t`. Now: a small fixed
`bridge_link_header_t` (~23B, packed: msg_type/mac/ok/rssi/timeout_ms/max_attempts/
accept_reply_types+count/payload_len/header_crc — CRC16, no SEQ_NUMBER, user confirmed
unnecessary: this synchronous single-outstanding-request-per-MAC P2P link can't reorder/
duplicate) is always sent first; only if `payload_len > 0` does a second transaction follow
carrying `payload_len` bytes + a trailing CRC16. `bridge_link_msg_t` (packed, header + max
payload buffer) is the in-memory convenience type both sides use; `bridge_link_msg_wire_len()`
gives the actual bytes to put on the wire (usually tiny — PING/SET_CHANNEL etc. are now just the
23B header, not the old 1493B every time). Both `Cntl/main/i2c_bridge.c` (master:
`transmit_msg()`/`receive_msg()` helpers do the two-phase send/receive) and
`Bridge/main/i2c_slave_link.c` (slave: `on_receive` ISR is now a 2-state `RX_PHASE_HEADER`/
`RX_PHASE_PAYLOAD` state machine; tx side sends header+payload as one `i2c_slave_write()` since
the slave's send buffer is a byte-stream ring buffer the master's two separate reads just drain
in order) were rewritten to match. **Both projects build clean.** Not yet stress-tested against
real bridge traffic (blocked by the hardware issue below before that could happen).

**Defensive I2C error handling added** (so a bad I2C transaction can never crash-loop CNTL again):
new `ui_log.h` codes `UI_ERR_TOUCH_INIT_FAIL 5010` / `UI_ERR_BRIDGE_I2C_BUS_NULL 5011`. Every
`ESP_ERROR_CHECK` wrapping an I2C-touching call in the touch/backlight boot path was converted to
capture-and-log-instead-of-abort: `Cntl/components/waveshare_rgb_lcd_port.c`'s
`waveshare_esp32_s3_rgb_lcd_init()` touch/GT911 block (3 call sites) and
`waveshare_rgb_lcd_backlight_on()` (2 call sites, the latter retried 3x since backlight failing
means a literally blank screen) now log via `ui_log_add_err()` and return `ESP_OK` instead of
aborting — LCD panel itself (unrelated bus) still inits normally, only touch/backlight degrade.
`Cntl/main/i2c_bridge.c`'s `i2c_bridge_init()` also no longer aborts if
`waveshare_rgb_lcd_get_i2c_bus()` returns NULL or `i2c_master_bus_add_device()` fails — logs and
returns, bridge feature just stays inactive. `main.c:643`'s own `ESP_ERROR_CHECK(waveshare_rgb_lcd_backlight_on())`
was also unwrapped (that function now always returns ESP_OK). **This defensive layer is good
practice regardless of the root cause below and should stay.**

**THE ACTUAL ROOT CAUSE — hardware, not software (confirmed via rigorous A/B test)**: after the
above fixes, CNTL still crash-looped on real hardware — `ESP_ERROR_CHECK failed: esp_err_t 0x108
(ESP_ERR_INVALID_RESPONSE)` at `waveshare_rgb_lcd_port.c:192`, GT911 touch init, wrapped in
`ESP_ERROR_CHECK` (later made non-fatal per above) — caused by sustained, continuous `I2C
transaction timeout detected` errors affecting **CH422G and GT911, both pre-existing devices on
CNTL's own internal shared bus (GPIO8/9), unrelated to the bridge protocol**. A clean 2×2 test
(CNTL's bridge software fully on/off × Bridge board physically wired/unwired) isolated this
completely:
- Software ON + physically wired → broken (timeouts, GT911 fails, boot hangs/very slow, SD not
  mounted, touch dead)
- Software OFF (i2c_bridge_init() itself never called) + physically wired → **identical** breakage
- Software OFF + physically **unwired** → clean boot, zero I2C timeouts
- Software ON (poll task + set_channel active) + physically **unwired** → also clean boot, zero
  I2C timeouts, bridge poll task correctly logs "브릿지 무응답(5초+)" every 5s (expected — nothing
  physically there to answer)

**Conclusion**: the failure is 100% caused by the bridge board's physical presence on the shared
I2C bus (GPIO8/9) — completely independent of any CNTL software, on/off. This is an electrical
problem (signal integrity / bus loading), not a bug in anything built this session. User
physically confirmed by unplugging the bridge wiring mid-session and watching CNTL immediately
work normally again.

**Leading hypothesis (not yet confirmed — investigation paused here)**: pull-up resistor
mismatch. General I2C principle confirmed via WebSearch (Adafruit, SparkFun, Sensirion sources):
a shared bus should have exactly ONE set of pull-ups; if both sides have their own (internal SoC
pull-ups and/or onboard board resistors), the parallel combination becomes too strong and
destabilizes the bus, especially as wire length/capacitance grows — and conversely a bus that
ends up with NO effective pull-up anywhere is just as broken. Checked so far:
- CNTL's `i2c_master_bus_config_t` (`waveshare_rgb_lcd_port.c`) has `.flags.enable_internal_pullup
  = true` — CNTL's SoC-internal pull-up is definitely active on this bus.
- XIAO ESP32-C6 **schematic** (user-provided PDF, now saved — see below) checked directly: **no
  pull-up resistor on the D4/D5 (SDA/SCL, GPIO22/GPIO23 — the actual pins this project uses)
  net** anywhere in the schematic. The one WebSearch result that claimed "3.3kΩ pull-ups on
  GPIO8/GPIO9" does NOT apply here — that's a different pin pair than D4/D5, likely describing
  something else on the chip (possibly confused with the low-power I2C on MTCK/MTDO per the
  schematic's own note) — do not reuse that claim, it was wrong for this board's actual wiring.
  `Bridge/main/i2c_slave_link.c`'s own `i2c_slave_config_t` also doesn't explicitly enable an
  internal pull-up (defaults unset/false) — so the bridge side currently contributes **no**
  pull-up at all, software or hardware, on D4/D5.
- **CNTL's own board schematic not yet checked** — this is the immediate next step once able
  (see blocker below). Need to check whether CNTL's isolated I2C connector (VOUT/GND/SDA/SCL,
  level-shifted from GPIO8/9 via M1/NDC7002N per [[reference_cntl_schematic]]) has its own
  onboard pull-ups on the external side, and whether the level-shifter itself changes the
  effective pull-up situation.
- Also worth checking once resumed: wire length/quality of the actual physical link used for
  today's test (SparkFun's article: I2C tolerates short runs of a few meters; a longer or
  poor-quality wire between the two boards could push bus capacitance high enough to matter even
  with everything else nominal — a proper I2C bus extender IC like PCA9615 is the standard fix
  for longer runs if the pull-up angle doesn't fully explain it).

**Schematics now saved to disk** (user was manually re-uploading these every session — fixed):
`C:\projects\documents\ESP32-S3-Touch-LCD-4.3B-Sch.pdf` (CNTL, was already there from 2026-09-06)
and `C:\projects\documents\XIAO-ESP32-C6_v1.0_SCH_PDF_24028.pdf` (Bridge/XIAO, saved 2026-09-22).
**Claude cannot itself persist a pasted-in-chat PDF/image to disk** — this is a real tool
limitation (confirmed twice now), not something to keep re-attempting; the user has to save the
file themselves to a path in the repo/filesystem, then Claude reads it from there going forward.

**Blocker at session-save time**: Claude's local `Read` tool needs `pdftoppm` (poppler-utils) to
render PDF pages, which wasn't installed. Installed via `winget install --id
oschwartz10612.Poppler` (succeeded) but the already-running session/process's PATH predates the
install and doesn't pick it up — needs a full session/PC restart before `Read` can open either
schematic PDF directly. **First thing to do on resume**: retry `Read` on
`C:\projects\documents\ESP32-S3-Touch-LCD-4.3B-Sch.pdf` to check CNTL's own pull-up situation on
the external I2C connector — that's the concrete next diagnostic step, not yet done.

**Current physical/software state at save time**: bridge wiring is physically **disconnected**
(user unplugged it for the A/B test). CNTL's software is back to fully bridge-active (poll task +
set_channel + i2c_bridge_init all uncommented, last flashed build) — this combination was
verified clean (no I2C timeouts, no crash, bridge correctly logs unresponsive-peer warnings since
nothing is physically wired). **Do not re-wire the bridge and expect it to work yet** — the
electrical root cause isn't fixed, only diagnosed down to "pull-up mismatch, unconfirmed" so far.

**How to apply (2026-09-22)**: this is now a hardware investigation, not a software one. Don't
propose more CNTL/Bridge code changes to "fix" the I2C timeout — the A/B test already proved
software isn't the cause. Next step is finishing the pull-up analysis (CNTL's own schematic) and
then deciding a hardware fix (remove one side's pull-up, add/adjust external resistors, or a bus
extender IC) before physically reconnecting and retesting.

## CNTL schematic checked (2026-09-22, after poppler restart) — pull-up theory refined, new voltage hypothesis found

**Confirmed from `ESP32-S3-Touch-LCD-4.3B-Sch.pdf` netlist (cross-referenced pin-to-net pairs, not
just visual text layout):**
- CNTL's external isolated I2C connector (`D_SDA`/`D_SCL`, the pins this project wires to the
  Bridge) is NOT a bare GPIO8/9 breakout — it goes through a level shifter, **M1 (NDC7002N,
  dual N-MOSFET)**, the standard 2-transistor bidirectional I2C level-shift circuit.
- Both segments of that level shifter DO have their own onboard pull-ups, 4.7KΩ each:
  `R100`/`R101` pull the internal `SDA`/`SCL` (GPIO8/9 side) to `3V3`. `R99`/`R102` pull the
  external `D_SDA`/`D_SCL` (the side wired to the Bridge) to a net called **`I2C_VCC`**.
- This is topologically the textbook-correct level-shifter pull-up arrangement (one matched pair
  per segment) — it does NOT look like the "too many/too few pull-ups" failure mode originally
  suspected. That earlier hypothesis is now weaker than before this check.

**New finding, not yet verified against physical hardware — labeled as inference:**
`I2C_VCC` (the rail feeding `R99`/`R102`, i.e. the external bus's pull-up target) is
**selectable between 3V3 and 5V near header `H8`** (silkscreened "I2C 3V3 5V" on the PCB layout).
**User correction, 2026-09-22: this is NOT a pluggable jumper** — it's selected by which onboard
resistor footprint is actually populated (a 0R-style resistor-position select, not a shorting
block a user can move by hand). Changing it means reworking a resistor (desolder/resolder), not
flipping a jumper cap. `I2C_VCC` also feeds the connector's `VOUT` pin — the same pin this
project's wiring plan already settled as "not connected" (see the VCC-wiring section above), on
the reasoning that the Bridge is independently powered. **That reasoning covered power delivery,
not logic level** — regardless of whether `VOUT` is wired, `I2C_VCC` still sets the idle-high
voltage that `D_SDA`/`D_SCL` get pulled up to. If the populated resistor selects 5V, the Bridge's
XIAO ESP32-C6 GPIO22/23 (3.3V-only logic, not confirmed 5V-tolerant) would see ~5V idle-high on
both lines — a plausible cause of the sustained I2C timeouts, independent of any pull-up
strength/count question. **This has not been checked against the physical board** — the schematic
only shows the resistor-select mechanism exists, not which position is actually populated.

**RULED OUT same session, 2026-09-22**: user had already measured `I2C_VCC` at **3.3V** on the
real board before this schematic check — Claude failed to carry that fact forward and proposed
re-checking it as if unknown. The 5V-overdrive hypothesis is closed: `I2C_VCC` is confirmed 3.3V,
so the Bridge's 3.3V-only GPIO22/23 are not being overdriven by this rail. Combined with the
pull-up-count analysis above (both segments correctly matched, 4.7K pairs), **neither of the two
schematic-derived hypotheses (pull-up mismatch, voltage mismatch) is currently supported.** Don't
re-propose either without new evidence.

**How to apply**: the schematic-analysis avenue is exhausted for now — both leading theories it
produced are closed. **Do not propose wire length/quality, EMI, signal integrity, or a bus
extender IC (PCA9615) as a next step** — user called this out directly (2026-09-22) as a repeat
violation of [[feedback_no_hardware_blame_cntl_arbiter]]; that category is off-limits as a
Claude-generated theory even in a project already agreed (by the user's own A/B test) to be
electrical in nature. Next step comes from the user's direction, not from Claude filling the gap
with another physical-layer guess.

## Bridge-side SDA/SCL stuck-low CONFIRMED on real hardware (2026-09-22)

User directed checking whether Bridge's own I2C slave peripheral gets stuck (per
espressif/esp-idf#15572, an ESP32-C6 I2C-slave issue found via web research: slave ACKs a read
then pulls SDA/SCL low permanently). Added a temporary `diag_task` to `Bridge/main/main.c`
(`gpio_get_level()` on GPIO22/23 only — no direction/mode change, doesn't disturb the I2C
peripheral's own control of the pins) logging SDA/SCL level + `esp_get_free_heap_size()`/
`esp_get_minimum_free_heap_size()` every 2s. Built, flashed to the physical board on **COM24**,
captured ~25s of serial output.

**Result — reproduced, on the Bridge board ALONE, with the CNTL↔Bridge I2C wire still physically
disconnected (no master, no external pull-up, nothing else on the bus at all):**
- `SDA(22)=0` (stuck LOW) from the very first reading (~39s after boot) through the entire
  capture, no exceptions.
- `SCL(23)=1` initially, then at ~55s uptime it also drops to `0` and stays there for the rest of
  the capture.
- `free`/`min_free` heap were both already flat (263908/259576 bytes) for the whole window — no
  ongoing heap decline, the minimum was already hit early (WiFi/ESP-NOW init) and stayed there.

A floating, unconnected pin would not read a stable, repeated `0` across 25s of independent reads
— this pattern (silent, permanent, no external cause possible since nothing is wired to these pins
right now) matches the exact espressif/esp-idf#15572 symptom description ("pulls the data and
clock line low and nothing happens anymore"), reproduced in isolation on this exact chip
(ESP32-C6) and this exact driver usage (`driver/i2c_slave.h`, `i2c_slave_config_t` in
`Bridge/main/i2c_slave_link.c`).

**This is now the leading, hardware-confirmed (not guessed) explanation for the whole CH422G/GT911
breakage**: Bridge's own I2C slave peripheral independently drives its SDA/SCL pins low regardless
of whether CNTL ever talks to it — exactly matching "Software OFF + physically wired → identical
breakage" from the original A/B test, since wiring Bridge onto CNTL's shared GPIO8/9 bus would
pull that whole bus down the same way, with CH422G/GT911 just being the visible casualties.

**Note on `diag_task`**: this is a temporary diagnostic left in `Bridge/main/main.c` as of this
writing (logs every 2s via `ESP_LOGW("DIAG", ...)`) — remove it once no longer needed, it's not
meant to ship.

**How to apply**: this is squarely software/driver territory (the I2C slave peripheral's own
init/usage in `i2c_slave_link.c`, not a hardware defect) — consistent with
[[feedback_no_hardware_blame_cntl_arbiter]]'s steer to look at own init code rather than physical
causes. Next investigative step: narrow down what specifically triggers the SDA/SCL lockup — try
disabling pieces of the driver config (large `send_buf_depth`/`receive_buf_depth`, the
`on_request`/`on_receive` callbacks, `i2c_slave_write()` calls) one at a time to see which one
correlates with the stuck-low onset, or check whether esp-idf#15572 or related issues name a
specific trigger/workaround beyond what was already surfaced.

## Research + eliminated a sub-theory (2026-09-22, same session)

User asked for more articles/fixes. Found and read in full: espressif/esp-idf#15259 (ESP32-S3,
`on_request` ISR fails to report `xTaskWoken`, task never wakes, SDA held by clock stretching —
closed "Done", no public fix), #13354 (new i2c_slave driver RX FIFO can overrun
`t->rcv_fifo_cnt` into negative when incoming bytes exceed buffer space — closed "Resolution: NA"),
#15592 (ESP32-S3, callbacks don't fire at all, TX buffer returns garbage — open, unresolved),
and the community article [productionesp32.com/posts/esp32-i2c-slave-issue](https://productionesp32.com/posts/esp32-i2c-slave-issue/)
(states plainly: ESP32 native I2C slave driver "should not be relied upon... unless exhaustive
testing" — recommends Arduino-ESP32's I2C slave implementation as the community-preferred
alternative to the buggy native driver). No source has a confirmed, published fix for any of
these — all either closed without public explanation or still open/unresolved.

**Solution options surfaced, ranked by how much they've been validated elsewhere (none tried yet)**:
1. Switch Bridge to Arduino-ESP32's I2C slave (Wire.h) via the `espressif/arduino-esp32` IDF
   component — most-recommended community workaround, but a real integration effort (rewrite
   `on_receive`/`on_request` as Wire's `onReceive`/`onRequest`).
2. Legacy `i2c_slave` v1 API instead of the new v2 driver Bridge uses — exists today, but
   Espressif's own docs say v1 is being removed in IDF v6.0, so this is a stopgap at best.
3. Bitbang/software I2C slave (GPIO-interrupt-driven, no hardware peripheral) — a forum user's
   working alternative, most implementation effort, but sidesteps the native peripheral bug class
   entirely.
4. Reduce `send_buf_depth`/`receive_buf_depth` from ~2990B to something near the ~256B seen in
   IDF examples, in case #13354's overrun bug is contributing — cheapest to try, not confirmed
   relevant.
5. Hardware-level bus isolation switch (e.g. a mux/switch IC that disconnects Bridge from the bus
   until needed) — doesn't fix Bridge, works around it physically; not pursued in detail.

**User's read, 2026-09-22**: option 1 (Arduino-ESP32 Wire) looks closest to viable of the five.
Also directly noted **none of these solve "CNTL dies just from wiring it up"** — they're all fixes
for Bridge's own bug, and there's no confirmed CNTL-side mitigation. This was independently
verified true: the standard master-side "send clock pulses/STOP to unstick a slave holding SDA"
recovery technique doesn't apply here, because the lockup was proven (see below) to happen with
**zero master present at all** — a mid-transaction-stuck slave can be walked free by clocking; a
peripheral that spontaneously re-latches low with no transaction in progress cannot, since there's
no transaction for clocking to complete. CNTL-side fixes are therefore not expected to help; the
dependency is entirely on Bridge's own implementation (or physical bus isolation).

**#15259 sub-theory eliminated by direct hardware test, same session**: added diagnostic counters
(`s_on_request_count`/`s_on_request_woken_count`/`s_tx_task_notify_count` in
`Bridge/main/i2c_slave_link.c`, exposed via `i2c_slave_link_get_diag_counters()`, logged every 2s
from `diag_task` in `Bridge/main/main.c`) to check whether espressif/esp-idf#15259's specific
failure mode (`on_request` firing but failing to wake `i2c_tx_task`) is what's happening here.
Built, flashed to COM24, captured ~25s: **`on_request=0 woken=0 tx_notified=0` the entire
capture — the ISR never fired even once** (expected, since no master is physically connected to
issue a read), while SDA/SCL were both already stuck at 0 from the very first log line (this run
locked up even faster than the previous capture — before ~5s uptime vs ~55s previously). **This
rules out #15259's specific mechanism as the cause of the currently-observed standalone lockup** —
whatever is happening, it happens before/independent of any `on_request` event, matching #15572's
"stuck right after init" pattern rather than #15259's "stuck mid-request-handling" pattern. #15259
may still matter once a real master is talking to Bridge (a separate, not-yet-tested scenario),
but it is not the explanation for the currently reproduced init-time lockup.

**Diagnostics currently left in the code** (both temporary, remove once investigation concludes):
`diag_task` (`Bridge/main/main.c`) and the three counters + getter in `Bridge/main/i2c_slave_link.c`/`.h`.

## SCL theory retracted, SDA-only confirmed with internal pull-up enabled (2026-09-22, same session)

User caught a real flaw in the standalone test above: with NO pull-up anywhere (Bridge has none,
nothing wired to CNTL), reading `0` on SDA/SCL doesn't distinguish "actively driven low by a bug"
from "just floating with nothing pulling it high" — both look identical. Correct test: enable
Bridge's own internal pull-up (`cfg.flags.enable_internal_pullup = true` in
`i2c_slave_config_t`, `Bridge/main/i2c_slave_link.c`) temporarily and re-measure — if a line is
merely floating, the pull-up resolves it high; if something is actively driving it low, a weak
pull-up can't override that. **User's explicit clarification: this pull-up-enable is diagnostic-
only, not a proposed production fix** — in the real deployed wiring, CNTL is meant to own the
pull-up (R100/R101 + SoC internal on GPIO8/9 per the earlier schematic finding), not Bridge.

**Result (25s capture, internal pull-up on)**:
- `SCL(23)=1` for the entire capture — resolves high once given a pull-up. **The earlier "SCL
  stuck low" finding was a test artifact, not a real bug** — SCL was simply floating with no
  pull-up in that first test, nothing was actually holding it.
- `SDA(22)=0` for the entire capture, unchanged despite the pull-up being active. A weak pull-up
  cannot override an actively-driven-low line, so **this confirms SDA specifically is genuinely
  being held low by something in Bridge's I2C slave peripheral/driver — not a floating-pin
  artifact.**

**Updated conclusion**: only SDA is a confirmed real lockup; SCL is not. This narrows (doesn't
invalidate) the espressif/esp-idf#15572 match — that issue describes both SDA and SCL going low,
which doesn't fully match anymore; treat #15572 as a partial/related match, not a confirmed
identical repro, going forward. `on_request/woken/tx_notified` stayed `0` in this run too — still
consistent with the lockup happening at/near init, independent of any master activity.

**How to apply**: don't re-cite "SCL stuck low" as an established fact — it's retracted. The
confirmed, narrower finding is SDA-only. Next step (not yet done): narrow further what part of
Bridge's init sequence causes SDA specifically to latch — bisect `i2c_slave_link_init()` (e.g.
does the lockup still happen with `on_receive`/`on_request` callbacks unregistered, or with
`send_buf_depth`/`receive_buf_depth` reduced to something near the ~256B seen in IDF examples).

## NEW, more severe problem found: SDA held low even with Bridge fully POWERED OFF (2026-09-22)

User tested with Bridge's power completely off (not just idle firmware — no power at all), wired
via D_SDA/D_SCL as described above. Measured with a multimeter:
- SCL+GND only connected → SCL = 3.3V (healthy, matches CNTL's pull-up working normally).
- SDA+GND only connected → **SDA = 0V, and CNTL dies** (same crash symptom as the powered-on case).
- With CNTL already dead, additionally connecting SCL too → SCL now reads 2.2V (not a clean level
  — likely CNTL's driver still toggling/retrying, read as an averaged voltage by the meter; not
  confirmed, flagged as inference).

**User's architectural read (confirmed accurate)**: this is worse than the powered-on bug alone —
the two boards are not guaranteed to always be powered together, so **any time Bridge merely loses
power (crash, brownout, unplugged) while physically wired, CNTL goes down with it**, independent of
whether Bridge's I2C slave firmware bug (SDA-latch while running) is ever fixed. Two separate
problems now, not one: (a) Bridge's running firmware latches SDA low (software/driver bug,
narrowing work above), (b) Bridge merely being unpowered ALSO pulls SDA low (a different
mechanism, below) — fixing (a) alone would not fix (b).

**Research on mechanism (2026-09-22)**: this matches a well-documented general I2C phenomenon —
an unpowered device's own ESD protection diodes can conduct current from the still-powered bus
back into the dead chip, pulling the line down ("backpowering"). Confirmed via multiple sources:
[Analog Devices EngineerZone Q&A](https://ez.analog.com/data_converters/precision_adcs/f/q-a/599909/i2c-function-when-unpowered-device),
[EEVblog: i2c bus isolation for un-powered AVR](https://www.eevblog.com/forum/microcontrollers/i2c-bus-isolation-for-un-powered-avr/).
**Doesn't fully match though**: generic ESD-diode backpowering should affect SDA and SCL
symmetrically (both pins normally have identical ESD structures), but only SDA is affected here —
SCL stays clean at 3.3V. Why only SDA is unexplained by anything found so far (labeled as an open
question, not a confirmed mechanism) — a guess floated (GPIO22 also being SDIO_DATA2) is
**unconfirmed, do not restate as fact**.

**CNTL's board has no protection against this today**: confirmed (see wiring-correction section
above) that M1/NDC7002N is a level shifter, not a galvanic isolator, and provides no defense here.

**Solution directions surfaced, not yet chosen/implemented**:
1. True I2C isolator IC (e.g. PCA9615-class) between CNTL and Bridge — galvanically separates the
   two sides so Bridge losing power can't electrically affect CNTL's bus at all. Structural fix,
   doesn't depend on fixing Bridge's firmware.
2. Series diode isolation on SDA/SCL — simpler/cheaper, standard textbook fix for this exact
   backpowering scenario, but adds a diode voltage drop to consider.
3. Stronger/lower-value external pull-up — tested implicitly already: even Bridge's own internal
   pull-up (much stronger than a passive resistor would typically need to be) didn't lift SDA, so
   a modestly stronger board pull-up alone is unlikely to be sufficient against whatever is
   sinking SDA this hard.

**How to apply**: this is now the higher-priority problem of the two (affects CNTL even when
Bridge is simply off, which will happen routinely in normal use) — solving Bridge's running-state
SDA-latch bug (the software/driver investigation above) does NOT address this. Next step is
deciding between isolator IC vs. diode isolation vs. further investigating why SDA/SCL are
asymmetric before picking a fix.

## Physical wiring correction (2026-09-22) — goes through M1 level shifter, NOT bare GPIO8/9

**Claude got this wrong twice in this session and was corrected both times — record precisely.**
The physical test wire connects Bridge to CNTL via the **external isolated I2C connector
(D_SDA/D_SCL, through level shifter M1/NDC7002N)**, not by probing bare GPIO8/9 pins directly.
This means M1's MOSFETs and the external-side pull-ups (R99/R102, 4.7K to `I2C_VCC`, confirmed
3.3V) ARE part of the circuit for every voltage measurement recorded in this section — not just
CNTL's internal-side pull-ups (R100/R101 + SoC `enable_internal_pullup`). Two separate but
compatible facts, don't re-confuse them: (1) CNTL's **software** (`i2c_bridge.c`) still just calls
`waveshare_rgb_lcd_get_i2c_bus()` and only knows about GPIO8/9 — from the master driver's
perspective it only ever talks to its own pins; M1 is a passive/transistor bridge that
transparently extends that same electrical bus out to the external D_SDA/D_SCL header, no software
awareness of M1 needed. (2) The **physical wire** to Bridge is on the far (D_SDA/D_SCL) side of
that bridge, so M1 sits electrically between Bridge and CNTL's actual GPIO8/9 for every test in
this document that says "connected to CNTL." **Also corrected: M1/NDC7002N is a level SHIFTER
(voltage translator, bidirectional passthrough), not a galvanic ISOLATOR** — a low state on either
side passes through to the other side by design (that's how the classic 2-MOSFET I2C level-shift
circuit works). It provides zero protection against the SDA-backpowering problem below; CNTL has
no true I2C isolator (e.g. PCA9615-class chip) anywhere in this signal path today.

**Real-hardware corroboration (2026-09-22, user's own test) — ROOT CAUSE FULLY CONFIRMED**: user
ran the two single-wire tests on the real CNTL board:
- SCL only wired (SDA disconnected) → CNTL did **not** break.
- SDA only wired (SCL disconnected) → CNTL **broke** (died, matching the original CH422G/GT911
  symptom).

This is definitive, real-hardware confirmation: **SDA being stuck low on Bridge's own I2C slave
peripheral is the actual, complete root cause of CNTL/CH422G/GT911 breaking when the bridge is
physically wired in.** SCL was never the problem (matches the internal-pull-up bench test above).
No longer a hypothesis — this closes the root-cause question. Remaining open work is fixing SDA's
lockup in Bridge's implementation (see the solution options list earlier: Arduino-ESP32 Wire.h,
legacy i2c_slave v1, bitbang, reduced buf_depth, or bus isolation), not further root-cause
investigation.
