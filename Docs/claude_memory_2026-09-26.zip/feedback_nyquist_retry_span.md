---
name: feedback-nyquist-retry-span
description: "For any CNTL request retry against a peer with a known periodic sleep/wake duty cycle, the total retry span must be >= 2x that period (Nyquist-style), not just closely-spaced attempts — established 2026-08-21 fixing 'pairing fails once, succeeds on retry'"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-21T10:16:26.938Z
---

When CNTL retries a request against a node (CAM/Sens) that has a periodic ON/OFF duty cycle (e.g.
CAM's pre-pairing "wake briefly, retry, sleep briefly" loop), the retry *spacing* between attempts is
not what matters most — the total *span* the retries cover does. If that total span is shorter than
the peer's full sleep+wake period, a single button press can have its entire retry burst land
entirely within the peer's "asleep" phase, failing outright regardless of how tight the retry
interval is. The fix is not to make retries more frequent — it's to make the retry burst last long
enough.

**The rule (stated directly by the user, in these words):** "안전한 간격은 CAM의 두배야" — the safe
total retry span is at least 2x the peer's full cycle period. This guarantees at least one full
"awake" window is covered regardless of what phase the peer happened to be in when the request
started (analogous to the Nyquist sampling principle, though here it's about retry-window duration
vs. cycle period, not sampling frequency vs. signal frequency — the user drew the analogy
deliberately and it's the right mental model to reuse).

**Why:** Root-caused 2026-08-21 — CAM's `cam_node_wake_window_done()` (CAM/main/cam_node.c) makes CAM,
while unpaired, wait only `CAM_DEEPSLEEP_PAIR_WAIT_TIMEOUT_MS` (3000ms) before going back to sleep for
`CAM_DEEPSLEEP_RETRY_SLEEP_SEC` (3s) — a ~6-7.8s full cycle including boot overhead, confirmed via a
live serial capture showing CAM rebooting every ~7.8s. CNTL's `esp_now_hub_pair()` (Cntl/main/
esp_now_hub.c) was retrying PAIR_REQUEST for only 500ms x 5 = 2.5s total — well under one cycle —
explaining the "connect fails once, works on the second press" symptom the user kept reporting (three
other theories — CNTL WiFi channel instability, COM5 serial-monitor flicker, response-interval tier —
were each raised and explicitly ruled out by the user before this one was confirmed correct).

**How to apply:** Define the mirrored peer-cycle-period constant as an expression (not just a bare
literal) at the retry call site, with a comment cross-referencing the source-of-truth constants on the
peer's side (since CAM and Cntl are separate projects/binaries — the constant can't be literally
shared, only kept in sync by convention + comments, same category as
[[feedback_cntl_owns_mutually_judged_values]]'s "pre-pairing constants" case). Then compute
`retry_attempts = (peer_cycle_ms * 2) / retry_interval_ms` rather than hardcoding attempt counts.
Applied to `esp_now_hub_pair()`'s PAIR_REQUEST retry (`CAM_UNPAIRED_RETRY_CYCLE_MS=6000`,
`*2/500=24` attempts) 2026-08-21. User explicitly said this same pattern applies to Sens once that
gets the same treatment — Sens has an analogous deep-sleep pairing cycle.
