---
name: project-cam-cntl-pairing-state-machine
description: "2026-08-23: CAM/CNTL pairing races diagnosed via a hand-drawn sequence diagram + speaker diagnostics; unified ConnectionState enum on both sides; 2 races closed; PING-failure root cause and UNPAIR one-way fragility still open"
metadata:
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-25T22:44:38.130Z
---

Deep-dive session (2026-08-23, same day as [[project_caml_bat_en_latch_missing_resolved]] and the
CAM/CAML port-back work) into why CAM/CNTL pairing was unreliable or never completed. Method: user
walked through the actual message flow case-by-case ("사용자-콘-캠" 3-step handshake), had me verify
each claim against the real code rather than reason abstractly, and had me draw/redraw a sequence
diagram (published Artifact, see below) to keep both of us aligned on the actual state model.

**Root architectural finding:** connection status was scattered across independent booleans that could
drift out of sync — CAM had `s_synced` (esp_now_channelsync.c) + `s_paired` (esp_now_cam.c); CNTL had
`n->paired` + `n->ever_paired` + `n->user_unpaired` per node. User's core principle: "상태머신이면
상태에 따라 입력과 출력이 달라져야지" (if it's a state machine, state must directly determine both
inputs and outputs) — a single state variable isn't enough if the actual send/receive code paths don't
consult it.

**Fixed and shipped (both CAM COM5 and CNTL COM18 flashed):**
1. CAM: unified `s_conn_state` enum (`CAM_CONN_ORPHAN` / `CAM_CONN_FOUND` / `CAM_CONN_PAIRED`) in
   esp_now_cam.c, replacing the old `bool s_paired`.
2. CNTL: unified `n->conn_state` enum (`NODE_CONN_ORPHAN` / `NODE_CONN_PAIR_PENDING` /
   `NODE_CONN_PAIRED`) per node in esp_now_hub.h/.c, replacing `bool paired` (kept `ever_paired`/
   `user_unpaired` as separate policy/history flags, not folded into the state — they're not "current
   state," they're modifiers).
3. **Race 2 (CNTL side)** — CNTL used to unconditionally reset `paired=false` + re-ACK + re-trigger
   pairing on ANY advertise it heard, even one sent by CAM's own scan_timer in the narrow window before
   PAIR_ACK is confirmed. Fixed with `n->pair_request_pending_until_ms`: while a PAIR_REQUEST retry
   burst is outstanding, incoming advertises from that node are ignored entirely (no ACK, no reset).
4. **Race 3 (CAM side)** — `esp_now_channelsync_notify_paired()` (mutex-protected, stops scan_timer)
   is now called as early as possible in the PAIR_REQUEST handler (right after validating the message,
   before peer-add/rate-config), shrinking the window where `scan_timer_cb` could still sneak out one
   more ADVERTISE. Not theoretically perfect (a mutex can't cancel an already-started timer callback,
   only block future ones) but now very narrow.
5. **Defensive output gate** — `send_advertise_on_current_channel()` (esp_now_channelsync.c) now
   consults a registered `should_advertise_cb` before transmitting; CAM registers one that returns true
   only for `s_conn_state == CAM_CONN_ORPHAN || s_conn_state == CAM_CONN_FOUND` (explicit allow-list,
   not `!= PAIRED` — user explicitly corrected this distinction so a future added state doesn't
   accidentally fall through to "allowed"). This makes the advertise SEND path itself state-driven, not
   just dependent on the timer having been stopped elsewhere.
6. Also: mutex added around all of esp_now_channelsync.c's shared state (`s_scan_channel`/`s_synced`/
   timers) — scan_timer_cb (esp_timer task) and esp_now_channelsync_on_recv (ESP-NOW recv task) could
   genuinely run concurrently on the dual-core S3 with no prior synchronization.

**Still open, explicitly deferred by user to revisit later — do not start unprompted:**
- **Why does PING fail** even when the link is otherwise fine — this is what triggers lost-sync
  (`enter_unsynced()` + `on_lost_sync()` → back to ORPHAN) and was the proximate cause of the
  "무한 광고" (endless advertising) symptom reported repeatedly this session. Root cause not yet found;
  user explicitly said "핑은 다음에 볼꺼니까" (we'll look at ping separately, later) multiple times.
- **UNPAIR is one-way, no ack, no retry** (`esp_now_hub_unpair()` sends `ESP_NOW_MSG_UNPAIR` via a bare
  `esp_now_send()`, not the reliable_request pattern used for PAIR_REQUEST). If it's lost, CNTL believes
  it disconnected (conn_state=ORPHAN, user_unpaired=true) but CAM stays PAIRED and keeps behaving
  normally — CNTL's PING handler replies unconditionally regardless of pairing state, so CAM never
  notices anything is wrong. User: "이건 나중에 검토할테니 할일로 기억해 두고" (remember this as a
  TODO, will review later) — explicitly told to hold, not fix now.
- Similarly worth revisiting later (not yet raised as a formal TODO by the user, just noted from the
  same investigation): CAM's PAIR_ACK reply is also a bare one-shot `esp_now_send()` (not reliable) —
  if it's lost, CNTL's PAIR_REQUEST retries get silently ignored by CAM (already PAIRED, guard blocks
  reprocessing), leaving CNTL stuck at PAIR_PENDING until its own retry burst exhausts. User confirmed
  this self-heals via CAM's normal deep-sleep reboot cycle (full state reset → re-advertises within
  seconds) — "사용자가 여러번 시도하면 성공해" — so it's a real but low-severity gap, not urgent.

**Reference artifact:** published sequence diagram (mermaid, in an HTML artifact) walks the full
ORPHAN→FOUND→PAIRED→PING/PONG→lost-sync cycle with the two closed races marked green and the PING
mystery marked red — kept updated in place (same URL) as the design evolved during the session. Check
`action: "list"` on the Artifact tool to find it if picking this back up in a future session — title
"CAM 페어링 시퀀스".

**How to apply:** when resuming this work, re-verify current code state before trusting any of the
above as still-true (this file describes 2026-08-23's session state, not necessarily current) — this
session repeatedly found that even careful analysis was wrong until checked against a live capture or
the actual source, per [[feedback_audit_own_change_first]] and [[feedback_anchoring_bias_on_hypothesis]].
Do not start on the two deferred items without the user explicitly re-opening them.

---

**2026-08-24 continuation — the "무한 광고" mystery fully resolved, plus a real protocol redesign.**
Picking up the same day (session ran past midnight), the "endless advertising sound" symptom turned
out to have TWO separate causes, both now fixed and HW-verified:

1. **Root cause of the audible mystery: ESP32 I2S DMA underrun-repeat**, not a software/protocol bug at
   all. `i2s_chan_config_t.auto_clear` defaults to `false` — confirmed by reading ESP-IDF v6.0.2 source
   (`i2s_common.c`: `if (handle->dma.auto_clear_after_cb) memset(curr_buf, 0, ...)`). With it off, once
   `play_tone_blocking()` finishes writing a tone, the DMA hardware keeps re-transmitting the last
   written buffer forever instead of going silent — a well-documented general ESP32 I2S behavior
   (see ESPHome issue #6921, "keeps repeating audio like its stuck in a buffer"). This is why every
   software-side diagnostic that day (event/queue counters, `eTaskGetState()` on the speaker task,
   `uxQueueMessagesWaiting()`) showed a perfectly idle system while the user kept hearing continuous
   sound — the repeat was happening entirely below the software, in DMA hardware the CPU wasn't
   touching anymore. Fix: `cam_speaker.c`'s `cam_speaker_init()` now sets `chan_cfg.auto_clear = true;`
   before `i2s_new_channel()`. Two earlier attempted fixes (disable/re-enable the channel after each
   tone; manually writing silence chunks after each tone) were both tried and BOTH failed on real
   hardware — only the driver-level `auto_clear` config actually works. HW-verified: CNTL-off scanning
   now sounds like clean 300ms(=SCAN_DWELL_US) ticks, and sound cleanly stops the instant CNTL pairs.

2. **Separately, a genuine protocol redesign for the "connect" button**, per user's explicit "원론적으로
   해결" instruction (stop tuning retry timing, fix the actual mechanism): the manual pair button no
   longer fires an independent blind unicast retry burst on CNTL's own fixed channel hoping to catch
   CAM's channel-hopping by luck (the old ~6.5s window, itself a stale Nyquist-style calc that had
   already been invalidated by an unrelated same-day change to CAM's unpaired-awake-duration policy).
   Instead: `esp_now_hub_request_pair()` just sets a per-node `user_pair_wanted` flag; the actual
   `PAIR_REQUEST` send (the old, now-`static` `esp_now_hub_pair()`) only fires from inside the
   ADVERTISE-receive handler, at the exact instant CAM's real advertise is heard — a moment already
   channel-matched by construction, so there's no timing gamble left. Capped at 3 advertise-triggered
   attempts (`pair_req_attempts_left`) before giving up, replacing the old time-based
   `pair_request_pending_until_ms` "in-flight" window entirely (that field/mechanism is gone — the race
   it guarded against no longer exists now that CAM's `send_advertise_on_current_channel()` re-checks
   state fresh at the real send point, see next item). ADVERTISE_ACK is now skipped when a PAIR_REQUEST
   is being sent for the same advertise (no more double-message per event).

3. **CAM-side structural fix, per user's "체크는 실제 송출 함수에서" instruction**: the
   `should_advertise_now()` gate moved from being pre-computed once by callers (`enter_unsynced()` /
   `scan_timer_cb()`) into `send_advertise_on_current_channel()` itself, re-checked fresh immediately
   before every real send. This closed a real ordering bug: PING-failure/PONG-mismatch lost-sync calls
   `enter_unsynced()` *before* the app-level callback flips `s_conn_state` back to ORPHAN, so a
   caller-side pre-check was reading stale state. Now the timer-restart calls in `enter_unsynced()` /
   `rest_timer_cb()` are unconditional — safe, because the real gate lives in the send function itself
   and the existing self-healing check at the top of `scan_timer_cb()` still stops a wrongly-running
   timer within one tick.

4. **CNTL's `was_paired` desync auto-repair now overrides stale `user_unpaired` history** — if CNTL
   currently believes a node is PAIRED and then hears a fresh ADVERTISE from it (proof the node reset),
   it re-triggers pairing unconditionally, regardless of a `user_unpaired` flag left over from an
   earlier, unrelated session — that flag was blocking legitimate desync recovery.

**Also found, real, separate, explicitly deferred (not fixed) — see
[[project_cam_sd_espnow_crash_recurrence]]:** a `LoadProhibited` panic (SD capture racing ESP-NOW
activity, same known-but-unfixed class of bug first found 2026-08-08) reproduced live at ~30min uptime
during a diagnostic capture. Unrelated to the sound bug — do not conflate the two if revisiting.

**Still explicitly deferred by user, unchanged — do NOT start unprompted:** the `#if 0`-disabled
PING-failure→lost-sync trigger in `esp_now_channelsync.c`'s `ping_timer_cb()` is still disabled (left
that way on purpose — "다음 단계에서 볼꺼야"). PING currently fails 100% of the time once paired
(confirmed via hours of live capture, consistent ~500ms-interval failures, never once succeeding) but
because the reaction to it is disabled, this no longer causes any visible symptom — CAM just stays
PAIRED and quiet. The underlying "why does PING never succeed" question is still completely open and
was never investigated this session — re-enabling that `#if 0` block without first understanding *why*
PING fails would likely reintroduce the original rapid re-scan symptom.

**Meta-lesson reinforced hard this session:** software-level diagnostics (logs, queue counters, task
state via the RTOS scheduler) can all be 100% self-consistent and 100% wrong about explaining a
real, physically-observed symptom, if the actual cause lives one layer below what's being
instrumented (hardware DMA, in this case). When every software signal says "idle" but a user reports
continuous, reproducible physical output, the right move eventually was widening the search to the
driver/hardware layer (which a web search plus reading the actual ESP-IDF driver source resolved in
minutes) rather than continuing to add more software instrumentation on top of software that was
already proven not to be the site of the bug.

**User's own closing assessment (2026-08-24):** "결국 부실한 사운드 로그 때문에 이틀을 날렸고" — the
two days lost on this investigation are attributed to the sound-log diagnostic itself being
inadequate at first (only logging on specific solfège events, no per-playback channel tagging, no
queue/task-state visibility) until it was built out properly late in the session — not to hardware or
external causes. Worth remembering next time a "weird intermittent" symptom shows up: build the
verification instrumentation to be trustworthy FIRST (this session's actual working methodology,
once it was finally applied — per-event logs with real payload data, checked against ESP-IDF source,
not just inference from partial signals) rather than iterating on theories against a thin log.

**Next session (from 2026-08-24, whenever it resumes):** user stated intent to go through
post-pairing behavior scenarios one by one ("내일은 패어 이후의 상황들을 하나씩 짚어볼테니까") —
expect a similar case-by-case walkthrough method to the 2026-08-23 pre-pairing one (see the
"Method" note at the top of this file), applied to what happens after PAIRED state is reached
(this is presumably where the still-open PING-fail item and possibly UNPAIR fragility will surface
again, but wait for the user to drive which scenarios, don't pre-empt).

**First item to solve tomorrow, explicit user instruction (2026-08-24):** after CAM/CNTL connect,
roughly 30 seconds later (user's estimate — "50초일 수도 있어, 측정한게 아니니까", not precisely
measured) CAM disappears from CNTL's node list, AND CAM does not advertise again afterward, so
there is no way for it to reconnect automatically — this is the first thing to fix, ahead of the
rest of the post-pairing walkthrough. Diagnosis so far this session (grounded in code read, not yet
confirmed live): two independent things line up to plausibly cause exactly this —
1. CAM-side: with the PING-fail→lost-sync reaction still `#if 0`-disabled in
   `esp_now_channelsync.c`'s `ping_timer_cb()` (see the entry above), CAM never falls back out of
   its internal PAIRED-equivalent synced state no matter how many PINGs fail — so it never
   re-enters ORPHAN/UNSYNCED, and `should_advertise_now()`'s allow-list (ORPHAN/FOUND only) means
   it never advertises again. CAM keeps sending CHANNEL_PING forever regardless of failures
   (confirmed by reading `ping_timer_cb()` — the send itself isn't gated on failure count, only the
   `#if 0`'d reaction is), so this isn't a "CAM stopped pinging" bug, it's "CAM stopped being
   willing to re-announce itself" bug.
2. CNTL-side: `esp_now_hub_get_nodes()` (esp_now_hub.c) drops a node from the list once
   `now_ms - last_seen_ms` exceeds `esp_now_hub_node_timeout_ms()`, floor `ESP_NOW_HUB_NODE_TIMEOUT_MS
   = 50000` (50s, esp_now_hub.h) — confirmed via code read this session. `last_seen_ms` is refreshed
   by ADVERTISE, PAIR_ACK, and CHANNEL_PING reception (esp_now_hub.c ~line 435) — so if CNTL is
   genuinely receiving CAM's PINGs, last_seen_ms should keep refreshing and the node should NOT go
   stale. The fact that it reportedly does go stale (~30-50s, i.e., roughly one timeout window)
   suggests CNTL may not actually be receiving those PINGs at all (not just losing the PONG on the
   way back) — this is the still-unconfirmed half. **Not yet checked live**: whether CNTL is
   actually receiving CHANNEL_PING while "paired" — there's currently no log on that reception path
   to confirm either way.
User's own assessment when given this analysis: "답이 안되지만 알았다" (not a real answer, but
noted) — i.e., the diagnosis above is a plausible mechanism from code reading alone, NOT yet
verified against a live capture, and should not be treated as confirmed. Start here tomorrow with
real measurement (exact disappear timing + whether CNTL logs receiving PING at all during that
window) before proposing a fix, per [[feedback_dont_use_user_as_test_oracle]].

**Superseded 2026-08-25/26**: rather than debug PING/PONG further, the whole heartbeat concept was
removed and replaced by the CASK protocol redesign — see
[[project_cam_cntl_known_hub_direct_wake_protocol]]. The structural fix for "CAM disappears and never
reconnects" is CNTL's new active liveness sweep (`liveness_sweep_cb()`, demotes stale PAIRED nodes to
ORPHAN) paired with CAM's own mid-CASK stall timeout + `esp_now_cam_reconnect()` fallback — CAM now
has a bounded, unconditional path back to re-advertising no matter which side caused the silence. CAM/
CNTL/Sens all build clean as of 2026-08-26. **Not yet hardware-verified** — the original 30-50s
disappearance symptom has not been re-run live against this new code.
