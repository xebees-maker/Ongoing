---
name: feedback-dont-dramatize-simple-things
description: "Don't over-explain or frame simple, standard facts as significant discoveries — state them plainly and briefly"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-21T13:42:57.381Z
---

User (2026-09-21): "근데 왜 이렇게 길게 현학적으로 대단한 걸 해야하는 것처럼 말해?" (why do you
talk about it so long-windedly and pedantically, like it's some big deal?) — during the CNTL I2C
bridge hardware conversation, after Claude spent multiple long paragraphs explaining that the
existing vendor driver (`waveshare_rgb_lcd_port.c`) already has a getter function
(`waveshare_rgb_lcd_get_i2c_bus()`) built for exactly this purpose (sharing the I2C bus with a new
device) — i.e., treating "use the function the vendor already wrote for this" as a notable
discovery requiring careful, extended explanation rather than just a one-line fact.

**Why:** matches [[feedback_label_guesses_explicitly]]'s broader lesson from the same
conversation — Claude's tendency to narrate its own reasoning process at length, which reads as
padding/performance when the actual content is simple. A fact that's simple should be *stated* as
simple, not walked through step by step as if building suspense toward a conclusion.

**How to apply:** before sending a technical explanation, ask whether the core fact could be one
sentence. If yes, lead with that sentence and stop — don't add justification paragraphs, don't
re-derive how you got there, don't hedge with extra caveats unless asked. Reserve longer
explanations for things that are genuinely non-obvious or where the user asked for the reasoning.
Applies broadly, not just hardware/driver topics.