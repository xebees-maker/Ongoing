---
name: project-cntl-internal-ram-crunch
description: "CNTL's internal (non-PSRAM) DRAM was critically low at boot (~1.1-1.4KB free) causing intermittent httpd_start failures (5005) and possibly WiFi instability; root-caused and fixed by moving large static buffers to PSRAM, 2026-08-21"
metadata: 
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-21T12:10:18.035Z
---

Found via `idf_size.py --archives`/`--files` analysis of the linker map: `libmain.a` (Cntl's own
application code) was using **21,248 bytes of internal DRAM (.bss)** — by far the single largest
internal-RAM consumer in the whole firmware, nearly 3x bigger than WiFi's own net80211 buffers
(7,698B). This left free internal DRAM at only ~1,111-1,419 bytes at the point in boot where
`httpd_start()` runs, causing intermittent 5005 (httpd_start failure) errors — `HTTPD_DEFAULT_CONFIG()`
forces `task_caps = MALLOC_CAP_INTERNAL`, so the httpd task's stack allocation had nowhere near enough
room.

**Root cause:** many static buffers across `main` component files default to internal DRAM/.bss unless
explicitly PSRAM-backed. The two biggest single offenders: `ui_main.c`'s `snapshot[3072]` (a
function-local `static` inside `refresh_log_box`, easy to miss since it's not a top-level global) and
`ui_log.c`'s `s_buf[6144]` (the on-screen log ring buffer) — together ~9.1KB. After also moving
`esp_now_photo.c`'s `s_list_items[64]`, `ui_main.c`'s `s_power_log_buf[2048]`, `s_current_list[64]`,
and the four node-tracking arrays (`s_dash_nodes`/`s_dash_nodes_prev`/`s_camera_nodes`/
`s_camera_nodes_prev`, each `esp_now_hub_node_t[8]`) to `heap_caps_malloc(..., MALLOC_CAP_SPIRAM)`,
`libmain.a`'s .bss dropped to **5,175 bytes** (a 16KB reduction) and free internal DRAM at the same
boot checkpoint rose from ~1,300B to **15,063 bytes** — roughly a 10x improvement, confirmed on
hardware.

**Also fixed as part of the same investigation:** `HTTPD_DEFAULT_CONFIG()`'s task now explicitly gets
`config.task_caps = MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT` (main.c) so httpd's own task stack doesn't
compete for internal RAM at all going forward, independent of the general headroom fix above.

**How to apply — the pattern for any future large buffer in this codebase:** if a `static` array/
struct-array is purely for display/text/list purposes (no DMA, no hardware timing requirement), always
`heap_caps_malloc(size, MALLOC_CAP_SPIRAM)` it once (in `ui_init()`/`esp_now_photo_init()`/equivalent
module init) rather than declaring it as a bare `static TYPE name[N];` — the latter silently lands in
scarce internal DRAM. Watch especially for `static` *local* variables inside functions (like the
`snapshot[3072]` case) — these are easy to overlook in a review since they don't show up in a
top-of-file scan of global statics, but still consume permanent internal RAM exactly like a global.
When adding a PSRAM-backed buffer this way, guard every access site with a `if (!ptr) return;` (matches
existing convention for `s_recv_buf` etc.) since allocation failure, while rare, is a real code path now.

**Open/unconfirmed:** the user separately reported intermittent WiFi "channel dancing" (repeated
disconnect/reconnect) around the same session — unconfirmed whether this was actually caused by the
same internal-RAM pressure (WiFi driver buffers also require internal RAM) or a separate issue; worth
re-checking after this fix if it recurs. See [[project_cntl_xclk_preset_ui]] and
[[feedback_nyquist_retry_span]] for other fixes from the same session that turned out to be unrelated
red herrings for a similar "used to work, now doesn't" pattern (channel-scan timing, response-interval
tier) — this internal-RAM finding is a more systemic candidate explanation worth keeping in mind for
future "intermittent since ~a month ago" symptom reports on this board.
