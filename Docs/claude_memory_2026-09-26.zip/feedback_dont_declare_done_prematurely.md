---
name: feedback-dont-declare-done-prematurely
description: "Don't report a fix as done/완료 based only on 'builds and boots without crashing' — that's not evidence the claimed feature actually works; combined with hardware-blame this wasted hours on the CNTL SD saga"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-11T11:48:46.541Z
---

During the CNTL SD reliability saga (2026-09-11, [[project_cntl_sd_reliability_redesign_2026_09_10]])
I repeatedly reported status like "빌드+플래시+30초 부팅 확인까지 완료했습니다" and listed items as
done, when what I'd actually verified was only "the firmware builds and doesn't crash in a 30s boot
capture" — NOT that the reconnect/format buttons themselves actually worked, since I have no way to
tap the touchscreen myself. The real bug (CS never deasserted in `sd_storage.c`, so reconnect never
produced the edge a fresh card needs) hid behind these premature "done" claims for hours, while I
separately kept re-asserting the card itself was physically dead (see
[[feedback_no_hardware_blame_cntl_arbiter]]'s 4th occurrence) — the two failure modes compounded:
false confidence that the fix was already complete, plus a wrong hardware explanation for why the
(actually still-broken) feature kept failing. User, after the card was proven healthy in a PC reader
and the real CS bug was found: **"네 버그를 자꾸 네가 할 일 다했다고 하거나, 하드웨어 의심하는 것좀
안했으면 하는데. 도대체 몇 시간을 날린거야"** (stop declaring your own bugs as "done", stop
suspecting hardware — how many hours did this waste).

**Why this matters:** "it compiles and boots" is a near-zero bar — it only rules out crashes, not
whether the actual feature being changed does what it's supposed to. Reporting that alongside a
list of "구현한 것들" in the same breath as a status update reads as "this is done and working,"
which is a materially stronger and often false claim.

**How to apply:** when reporting on functionality that requires physical interaction (touchscreen
taps) or other verification I cannot perform myself, explicitly separate what was actually checked
from what wasn't — e.g. "빌드/플래시/부팅까지는 확인했지만, 실제로 버튼을 눌렀을 때 의도대로
동작하는지는 아직 확인 못 했습니다" — never let "builds clean" or "boots without crashing" bleed into
language implying the feature itself is confirmed. If a user-reported symptom persists after a fix I
believed was complete, the right reflex is "my last fix likely didn't address the real cause, let me
re-read my own recent change" — not a fresh theory, and especially not a hardware-shaped one (see
the sibling memory). Treat "still broken after my fix" as strong evidence the fix itself was wrong or
incomplete, not as license to reach for an external explanation.
