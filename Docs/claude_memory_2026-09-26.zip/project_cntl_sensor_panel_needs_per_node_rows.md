---
name: project-cntl-sensor-panel-needs-per-node-rows
description: "SUPERSEDED 2026-09-09 — old spec for per-node indented multi-value Sensor rows; values moved to Summary panel instead, re-derive fresh if this resurfaces"
metadata:
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-08T15:09:32.844Z
---

CNTL's main-screen (주화면) Sensor panel builds its CO2/Temp/Humid display by concatenating all
connected Sens nodes' channel values into a single string with embedded `\n` line breaks
(`append_sensor_value_row()`, written into one label — the label var is `s_sensor_todo`, a
holdover name from when it was still a placeholder), all inside `refresh_dashboard()`
(`Cntl/main/ui_main.c`, ~line 2931-2961 as of 2026-09-08).

This is architecturally different from the Summary panel just above it, which gives each
connected device (CAM/Sens) its own separate `lv_obj_t` row inside `s_summary_list`
(`lv_obj_create` per row + `pad_row` gap between them, ~line 2860+) — the pattern used
everywhere else in this app for "one row per connected thing" (Settings' camera/sensor
connection lists follow the same per-row-widget convention).

**Why this matters:** the user pointed this out (2026-09-08) after noticing Sensor's line
spacing looked different from Summary's — traced to the fact that a single label's internal
line-height (font metric, no `pad_row` involved) is not the same as several separate widgets
with an explicit flex `pad_row` gap between them. The user's own conclusion: **the Sensor side
is the one that's wrong**, not Summary — because once more than one Sens node is ever paired at
the same time, cramming all of them into one text blob won't scale (can't style/update/manage
each node's row independently, no way to give one node's row special treatment, etc.).

**How to apply:** when actually implementing real multi-sensor support (today only one SCD41
Sens node exists; [[project_cam_cntl_storage_unification_2026_09_06]] and related sensor-family
work are still ahead), rebuild the Sensor panel to give each connected Sens node its own row
widget (mirroring the Summary panel's `s_summary_list` per-row pattern), not a single label with
embedded newlines. This was explicitly deferred, not fixed in the moment — user said "기억해
뒀다가 나중에 꼭 반영해" (remember this and make sure to apply it later).

**Exact intended layout (user described 2026-09-08, same session):** most Sens board types
report only ONE value; SCD41 is unusual in reporting several (CO2/Temp/Humidity) from one
board. Per-node row should be: board name/ID on its own line, then that board's value(s)
indented underneath — single line directly if the board has one value, or several indented
lines if it has more than one (SCD41 case). User's own words: "지금처럼 한 보드를 세줄에
나눠서 표기하면 이상하잖아" (splitting one board across three flat, ungrouped lines like today
looks wrong) — the indentation is what visually ties multiple values back to their one board.

**SUPERSEDED 2026-09-09 — premise changed, this specific layout is no longer the plan.** In
[[project_cntl_connection_mgmt_main_screen_2026_09_09]] the user redesigned where sensor values
live at all: Sensor panel's main-screen rows now show only connection status (name/Alias +
signal + battery + measure interval) per device, no measured values; the actual CO2/Temp/
Humidity/NH3 readouts moved to a new Summary-panel live block showing one aggregate current
value per channel type (not per-node, not indented-under-board). So the "per-node indented
multi-value" layout described above was never built and the need for it may not resurface in
this form — if a future request revisits per-node *value* display, re-derive the requirement
fresh rather than assuming this old spec still applies.
