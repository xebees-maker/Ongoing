---
name: feedback-event-driven-not-polling
description: "User's general coding principle — prefer event-driven triggers over polling, across all projects (Cntl/CAM/Sens). Confirmed 2026-08-21."
metadata:
  node_type: memory
  type: feedback
  originSessionId: current-session
  modified: 2026-09-21T14:54:45.426Z
---

When a state change needs to trigger an action, prefer an event/callback mechanism over a periodic
background timer polling for the change.

**Why**: caught live in Cntl's `ui_main.c` — after a capture-now popup auto-selects the newest photo,
I first implemented "does the photo need fetching?" as a check inside the 1-second `refresh_dashboard`
background timer. The user asked directly: "목록 콘트롤이 selected event 를 발생 안시켜? 폴링해야되?"
("Doesn't the list control emit a selected event? Do we need to poll?") — polling was the wrong
instinct when an event-driven path was available. After I explained the real constraint (the row's
LVGL click event can't fire synchronously here because the still-open capture popup would collide
with a new fetch popup trying to open in the same call stack — LVGL's progress-popup module here uses
single global static overlay/timer handles, not a stack, so two open at once corrupts state) and
switched to `lv_async_call()` (defers the trigger to the next LVGL processing cycle — after the
current popup has definitely closed — instead of a 1-second poll), the user confirmed: "그래 이게
맞지. 앞으로도 코딩은 이렇게 해. Event driven으로" (yes, this is right — code this way going forward,
event-driven).

**How to apply**: when a background timer's tick function is about to gain a new "check if X changed
and react" block, stop and ask whether X changing already has (or could have) a natural event/callback
attached to it instead (LVGL `LV_EVENT_*` + `lv_obj_send_event()`, or `lv_async_call()` when the event
needs to fire after the current call stack unwinds to avoid reentrancy/collision, e.g. two modal
popups both trying to own the same single-instance global state). Reserve polling for cases with no
real event source (e.g. watching an external device's radio-delivered state that genuinely only
updates via periodic messages) — not for purely in-process UI state transitions like this one.

**Repeat violation, 2026-09-21** — `Cntl/main/i2c_bridge.c`'s `i2c_bridge_poll_task()` (new code,
part of [[project_cntl_i2c_bridge_design_2026_09_21]]) was written as a `for(;;) { ...; vTaskDelay(20ms); }`
polling loop without even checking this memory first — not a considered trade-off, just default
habit. User: "응 네가 늘 그래. 폴링, 타이머, 땜빵" (yeah you always do that — polling, timers,
patch-jobs), explicitly linking this to the chronic pattern in [[feedback_fix_root_cause_not_bypass]]
— polling-by-default and workaround-by-default are treated as the same underlying habit, not two
separate issues. Note: this specific case has a real hardware constraint (isolated I2C, no spare
GPIO for a hardware alert/interrupt line, so the bridge can't spontaneously signal the master) that
may make *some* master-side checking structurally necessary — but that's a reason to discuss the
constraint with the user and design around it deliberately, not license to default to a plain
polling loop without even raising the question.
