---
name: cntl-memory-decline-under-pairing-churn
description: "CNTL internal free-heap steadily declines (56K->44K over ~90s) under heavy Sens pairing-desync churn — confirmed pre-existing via A/B test against a known-good commit, NOT caused by 2026-09-18 settings refactor; root cause not yet investigated"
metadata:
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-17T15:24:59.875Z
---

While verifying a settings-popup model-lifecycle refactor (2026-09-18), MEMDIAG's
`internal free` reading dropped steadily and did not stabilize: 56867 -> 53183 -> 49271 -> 49143
-> 49271 -> 48703 -> 47851 -> 45031 -> 44659 -> 44855 over ~90s, well below the
[[reference_cntl_memory_floor_57k]] 57K floor the user set that same session.

**Confirmed NOT caused by that day's refactor**: git-stashed the refactor, rebuilt/flashed the
prior commit (02ede3f), and captured the same ~90s window — identical decline pattern
(56867 -> ... -> 44855). Same test environment had 3 Sens nodes continuously retrying pairing
("desync 감지" / PAIR_REQUEST loops) with `ESP_ERR_ESPNOW_NO_MEM` warnings appearing during the
decline — the correlation with pairing churn is observed, not yet confirmed as the cause.

**How to apply**: this is an OPEN, unconfirmed-root-cause memory issue, separate from the SR/
Power-Control popup work. Do not assume it's fixed or explained — next session should reproduce
with the same heavy-pairing-churn condition (multiple Sens nodes desyncing/retrying) and use
MEMDIAG-style instrumentation to find what's actually growing (candidates given prior project
history: esp_now TX queue/retry buffers — see [[project_cntl_tx_queue_full_root_cause_2026_09_10]]
which was a *different*, already-closed TX queue issue but shows this class of bug has recurred
before in this codebase). Don't reflexively blame the settings refactor again without re-measuring.
