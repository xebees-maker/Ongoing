---
name: feedback-report-facts-not-conclusions
description: "User draws conclusions from test data themselves; report only the observed facts, don't append my own interpretive \"즉 ~라는 뜻입니다\" summary — corrected 2026-08-28 mid RS485 CNTL-to-CNTL loopback test"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-21T15:25:31.389Z
---

During the [[project_rs485_experimental_project]] reverse-direction debugging (two CNTL units wired
directly via RS485, no 변/Arbiter involved), after reporting that the second, independent CNTL unit
also failed to receive the first unit's transmitted frames, I appended my own interpretation: "즉 이
특정 개체만의 문제가 아니라, 이 보드 모델/설정에 공통된 문제라는 뜻입니다" (meaning: not specific to
this one unit, but a problem common to this board model/config). User: "아니 결론은 내가 내려.
건방지게 하지 마" (No — I draw the conclusions. Don't be presumptuous.)

**Why:** the user has been directing this entire investigation via their own step-by-step reasoning
(deciding what to test next, walking through the logic of what each result rules in/out). Appending my
own "therefore this means X" conclusion after reporting a result — even when the inference is
technically sound — takes over a role the user has explicitly reserved for themselves. This is
distinct from [[feedback_dont_use_user_as_test_oracle]] (which is about not making the user physically
re-test blind guesses) — this is specifically about not editorializing on data the user already has in
front of them.

**How to apply:** when reporting test/capture/diagnostic results, state only what was observed (byte
counts, frame counts, log lines, timing) — stop there. Do not add a summary sentence starting with
"즉," "이건 ~라는 뜻입니다," "결론적으로," or similar that draws the implication for the user. If asked
directly what I think it means, that's a different situation — answer then. But unprompted, let the raw
result stand on its own and let the user decide what it rules in or out.

**Repeat violation, 2026-09-21** — reported 4 facts from official ESP-IDF docs about async I2C
master callbacks cleanly, then appended on point 4: "지금 이미 발견된 '1493바이트가 너무
크다'는 문제와 정확히 겹치는 경고입니다" — explicitly connecting the doc's "large transactions
cause memory problems" warning to the session's earlier packet-size finding, unprompted. User:
"네가 해석만 안 달았으면 참 좋았을텐데. 해석이 거지같네" (it would've been so much better if
you hadn't added your own interpretation — your interpretation is crap). This applies even when
the connection is obviously correct and the user would draw it anyway in the next second — the
point isn't accuracy, it's whose job the connecting is. Quote the fact, stop; don't editorialize
even one clause further ("겹치는 경고입니다" was the violation, not the earlier factual
quotation).
