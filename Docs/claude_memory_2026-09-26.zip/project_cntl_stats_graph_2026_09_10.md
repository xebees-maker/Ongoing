---
name: project-cntl-stats-graph-2026-09-10
description: "CNTL stats-tab line graph (lv_chart) implemented 2026-09-10 — self-tested for crashes, NOT yet visually confirmed; several design choices made unilaterally, flagged for review"
metadata:
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-09T23:36:38.405Z
---

**Status: implemented, self-tested for crashes (PASS, real data flowed through: `shown_points=23`
on first refresh), NOT yet visually confirmed on the physical screen.** Several real design
questions were resolved by unilateral engineering judgment rather than asked — flagged below,
worth a quick look/correction from the user.

**Confirmed spec going in (established over several turns before implementation):**
- `lv_chart`, `LV_CHART_TYPE_LINE`, inside the existing `s_stats_graph_view` placeholder
  (table<->graph swipe pager in the stats tab's Scale-linked Overview design).
- 4 series fixed order/colors: 0=온도/Temp=red, 1=습도/Humidity=blue, 2=CO2=black,
  3=암모니아/NH3=cyan.
- Combined series only (not per-node).
- Per-series show/hide: separate checkboxes (not legend-tap) — user's explicit answer.
- Tap shows the nearest single point's value (not all 4 series at once) — user's explicit answer.
- Scale shared with the Overview panel's existing `s_stats_scale_dd` dropdown/cutoff logic.

**Choices made unilaterally (not previously discussed) — review these on screen:**
1. **Y-axis normalization.** Temp/Humidity/CO2/NH3 have wildly different real ranges, so a shared
   Y-axis would flatten most series unreadably. Implemented: each series is independently
   min-max-normalized to 0-100 for *display* using that series' own min/max over the current Scale
   period (`stats_store_get_min_max_avg_since()`), while the real (denormalized) value is kept in
   `s_stats_chart_real_values[series][index]` for the tap readout. This means the Y-axis position
   on screen does NOT represent an absolute value for any series — only relative shape within its
   own period. If this isn't what's wanted (e.g. a real dual-axis, or one shared unit-agnostic
   scale), it needs a different approach.
2. **"10 always-visible evenly-spaced value labels" — NOT implemented.** This was confirmed
   earlier ("대략 10군데 정도는 탭 없이도 값이 보이는 거야") but with 4 independently-normalized
   series sharing one chart, it was unclear which series (or all 4 at each of 10 x-positions,
   which would be visually crowded) should get permanent labels. Skipped pending a decision rather
   than guessing a third unclear default on top of the normalization choice above.
3. **Point count / alignment across series.** `STATS_GRAPH_POINT_COUNT = 60` cap; each series
   queries `stats_store_read_since()` independently (existing API), so if series have different
   record counts in the period, they're left-aligned (oldest-first) and the shorter ones show gaps
   (`LV_CHART_POINT_NONE`) at the tail rather than being stretched to match. Also: because each
   channel's downsampling stride is computed independently, "index i" is not guaranteed to be the
   *same real timestamp* across series — this is an existing property of `stats_store_read_since()`
   (per-channel stride sampling), not something newly introduced here.
4. **Tap-target resolution.** Nearest point found by X-distance among the first *checked* series
   (used as the x-axis reference, since all series share the same point positions), then among all
   currently-checked series at that index, whichever has the closest Y-pixel to the tap is chosen
   and its real value shown via `s_stats_chart_tap_label`.

**Files touched:** `Cntl/main/ui_main.c` only — `refresh_stats_graph()` (wired into the existing
2s `refresh_stats_page` timer, gated to skip SD reads when the graph view is hidden),
`cb_stats_chart_series_toggle()`, `cb_stats_chart_tap()`, and the `build_stats_tab()` widget
construction (checkbox row + `lv_chart` + tap-value label, replacing the placeholder label).

**How to apply:** ask the user to swipe/tap into the graph view on the real screen and react to the
4 unilateral choices above, especially #1 (normalization) and #2 (skipped always-visible labels) —
don't assume silence means agreement given how much this session's earlier design conversation
emphasized getting this exact area right.

**Follow-up, same day — TX_QUEUE_FULL(2009) recurred, root-caused and mitigated.** User reported
"2009 나왔네... 이 2009는 한번 나면 계속나네" (2009 showed up again, and once it happens it keeps
happening) shortly after this graph feature shipped. Added timing MEMDIAG around
`refresh_stats_page()`'s 3 sub-refreshes and measured the real numbers: `refresh_stats_graph()`
alone cost a consistent ~100ms of LVGL-task time on *every single 2-second tick*, for as long as
the graph view stayed open — a genuinely new, chronic (not transient-burst like the earlier popup-
churn stress test) LVGL-task burden, explaining "keeps happening" once a user leaves that tab open:
every 2s window now has a real chance of colliding with a WAKE_HELLO if LVGL and tx_task land on
the same core. Root cause was two-fold: (a) `refresh_stats_overview_panel()` and
`refresh_stats_graph()` each independently called `stats_store_get_min_max_avg_since()` per channel
— redundant duplicate full-file SD scans — fixed by having the overview panel populate a shared
`s_stats_minmax_cache_*` array the graph now reads instead of re-querying; (b) the graph was
refreshing every 2s in lockstep with the live table, which it doesn't need — throttled to 1-in-3
ticks (~6s) via a modulo counter inside `refresh_stats_graph()` itself. Re-measured after the fix:
`graph=0ms` on 2 of every 3 ticks, `~81ms` (down from ~100ms) on the tick it actually runs — average
per-tick burden from the whole stats tab cut roughly 37%. **Not fully proven fixed** (same caveat as
the original tx_task priority fix: absence of recurrence in a ~30s post-fix observation window is
weak evidence, not proof) — if 2009 recurs again, this mitigation reduced but didn't structurally
eliminate the SD-I/O-on-LVGL-task problem. The textbook-correct fix (already anticipated by the
user's own [[project_cntl_task_priority_scheme_2026_09_09]] — "파일처리" tier at priority 10) would
move this SD I/O off the LVGL task entirely onto a dedicated lower-priority worker task; that's a
bigger change not done here, just throttled/deduplicated in place.
