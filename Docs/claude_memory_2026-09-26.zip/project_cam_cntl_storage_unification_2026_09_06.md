---
name: project-cam-cntl-storage-unification-2026-09-06
description: "Design decision 2026-09-06: move CAM's SD card to CNTL, CAM stops local photo storage and pushes captures immediately (like Sens's readings) — full detail in Docs/한일_2026-09-06.txt item 5"
metadata: 
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-06T05:43:42.517Z
---

Decided 2026-09-06 (design discussion only, not yet implemented): move CAM's SD card (4GB) to
CNTL — CNTL already has a physical SD slot/connector wired (user confirmed, see
[[reference-cntl-schematic]] for the actual pin details found from the schematic). CAM would stop
storing photos locally and instead push every capture straight to CNTL immediately, matching how
Sens already reports sensor readings — CNTL becomes the single storage authority for both CAM
photos and the new (also 2026-09-06) sensor time-series stats feature.

**Why**: CNTL will need bulk storage for the stats-tab time-series retention requirement (1+ year)
regardless — LittleFS's ~8MB partition can't hold that. Given CNTL needs an SD card anyway, keeping
CAM's separate SD (with its own list/fetch protocol) stops making sense — simpler to have one
storage location and one simpler push-only protocol for both node types. My initial objection
("selective fetch saves bandwidth on unwanted large photos") was directly refuted by the user:
periodic captures are already infrequent (every 30min-3hr) and manual captures get fetched
immediately anyway, so the current LIST+selective-FETCH protocol's bandwidth-saving benefit is
much smaller in practice than I assumed.

**Expected effects**: simpler CAM<->CNTL protocol (unify with Sens's push model), better user
responsiveness (no list-then-fetch round trip), single storage location. **Caveat flagged by
user**: multiple CAMs can be paired to one CNTL, so storage must be organized per-CAM (e.g. a
folder/namespace per CAM identity), not just one flat pool.

**Status 2026-09-06 update**: CNTL-side SD card mounting is DONE and HW-verified (see
[[reference-cntl-schematic]] for the full technical resolution — CH422G EXIO4 bit-mapping found in
an old archived driver, migrated cleanly, SD mounts successfully at `/sdcard` with `/stats/` and
`/photos/<cam_mac>/` folders precreated). What's NOT done yet: the actual stats time-series file
format/write path (the feature this SD work was originally for), and the CAM-side push protocol
change itself (CAM still stores photos on its own SD, still uses LIST+FETCH) — this memory's
original CAM-simplification proposal remains design-only/not started. Also not yet decided: whether
CAM keeps ANY local buffering (e.g. holding one photo in RAM/PSRAM while transmitting) vs. a fully
synchronous push-per-chunk model.
