---
name: reference-cam-fetched-photos-folder
description: "Fixed local folder for photos pulled from CAM via cam_get.py/dev_console — always use this path, don't invent a new one per session"
metadata: 
  node_type: memory
  type: reference
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-21T06:24:08.964Z
---

When pulling CAM photos to the PC for visual inspection (via `cam_get.py` / dev_console `get`
command), always save them to **`C:\Projects\Ongoing\CAM\tools\_fetched\`** — never to the
session-scoped scratchpad temp directory.

**Why:** User corrected this 2026-08-21 ("아니 왜 자꾸 폴더 위치를 바꿔? 하나로 고정해") — the
scratchpad path changes every session (it's session-ID-scoped by design), so photos "disappeared"
between conversations from the user's perspective even though they were saved correctly. `_fetched/`
is a pre-existing untracked folder in the CAM tools dir that was already the de facto convention
before this was made explicit.

**How to apply:** Existing filenames in that folder follow `photo_<id>.jpg` where `<id>` is the raw
numeric id from CAM's `ls` output. That id resets to 0 each CAM boot/wake cycle, so collisions across
fetch sessions are possible — check for an existing file with the same id before writing and
disambiguate (e.g. suffix) rather than silently overwriting a prior capture. See
[[project_cam_esp_now_production]] for the dev_console/cam_get.py fetch flow itself.
