---
name: feedback-change-one-variable-per-test
description: "User's firm rule: each build/flash/test cycle must change exactly one variable — never bundle a real fix with other changes (convenience hacks, new features) in the same test"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-29T09:30:56.964Z
---

When testing a hypothesis about a bug's cause, change exactly one thing between test rounds. Don't
bundle a real fix together with unrelated changes (test-convenience hacks, new features, UI tweaks)
in the same build/flash/test cycle, even if the user asked for those other things too — sequence
them into separate rounds instead.

**Why:** during the CNTL WiFi-connect-test debugging session (2026-08-29), after diagnosing that
`esp_wifi_sta_get_ap_info()` misjudged "idle vs. actively mid-handshake" (see
[[project_cntl_network_wifi_settings]] if present), the user said "하드코드 비번으로 바꾸고, 토스트로
뭐하는지 단계마다 나오게 하고 실험하자" (switch to hardcoded password, add stage toasts, and let's
experiment). I implemented all three in one build — the real state-machine fix (`s_sta_conn_in_flight`
tracking), the new stage-toast feature, AND re-enabling the hardcoded password prefill — then flashed
and tested together. When the test succeeded, the user immediately caught it: "테스트는 동일 조건에서
한가지만 바꿔서 한다라는 대전제를 또 어겼네" (you violated the basic premise that a test changes only
one thing under otherwise-identical conditions — again) and noted this is a repeat offense they
expected memory to already prevent. The success COULD have been from the real fix, or partly an
artifact of the other simultaneous changes — bundling made it impossible to attribute cleanly. Earlier
in the same session, the user had modeled the correct discipline explicitly: "테스트를 위해서 PWD를
아예 저장하지 않는 코드로 해보고 문제가 없으면 이 방법이 맞고 계속 문제가 있으면 다시 찾아보자" — one
isolated change, one clear verdict — and I followed it correctly that time.

**How to apply:** when a user gives multiple instructions in one message ("fix X, and also do Y, and
Z"), and X is a hypothesis-driven bug fix while Y/Z are unrelated (convenience, cosmetic, new
feature), do NOT flash them all together as a single test. Either (a) do X alone first, get a clean
verdict, then do Y/Z in a follow-up build, or (b) if bundling is truly necessary for time reasons,
say so explicitly and flag that the upcoming result won't cleanly isolate which change mattered —
let the user decide, don't silently bundle. This applies even under schedule/speed pressure
([[feedback_development_speed_too_slow]]) — bundled tests that produce ambiguous results cost more
time overall than sequencing cleanly the first time.
