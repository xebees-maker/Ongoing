---
name: reference-com5-flicker-behavior
description: "COM5 (CAM board USB serial) flickers present/absent every ~1s when disconnected — normal quirk, not a sign of real wireless/RF instability"
metadata: 
  node_type: memory
  type: reference
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-21T10:09:01.669Z
---

When CAM's USB serial connection (COM5) drops, it cycles dead/alive roughly every 1 second (confirmed
present via `Get-PnpDevice`, then absent, repeating) rather than just disappearing cleanly. This causes
`_dual_monitor.py`/pyserial capture scripts to intermittently throw `SerialException: ClearCommError
failed (PermissionError...)` mid-capture, losing the CAM-side thread while the CNTL-side thread
(usually more stable) keeps going.

**Why this matters:** User corrected 2026-08-21 — don't treat this flickering as evidence of real
ESP-NOW/RF connection instability. It's a USB-serial-level quirk of the board/OS re-enumeration, not
a wireless-channel or pairing problem. When diagnosing CAM<->Cntl pairing/connection issues, don't
conflate "COM5 capture kept crashing" with "the wireless link is flaky" — they are unrelated. Also:
user runs response_interval in "즉시"(Live, 0s) mode deliberately and it normally pairs fine, so a tight
response-interval retry budget is not, by itself, an adequate explanation for occasional
first-attempt-pairing-fails-retry-succeeds symptoms either (ruled out 2026-08-21 alongside a channel-
scan-timing theory that was also rejected as insufficient — neither fully explained a reported
regression from "used to work first try").

**How to apply:** If a capture script crashes on COM5 specifically, don't read that as a hardware
scare — just retry the capture. If pursuing the actual root cause of a pairing/connection flakiness
report, look elsewhere (not COM5 monitor stability, not response-interval tier) — as of this writing
the real cause of "first pairing attempt fails, second succeeds" is still unresolved.
