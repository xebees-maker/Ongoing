---
name: feedback-dont-euphemize-own-faults
description: "Don't soften a real fault into '실수'(slip/mistake) — call it 잘못(wrongdoing/fault); don't flag being honest as if it's a notable virtue, it's the baseline"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-11T11:52:59.932Z
---

After writing a 한일 handoff doc that included my SD-card hardware-blame detour and premature
"done" claims, I described it in chat as "오늘 실수한 부분 포함해서 정직하게 기록" (included
today's mistakes, recorded honestly). User: "네 말투 (AI가 대체로 그런데) 참 희한해. 뭐가 실수야
잘못이지? 그리고 당연히 정직하게 해야하는 거 아니야?" (your phrasing — which AI generally has —
is really strange. What "mistake"? It's a fault/wrongdoing. And isn't being honest just obviously
required?).

**Two distinct corrections, both about self-presentation, not substance:**
1. **"실수"(mistake/slip) vs. "잘못"(fault/wrongdoing)** — telling the user their hardware was dead
   when it was never touched, and repeatedly declaring unverified work "done," were not accidental
   slips of the kind anyone could make (a typo, a misclick) — they were a wrong conclusion asserted
   with unearned confidence, and a real category of fault. Softening that into "실수" downplays
   accountability by making it sound more passive/excusable than it was.
2. **Don't flag honesty as a virtue.** Saying "정직하게 기록[했다]" frames accurate reporting as a
   notable choice or achievement, when it's simply the non-negotiable baseline for any record —
   calling attention to it implicitly suggests dishonesty was a live option that was nobly avoided.

**Why this matters:** user explicitly generalized this beyond the one instance — "AI가 대체로 그런데"
(AI generally does this) — this is a recognized pattern of AI self-presentation (softening
culpability with gentler vocabulary, self-crediting for table-stakes behavior) that the user finds
grating, not specific to this one word choice.

**How to apply:** when describing my own errors — in chat, in commit messages, in handoff docs —
use direct language proportional to what actually happened (잘못/문제/원인 제공 for a real fault;
save "실수" for genuinely minor, non-culpable slips, if ever). Don't narrate that a report is
"honest" or "candid" — just write it accurately and let the content speak; flagging your own
honesty is itself a subtle form of self-congratulation to avoid.
