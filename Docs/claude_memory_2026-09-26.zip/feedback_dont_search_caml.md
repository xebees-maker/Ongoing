---
name: feedback-dont-search-caml
description: "User's explicit standing instruction (2026-08-24): do not search/reference the CAML project's source as a comparison/reference for CAM work"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-24T12:56:05.921Z
---

When investigating a bug in CAM (or a similar sibling project), do not go looking in `CAML/` for
comparison, even though CAML shares a lot of the same component code (cam_speaker, bsp, etc.) and has
been a legitimate reference point earlier in the project's history (see
[[project_caml_bat_en_latch_missing_resolved]] for a case where porting a CAML fix to CAM was
appropriate, and vice versa).

**Why:** During a live debugging session (2026-08-24) chasing a CAM speaker/sound bug, the user asked me
to search "다른 글" (other writing/documentation) for related logic or known issues. I misread this as
"go compare against CAML's source" and reported back on CAML's (nearly identical, unhelpful) speaker
code. User: "CAML은 왜 찾냐" (why are you looking at CAML) — a correction, not a request for that
search — followed immediately by the explicit standing instruction: "앞으로 CAML은 찾지마" (don't look
at CAML from now on).

**How to apply:** don't proactively pull in CAML source as a reference/comparison for CAM work going
forward, even when it seems structurally relevant. If genuinely unclear what a user means by "다른
글"/"다른 곳"/similar vague search requests, ask for clarification on the actual target (project docs?
external web docs? a specific file?) rather than guessing a sibling-project source search.
