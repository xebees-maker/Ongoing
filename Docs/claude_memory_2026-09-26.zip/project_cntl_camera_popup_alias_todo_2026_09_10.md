---
name: project-cntl-camera-popup-alias-todo-2026-09-10
description: "DONE+HW-verified 2026-09-10: camera list dropdown (ui_main.c rebuild_camera_dropdown_if_changed) now shows Alias instead of device name, same pattern as Sensor/Camera dashboard rows"
metadata:
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-10T10:35:32.339Z
---

User instruction (2026-09-10, given mid-graph-implementation, explicitly deferred): "끝나고 할 일로,
카메라 팝업에서 카메라 목록 선택을 alias로 바꿈 을 기록해 둬" — change the camera-list selection
inside the camera popup to display/use Alias instead of the raw device name.

**Why:** Consistent with the already-established name-vs-alias display rule from 2026-09-09
(see the device-name/Alias identity conflation fix in [[project_cntl_connection_mgmt_main_screen_2026_09_09]]):
code must always keep the true device name as the ID internally, but any UI list/label meant for a
human should show Alias when set, falling back to the real name only when Alias is empty. This
was applied to the Sensor/Camera dashboard rows already; this to-do extends the same principle to
wherever camera selection happens inside the camera popup (likely the camera picker/dropdown
mentioned in the single-screen redesign plan, not yet located/verified in code).

**Done 2026-09-10.** Located the widget: `s_camera_select_dd`, a dropdown on the 카메라 판넬(main
screen), populated by `rebuild_camera_dropdown_if_changed()` (`ui_main.c` ~line 2615), which was
building its options string straight from `nodes[i].name` (raw device name). Fixed by adding
`const char *alias = device_config_get_alias(macs[i]); const char *display_name = (alias[0] !=
'\0') ? alias : nodes[i].name;` — the same pattern already used for the Sensor/Camera dashboard
rows (`ui_main.c` ~3351/~3469). Also had to resize the `options[]` buffer from
`ESP_NOW_HUB_MAX_NODES * (ESP_NOW_LINK_NAME_LEN + 1)` to `... * (DEVICE_CONFIG_ALIAS_MAX_LEN + 1)`
since alias(32) can be longer than name(16) — the old size would've silently truncated/dropped
later entries once aliases were in use. Selection logic (`cb_camera_select_changed`) is unaffected
since it maps dropdown index -> mac via the separate `s_cam_dd_macs[]` array, not the display text.
Built clean, flashed, boot verified clean (no crash/MEMDIAG issue), and user confirmed on the
actual touchscreen ("나와" — it's showing).
