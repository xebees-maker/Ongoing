---
name: cntl-memory-floor-57k
description: "CNTL main-screen internal free-heap floor is 57K — user-stated budget constraint, check MEMDIAG logs against this during any refactor/feature work"
metadata:
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-17T15:14:11.340Z
---

User (2026-09-18, right before stepping away during a settings-popup model-lifecycle refactor):
"지금 메모리는 주화면 57K가 하한이야. 기억해두고 진행해." (Right now the memory floor for the main
screen is 57K — remember that and proceed.)

**Why:** this project has a documented history of internal-RAM regressions ([[project_cntl_stats_tab_memory_2026_09_06]],
the 2026-09-16 SR-task-stack-in-internal-RAM regression) — 57K is the line below which the main
screen's idle internal free heap must not fall.

**How to apply:** when making changes that could affect memory (new static buffers, task stacks,
struct size growth, especially anything touching per-instance arrays like the Sens per-MAC interval
slots), check the periodic `MEMDIAG periodic internal free=` log line (ui_main.c) after building and
flashing, on the main screen, and confirm it stays at or above 57K. Don't just assume a change is
memory-neutral — this project's established discipline is to measure via MEMDIAG, not guess (per
[[feedback_report_facts_not_conclusions]] and the "measure, don't guess" pattern already used to fix
prior regressions).
