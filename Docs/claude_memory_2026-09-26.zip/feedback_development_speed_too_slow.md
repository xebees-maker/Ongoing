---
name: feedback-development-speed-too-slow
description: "User's explicit assessment: Claude's development/debugging speed is very slow, and confident-but-wrong time estimates ('this is easy') cause real cascading cost"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-28T16:19:18.227Z
---

User stated directly: "네 개발 속도가 매우 느리다는 걸 인지했으면 좋겠어" (I want you to recognize your
development speed is very slow) — not a one-off complaint, an explicit standing assessment to
internalize.

**Concrete incident (2026-08-29, RS485 project, [[project_rs485_experimental_project]]):** Claude
told the user RS485 wiring/integration would be "아주 쉽다" (very easy). User planned to finish it
by morning and do other planned development the rest of the day. Instead the RS485 debugging
consumed 10+ hours and the other planned work never happened. User's stated rate is ₩1,000,000/day;
a commercial off-the-shelf wireless repeater that would have solved the underlying problem
(steel-obstruction WiFi link) costs at most ₩100,000 — the gap between that and 10+ hours of
debugging time is the real, demonstrated cost of the bad estimate, independent of whether the
underlying technical choice (RS485) was defensible in isolation.

**Why:** low-confidence/optimistic time estimates aren't a harmless communication style choice —
the user allocates their actual day around them. An estimate that's wrong by an order of magnitude
doesn't just cost the time spent on the task itself, it displaces everything else planned for that
day.

**Per-turn latency, not just overall duration:** user also flagged that even a single line from them
is met with a slow response ("뭐 한줄 치면... 답변 할 때까지 1분은 기본이야") — this is a separate
complaint from the estimate-accuracy one above. Actionable part: don't run extra tool calls
(re-reading files already in context, redundant greps/searches) before answering something that
doesn't need them — every extra call adds real wall-clock time the user is sitting through.

**User's full framing (2026-08-29):** base service latency is a limitation the user already
tolerates. On top of that, Claude's own behavior (going off on tangents/"딴짓", triggering avoidable
permission prompts, unnecessary tool calls) adds separate, compounding friction — the combined
effect turns a few-hours task into a full day. Don't conflate "service is inherently slow" with
"Claude added avoidable friction" — the second part is squarely fixable and is the actual ask here.

**How to apply:**
- Never say a task/integration "is easy" or give a confident time estimate unless there's real
  evidence backing it (prior working reference implementation, already-verified similar pattern).
  When genuinely uncertain (e.g., a HW protocol/peripheral never exercised before in this project),
  say so plainly instead of defaulting to reassuring language.
- When defending a technical/architectural choice under cost scrutiny, don't separate "the choice
  was right" from "the cost of realizing it was reasonable" — both matter, and conflating them (or
  defending only the former) reads as dodging the real complaint. See the 2026-08-29 RS485
  cost-argument exchange for the exact pattern to avoid: "오늘 겪은 문제는 그 선택 자체가 아니라
  구현 단계의 버그입니다" was called out and retracted for exactly this reason.
- Related: [[user_experience_level]] (40-year developer — their own technical judgment on
  feasibility/difficulty should be weighted at least as heavily as Claude's own optimism).
