---
name: feedback-dont-use-user-as-test-oracle
description: "CHRONIC, 4+ occurrences over 3 months as of 2026-09-11 — user's firm rule: diagnose with available tools (serial, logs, code reading) before asking the user to test on real hardware; when a live test IS genuinely needed, propose the exact method and get explicit approval BEFORE asking them to act, not after"
metadata:
  type: feedback
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-09-11T12:47:45.958Z
---

Don't fall into a "change code → ask user to test on real hardware → get new failure → guess again" loop.
Each round costs the user a real build+flash+re-pair+manual-test cycle on physical devices. If a diagnostic
tool exists that doesn't require the user (serial console, dev-console commands already built into the
firmware, static code tracing of the full path end-to-end), use it BEFORE proposing a code change, and
verify the fix's premise before asking for another hardware round.

**Why:** stated directly during the [[project_cntl_cam_todo_2026_08_02]] ESP-NOW chunk-transfer debugging
session (2026-08-02→03) after several consecutive "fix" attempts each shifted the failure to a new error
code (3002 → 3006 → 3007) without resolving the underlying packet-loss problem: "좀 알고 고치면 좋겠어.
내가 네 테스트 머신도 아니고." (I wish you'd actually understand the problem before fixing it — I'm not
your test machine.) The pattern that caused this: proposing plausible-sounding hypotheses (channel drift,
power-save, buffer sizing, request-generation races) and shipping a fix for each without first gathering
hard evidence that the hypothesis was correct, then relying on the user's live hardware test as the
verification step — which is expensive and repeatedly wrong.

**Repeat, 2026-09-05 (CNTL/CAM WAKE_HELLO/photo-fetch race debugging session): asking the user
subjective recall questions ("did you actually click photo 4?", "did you refresh the list in between?")
is the SAME violation even when it isn't a request to reflash+retest.** User: "이따위 질문 절대 하지
말라고 했는데 왜 자꾸 해?" (I told you to never ask this kind of question — why do you keep doing it?),
then when nudged to check memory: "하드웨어문제, 전자파 문제, 내 실수 탓하지 말고 네 소스의 문제를
보란 얘기 없어?" (isn't there something telling you to look at YOUR OWN source's bug instead of blaming
hardware/RF/my mistake?) — pointing at [[feedback_audit_own_change_first]]. The fix that actually worked:
opened a live serial capture (pyserial, DTR/RTS false per [[reference_pyserial_dtr_reset_bug]]) on CNTL's
console and asked the user to reproduce ONCE while it ran, then read the real ESP_LOGI trace — this
surfaced the actual mechanism (a WAKE_HELLO/NO_MEM/desync storm) in one shot, no guessing. Even this drew
pushback ("내가 네 테스터잖아" — I'm your tester [again]) because it still put the reproduction burden on
the user; the better sequence is to reason from code + any logs already available FIRST, and only reach
for a live capture as a last resort when static analysis has a genuine, named gap (not "let me watch you
click things"). **How to apply:** when a repro's exact mechanism is unclear, do NOT ask the user to recall
details or to redo the action for you to watch — either trace it fully in the source first, or (only if
that's insufficient) start your own log/serial capture and let them act once, unprompted for a second
round.

**How to apply:** for embedded/hardware bugs in this codebase, prefer (in order): (1) full careful reading
of the actual code path end-to-end for the specific failure, (2) self-directed serial/log inspection
(CAM/Sens dev consoles, boot logs) when it doesn't require the user's touchscreen interaction, (3) targeted
instrumentation added and checked via serial before proposing a fix, (4) only then a code change — and when
asking the user to reflash+test, be reasonably confident, not hopeful.

**Fourth occurrence, 2026-09-11 (CNTL stats-graph swipe-gesture debugging) — user explicitly named this
a CHRONIC pattern spanning the entire working relationship, not a one-session lapse: "내가 너랑 작업
시작한 3개월 전부터 지금까지 계속 되니까 짜증 나잖아" (this has kept happening continuously from 3
months ago when we started working together, until now — that's why it's annoying).** Sequence that
triggered it: a graph swipe gesture wasn't registering; instead of first exhaustively tracing the LVGL
touch/gesture pipeline in source, I added diagnostic logging and asked for a live test — twice — each
round requiring a rebuild+reflash+live capture+the user physically swiping the touchscreen while I
watched for a log line, and both rounds came back inconclusive/misleading (grep-filtered capture showed
nothing due to an unrelated filtering issue, not because the touch wasn't landing). The user then pointed
out the exact logical flaw I'd missed by testing before fully reasoning: "탭이 된다는 거야. 그런데
스와이프는 안와... 씹히는 걸 네가 로그 받으면 뭐가 달라져? 받을 수가 없는데?" (tap already works, but
swipe doesn't come through — if it's being swallowed before reaching your instrumented code, no amount
of logging on that object would ever show anything) — a live test/log CANNOT diagnose a problem that
occurs *before* the instrumented point, so the request for it was not just premature but structurally
incapable of answering the question. Separately, but from the same session: **"네 테스트 방법이 옳은
지에 대한 승인도 없이 내가 몇 번씩이나 네 장단에 춤추랴?"** (without even getting approval on whether
your test method is sound, how many times am I supposed to dance to your tune?) — a new, sharper
requirement beyond the existing memory: when a live test genuinely is the right next step, **state the
exact proposed method and get explicit approval BEFORE asking the user to act**, not "let me try this,
please do X" in the same breath. And, stated as a strict ordering rule for research generally: **"코드
보고 아티클 찾고 이게 순서야"** (read the code first, THEN look for [external] articles — that's the
order) — don't reach for WebSearch/external research before code-level analysis has been exhausted,
mirroring the same "don't skip to the expensive/external step" principle this whole memory is about,
just applied to research sources rather than hardware tests specifically.

**Concrete new rule from this occurrence:** before proposing ANY live hardware test (serial capture +
user physical interaction), explicitly ask "이 방법으로 테스트해도 될까요?" (or equivalent — state the
exact method: what you'll capture, what you'll ask them to do, what result would confirm/refute the
hypothesis) and wait for a yes, every time — do not bundle "let me set up a capture" and "please tap now"
into one unprompted action the way [[feedback_confirm_before_editing]] already requires for code edits.
A test round that comes back inconclusive costs exactly as much of the user's patience as a wrong code
guess did in the earlier occurrences — the "ask before acting" discipline applies to test method choice
just as much as to code changes.

**New facet, 2026-08-28 ([[project_rs485_experimental_project]] session): don't demand a redundant
re-test to independently "confirm with data" something the user already directly reported as observed
fact.** During the CNTL-RX asymmetry debugging, the user stated plainly "중 입력은 콘에 반영 돼"
(Arbiter's input shows up correctly on CNTL) — a first-hand report of what they'd just seen on real
hardware. Instead of accepting this, I set up a fresh serial capture and asked them to press the
button again so I could independently log/verify it. User: "중 콘은 잘된다니까 얘기 했잖아. 왜 시간이
썩어나냐?" (I already told you it works — why is time being wasted?). **This is a distinct trap from
the memory's main pattern** (which is about not iterating blind code-guesses through the user as a
test rig) — here the user wasn't being asked to test a *new* hypothesis, they'd already reported a
*result*, and I re-demanded proof of it anyway. **How to apply:** when the user states a direct,
first-hand observation as a plain fact ("X works", "Y shows up", "the screen does Z") — not phrased as
a question or uncertainty — accept it as ground truth. Only ask for a fresh capture/re-test when (a)
you need additional detail they wouldn't otherwise report (e.g., exact hex content, timing), and even
then frame it as "can you tell me more" rather than "please redo this so I can verify you were right",
or (b) something they just told you is inconsistent with data you already have and the contradiction
itself needs resolving — never as a default reflex to re-confirm a plain statement of fact.
