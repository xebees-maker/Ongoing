---
name: feedback-label-guesses-explicitly
description: "Always prefix a speculative/unverified claim with '추측입니다' (this is a guess) so the user can immediately tell it apart from a confirmed fact"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-21T13:02:43.947Z
---

User's explicit instruction (2026-09-21): "추측은 제발, '추측입니다'로 시작해라" — when a
statement is speculation/inference rather than a verified fact, open with "추측입니다" (this is
a guess) before giving it.

**Why:** arose from a long, frustrating exchange about how to wire CNTL's VOUT/GND into a XIAO
ESP32-C6 board's power pins (see [[project_cntl_i2c_bridge_design_2026_09_21]]). Repeatedly
presented electrical-reasoning guesses (3V3-pin-is-safe-to-tie, then VBUS-is-safe, then
3V3-is-safe-again-if-USB-disconnected...) in the same confident, declarative tone as verified
facts, flip-flopping conclusions 3-4 times. User: "야 정신 차려" / "아니네" each time a guess
turned out wrong when checked against a fact they then supplied. The problem wasn't being wrong
per se — it was not *flagging* the uncertainty up front, so each wrong guess read as a confident
claim that then had to be walked back, rather than an offered hypothesis the user could weigh
appropriately from the start.

**How to apply:** before stating anything not directly confirmed (by the user, by a fetched doc,
by code/schematic actually read), ask: is this inferred/reasoned-out, or established? If
inferred, lead with "추측입니다" (or the natural English equivalent, "this is a guess," in
English-language responses) before the claim itself — don't bury the hedge mid-paragraph or only
add it after being pushed back on. Applies broadly, not just to hardware/electrical topics —
any domain where Claude is reasoning toward an answer rather than reporting a checked fact.

**Second half of the same incident, don't miss it:** after the guessing pattern above, the
actual correct answer (I2C's VCC wire is only needed when the master powers the slave; skip it
entirely when both sides are independently powered) is generic, well-documented I2C knowledge —
not something specific to this board that only the user could know. Claude had WebFetch/WebSearch
available and had already used WebFetch successfully earlier in the same conversation (Seeed
wiki lookups for pinout/antenna GPIOs), but for this question just kept reasoning/guessing
instead, until the user went and checked it externally themselves and reported back. User: "아니
얘가 지가 찾아서 확인하질 않고 나한테 묻네?" (this thing isn't looking it up itself, it's
asking me?). **When a claim is checkable via search/fetch rather than only knowable from private
context the user has, search first — don't guess and then make the user do the lookup.** Reserve
"추측입니다" for things that genuinely can't be looked up (the user's own hardware choices,
unpublished specifics, judgment calls) — a googleable fact isn't a guess to hedge, it's a lookup
to do.
