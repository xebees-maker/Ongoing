---
name: project-cntl-cam-photo-fetch-nack-round-bug
description: "Off-by-one between CAM's and Cntl's independent NACK-round counters caused misleading 3006 errors on photo fetch; root-caused via live serial capture 2026-08-21"
metadata: 
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-22T01:46:54.151Z
---

Found and fixed via live dual-board serial capture (`CAM/tools/_dual_monitor.py`) while user was
testing XCLK=10MHz: photo fetch of an already-captured file (not a new capture) was failing ~75% of
the time with error 3006 (fetch stalled/no-response), always right at the popup's timeout deadline.

**Root cause:** `MAX_NACK_ROUNDS` (CAM, `esp_now_cam.c:102`) and `PHOTO_NACK_MAX_ROUNDS` (Cntl,
`esp_now_photo.c:50`) were both hardcoded to 3, but CAM's send loop (`for round=0; round<3; round++`)
sends exactly 3 "still missing chunks" DONE messages total then silently gives up, while Cntl's
`handle_done()` checked its round counter *before* incrementing — so on the 3rd DONE it still thought
it had rounds left and kept waiting for a 4th DONE that would never arrive. Cntl only discovered the
failure via its unrelated stall-timeout path (`fetch_popup_tick_fn`'s progress-not-advancing check),
producing the wrong/confusing error code (3006 instead of the correct 3002 chunk-missing).

**Fix applied 2026-08-21:** moved the increment before the comparison in
`esp_now_photo.c:handle_done()` so Cntl's 3rd received DONE (matching CAM's last round) immediately
falls through to the real ERROR path instead of waiting for a phantom round 4. Built and ready to
flash (not yet confirmed on hardware as of this writing).

**Follow-up in progress:** generalizing this into an actual CNTL-owned-and-pushed value (via
`device_config` + `CAM_CONFIG_SET`, same mechanism as `capture_interval`/`agc_enable`/`xclk_mhz`) so
the two sides can never independently hardcode a mismatched round count again — see
[[feedback_cntl_owns_mutually_judged_values]] for the precise scope rule the user established for
which constants qualify for this treatment.

**Correction (same session, later):** the "high first-pass loss rate" read above was a misdiagnosis —
`resend_chunks()` is genuinely reused for both a window's first send AND real retries, and logs the
identical message either way, so most "NACK 재전송 완료" lines were actually just next-window first
sends, not retries. Re-reading the capture showed nearly all windows report "누락 0개" — the wireless
link itself performs well; there is no general high-loss problem.

**Real second bug found and fixed 2026-08-21 (same session):** `PHOTO_META` was the one message type
never migrated to the reliable stack — CAM fired it 3x fire-and-forget with no ACK and started
sending chunks immediately after, without confirming Cntl received it. `handle_meta()`
(esp_now_photo.c) unconditionally resets `chunk_bitmap`/`s_chunks_received`/`s_nack_rounds_used` on
every META arrival with no duplicate/in-progress guard. If one of the 3 redundant META copies arrived
late — after chunk transfer had already begun and some chunks were already correctly received — it
silently wiped the receive bitmap, "losing" already-received chunks from Cntl's bookkeeping (the
bytes were still in the buffer, only the tracking was reset). Since the wipe could land in an
already-passed SR window, the loss wasn't caught by that window's own status check and only surfaced
at the final whole-file DONE safety net — matching the observed symptom exactly.

**Fix:** converted PHOTO_META to the reliable stack (new `ESP_NOW_MSG_PHOTO_META_ACK=45`, CAM now
calls `esp_now_reliable_request()` and does not start chunk sending until acked — `send_one_photo_sr`
in esp_now_cam.c). User explicitly rejected adding a belt-and-suspenders duplicate-guard in
`handle_meta()` as unnecessary: "SR 자체가 가드니까" — since CAM structurally cannot send a duplicate
META after chunk transfer has started (chunks only begin after the reliable request returns), the
race is eliminated by construction and no separate idempotency check is needed. See
[[feedback_default_to_reliable_messaging]] for the general principle this bug prompted.

**Resolved and committed 2026-08-22** (commit 3169d1b). The CNTL-owned-and-pushed follow-up mentioned
above was also completed in the same batch: `esp_now_cam_config_t.nack_max_rounds` field +
`s_nack_max_rounds` (CAM, replaces the old hardcoded `MAX_NACK_ROUNDS` define) applied via
`CAM_CONFIG_SET` when nonzero — CAM and Cntl can no longer independently drift on this count. General
system testing this session (pairing, 5005, stats-tab) passed, but this specific fetch fix was not
singled out for a dedicated re-test — worth confirming 3002/3006 stay gone on the next real fetch.
