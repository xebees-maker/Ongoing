---
name: askuserquestion-bad-for-design-discussion
description: "Don't use the AskUserQuestion tool for open-ended design-conversation clarifying questions with this user — plain conversational text works, the structured tool doesn't"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-15T10:59:05.272Z
---

During the 2026-09-15 SR(Power control)-design conversation, three genuine clarifying questions (SR channel count/mapping, threshold direction, source value) were sent via the AskUserQuestion tool (multi-select cards, English text per [[feedback_askuserquestion_korean_garbled]]). The user rejected the tool call outright and said "무슨 질문인지 이해 못했어" (didn't understand what the questions were about). Re-asking the exact same three questions as plain Korean text in the chat worked fine — the user answered all three in detail across several follow-up turns, including back-and-forth refinement (e.g. "2번은 사용자가 지정하지, 왜냐하면...") that the structured tool's fixed-option format couldn't have captured anyway.

**Why:** this user's design conversations are exploratory and iterative — an answer to one question often reshapes a later one (e.g. the source-value answer literally added a whole new axis: "avg가 아닌 단일 측정값으로도 할 수 있어"). AskUserQuestion's fixed 2-4 option cards can't hold that kind of answer, and apparently the card UI itself didn't read clearly to this user even when the underlying question was reasonable. The earlier [[feedback_askuserquestion_korean_garbled]] fix (write in English) addressed a text-rendering problem, not this — this is a format/fit problem, a different failure mode.

**How to apply:** for this project, default to plain conversational Korean text for clarifying questions during design discussions ("대화하자" mode), even when there are genuinely 2-3 discrete options to choose from. Reserve AskUserQuestion (if used at all here) for a single, simple, self-contained binary/ternary choice with no follow-up nuance expected — and even then, given this concrete rejection, lean toward plain text by default unless the user asks for the structured picker.
