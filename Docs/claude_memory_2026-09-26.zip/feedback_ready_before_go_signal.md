---
name: feedback-ready-before-go-signal
description: "Live hardware test synchronization: capture must be fully running BEFORE telling the user to act, and always give an explicit 'do it now' signal — never ambiguous timing, called out 2026-08-28"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-28T02:37:47.015Z
---

During RS485 Arbiter touch debugging, I asked the user to tap the touchscreen while I ran a 30s
live serial capture, then reported "no change even with tapping" as if that ruled something out.
User: "내가 지금 한번도 화면 터치 안했어" — they never actually touched it, because my instructions
around live tests have been inconsistent: sometimes I tell the user to act and then I'm not actually
ready yet (the capture/tool call takes a while to actually start listening), and other times I report
a test as finished without ever having given a clear "do X now" signal during the window — so the
user can't tell when they're supposed to act.

**Why:** without a crisp, reliable signal boundary, the user has no way to know whether their action
will actually be observed. A "please tap during this" instruction is worthless if the capture wasn't
actually running yet when they read it, or if there was never a clear moment marking "now."

**How to apply:** for every live/synchronized hardware test going forward:
1. Fully set up and start the capture/listener FIRST (e.g., start it as a background tool call, or
   otherwise get it verifiably running) — before writing anything asking the user to act.
2. Only once capture is confirmed active, send an explicit, standalone "지금부터 OO 해주세요" (do X
   now) instruction — this must be unambiguous and always present, never skipped or implied.
3. Never report a test as "finished" or draw a conclusion from a window during which the user was
   never clearly told to act — if in doubt whether they actually acted, ask, don't assume.
4. Apply this consistently every single time, not just when convenient — the user explicitly asked
   for consistency ("일관성있게"), meaning a one-off fix isn't enough; every future live test in this
   project (and generally, live hardware tests elsewhere) should follow this same ready-then-go
   sequence.
