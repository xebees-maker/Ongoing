---
name: feedback-diff-config-not-just-source
description: "When comparing against a reference implementation (vendor demo, working-vs-broken state) always diff sdkconfig/sdkconfig.defaults/environment alongside source code — repeated mistake, most recently the RS485 CNTL-RX bug 2026-08-28"
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-28T10:12:02.857Z
---

When diagnosing "why does the reference/vendor example work but mine doesn't" (or "why did this used to
work"), I default to diffing only the `.c`/`.h` source files and conclude "no difference" too early —
missing that build configuration (`sdkconfig`, `sdkconfig.defaults`, Kconfig-selected options) is just as
load-bearing as source code and needs to be diffed too.

**Why:** in the [[project_rs485_experimental_project]] CNTL-RX-never-works investigation (2026-08-28), I
fetched Waveshare's official `RS485_Test` example source (`uart_echo_example_main.c`) and told the user
"벤더 코드엔 특별한 게 없다" (the vendor code has nothing special) — true for the `.c` file, but I hadn't
looked at the example's `sdkconfig.defaults`. The user caught the resulting contradiction ("그렇군, 그럼
왜 대화도 안 통하지?" — paraphrased: if the vendor code is really identical, why does the vendor's demo
work and mine doesn't?), which forced a second look — the vendor's `sdkconfig.defaults` had
`CONFIG_ESP_CONSOLE_USB_SERIAL_JTAG=y` (console primary channel = USB-Serial-JTAG only), while my project's
default was `CONFIG_ESP_CONSOLE_UART_DEFAULT=y` (primary = UART0) + secondary USB-JTAG — a real,
consequential difference invisible from the `.c` diff alone. Matching this exact Kconfig setting was the
change that finally made RS485 RX work, after roughly a full day of testing pin mapping, pull-ups, task
priorities, baud rate, line inversion, and IDF-internal driver diffs that all came back negative. The user
named the pattern explicitly: this happened once before too, early in this same board's bring-up, for the
same reason (diffed source only, not environment/config).

**How to apply:** whenever comparing against ANY reference (a vendor example, an official demo, a prior
working commit, another developer's setup) to explain a behavioral difference, diff BOTH source AND
config/environment as a matched pair from the start — never declare "no difference found" from a source-only
diff. For ESP-IDF projects specifically, that means `sdkconfig` and `sdkconfig.defaults` (Kconfig-selected
options), not just `main/*.c`. This generalizes beyond ESP-IDF: build flags, environment variables, package
versions, and other declarative config are exactly as capable of being "the actual difference" as code is,
and are easy to skip because they don't show up in a `diff *.c` mental model.
