---
name: feedback-design-for-exceptions-not-just-fails
description: "Three-way failure taxonomy (fail/hang/die) for I/O and risky calls — each needs a DIFFERENT defense; conflating them (esp. treating accumulated fails as a hang) leads to overbuilt, wrong fixes. Corrected 2026-09-10 after the fix built from the first version of this memory turned out to be itself wrong."
metadata:
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-10T13:44:18.740Z
---

**IMPORTANT — this memory was itself wrong once and got corrected the same day; read the whole
thing, not just the first principle.** The original version below ("always isolate, danger is
always lurking") was stated after a CNTL SD-card crash, and I used it to justify building a whole
task-isolation architecture (separate worker task, two mutexes, priority tuning) for the stats-tab
SD reads. That fix caused several NEW bugs (teardown blocking the UI, wrong task priority starving
LVGL/input entirely) before the user walked me through a proper Socratic diagnosis and it turned out
**the isolation was solving a problem that didn't exist** — the real SD error was a clean, bounded
"fail" (return-value error), not a hang, and task isolation is specifically the wrong tool for a
fail. "잘못된 해결책을 더 잘못된 해결책으로 덮는다" — the user's own description of the resulting
mess. See [[project_cntl_sd_reliability_redesign_2026_09_10]] for the full corrected design that
replaced it (removes the isolation, adds a fail circuit-breaker instead).

**The corrected three-way taxonomy — use this, not "just isolate everything":**

1. **Fail** — the call returns (promptly or within a bounded time) with an error code/NULL/etc.
   This is the NORMAL, expected case for I/O. **Defense: check the return value and handle it** —
   nothing fancier needed. A SEQUENCE of fail-prone calls (e.g. scanning 4 channels + a table + 4
   more channels, each independently fail-prone) needs a **circuit-breaker**: on the FIRST fail,
   abort the rest of the sequence for that cycle rather than blindly continuing to try the rest —
   "제일 바보같은 코딩은 fail인 결과를 무시하다가 프로그램을 먹통만들거나 죽이는 거" (accumulating
   many individually-bounded fails by not stopping on the first one is what actually produces a
   hang-*looking* symptom, e.g. a watchdog trigger from a task busy running through 10+ sequential
   ~200-1000ms fails — that is still fundamentally a fail-handling bug, not a hang, and the fix is
   "stop on first fail," not "move the whole sequence to another task").
2. **Hang** — the call never returns, full stop (true unbounded block). Return-value checks and
   try/catch are both useless here (nothing is ever returned or thrown). **Defense: task-level
   isolation, set up BEFORE the call** — run it on its own task/thread that nothing else
   synchronously waits on, so its blast radius can't reach anything else. Once already inside a
   hang there is nothing to do from the outside; the defense has to already be in place. This is
   the ONLY case among the three where isolation is the right tool.
3. **Die (crash)** — an immediate, instantaneous fault (hard fault, stack overflow, etc.), not a
   duration problem at all. **Timers and task isolation are both conceptually meaningless against
   this** — you cannot "wait out" or "bound the time of" something that either happens or doesn't in
   a single instant ("죽는 건 타이머로 기다릴 대상이 아닙니다" — a timer/isolation-based defense
   against a crash is nonsensical, not just insufficient). On a platform with no per-task memory
   protection (FreeRTOS/ESP-IDF on ESP32 has none) a hard fault in ANY task typically panics/reboots
   the WHOLE chip regardless of task separation — so isolation gives literally zero protection here
   either. The only real defenses are (a) preventing the fault from being reachable in the first
   place (root-cause fix), or (b) accepting the reboot as the recovery and designing state to
   tolerate it (e.g. idempotent re-init on boot). A sub-case, **exception** (a language-level
   catchable throw), CAN be guarded with try/catch where the language provides it — but plain C (this
   codebase) has no such mechanism, so in practice "die" here always means "crash," not "exception."

**How to apply:** before reaching for isolation (or a timer/timeout, or any other defensive
mechanism) around a risky call, first classify which of the three it actually is: **does it always
return an error I can check (fail), can it genuinely never return (hang), or can it end the task
instantly with no return at all (die)?** Only build the isolation/timeout machinery for genuine hang
cases. For fail cases — which is most I/O error paths, including the vast majority of what looks
scary at first glance — the fix is almost always just "check the return value, and if there's a
sequence of such calls, stop the sequence on the first failure instead of accumulating." Building
isolation for a fail-class problem doesn't just waste effort, it actively adds new bugs (as it did
here) without solving anything the simpler fix wouldn't have.

**Also confirmed as a related principle the same session:** try/catch-style broad protective
wrapping is more of a development-time safety net, used when the failure modes aren't yet fully
understood; as code matures (especially on a main/production path), the right direction is to
convert known failure modes into explicit, specific return-value branches instead of leaning on a
broad catch-all — mirrors the fail/hang/die classification above (once you know it's "fail," write
the explicit check; don't leave it wrapped in generic protection "just in case").
