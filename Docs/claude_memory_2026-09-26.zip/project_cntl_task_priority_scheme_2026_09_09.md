---
name: project-cntl-task-priority-scheme-2026-09-09
description: "CNTL app-level FreeRTOS task priority convention defined 2026-09-09 — not yet applied to code, apply when implementing/touching relevant tasks"
metadata:
  node_type: memory
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-09T14:32:08.197Z
---

User defined a priority tier scheme for CNTL's own app-level FreeRTOS tasks (2026-09-09), during the
[[project_cntl_tx_queue_full_2026_09_09]] investigation. Not applied to any code yet — this is a
definition to reference and apply later when implementing or touching the relevant task.

**Scheme (higher number = higher priority, FreeRTOS/ESP-IDF convention, configMAX_PRIORITIES=25 on this
project, so range is 0-24):**
- 통신 (communication) = 17
- SR제어 (SR/relay control) = 15
- 파일처리 (file/storage I/O — LittleFS settings writes, NVS) = 10
- 뷰/사용자입력 (view + user input, currently bundled together in LVGL) = 6 (current default, unchanged)

Deliberate gaps left between tiers ("또 다른 태스크 종류가 나올 수 있어서 사이를 벌려놓음") so a future
task category can be inserted between tiers without renumbering everything.

**Why:** User's own design principle, stated during the investigation: app task priority should reflect
consequence-of-delay — communication (dropped/lost messages = real functional failure) > SR/relay
control (presumably real-time/safety-adjacent physical actuation) > file I/O (data-loss risk if
interrupted, less time-critical) > view/input (cosmetic lag only, least consequential). This directly
motivated by discovering LVGL (priority 6) sits ABOVE tx_task (priority 5) — backwards from this
principle — as the likely explanation for intermittent TX_QUEUE_FULL errors with zero photo-transfer
activity (see [[project_cntl_tx_queue_full_2026_09_09]]).

**Current real task landscape verified this session** (Cntl, ESP-IDF v6.0.2, ESP32-S3):
- tx_task (esp_now_tx.c, app) = 5 — the only CNTL app code that calls esp_now_reliable_request()
- LVGL (esp_lv_adapter managed component, app) = 6 (ESP_LV_ADAPTER_DEFAULT_TASK_PRIORITY), no core
  affinity (tskNO_AFFINITY) — all periodic UI refresh (clock/dashboard/lists/error-poll/stats/log/power)
  runs via `lv_timer_create`, i.e. inside LVGL's own task loop, so it stalls whenever LVGL does
- lwIP TCP/IP (IDF system) = 18 (CONFIG_LWIP_TCPIP_TASK_PRIO)
- esp_event / WiFi event dispatch (IDF system) = ESP_TASK_PRIO_MAX-5 = 20
- esp_timer daemon (IDF system, real esp_timer_create callbacks — NOT lv_timer) = ESP_TASK_PRIO_MAX-3 = 22
- WiFi driver's own task: pinned to Core 0 (CONFIG_ESP_WIFI_TASK_PINNED_TO_CORE_0=y), exact priority
  number not found in accessible source (precompiled lib) but known to run very high
- app_main task = ESP_TASK_PRIO_MIN+1 = 1 (mostly idle after boot)
- No dedicated task exists yet for SR/relay control or file processing — both are still TODO/unimplemented
  ([[project_cntl_physical_relay_output]], [[project_cntl_cam_steel_obstruction_relay]]); LittleFS
  settings writes currently execute synchronously inside whatever task calls them (today: LVGL button
  handlers, i.e. effectively priority 6)

**How to apply:** When tx_task's priority is actually changed (the live fix once agreed), bump it from 5
into the 통신 tier (17) rather than just nudging it above 6 — leaves headroom below the reserved system
tiers (18/20/22) while clearly signaling its category. When an SR/relay-control task or a dedicated file-
processing task is eventually implemented, assign 15 / 10 respectively rather than picking an arbitrary
number.
