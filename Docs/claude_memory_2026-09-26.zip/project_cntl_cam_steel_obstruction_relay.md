---
name: project-cntl-cam-steel-obstruction-relay
description: "2026-08-27: CNTL<->CAM link passes through an enclosed steel structure (with holes); CNTL's WROOM-1 module has no external antenna option, so the planned fix is two ESP32 relay boards (one per side) linked by wired UART through an existing hole, not an antenna mod"
metadata:
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-28T07:22:43.045Z
---

CNTL (Waveshare ESP32-S3-Touch-LCD-4.3B — see [[project_cntl_4_3b_bsp]]) and CAM sit on opposite
sides of an enclosed steel structure, degrading the ESP-NOW link. User confirmed by reading the
module's own printed marking: it's a plain **ESP32-S3-WROOM-1** (no "U" suffix) — PCB trace antenna
only, no u.FL/IPEX pad, so an external antenna cannot simply be added; doing so would require
desoldering/replacing the entire RF-shielded module for a U-variant, a nontrivial rework.

**Decided approach**: two relay ESP32 boards, one on each side of the steel structure, each talking
ESP-NOW normally (unobstructed) to its own local side (CNTL or CAM), linked to each other over a
**wired UART** (TX/RX/GND) run through an existing hole in the structure — not RF, so the steel
enclosure doesn't matter for that hop. Reasoned through with the user step by step:

- A **single** relay node only works if some one vantage point has line-of-sight-ish access to both
  CNTL and CAM (edge/gap/elevated spot) — ruled out here since the structure is fully enclosed
  (holes exist but aren't necessarily large enough to trust for RF, and relying on RF leakage through
  a small hole is guesswork). Two relays + a wired hop through the hole is deterministic instead.
- **Why UART, not USB**, for the inter-relay wired hop: USB needs host/device role negotiation (one
  ESP32-S3 would need a USB Host stack, real extra complexity), whereas UART is symmetric and only
  needs 2-3 wires. ESP-NOW packets are small (≤250 bytes) so UART bandwidth is a non-issue.
- **UART doesn't need a labeled "UART connector"** — the ESP32-S3 GPIO matrix can map the UART
  peripheral to any exposed GPIO pin/pad, so as long as the relay board has *any* accessible pins
  (header or bare test pads), that's enough; a dedicated UART connector isn't required.

**How to apply**: when this gets implemented, the relay boards need an ESP-NOW forwarding role (just
relaying whatever unicast/broadcast traffic arrives) — this is new firmware, not yet started as of
2026-08-27. Don't re-propose an antenna-based fix for CNTL — the module type is confirmed, not a
guess. Confirm which side's hole size/routing is practical before buying hardware.

**To-do flagged 2026-08-28 (from [[project_rs485_experimental_project]]): check for the UART0-
console-leak bug before/while wiring CNTL's real UART bridge to this relay.** In the separate RS485
experiment, both test boards (running on the same board types as real CNTL) showed their own default
console log output leaking as phantom bytes into a *different* UART port used for RS485 — confirmed
directly (RX hex dump literally read back as the console's own log text). Fixed there via
`esp_log_set_vprintf()` routing console output only through USB-Serial-JTAG, UART0 physical output
disabled. **When implementing this relay's UART link on real CNTL** (`esp_now_transport` UART
backend per the CNTL↔Relay bridge plan), verify from the start whether CNTL's own console output is
leaking into that bridge UART the same way — don't assume it's fine just because it wasn't flagged
before; the RS485 project only caught it because a byte-level RX dump was added specifically to look
for it. If present, port the same USB-Serial-JTAG-only vprintf fix over.
