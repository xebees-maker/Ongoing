---
name: reference-espidf-uart-read-bytes-blocking
description: "ESP-IDF uart_read_bytes(buf, length, ticks_to_wait) doesn't return on first byte — it blocks trying to fill length bytes total, re-arming ticks_to_wait each time new data arrives, so a large length + steady incoming stream can silently withhold data for a long time"
metadata:
  type: reference
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-28T14:15:07.952Z
---

Confirmed by reading `components/esp_driver_uart/src/uart.c` (IDF v6.0.2, `uart_read_bytes()`,
~line 1720): the function runs `while (length) { data = xRingbufferReceiveUpTo(ring_buf, &size,
ticks_to_wait, length); ... }` — it keeps looping, re-blocking for up to `ticks_to_wait` on **each**
iteration, until either `length` bytes total have been collected, or one iteration times out with
no new data at all.

**Practical trap:** if you call `uart_read_bytes(port, buf, sizeof(buf), pdMS_TO_TICKS(1000))` with
a large `buf` (e.g. 64 bytes) while data is trickling in steadily with gaps shorter than
`ticks_to_wait` (e.g. one byte every 500ms), the call will **not** return after the first byte — it
keeps re-arming the timeout and accumulating, only returning once `buf` fills completely or a gap
longer than `ticks_to_wait` finally occurs. Symptom: a receive task that's supposed to react
per-byte instead appears to "stall" for a long time and then dump a burst of values all at once —
easy to misdiagnose as a wire/RF/framing problem when it's purely this API's blocking semantics.
Traced from [[project_rs485_experimental_project]]'s 2026-08-28 "받는 쪽 값 뭉쳐서 나옴" bug: TX
every 0.5s, RX call used `length=64, ticks_to_wait=1000ms` → never returned early since 0.5s < 1s,
so it wouldn't hand back data until ~64 bytes had accumulated.

**Fix:** if you want the call to return as soon as any data is available, request exactly the
number of bytes you're prepared to consume right away — e.g. `length=1` for strict per-byte
handling — rather than a generously-sized scratch buffer. A large `length` is only appropriate when
you actually want to wait for that much data (e.g. draining a burst you expect to arrive together),
not as a generic "big enough" buffer size for a polling loop.

**How to apply:** any time a UART/serial receive loop on ESP-IDF seems to batch/delay data instead
of reacting per-chunk, check the `length` argument passed to `uart_read_bytes` before suspecting the
sender, the wire, or interrupt timing — the blocking contract itself is the first thing to rule out.
