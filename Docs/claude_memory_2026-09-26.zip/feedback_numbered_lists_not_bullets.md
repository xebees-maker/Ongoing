---
name: numbered-lists-not-bullets
description: "User wants multi-point responses formatted as numbered lists (1. 2. 3.), not bullet points — was previously stated but missing from memory, caught 2026-09-17"
metadata:
  node_type: memory
  type: feedback
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-21T13:41:16.419Z
---

User: "네가 불릿으로 얘기하면 내가 키보드를 많이 쳐야 하니까 번호를 붙여서 말하라고 했잖아." (If you
talk in bullets, I have to type a lot [to refer back to a specific point by quoting it] — that's why
I told you to number them instead.) This was a standing instruction from an earlier session that was
never actually saved to memory — caught 2026-09-17 when it surfaced again ("메모리가 개판이군" — your
memory's a mess) mid-conversation.

**Why:** numbered items let the user respond by typing just "3" or "2번" instead of quoting/retyping the
bullet's text to refer back to it — a real typing-effort saver, not a stylistic preference.

**How to apply:** whenever a response lists multiple distinct points, options, or items, use a numbered
list (1. 2. 3. ...) — never a bare bullet list (•/-/*). This applies broadly: summaries, findings,
proposed fixes, clarifying-question sets, to-do recaps. Keep using numbers even for short 2-3 item
lists, not just long ones.

**Repeat violation, 2026-09-21:** slipped back into bare "- " bullets mid-way through a long, tense
CNTL I2C-bridge hardware conversation — not at the start of a new topic, well after this rule should
have been established habit. User had to spend a message just pointing it out again ("재밌냐?" — is
this fun for you?). The rule doesn't decay in relevance as a conversation runs long; check every
multi-point response against it, not just the first one in a session.
