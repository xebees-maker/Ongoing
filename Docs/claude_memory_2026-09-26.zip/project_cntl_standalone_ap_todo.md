---
name: project-cntl-standalone-ap-todo
description: "Cntl Network/WiFi settings feature shipped 2026-08-29 (AP/STA toggle + live STA scan/connect, multi-credential save); intermittent post-connect crash deferred to coredump; 3 concrete follow-ups queued"
metadata:
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-08-29T11:02:32.794Z
---

**Status: shipped 2026-08-29.** The old `CNTL_WIFI_STANDALONE_AP_TEST` compile-time switch is now a
real, persisted (`device_config_get/set_wifi_ap_mode()`, file-based) runtime setting with a UI row in
설정-제어기 판넬 ("네트워크" label, 독립(AP)/종속(STA) dropdown, restart-confirm on mode change). STA
side got far more than originally scoped: a full "찾기" flow — scan popup, SSID list (with a
"[연결됨]" tag on the currently-active network), password entry (prefilled if previously saved,
show/hide toggle) — and a **live test-connect that does NOT restart the device** (only the AP/STA
mode switch itself still requires restart; confirmed correct per the existing
`esp_now_channelsync` self-healing component, see conversation). Passwords are stored in an 8-slot
LRU array (`device_config_set/find_sta_credentials`, PSRAM-allocated) so multiple networks are
remembered.

**Key bugs found and fixed this session** (all in `esp_now_hub.c`/`ui_main.c`, see git diff for
exact code — not reproduced here since code is authoritative):
- Stack overflow crash on connect-success (heavy work — `device_config_save()`, popup teardown,
  toast — ran synchronously on the tiny WiFi/`sys_evt` event task). Fixed via `lv_async_call()`
  deferral to the LVGL task + `CONFIG_ESP_SYSTEM_EVENT_TASK_STACK_SIZE` 2304->6144.
- Connect-attempt race (wrong-password-then-retry hanging/misfiring) — fixed via a two-phase
  DISCONNECTING->CONNECTING state machine in `esp_now_hub_test_sta_connect()`.
- First-attempt-after-boot always burning the full 25s timeout — `esp_wifi_disconnect()` is a
  no-op (no event) when STA is already idle, so the phase machine could get stuck waiting for an
  event that would never come. Fixed by replacing an `esp_wifi_sta_get_ap_info()` check (which only
  knows "fully connected", not "connecting-but-not-yet-connected") with a self-tracked
  `s_sta_conn_in_flight` flag set on every `esp_wifi_connect()` call and cleared only on a real
  `STA_DISCONNECTED` event.
- CONNECTING-phase disconnect being treated as instant failure — real WiFi auth/assoc often needs a
  retry cycle before succeeding (confirmed via a real "Association refused temporarily... comeback
  time" log). Fixed by just retrying `connect()` on CONNECTING-phase disconnects and letting the 25s
  timeout be the sole failure verdict — no new timer added, an existing one repurposed correctly
  (see [[feedback_change_one_variable_per_test]] context for why this mattered).
- **Root cause of the AUTH_EXPIRE-loop / display bugs**: `trigger_wifi_scan()` (called when the
  "찾기" popup opens) used to call `esp_wifi_disconnect()` *immediately on popup-open*, before the
  user had chosen anything. This tore down the real connection just to browse the list, and the
  "already-same-credentials" short-circuit in `cb_wifi_connect_btn` never reconnected — leaving the
  device silently disconnected (top-of-screen Network row correctly showed "찾기" because it *was*
  actually disconnected, not a display bug). Also broke the scan list's "connected" tag, since it
  checks live IP presence and IP is always empty right after a forced disconnect. **Fixed per
  explicit user architecture correction: disconnect only when the user actually presses Connect in
  the password popup** (`esp_now_hub_test_sta_connect()` already handles disconnect-then-connect
  internally) — removed the premature `esp_wifi_disconnect()` from `trigger_wifi_scan()` entirely.
- UI-only network-row label not refreshing after a successful connect (`refresh_network_right_zone()`
  wasn't called from the connect-success or short-circuit paths) — added.

**Open, explicitly deferred, 2026-08-29**: an intermittent crash after a successful credential-save
(not reproduced consistently — sometimes several connect/save cycles in a row are clean, then it
crashes once). User's own call: stop chasing it live for now; next time, set up an ESP-IDF coredump-
to-flash partition so a crash instance can be inspected after the fact instead of needing a live
serial capture running at the exact moment it happens. This needs a partition-table change (new
coredump partition) — bigger lift than the ad-hoc Python serial-capture approach used all session,
deliberately not done yet.

**Three concrete follow-ups queued by the user for after wrap-up (2026-08-29), in his own words**:
1. AP 상태에서 캠이 붙는지 확인 — verify CAM can still pair/connect when CNTL is in standalone AP mode
   (this was the whole original point of the AP-mode feature — see the *why* in the git history /
   [[project_cntl_cam_steel_obstruction_relay]] — not yet actually tested this session, only the
   settings plumbing was built and STA-side tested).
2. AP 상태에서 웹 접속이 되는지 확인 — verify the web dashboard is still reachable while in AP mode.
3. **New feature**: when in STA mode and the previously-connected AP can't be found at boot/init,
   stop the endless retry-search loop. Instead, show "AP 없음(No AP)" in the CH-1 slot near the logo
   (부연 자리) and halt/wait there until the user goes into 설정 and connects a network — don't keep
   silently retrying forever in the background.
