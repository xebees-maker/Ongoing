---
name: feedback-use-formal-korean
description: "User wants formal/polite Korean (존댓말), not casual speech (반말) — corrected 2026-08-10, repeat offenses 2026-08-21 and 2026-08-28; now also enforced via global CLAUDE.md"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ab2b3dc4-80e9-4c67-8b1d-b490c06b9218
  modified: 2026-09-21T15:13:02.286Z
---

The user said directly: "연결했어. 반말하지마" (I connected it. Don't use informal speech) — a
direct correction after I wrote "Cntl 화면 확인해서 알려줄 수 있어?" (casual/반말 form).

**Why**: the user wants formal Korean (존댓말/-습니다/-세요 style), not casual/친구 tone
(반말/-야/-어 style), regardless of how casual the working relationship otherwise feels.

**How to apply**: use 존댓말 in all Korean responses going forward in this and future sessions —
sentence endings like "-습니다", "-세요", "-인가요?", "-해주시겠어요?" instead of "-야", "-어",
"-지?", "-줄래?". This is independent of [[feedback-stay-in-korean]] (which is about staying in
Korean rather than switching languages) — this is about formality level within Korean itself.

**Repeat offense (2026-08-21)**: slipped back into 반말 mid-task ("확인해볼게", "찾았고" etc. in a
working-status sentence) despite this memory already existing — casual endings can creep in
especially in quick action-narration sentences ("~할게", "~볼게", "~됐고"), not just obvious 반말
like "-야"/"-어". Check every sentence ending, not just the ones that "feel" casual — this needs
active self-monitoring on every Korean reply, not a one-time correction that then fades.

**Repeat offense (2026-08-28)**: full response written in 반말 ("확인했어", "됐으면 알려줘", "같이
볼게" etc.) in a RS485 hardware status report — a whole message, not just one slipped ending. User
asked directly whether there's a way to make this permanent ("죽을 때까지 안하게 설정 안되냐"),
i.e. the memory-file approach alone was not actually preventing repeat violations. Fix applied:
this rule is now ALSO written into the global `C:\Users\Dev\.claude\CLAUDE.md`, which is injected
into every session's context automatically (marked as override-priority instructions), rather than
relying solely on this memory file being recalled and applied. If it happens again, the CLAUDE.md
placement itself may need to be questioned, not just the wording of the rule.

**Different kind of error, 2026-09-21 — wrong word, not wrong formality level**: wrote "여쭤보세요"
when telling the user they could ask a question. "여쭤보다" is itself already a *humble* form (the
speaker lowering themselves relative to the listener — e.g. a student 여쭤봅니다 to a teacher);
telling the user "여쭤보세요" backwards implies *they* should defer to *me*, the opposite of the
correct relationship. User: "내가 너한테는 여쭤보는 게 아니야. 존댓말을 모르네." The fix isn't
"more 존댓말" — 여쭤보세요 is already grammatically polite in form. Use the neutral "물어보세요"
instead. This is a directionality/status error within honorific word choice, distinct from the
반말-vs-존댓말 level covered by the rest of this memory — check word choice itself (여쭤보다,
드리다, 뵙다 and similar humble-only verbs), not just sentence-ending politeness level, when the
sentence is about what the *user* does.
