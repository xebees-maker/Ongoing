---
name: project-cntl-popup-close-vs-action-buttons
description: "Cntl-wide UI convention: a popup's plain close/dismiss is always the top-right X, semantic choices (confirm/cancel/yes/no) are always separate bottom buttons — never conflate the two"
metadata:
  type: project
  originSessionId: b17b2f51-3975-463b-a8ec-56dde400e638
  modified: 2026-09-11T10:25:10.965Z
---

User's explicit standing convention (2026-09-11), stated while designing the SD-error popup's close
button, but declared project-wide ("이건 프로젝트 전반에 같은 UI 개념이니까"):

- **Plain close/dismiss** (no semantic meaning — just "stop looking at this") → top-right **X**
  button on the popup.
- **Confirm/Cancel/Yes/No** (an actual choice with consequence) → separate button(s) at the
  **bottom** of the popup/screen, never the X.

**Existing precedent this matches:** `add_page_popup_header()` in `ui_main.c` already builds an
"X" close button for full-screen popups (Stats/Settings/Camera/etc.) — that's the X-for-plain-close
half of the convention, already correct. `show_confirm_popup()` (Yes/Cancel) and other
`create_modal()`-based dialogs already put their buttons in a bottom `create_modal_btn_row()` — that
half is already correct too. The gap this call-out was about: the error/warning-list popup
(`cb_logo_warning_tap`) currently only has a bottom "확인"(OK) button acting as its close — it needs
a top-right X added for plain dismiss, separate from any per-error action buttons (재연결/포맷/etc.,
see [[project_cntl_sd_reliability_redesign_2026_09_10]]) that belong at the bottom per-row.

**Sharper framing (user's own follow-up, same conversation):** it's not really "plain dismiss vs.
choice" — it's about *where the action lives*.
- **X-closed popups**: the action lives **inside the content**, per-item (e.g. each error row gets
  its own 적용/재연결/포맷-style button). The popup itself has no single pending decision to
  commit; you interact with whichever row-level controls you need, then X out whenever — nothing
  is "decided by leaving."
  - **Bottom-button popups**: the popup *as a whole* represents exactly one pending value/action,
  and that specific bottom button (확인/취소/예/아니오) is what executes or commits it. There's no
  X because leaving without pressing the button IS the cancel.

This is the same distinction as the earlier (already-implemented) "popup size classification rule"
from the single-screen redesign ([[project_cntl_ui_rebuild]] era plan) — "simple confirm/alert
dialogs stay small, anything the user actually does something functional in goes bigger" — just
restated in terms of which close-affordance to use rather than size.

**How to apply:** before adding a close control to a new popup, ask: does this popup have
independently-actionable content (→ X, top-right, content gets its own per-item buttons), or does
the popup as a whole represent one decision this button commits (→ bottom button only, no X)? Don't
default to a bottom "확인"/OK button out of habit when the popup actually has X-shaped, per-item
actionable content instead.
