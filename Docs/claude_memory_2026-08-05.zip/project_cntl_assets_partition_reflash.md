---
name: project-cntl-assets-partition-reflash
description: "Cntl's assets (LittleFS) partition gets fully rewritten on every flash, wiping runtime-persisted files like settings.bin"
metadata:
  type: project
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-08-01T14:04:03.710Z
---

`cntl_incremental_test/CMakeLists.txt` has `littlefs_create_partition_image(assets
"${CMAKE_SOURCE_DIR}/assets_root" FLASH_IN_PROJECT)`. The `FLASH_IN_PROJECT` flag auto-bundles the
generated `assets.bin` into `build/flash_args`, so any `write_flash "@flash_args"` rewrites the whole
assets partition every time — including files the device itself wrote at runtime (e.g.
`/assets/settings.bin`, used by `ui_lang_set()`/`ui_lang_load()` in `ui_strings.c` for the language
setting). `assets_root/` only contains the build-time source files (`NanumGothic-Regular.ttf`,
`time_sync.txt`) — `settings.bin` isn't part of it, so every reflash silently reverts language (and any
other file-based setting) back to default.

**Why this matters:** discovered 2026-08-01 when the user found their language setting reset after a
session of repeated reflashes. Root cause confirmed by inspecting `build/flash_args`: app partition is at
`0x10000` (`lvgl_v9_demo.bin`), assets at `0x810000` (`assets.bin`) — both get written by the blanket
`write_flash "@flash_args"` command used throughout this session's iteration.

**How to apply:** [[feedback_settings_as_files_not_nvs]] rules out NVS as the fix — settings must stay
file-based. Instead, flash routine app-only code changes with just the app partition (`write_flash 0x10000
lvgl_v9_demo.bin`, skip bootloader/partition-table/assets), and only include assets.bin in the flash
command when `assets_root/` content (font file, etc.) actually changed. This preserves runtime-written
settings.bin across ordinary iteration. (CAM has no assets/LittleFS partition — its `flash_args` is just
bootloader+partition-table+app, so this issue is Cntl-specific.)
