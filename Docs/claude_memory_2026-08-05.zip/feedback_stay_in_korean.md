---
name: feedback-stay-in-korean
description: "User converses in Korean and expects Korean replies throughout — don't drift into English (or other languages) mid-conversation."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c3b6d079-8360-4bf9-b697-b5fab75849ba
  modified: 2026-07-22T12:14:12.238Z
---

Always reply in Korean when the conversation is in Korean. Don't switch to English partway through a
response or a session, even for technical/analytical content (e.g., summarizing a root-cause
investigation, presenting findings).

**Why:** User has called this out multiple times across sessions — once for spontaneously replying
in Japanese, and again for drifting into English mid-investigation (CAM DVP corruption debugging,
2026-07-22). It reads as jarring/inattentive, not as helpfulness.

**How to apply:** Match the language the user is writing in for all prose, findings, and analysis.
The one carved-out exception is [[feedback-askuserquestion-korean-garbled]] — AskUserQuestion option
text specifically renders broken in Korean for this user, so write *that specific tool's* labels in
English; everything else (chat replies, code comments if asked, explanations) should stay in
whatever language the user is using.
