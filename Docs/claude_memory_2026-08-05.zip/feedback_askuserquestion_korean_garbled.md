---
name: askuserquestion-korean-garbled
description: AskUserQuestion option text in Korean renders garbled for this user — phrase AskUserQuestion questions/options in English instead
metadata: 
  node_type: memory
  type: feedback
  originSessionId: bb120d6f-b2b7-438a-afdc-01fae1be2eeb
---

User explicitly reported (2026-06-24, Cntl 1.85C display debugging session): Korean text inside `AskUserQuestion` question/option fields consistently renders broken/garbled on their end, even though Korean text everywhere else in the conversation (plain chat replies, code comments, file content) displays fine.

**Why:** unknown root cause (likely an encoding issue specific to how this UI renders that component's structured option text) — but it's consistent enough that the user called it out directly: "너 이런 질문에는 항상 한글이 깨져. 이런 질문은 영어로 물어봐" (Korean always breaks in these question prompts; ask in English instead).

**How to apply:** always write `AskUserQuestion` question text, headers, and option labels/descriptions in English for this user, regardless of what language the rest of the conversation is in. Free-form chat replies and code/comments can stay in Korean as before — this is specific to the AskUserQuestion tool's rendered fields.
