---
name: project-cntl-error-code-system
description: "Cntl gained a proper error-handling/reporting system 2026-08-01: numeric error codes, on-screen log box, toast, warning logo icon"
metadata:
  type: project
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-08-01T14:42:16.380Z
---

Added 2026-08-01 after the user pushed back hard on failures being silently swallowed ("네 코드가
에러처리가 없어서 지금까지 헤멘거잖아" — "your code has no error handling, that's why we've been lost this
whole time"). New module `cntl_incremental_test/main/ui_log.c`/`.h`:

- `ui_log_add(fmt, ...)` — lightweight rolling log (~6KB append buffer) rendered live in a textbox on the
  **Statistics tab** (replaced the vendor Analytics demo widget there) — built specifically to avoid
  needing a serial monitor (which resets the board on port-open, a long-standing pain point this session).
- `ui_log_add_err(code, fmt, ...)` — same, but also sets a "pending error" flag consumed by a 200ms poll
  timer in `ui_main.c` that shows a **4-second red toast** and switches the tab-bar logo to a **warning
  triangle icon** (persists until acknowledged — tapping it opens a popup listing all distinct accumulated
  error codes + short descriptions via `ui_log_get_error_history()`/`ui_log_err_desc()`).
- Error codes are 4-digit, loosely grouped by leading digit (1xxx memory alloc, 2xxx comm send, 3xxx photo
  recv/display, 4xxx CAM-reported failure, 5xxx font/system init, 9xxx test-only) — defined as `UI_ERR_*`
  macros in `ui_log.h`, spec finalization ("code 개수가 적어서 규칙 없이 앞자리로만 대충 구분") was
  explicitly deferred by the user to a later session, not yet fully reviewed/finalized.
- Settings tab (제어기 group box) gained two dev buttons: "시험" (forces one `UI_ERR_TEST_FORCED` to
  verify the toast/icon pipeline — **deliberately does not touch real memory**, an earlier version that
  looped `heap_caps_malloc` to genuinely exhaust PSRAM froze the whole device, per user's explicit
  correction that an error handler must detect-and-stop, not keep retrying) and "재시작" (soft
  `esp_restart()` behind a Yes/Cancel confirm, added as a recovery path after the memory-test button).

**How to apply:** when adding new failure paths in Cntl code, use `ui_log_add_err(UI_ERR_..., ...)` (add a
new code to `ui_log.h`'s table + `ui_log.c`'s description table) rather than a bare `ESP_LOGE`/silent
return — this is now the established pattern, not a one-off.
