---
name: project-cntl-cam-delete-all-popup-modules
description: Cntl 3 common popup modules (예취소/list-sync/progress-popup) + CAM photo delete-all feature — built and verified on real hardware 2026-08-01
metadata: 
  node_type: memory
  type: project
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-08-01T06:00:34.519Z
---

Built on top of [[project-cntl-cam-photo-list-rtc]] the same session, immediately after that feature was
verified working. User explicitly asked to standardize popup patterns *before* moving to the next feature
(list-tap-to-view verification), reasoning that repeated flows should share one implementation.

**Three common `ui_main.c` modules, all confirmed reusable and working on hardware:**
1. **예취소 (Yes/Cancel confirm)** — `show_confirm_popup(message, confirm_yes_fn_t on_yes, void *ctx)`.
   Trampoline pattern (LVGL event callbacks have a fixed signature) via a static `confirm_popup_state_t`
   singleton — safe because only one modal is ever open at a time in this app. Migrated onto it: unpair
   confirm, single-photo delete confirm, new delete-all confirm. **Deliberately NOT migrated**:
   `show_pair_confirm_popup` — it uses "확인"(Confirm) not "예"(Yes), a different semantic; still doable
   later by parameterizing the yes-label if wanted.
2. **목록 동기화 (list sync)** — `request_photo_list_sync()` (fire the request) + `sync_photo_list_tick(int
   select_index)` (poll-and-refresh-and-ack, returns true once applied). Used by `refresh_dashboard()`'s
   background poll, the capture-now popup, and the delete-all popup — one implementation instead of three
   near-duplicates.
3. **진행 팝업 (progress popup) 공용 틀** — `show_progress_popup(progress_tick_fn_t tick_fn)` returns a
   `box` for the caller to fill with its own stage labels, then `start_progress_popup(box)` adds the
   **"취소"(Cancel)** button (was "닫기"/Close on the old capture-only version — user explicitly wanted
   this renamed since Cancel is the standard for CAM/SENS-communication popups) and starts the 200ms poll
   timer. `tick_fn` returns true to auto-close. `close_progress_popup()`/`cb_progress_popup_cancel` are
   generic; **no timeout logic lives in the shared module** — each flow owns its own `lv_tick_get()` /
   `lv_tick_elaps()` based timeout because different flows need different behavior on timeout (see below).
   Capture-now's popup (`capture_popup_tick_fn`) was refactored onto this scaffold with no behavior change
   (just reused `set_stage_label(labels[], idx, str, color)`, now parameterized by label array instead of
   hardcoded to one static array).

**New feature: 모두 지우기 (delete all)** — button in Dashboard→Camera toolbar, next to 지금촬영/목록갱신.
- Protocol: `ESP_NOW_MSG_PHOTO_DELETE_ALL_REQUEST`(19)/`_ACK`(20) added to `esp_now_link.h`, deliberately
  **separate message types** from single-delete (`PHOTO_DELETE_REQUEST`/`_ACK`) rather than a shared
  message with a mode parameter — decided against the `PHOTO_REQUEST_MODE_*` precedent because the ACK
  shapes are fundamentally different (single: `file_id`+`success`; all: `success`+`deleted_count`), and
  single-delete was already deployed/working, not worth retrofitting. `esp_now_photo_delete_all_ack_t` has
  an explicit `success` field (not just `deleted_count`) so "0 files existed" and "SD/dir access failed"
  don't collapse into the same wire value — `cam_storage_delete_all()` (already existed, used by CAM's
  console `clear` command) returns -1 on the latter.
- CAM: `cam_task_request_t.kind` gained `CAM_TASK_REQ_DELETE_ALL`, routed through the existing
  `photo_transfer_task` queue (same reasoning as LIST_REQUEST — SD directory walk is too slow for the
  recv_cb/WiFi task).
- **Key design decision (user-driven, worth preserving)**: delete-all's progress popup ALWAYS runs stage 2
  (list resync) after stage 1 (delete ACK), regardless of whether stage 1 succeeded, reported failure, or
  timed out waiting for CAM. Rationale: `cam_storage_delete_all()`'s directory walk isn't atomic, so a
  partial failure or a CAM crash mid-operation leaves Cntl's cached list untrustworthy — the only way to
  know the true remaining state is to re-ask CAM, so re-asking is unconditional. If stage 2 *also* times
  out, the popup shows "상태 확인 불가"(unable to verify) and explicitly leaves the existing list
  untouched rather than guessing — user must hit 목록갱신 later to re-check. `CAM_RESPONSE_TIMEOUT_MS`
  (8000) is a plain `#define` in `ui_main.c`, not a module-level concept — this is the first place in the
  whole ESP-NOW stack with any request/response timeout at all (everything else either polls forever or
  relies on the separate node-liveness keepalive timeout in `esp_now_hub.c`, which is a different concern).

**How to apply**: these three modules are the standard going forward for any new CAM/SENS-communication UI
— don't hand-roll another confirm dialog or progress popup. Verified end-to-end on real hardware same
session (delete-all button → confirm → 2-stage progress → auto-close → empty list; capture-now popup's
Cancel-labeled button confirmed still working after the refactor). Single-delete's failure path (ACK
`success=false`) still isn't shown in the UI (only logged) — flagged mid-session, deliberately deferred,
not fixed this pass.

**Same-session follow-up: capture/transfer decoupling + fetch progress popup — also verified on hardware.**
User caught that 지금촬영's old 4th stage ("영상수신") didn't belong there ("영상가져오기는... 목록이
선택됐을 때 가져올꺼잖아") — capture-now was auto-transferring the just-taken photo through the same
single-receive state machine used by list-select, and that transfer was slow and frequently failed on real
hardware, leaving the popup stuck. Fix chosen (user picked explicitly, "B가 맞아") over a lighter option
that just stopped the *popup* from waiting: decouple capture and transfer **end to end**.
- CAM (`esp_now_cam.c`): after `cam_node_capture_now()`, sends `CAPTURE_STATUS` only and `continue`s — no
  more auto-fallthrough into `PHOTO_REQUEST_MODE_LATEST`/send_one_photo/`PHOTO_DONE`. Viewing the new photo
  now always goes through list-select like any other photo.
- Cntl (`esp_now_photo.c/h`): `esp_now_photo_capture_now()` no longer calls `start_single_receive()` at all
  — sends `PHOTO_REQUEST(CAPTURE_NOW)` directly, never touches `s_state`. This *eliminates* the whole
  "stuck single-receive state machine" bug class from [[project-cntl-cam-photo-list-rtc]] for capture-now,
  since capture-now no longer participates in that state machine. `esp_now_photo_fetch_by_id()` (still the
  only path using single-receive) gained the same force-reset-`s_state`-to-IDLE-before-starting fix that
  capture_now already had, so a stalled prior fetch can't permanently block new ones either.
  `ESP_NOW_CAPTURE_STAGE_TRANSFER_DONE/_FAILED` removed from the enum (nothing produces them anymore).
- Cntl UI: capture-now popup shrank to 3 stages (명령전달/촬영결과/목록갱신), rebuilt on the exact same
  "always run stage 2 regardless of stage 1 outcome, timeout via `CAM_RESPONSE_TIMEOUT_MS`" pattern as
  delete-all — `CAM_RESPONSE_TIMEOUT_MS` moved to the shared progress-popup module section since 3 flows
  use it now.
- **New: fetch-by-id progress popup** (`show_fetch_progress_popup`/`fetch_popup_tick_fn`), triggered from
  `cb_photo_row_select` — user explicitly required a spinner (`lv_spinner_create`, `CONFIG_LV_USE_SPINNER`
  already on) plus live percent and ETA. Progress read via new `esp_now_photo_get_chunk_progress(received,
  total)` getter (lock-free reads of `s_chunks_received`/`s_total_chunks` — deemed fine, display-only,
  single-writer). ETA computed with plain integer math (`(total-received)*elapsed_ms/received`) — **never
  use `%f` in `lv_label_set_text_fmt`**, see [[feedback-lvgl-no-percent-f]]. Timeout here is
  stall-based (no *new* chunk for `CAM_RESPONSE_TIMEOUT_MS`), not total-elapsed, so large legitimate
  transfers aren't cut off early — only genuine stalls are.
- **Chunk size bumped 200→1200 bytes** (`ESP_NOW_PHOTO_CHUNK_DATA_LEN` in `esp_now_link.h`). Root cause of
  slow transfers found via code+boot-log inspection: both boards already run ESP-NOW v2.0 (confirmed in
  boot log "espnow [version: 2.0] init"), which allows up to 1470 bytes/packet
  (`ESP_NOW_MAX_DATA_LEN_V2`), but the chunk struct was still sized for the old v1.0 250-byte limit. New
  size (1200 data + 10 header = 1210) cuts chunk count ~6x (a 340KB photo: 1704 chunks → 284), verified
  fast + reliable on hardware post-change.
- **Photos are never persisted on Cntl** — `display_photo()` only holds the JPEG in a PSRAM heap buffer
  for on-screen display; no SD card on Cntl, no file write anywhere. CAM's SD card is the sole permanent
  copy. Cntl's buffer is freed the next time a photo arrives or on reboot.

**Two more bugs found + fixed same session, both verified on hardware:**
- **`ESP_NOW_MSG_PHOTO_DELETE_ALL_ACK` was never routed** — added to `esp_now_link.h` for the delete-all
  feature but forgot to add to `esp_now_hub.c`'s recv_cb message-type filter (the single ESP-NOW recv
  callback only forwards a hardcoded whitelist of msg_types to `esp_now_photo_on_recv`). Delete-all
  *looked* like it worked in the first test only because of the "always resync regardless of stage 1
  outcome" design — the ACK silently never arrived, stage 1 timed out to "무응답" after 8s, then stage 2
  (list resync, which *is* routed) still ran and emptied the list correctly. Fixed by adding the ACK type
  to the filter.
- **`ESP_NOW_MSG_SET_TIME` implemented** (was defined in the protocol since 07-31 but never actually sent
  — see [[project-cntl-cam-photo-list-rtc]] "explicitly deferred" note). Cntl now sends it right after
  `esp_now_hub.c`'s PAIR_ACK handler sets `became_paired = true`, carrying `rtc_sync_get_unix_time()`. CAM
  receives it in `esp_now_cam.c`'s `recv_cb` (guarded by `s_paired` + hub MAC match) and calls
  `settimeofday()`. Root cause this was needed: CAM has no RTC, boots near epoch 0, and
  `cam_storage.c`'s file_id generation uses `time(NULL)` directly — every photo's displayed date was
  "1-1" (Jan 1) until this fired. Confirmed fixed: new captures show today's real date post-pairing.

**Deferred to a separate planning pass (not started)**: a 3-tier photo resolution/serving redesign the
user specified in detail — (1) full original resolution viewable remotely via Cntl's web endpoint (trivial:
just serve the compressed JPEG bytes as-is, browser decodes), (2) the list-adjacent thumbnail panel decoded
at its own small panel size, (3) the tap-to-open photo viewer decoded at 1600×960 for its default/fit-to-800×480
view, with double-tap zoom panning the *original* resolution via **on-demand cropped decode** (not a flat
full-resolution buffer — confirmed physically impossible on this hardware: 2560×1920 original needs a
9.4MB RGB565 buffer, Cntl's usable PSRAM heap is only ~6.7MB of the 8MB physical total). Feasibility already
confirmed: `esp_new_jpeg`'s `esp_jpeg_dec` (`managed_components/espressif__esp_new_jpeg`) natively supports
both `scale` (decode-time downscale, up to 1/8) and `clipper` (decode-time crop to a sub-region) — exactly
what's needed for the mid-res default view and the crop-per-pan-position zoom view respectively. The
current LVGL wrapper (`esp_lv_decoder`) doesn't expose either option through the standard `lv_image_dsc_t`
path (its plain-JPEG branch always does one flat full decode, which is *why* the original 9.4MB alloc
failed) — implementing this means calling `esp_jpeg_dec` directly rather than through that wrapper. Also
wanted alongside this: a small file_id→compressed-JPEG-bytes cache so re-selecting an already-fetched list
item doesn't re-trigger an ESP-NOW transfer.
