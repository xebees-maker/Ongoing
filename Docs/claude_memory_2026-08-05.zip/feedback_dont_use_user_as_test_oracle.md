---
name: feedback-dont-use-user-as-test-oracle
description: "User's firm rule: diagnose with available tools (serial, logs, code reading) before asking the user to test on real hardware — don't iterate blind guesses through them"
metadata:
  type: feedback
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-08-02T22:32:39.836Z
---

Don't fall into a "change code → ask user to test on real hardware → get new failure → guess again" loop.
Each round costs the user a real build+flash+re-pair+manual-test cycle on physical devices. If a diagnostic
tool exists that doesn't require the user (serial console, dev-console commands already built into the
firmware, static code tracing of the full path end-to-end), use it BEFORE proposing a code change, and
verify the fix's premise before asking for another hardware round.

**Why:** stated directly during the [[project_cntl_cam_todo_2026_08_02]] ESP-NOW chunk-transfer debugging
session (2026-08-02→03) after several consecutive "fix" attempts each shifted the failure to a new error
code (3002 → 3006 → 3007) without resolving the underlying packet-loss problem: "좀 알고 고치면 좋겠어.
내가 네 테스트 머신도 아니고." (I wish you'd actually understand the problem before fixing it — I'm not
your test machine.) The pattern that caused this: proposing plausible-sounding hypotheses (channel drift,
power-save, buffer sizing, request-generation races) and shipping a fix for each without first gathering
hard evidence that the hypothesis was correct, then relying on the user's live hardware test as the
verification step — which is expensive and repeatedly wrong.

**How to apply:** for embedded/hardware bugs in this codebase, prefer (in order): (1) full careful reading
of the actual code path end-to-end for the specific failure, (2) self-directed serial/log inspection
(CAM/Sens dev consoles, boot logs) when it doesn't require the user's touchscreen interaction, (3) targeted
instrumentation added and checked via serial before proposing a fix, (4) only then a code change — and when
asking the user to reflash+test, be reasonably confident, not hopeful.
