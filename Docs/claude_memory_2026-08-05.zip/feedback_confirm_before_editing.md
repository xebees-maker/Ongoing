---
name: confirm-before-editing
description: "Canonical rule (2026-06-19): things explicitly instructed run without re-asking unless a problem comes up; self-initiated code edits or builds (not instructed) require asking first"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ea523f87-b6d2-47f1-ba7c-aac304e9e417
---

Before making code edits, say what you intend to change and ask for confirmation — do not edit first and explain after.

**Canonical statement (user's own words, 2026-06-19):** "앞으로도 내가 시킨 건 문제가 생기지 않는 한 되묻지 말고, 코드 수정이나 빌드 전(시키지 않은)에는 물어보길 바래." — i.e. (1) anything the user explicitly instructed: just do it, don't re-ask, unless something actually goes wrong/blocks; (2) anything *you* initiate on your own — a code edit or a build the user didn't ask for — ask first before doing it.

**Why:** This rule was originally "ask before every edit," then reversed to "don't ask, just edit" after the user found the first version overapplied. The user has now reversed it back to "ask before editing" (2026-06-19, Sens project, after a battery-calibration fix was made directly). Treat this as the current standing instruction unless reversed again.

**How to apply:** This gate only applies when *you* are the one proposing the edit — a self-diagnosed fix, or a design/approach you came up with that hasn't been explicitly approved yet. Describe the planned change and wait for a go-ahead before touching files.

It does NOT apply once the user has explicitly instructed the action in this or an earlier turn (e.g. "진행하고 코드 수정해서 빌드해", "수정해", "고쳐") — that instruction IS the confirmation. Don't ask again before executing it, and don't re-ask mid-sequence for its sub-steps (build, etc.) either — see [[no-step-confirmation]], same principle. Confirmed explicitly 2026-06-19 after the user had to call this out twice in one session: once to turn the gate back on, once to clarify it shouldn't refire on an instruction they'd already given.

For diagnostic/read-only work (grepping, reading files, explaining root causes), no confirmation is needed at all — only actual file edits trigger this gate, and only when not yet explicitly requested.
