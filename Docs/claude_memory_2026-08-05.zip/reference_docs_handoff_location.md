---
name: docs-handoff-location
description: Where to save work-log/handoff docs across Cntl/Sens/Common — Ongoing/Docs as of 2026-06-20
metadata: 
  node_type: memory
  type: reference
  originSessionId: 577f7696-cb50-4489-ad09-dad511378349
---

As of 2026-06-20, save all new handoff docs (`handoff_YYYY-MM-DD.md`, technical/structured) and work-log docs (`한일_YYYY-MM-DD.txt`, casual "today's struggles/wins/regrets" format) in **`C:\Projects\Ongoing\Docs\`** — not in `Cntl\.claude\memory\` or `Sens\.claude\memory\` per-project folders.

**Why:** User created the `Docs` folder specifically to consolidate these across both projects (Cntl and Sens share a single git repo at the `Ongoing` root, per [[project_sens_cntl_esp_now]]). Per-project `.claude/memory` handoffs from before this date (e.g. `Sens/.claude/memory/handoff_2026-06-19.md`) were left in place, not migrated — only new entries go to `Docs`.

**How to apply:** When wrapping up a session that touches Cntl, Sens, or Common, write the handoff/한일 doc to `Ongoing/Docs/` using the existing naming convention and style already present there (see `handoff_2026-06-18.md` for the structured format, `한일_2026-06-18.txt` for the casual log format). Don't create new files under either project's `.claude/memory/handoff_*` going forward.
