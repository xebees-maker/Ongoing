---
name: sens-cntl-wireless-link
description: "Spec for the next phase: wireless link between Cntl(S3, hub) and Sens(C6, sensor nodes) — ESP-NOW/BLE/WiFi decision, pairing UI, multi-tab dashboard"
metadata:
  node_type: memory
  type: project
  originSessionId: ea523f87-b6d2-47f1-ba7c-aac304e9e417
---

Full spec as given by the user on 2026-06-19, before any implementation started:

**Link layer choice (not yet decided):**
- Target range: 50m in open field, but with steel pipes erected nearby that may degrade range unfavorably.
- First try BLE 5.x long-range PHY (trade bandwidth for range).
- Fallback: if BLE range is unsatisfying AND battery draw is comparable anyway, switch to plain WiFi (likely ESP-NOW over WiFi, given the "다음 단계는 ESP-Now를 개발할꺼야" framing) instead of fighting BLE range.
- If WiFi/ESP-NOW path is chosen: each C6 node needs a stable **human-readable unique name**, not just its MAC address — firmware must support assigning/exposing this.

**Dev environment:** Need to manage both projects (Cntl=S3 hub, Sens=C6 node) open together in VS Code (multi-root workspace or similar) since shared constants/functions (protocol structs, message IDs, etc.) will likely live in or be coordinated between both — similar in spirit to how `Common/components` is already shared between them.

**Target architecture (applies whichever link layer wins):**
- **S3 (Cntl, hub) side:**
  - Shows a live list of unpaired/discoverable C6 nodes, refreshed every 1 second.
  - User selects one from the list → triggers pairing between S3 and that C6.
  - After pairing, S3 has a **variable number of tabs**: one "summary" tab showing max/min/avg across all connected C6 sensor values, plus one tab per paired C6 showing that node's individual sensor + battery readings.
  - S3 does not need power saving (mains/always-on context, unlike Sens).
- **C6 (Sens, node) side:**
  - Currently still has the touch LCD attached (dev/bring-up stage) so it can show pairing/connection status on-screen too.
  - Production C6 nodes will eventually drop the LCD for just a few LEDs + buttons — so pairing-status UI work on the LCD is temporary/bring-up scaffolding, not to be over-invested in.
  - After pairing, periodically pushes its sensor readings + battery status to S3: every 1s during development, every 1 minute in production (battery life).

**How to apply:** This is the spec as stated, before any design/implementation decisions were made on top of it (transport framing, pairing handshake details, how "name" is stored/assigned, how the S3 tab UI is actually built). Don't re-ask for this spec again — pick up from here when resuming. Link this to [[project_sens_status_2026_06_18]] / [[sens-vbus-sense]] for the broader Sens hardware context (still bring-up stage, LCD attached, power budget concerns already in motion).

**Progress as of 2026-06-19 — Sens(C6) node side done & verified:**
- Link layer decided: ESP-NOW over WiFi (not BLE) — went straight to ESP-NOW.
- Added `Common/components/esp_now_link/include/esp_now_link.h`: shared wire-format header, header-only component. Has `esp_now_msg_type_t` (`ADVERTISE`=1 implemented; `PAIR_REQUEST`/`PAIR_ACK`/`SENSOR_DATA` enum values reserved but unused) and `esp_now_advertise_t {version, msg_type, name[16], mac[6]}`. Cntl's hub side should `#include "esp_now_link.h"` and reuse these types/constants rather than redefining the wire format.
- Added `Sens/main/esp_now_node.c/.h`: resolves node name (`CONFIG_SENS_NODE_NAME` Kconfig override, else auto `"Sens-XXXX"` from MAC), `esp_now_init()`, broadcasts an `esp_now_advertise_t` every 1s via `esp_now_send` to `FF:FF:FF:FF:FF:FF`. Recv callback is a logging-only stub — no pairing logic implemented yet (deliberately deferred, see below). Name is exposed via `esp_now_node_get_name()` and surfaced in the phone dashboard's `/api/data` + page header.
- Build note: this repo's IDF toolchain selector defaults to v5.5.4, whose riscv32 toolchain can't compile for C6 (`zaamo`/`zalrsc` extension error) — had to activate v6.0.1 instead (`. C:\Espressif\tools\Microsoft.v6.0.1.PowerShell_profile.ps1`). Also in IDF v6.0.1, `esp_now.h` lives inside the `esp_wifi` component, not a separate `esp_now` component — don't add `esp_now` to a component's `REQUIRES`, it doesn't resolve.
- Verified on real hardware via serial monitor: node resolved name `Sens-6FFC`, advertise log fired steadily every ~1000ms alongside normal sensor/WiFi/dashboard operation. Node side is considered done for this phase.
- **Not yet implemented (this is the next task, on the Cntl/S3 side):** hub-side ESP-NOW receive of `ADVERTISE` frames, the 1s-refreshed discoverable-node list UI, the pairing trigger/handshake (would use `PAIR_REQUEST`/`PAIR_ACK` from the same shared header), and the resulting variable-tab summary+per-node dashboard. None of this exists yet — Cntl has zero networking code as of this date.
- Repo structure note: Sens, Cntl, and Common all live in one git repo/remote (root `C:\Projects\Ongoing`), so git history/files are shared regardless of which subfolder a VS Code window is opened on. This persistent-memory store, however, is scoped to the workspace path Claude is invoked from — if a future session opens only `Cntl/` as its own VS Code window/folder (not including the `Ongoing` root), it will NOT automatically see this memory file. Re-paste or re-link this spec/progress note in that case, or have the user include the `Ongoing` root in that window's trusted folders so the same memory path resolves.

**Progress as of 2026-06-19 — Cntl(S3) hub-side receive + discoverable-node list UI done (not build-verified):**
- Added `esp_now_hub.c/.h`: WiFi STA mode but **never calls `esp_wifi_connect()`** — radio is brought up and immediately pinned to a fixed channel via `esp_wifi_set_channel(CONFIG_CNTL_ESPNOW_CHANNEL, WIFI_SECOND_CHAN_NONE)`. Recv callback parses `esp_now_advertise_t`, keeps a MAC-keyed table (`ESP_NOW_HUB_MAX_NODES`=8), `esp_now_hub_get_nodes()` returns only nodes seen within `ESP_NOW_HUB_NODE_TIMEOUT_MS`=3000ms (3 missed 1s beacons → dropped from list).
- Added `ui_nodes.c/.h`: new "노드" tab, plain LVGL `lv_list` rebuilt every 1s showing `name - Ns전` per live node.
- **Known unresolved gap, deliberate for now:** Sens still joins a *real* AP via STA (`wifi_dashboard_init` in `Sens/main/wifi_dashboard.c`) for its phone dashboard, so its actual WiFi channel is whatever that AP assigns — not necessarily `CONFIG_CNTL_ESPNOW_CHANNEL`. User explicitly chose (2026-06-19) to leave Sens's STA dashboard as-is and revisit the AP-channel-mismatch problem separately later, rather than have Cntl join the same AP just to inherit its channel. Until that's revisited, `CONFIG_CNTL_ESPNOW_CHANNEL` must be hand-set to match whatever channel the AP Sens joins actually uses, or the hub won't see any advertise frames.
- Kconfig: `Cntl/main/Kconfig.projbuild` now has menu "Cntl ESP-NOW Hub" → `CNTL_ESPNOW_CHANNEL` (int, 1-13, default 1). No SSID/password needed on the Cntl side — that was an earlier wrong turn (AP join isn't required for ESP-NOW itself) and was removed.
- Not build-verified: this environment's Bash/PowerShell don't have a working ESP-IDF Python venv (`python_env` missing under both `C:\Users\Dev\.espressif` and `C:\Dev\.espressif\v6.0.1`), so `idf.py build` couldn't be run. Code was checked by hand against the LVGL/ESP-IDF headers actually present in `managed_components`, but the user should run a real build before flashing.
- Still not implemented: pairing handshake (`PAIR_REQUEST`/`PAIR_ACK`), the resulting variable-tab summary+per-node dashboard. The node list is discovery-only display, no tap-to-pair interaction yet.

**Final target network architecture, clarified by user on 2026-06-19 (supersedes the "known unresolved gap" note above):**
- Neither Sens nor Cntl will join an external AP in production. Each device hosts its **own independent SoftAP** — both are network *providers*, not sub-nodes of someone else's network. Sens's current STA-mode join of a real AP (`wifi_dashboard_init`, `CONFIG_SENS_WIFI_MODE_STA`) is **temporary, dev-only** — easier to test against today, but will revert to SoftAP hosting before production.
- **Channel sync across many independent SoftAPs:** all devices' SoftAPs must use the same hardcoded WiFi channel (Kconfig-set, matching `CONFIG_CNTL_ESPNOW_CHANNEL`'s existing approach on Cntl). User explicitly rejected the alternative (Cntl WiFi-scanning a Sens AP and dynamically matching its channel) — reasoning: with N independent Sens nodes potentially on different auto-picked channels, a WiFi radio can only sit on one channel at a time, so dynamic per-node matching can't serve multiple nodes simultaneously. Fixed/shared channel is the only approach that scales to multiple Sens nodes. **Action item:** Sens needs the same kind of fixed-channel Kconfig as Cntl once it moves to SoftAP hosting, set to the same channel number.
- **Web dashboard model — both tiers, not one-or-the-other:**
  - **Normal/primary operation:** Cntl aggregates all paired Sens nodes' data over ESP-NOW and serves one unified dashboard from Cntl's own SoftAP. This is the main way the data is viewed day-to-day.
  - **Per-node diagnostic access (kept permanently, NOT dropped after dev):** each Sens node also keeps hosting its own independent SoftAP + web dashboard (today's `wifi_dashboard.c` feature), so a technician can connect directly to one specific Sens node's own AP when it seems to be malfunctioning/unreachable via Cntl. User's reasoning: "정상 운영은 Cntl 통합 대시보드겠지만, Sens가 망가진 것 같을 때는 Sens에 별도로 접속할 수 있어야 해" — so this is a deliberate field-diagnostic requirement, not legacy cruft to clean up later.
- **How to apply:** when implementing Sens's eventual switch from STA to SoftAP, add a fixed-channel Kconfig option mirroring Cntl's `CNTL_ESPNOW_CHANNEL` and keep the individual per-node web dashboard alive alongside whatever Cntl-side aggregated dashboard gets built — don't consolidate them into one.

**Progress 2026-06-19 — Sens switched to SoftAP+fixed-channel; both Cntl and Sens build-verified for the first time:**
- Sens: added `SENS_ESPNOW_CHANNEL` Kconfig (int 1-13, default 1, mirrors `CNTL_ESPNOW_CHANNEL`) in `Sens/main/Kconfig.projbuild`. `wifi_dashboard.c`'s AP branch now sets `wifi_cfg.ap.channel = CONFIG_SENS_ESPNOW_CHANNEL` and auto-generates the SSID as `Sens-XXXX` (last 2 MAC bytes, same format as the ESP-NOW advertised node name) whenever `CONFIG_SENS_WIFI_SSID` is left empty — open AP (no password) since `CONFIG_SENS_WIFI_PASSWORD` is empty too. Local `Sens/sdkconfig` flipped from `CONFIG_SENS_WIFI_MODE_STA=y` to `CONFIG_SENS_WIFI_MODE_AP=y` with empty SSID/password and `CONFIG_SENS_ESPNOW_CHANNEL=1`. STA mode Kconfig choice still exists (kept for diagnostics) but AP is now the active build.
- Cntl's `Kconfig.projbuild` help text for `CNTL_ESPNOW_CHANNEL` updated to drop the old "hand-match Sens's AP channel" caveat — both sides now default to channel 1 and that's expected to just work without manual tuning.
- **Both repos compiled clean for the first time this session** (`idf.py build`, IDF v6.0.1, via `. C:\Espressif\tools\Microsoft.v6.0.1.PowerShell_profile.ps1`). Sens built with zero changes needed beyond the SoftAP work above. Cntl needed two unrelated fixes to get its first-ever successful build — see [[cntl-scd41-lp-i2c-bug]] for the SCD41/DHT22 removal + `EXCLUDE_COMPONENTS` fix, and note LVGL's `CONFIG_LV_USE_FS_POSIX` (with `CONFIG_LV_FS_POSIX_LETTER=65`, i.e. 'A' — letter 0 fails `LV_FS_IS_VALID_LETTER`) and `CONFIG_LV_USE_TINY_TTF` had to be turned on in `Cntl/sdkconfig`, since `main.c`/`ui_font.c` already called those APIs but nobody had ever run a build to catch the missing Kconfig.
- **Still not implemented:** pairing handshake (`PAIR_REQUEST`/`PAIR_ACK`), the variable-tab summary+per-node dashboard on Cntl. The "노드" tab is still discovery-only display (no tap-to-pair). Not yet flashed/tested on real hardware together — only individually build-verified.

**Progress 2026-06-19 (later same session) — channel moved from duplicated per-project Kconfig to one shared header constant:**
- User pointed out the two `CNTL_ESPNOW_CHANNEL`/`SENS_ESPNOW_CHANNEL` Kconfig defaults (both =1) were a duplication risk — nothing stopped them drifting apart later. Replaced both with a single `#define ESP_NOW_LINK_CHANNEL 1` in the shared `Common/components/esp_now_link/include/esp_now_link.h` header (same file that already holds the wire-format version/message-type constants). Deleted `Cntl/main/Kconfig.projbuild` entirely (it only existed for that one option) and removed the `SENS_ESPNOW_CHANNEL` config block from `Sens/main/Kconfig.projbuild`. `esp_now_hub.c` and `wifi_dashboard.c` now reference `ESP_NOW_LINK_CHANNEL` directly instead of `CONFIG_CNTL_ESPNOW_CHANNEL`/`CONFIG_SENS_ESPNOW_CHANNEL`. Also cleaned the now-orphaned `CONFIG_*_ESPNOW_CHANNEL` lines out of both local `sdkconfig`s.
- **How to apply:** the channel is no longer something to configure per-build — it's a single compile-time constant both repos compile against from the same file. If the channel ever needs to change, edit `ESP_NOW_LINK_CHANNEL` in `esp_now_link.h` once; don't reintroduce per-project Kconfig options for it. Re-verified both Sens and Cntl still build clean after this refactor.

**CONFIRMED 2026-06-19 — final design direction + terminology (design-level agreement; most of this is NOT implemented yet, see gap list at the end). User reviewed and explicitly confirmed nothing is missing/wrong before this was saved.**

*Terminology locked in:*
- **AP (Access Point):** the side of a WiFi link that provides/hosts a network; other devices (STA) join it.
- **STA (Station):** a client that joins an AP.
- **SoftAP:** a device acting as its own AP in software (no dedicated router chip) hosting an **independent** network — not joined to, or a sub-node of, anyone else's network.
- **AP+STA (APSTA) simultaneous mode:** ESP32 chips can host a SoftAP *and* be a STA joined to another AP at the same time. Defined for completeness but **not used** in this design — Sens's `SENS_WIFI_MODE` choice is exclusively STA *or* AP, never both.
- **"Web service via AP-supplied IP":** serving HTTP on whatever IP address an AP hands out (own SoftAP's IP, or — dev-only — an external router's DHCP IP).
- **ESP-NOW:** connectionless 802.11 action-frame protocol. Needs no AP join/association — only requires both peers to be parked on the same WiFi channel. Coexists with that same radio also hosting/joining an AP, since it's a different protocol layer (confirmed: Sens already does SoftAP-hosting + ESP-NOW broadcast simultaneously today).
- **`ESP_NOW_LINK_CHANNEL`:** the single shared compile-time channel constant (see entry above) — the one true source for "what channel do all ESP-NOW peers agree on."
- A STA **cannot** dictate which channel an AP operates on — the AP alone decides its channel; STA only discovers and follows it. (No "channel hint" trick forces this; ESP-IDF's `wifi_sta_config_t.channel` is only a scan-speedup hint, not a requirement.) Corollary: home routers in practice rarely change channel mid-operation — usually only at AP reboot or rare background auto-optimization (mesh/ISP routers) — which is *why* the dev-mode shortcut below is usually stable, but it is explicitly **not guaranteed**, which is exactly why production avoids depending on it.

*Final/production architecture:*
- No device (Cntl or Sens) ever joins an external WiFi AP. **Every device hosts its own independent SoftAP.**
- Each device's SoftAP exists to serve **that device's own** web service — not a multi-device aggregator:
  - **Cntl**: has its own physical display (primary interface). Its web service is a secondary/auxiliary interface, not the main way to use it.
  - **Sens**: has no physical display in production (LEDs + buttons only). Its web service exists specifically for field-diagnostic/troubleshooting access (matches the older "정상 운영은 Cntl 통합 대시보드, Sens가 망가진 것 같을 때 개별 접속" reasoning above — still holds).
- Cntl ↔ Sens device-to-device communication is **ESP-NOW only**, independent of and coexisting with each device's own SoftAP hosting.
- All ESP-NOW peers share one fixed channel (`ESP_NOW_LINK_CHANNEL`), and each device's own SoftAP is also set to that same channel — channel alignment is guaranteed by construction, no coincidence/external dependency.
- **Correction to the older "Cntl aggregates all Sens data into one unified Cntl dashboard" note (line 53-54 above):** that framing is superseded. Cntl's web service is *its own* auxiliary interface (mirroring its own LCD content), not necessarily a multi-node aggregator — the aggregation/summary-tab concept lives on Cntl's physical display (per the original spec's variable-tab plan), the web side is just "the same thing, accessible without walking up to the device."

*Dev-stage architecture (temporary, convenience-only):*
- All devices instead join the **same** real external WiFi AP (router) via STA, each getting its own DHCP IP for its own web service.
- ESP-NOW between devices during dev only works reliably if every device is on **the same AP's same channel** (precise phrasing matters — "same channel" alone is imprecise; it's "same AP ⇒ same channel" since one AP only ever runs one channel).
- During dev, hand-set `ESP_NOW_LINK_CHANNEL` in `esp_now_link.h` to whatever channel that shared dev router actually uses (already empirically confirmed once this session: Cntl fixed at channel 1 successfully received Sens's broadcast while Sens was STA-joined to `iptime2.4`, proving that router is currently on channel 1).
- To let a developer visually verify "is everyone actually on the same AP channel," each device should display its current WiFi channel + IP on-device (or via its web dashboard). **Not implemented anywhere yet** — new UI work on both Cntl's LCD and Sens's web dashboard.

*Hardware/display roadmap:*
- **Dev stage:** both Cntl and Sens have a physical display attached (Sens's is bring-up-only touch LCD, per the original spec — not to be over-invested in).
- **Production:** only Cntl keeps a physical display (and its size will change from what's used today); Sens drops its display for LEDs + buttons.

*Known implementation gaps as of this confirmation (design is locked, code is not — don't claim any of this is built):*
1. Cntl has **no web server/HTTP code at all**. Needs new code mirroring Sens's `wifi_dashboard.c` pattern.
2. Cntl has **no real AP-STA-join code**. Current `esp_now_hub.c` deliberately never calls `esp_wifi_connect()` — it only parks the radio on `ESP_NOW_LINK_CHANNEL`. The dev-mode "join the same real AP" path doesn't exist on Cntl yet.
3. Cntl's current hardcoded `esp_wifi_set_channel(ESP_NOW_LINK_CHANNEL, ...)` call is incompatible with actually joining a real AP (channel is then dictated by the AP, manual override would conflict). Cntl needs a dev(STA-join)/production(SoftAP-host) mode switch mirroring Sens's `SENS_WIFI_MODE` Kconfig choice, and the manual channel-set call should only fire in the no-AP-join (production) path.
4. Channel + IP on-device display: doesn't exist on either Cntl's LCD tabs or Sens's web dashboard yet.
5. Pairing handshake (`PAIR_REQUEST`/`PAIR_ACK`, automatic mutual peer registration) — still not implemented (carried over from earlier in this same memory file).
6. Cntl's variable-tab summary + per-node dashboard (the original spec's end-goal UI) — still not implemented; the "노드" tab today is discovery-only, no tap-to-pair.

**Progress 2026-06-24 — gaps 5 and 6 implemented, plus Cntl web dashboard real-data, build-verified (not yet flashed):**
- Policy confirmed with user before implementing: on pairing, Sens **stops advertising** and switches to unicast `SENSOR_DATA` to the hub at the same 1s period. No re-pair/re-discover trigger exists yet (deliberately out of scope — revisit at production transition).
- `esp_now_link.h`: added `esp_now_pair_request_t` (hub_mac), `esp_now_pair_ack_t` (node_mac), `esp_now_sensor_data_t` (dht/scd41/batt/powered fields) — all packed, mirroring `esp_now_advertise_t`.
- Sens (`esp_now_node.c`): `recv_cb` now handles `PAIR_REQUEST` — registers hub as a unicast peer, stops the advertise timer, starts a new 1s `SENSOR_DATA` timer, replies `PAIR_ACK`. New `Sens/main/sensor-c6.h` + `sensor_c6_get_last_readings()` getter exposes the same cached values `wifi_dashboard_set_readings()` already uses.
- Cntl (`esp_now_hub.c/.h`): `esp_now_hub_node_t` gained `paired`/`last_data_ms`/sensor fields. `recv_cb` handles `PAIR_ACK` and `SENSOR_DATA`. New `esp_now_hub_pair(mac)` (called from UI) sends `PAIR_REQUEST`; new `esp_now_hub_get_summary()` computes max/min/avg across paired+alive nodes. `esp_now_hub_get_nodes()` freshness check now uses `last_data_ms` for paired nodes (since they no longer advertise) and `last_seen_ms` for undiscovered ones.
- Cntl UI: `ui_nodes.c` list buttons are now clickable (`LV_EVENT_CLICKED` → `esp_now_hub_pair()`); paired nodes show a checkmark + "(페어링됨)". New `ui_node_tabs.c/.h` adds a "센서 요약" tab (always present, shows aggregate stats) plus one tab per paired node (sensor readings), refreshed every 1s via `esp_now_hub_get_nodes()`/`get_summary()`.
- **LVGL constraint discovered:** this LVGL version (`managed_components/lvgl__lvgl`) has `lv_tabview_add_tab`/`lv_tabview_rename_tab` but **no tab-delete API**. Scope was deliberately narrowed to "tabs are added on pairing, never removed" — unpairing/offline-node tab cleanup is out of scope, not just unimplemented.
- Cntl web dashboard (`web_dashboard.c/.h`): replaced the "CNTL" placeholder with a real `/api/data` JSON endpoint (summary + per-paired-node array) and an HTML+JS page polling it every 1s, mirroring Sens's `wifi_dashboard.c` pattern (no history/modal, just live cards).
- **Both repos build-verified clean** (`idf.py build`, IDF v6.0.1) after this work. Sens's build hit an unrelated environment blocker mid-session — see [[project_windows_smart_app_control_blocks_toolchain]] — resolved by the user disabling Windows Smart App Control.
- **Not yet done:** real-hardware flash/pairing test (build-only verified this session), and the unpair/tab-cleanup + re-discovery-trigger scope deferred per the LVGL constraint and the user's explicit "out of scope for now" on re-pairing triggers.
