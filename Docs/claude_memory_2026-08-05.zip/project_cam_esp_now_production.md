---
name: project-cam-esp-now-production
description: "CAM production pipeline restored after the corruption investigation: SD storage + WiFi/ESP-NOW re-enabled on both sensors, ESP-NOW photo-transfer protocol got CRC32 + on-demand capture, CPU bumped to 240MHz. Automatic Light Sleep tried and reverted — broke the board."
metadata:
  node_type: memory
  type: project
  originSessionId: c3b6d079-8360-4bf9-b697-b5fab75849ba
  modified: 2026-07-28T09:52:20.104Z
---

Direct continuation of [[project-cam-dvp-corruption-investigation]] (2026-07-28), once the actual
corruption bug was resolved: restored the isolation-test bypasses to production, then extended the
CAM→Cntl ESP-NOW photo pipeline per explicit user requests.

**Production capture path restored**: `camera_init()` in `cam_node.c` was switched back from
dedicated-SCCB-GPIO (a debugging experiment matching `take_picture.c`, proven irrelevant to the real
bug) to sharing the I2C bus via `bsp_esp32s3_cam_init()` + `.sccb_i2c_port = BSP_CAM_I2C_PORT`
(`.pin_sccb_sda/scl = -1`) — required because the SD-card-enable pins on the IO expander
(CH32V003, address 0x24) live on the *same physical I2C bus* as the camera SCCB, so both need to be
devices on one shared bus, not two separate masters on the same pins (that errors/hangs). `app_main()`
now calls `bsp_esp32s3_cam_init()`, `cam_storage_init()` (SD/SDMMC), and the WiFi(AP)+ESP-NOW init
block unconditionally again — all three were previously `#if 0`'d out for corruption isolation and
have now been verified clean on **both boards** (SD mounts, `shot`→`ls`→`get` round-trips with
matching content, ESP-NOW inits without error). `camera_capture_one()` now saves via
`cam_storage_save_capture()` (SD, file_id = timestamp) instead of the temporary flash-partition
scaffold. All of that temporary diagnostic code has been deleted now that SD is confirmed working:
`flash_save_capture()`/`cam_node_flash_read_capture()` in `cam_node.c`, the `getflash` console
command in `dev_console.c`, and `getflash` support in `tools/cam_get.py` — don't recreate these,
`get <id>` (SD-based) is the one real path now.

**ESP-NOW photo-transfer protocol extended** (`Common/components/esp_now_link/include/esp_now_link.h`,
CAM's `esp_now_cam.c`, Cntl's `esp_now_hub.c`) — the existing META→CHUNK*→DONE chunked-transfer
scaffold (200-byte chunks, per-chunk send_cb-based ACK + 3 retries) was already solid and needed no
redesign, just two additions:
1. **CRC32 filled in for real**: `send_one_photo()` in `esp_now_cam.c` now streams the file once
   through `esp_rom_crc32_le()` (256-byte read chunks, then `rewind(fp)`) before sending META, so the
   `crc32` field is no longer the placeholder 0 it used to be. Cntl's `esp_now_hub.c` now stores that
   expected CRC from PHOTO_META and, on PHOTO_DONE, computes the CRC of the fully-reassembled buffer
   and logs a match/mismatch instead of only checking chunk *count*. This directly applies the
   lesson from the corruption investigation ([[feedback-dont-relitigate-ruled-out-hardware]]): chunk
   count matching is not proof the reassembled content is correct.
2. **On-demand capture-on-request**: added `PHOTO_REQUEST_MODE_CAPTURE_NOW = 3` to
   `photo_request_mode_t` — no new wire message type needed, it reuses the existing
   `esp_now_photo_request_t`/`ESP_NOW_MSG_PHOTO_REQUEST`. In `esp_now_cam.c`'s `photo_transfer_task`,
   this mode calls `cam_node_capture_now()` synchronously (safe here since this runs in the
   dedicated photo-transfer task, not the ESP-NOW recv callback) and then falls through as
   `PHOTO_REQUEST_MODE_LATEST` to send just that one new file through the existing pipeline.
   Cntl's CMakeLists.txt needed `esp_rom` added to `REQUIRES` for `esp_rom_crc32_le`. Both CAM (IDF
   6.0.2) and Cntl (IDF 6.0.1 — Cntl was **not** migrated to 6.0.2, only CAM was per the user's
   instruction, verify before assuming otherwise if this comes up again) build clean with these
   changes, but this has **not yet been tested end-to-end against a live Cntl board** — only
   verified in isolation (protocol logic reviewed, both sides compile). Cntl's own final handling of
   a received photo (save? serve on the web dashboard?) is still an open TODO in `esp_now_hub.c`,
   out of scope of this pass — currently it just CRC-checks and frees the buffer.

**CPU frequency bumped 160→240MHz** (`CONFIG_ESP_DEFAULT_CPU_FREQ_MHZ`) per user request to check
whether CPU/memory speed could bottleneck ESP-NOW transfer. PSRAM was already at Octal-mode 80MHz
(the practical max for this chip), nothing to change there.

**Automatic Light Sleep — tried, broke the board, reverted. Do not re-enable without a different
design.** Per the user's request for a low-power idle mode that still receives Cntl's ESP-NOW
requests, added the same `esp_pm_configure()` pattern already proven on Sens
(`min_freq_mhz == max_freq_mhz`, `light_sleep_enable = true`, no DFS) plus `CONFIG_PM_ENABLE=y`.
**On real hardware this made `shot`/`ls` console commands hang completely (4+ minutes, no response,
had to be force-killed)** — `esptool chip-id` still worked fine (ROM level, chip not bricked), so
this is an app-level interaction between light sleep and either the USB-Serial-JTAG console or the
camera DVP timing, not a dead board. Reverting `CONFIG_PM_ENABLE` and removing the
`esp_pm_configure()` call restored normal (~6 second) response immediately — confirmed light sleep
was the cause, not a fluke. **Left disabled in the code with a comment explaining this.** If revisited:
don't just flip it back on — either scope it to WiFi modem-sleep only (`esp_wifi_set_ps()`, no
`esp_pm_configure()`/light-sleep at all), or if actual light sleep is wanted, use `esp_pm_lock`
explicitly held during console/camera activity so sleep can only engage during genuinely idle
stretches, and re-verify the console still responds before trusting it. This is a case where "the
standard pattern from another board in the same family" (Sens) did not transfer cleanly — Sens
doesn't have a USB-Serial-JTAG dev console or DVP camera timing to worry about, CAM does.

**Single source, selectable per-sensor build (2026-07-28, finished)**: rather than hand-editing three
separate settings (XCLK, fb_count, JPEG framesize) every time the physical sensor changes, added one
Kconfig choice — `CAM_SENSOR_VARIANT` in `main/Kconfig.projbuild` (`CAM_SENSOR_OV5640` /
`CAM_SENSOR_OV3660`) — that drives everything else: `cam_node.c`'s `CAM_VIDEO_XCLK_FREQ_HZ`/
`CAM_VIDEO_FB_COUNT` are now `#if CONFIG_CAM_SENSOR_OV3660 ... #else ...` instead of bare `#define`s,
and `CAM_JPEG_FRAMESIZE`'s default is now `CAM_JPEG_5MP if CAM_SENSOR_OV5640` /
`CAM_JPEG_QXGA if CAM_SENSOR_OV3660` (still independently overridable for testing at a lower
resolution, as done constantly throughout this whole investigation). One source tree, switching
sensors is: flip `CAM_SENSOR_VARIANT` (menuconfig, or the two `CONFIG_CAM_SENSOR_OV*` lines in
`sdkconfig` directly), reconfigure (`cmake -G Ninja -S . -B build`, not just `ninja` — new Kconfig
symbols need a real reconfigure pass), rebuild, reflash. Verified on real hardware **both ways**
after the refactor (OV5640 5MP on COM5, OV3660 QXGA on COM17) — checked-in `sdkconfig` is left at
`CAM_SENSOR_OV5640` (matches the Kconfig's own stated default). There is deliberately no runtime
auto-detect/hot-swap (ruled out by the user up front — a rebuild+reflash per sensor swap is accepted).

**Tooling gotcha found while debugging the above (false alarm, but costly)**: right after this
refactor, `cam_get.py COM5 shot` failed 3 times in a row with the exact "XCLK too low for 5MP"
signature (NO-EOI + 15s timeout), which looked like the refactor had silently resolved to 20MHz
instead of 24MHz. It hadn't — `sdkconfig.h` confirmed `CONFIG_CAM_SENSOR_OV5640` was correctly the
only one defined. The real cause: **opening the serial port via pyserial does not reliably reset
this board's USB-Serial-JTAG target every time** — the boot-log timestamps across those 3 "attempts"
kept climbing (23s → 46s → 114s) instead of restarting near 0, proving they were all still the same
original (apparently wedged) boot session, not 3 independent fresh boots. An explicit
`esptool ... chip-id` (which reliably forces "Hard resetting via RTS pin...") before retrying
immediately fixed it — two clean fresh-boot captures both succeeded. **Lesson**: if a board that was
proven working suddenly fails repeatedly right after a change, don't trust `cam_get.py`'s own
"리셋 후 부팅 대기" framing as proof of a fresh boot — check the log timestamp (should be small,
single-digit-to-teens seconds) or force a real reset via `esptool chip-id`/`chip_id` first, *before*
concluding the change broke something. This cost real time diagnosing a phantom regression.

**How to apply**: for any future work on CAM's ESP-NOW pipeline or power management, read this
memory before assuming SD/WiFi/shared-I2C-bus is broken (it isn't — that was the whole point of the
corruption investigation) and before re-attempting light sleep (it broke things once already, empirically,
not just in theory). Before concluding a fresh code change broke camera capture, force a real reset
(`esptool chip-id`) and check the log's own uptime timestamp before trusting a failure as reproducible.
