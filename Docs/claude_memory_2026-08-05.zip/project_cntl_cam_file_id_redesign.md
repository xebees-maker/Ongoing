---
name: project-cntl-cam-file-id-redesign
description: "2026-08-01: CAM photo file_id redesigned from a 10-digit Unix timestamp to a short shared M/T base36 sequence, with capture time sent as a separate wire field"
metadata:
  type: project
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-08-01T14:41:40.236Z
---

CAM's photo `file_id`/filename scheme was redesigned end-to-end (CAM storage + wire protocol + Cntl
display) on 2026-08-01, replacing the original "file_id = capture-time Unix timestamp, also used as the
filename" design.

**New scheme:**
- CAM filenames: `<kind><4-char base36>.jpg` (e.g. `M002A.jpg`) — `kind` is `'M'`(manual)/`'T'`(auto),
  the 4 base36 digits (0-9,A-Z) are a **sequence number shared between M and T** (36^4 = 1,679,616
  values, vs. the 500-file resident cap, so wraparound never realistically collides).
- No separate counter file on SD — `cam_storage.c`'s `enforce_capacity_and_get_next_seq()` derives the
  next sequence by scanning existing files, sorting by FAT mtime, and taking `(newest.file_id + 1) %
  CAM_STORAGE_SEQ_MOD`. This was the user's explicit direction ("마지막 날짜/시간의 파일명에서 계속
  순환 증가시키면 됨") over a persisted `.seq` file.
- `file_id` on the wire (`esp_now_photo_list_entry_t` in `Common/components/esp_now_link/include/esp_now_link.h`)
  is now just this sequence number — **not** a timestamp. Capture time is a **separate** `capture_time`
  field, populated from the file's real FAT mtime (`cam_storage_stat()`'s new `out_capture_time` param),
  and `kind` is also a separate explicit byte field. This was a deliberate "do it properly" correction —
  see [[feedback_dont_encode_metadata_in_ids]] for the underlying principle the user stated.
- Sorting/filtering that used to compare `file_id` as a timestamp (`enforce_capacity`, `PHOTO_REQUEST_MODE_LATEST`,
  `PHOTO_REQUEST_MODE_RECENT_HOURS`) now all sort/filter by FAT mtime instead (`cmp_by_mtime` in
  `cam_storage.c`) — file_id carries no time-ordering information anymore.
- Cntl's list row (`ui_main.c`, `refresh_photo_list_ui`) now shows `<kind><file_id>  <capture_time as
  MM-DD HH:MM:SS> (<size>KB)`.

**Consequence flagged and accepted by the user:** old photos captured under the previous filename format
(`M<10-digit-timestamp>.jpg`) became invisible to the new scan logic after reflashing (different filename
length) — they still occupy SD space but are no longer listed/manageable through the app. User was told
this explicitly before flashing and said to proceed anyway.

**How to apply:** if touching CAM photo storage/listing/deletion again, read `cam_storage.c` fresh — this
memory is for orientation (why the format looks the way it does), not a substitute for reading the current
code.
