---
name: sens-scd41-timing
description: "Sens SCD41 sample interval and stale-watchdog timeout are currently tight debug values, will be increased significantly for production"
metadata: 
  node_type: memory
  type: project
  originSessionId: ea523f87-b6d2-47f1-ba7c-aac304e9e417
---

`SAMPLE_MS` (Sens/main/sensor-c6.c, currently 3000ms) and `STALE_TIMEOUT_MS` (Common/components/sensor_scd41/scd41.c, currently 16000ms — see [[sens-scd41-recovery]]) are deliberately tight for active debugging of the SCD41 brownout-recovery logic.

**Why:** User stated these will be increased significantly once the product moves past bring-up/debugging into a production build — the short intervals are only to make recovery testing fast to observe.

**How to apply:** Don't treat 3s/16s as the "right" production values when reviewing or extending this code later — expect them to grow. Don't push back on raising them when asked; that's the planned direction, not a regression.
