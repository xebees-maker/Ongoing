---
name: reference-cntl-cam-com-ports
description: "Which COM port maps to which board (Cntl vs CAM) when both are plugged in — volatile, re-verify each session"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-08-05T00:00:00.000Z
---

Current mapping (as of 2026-08-05, this session's USB layout): **Cntl = COM12, CAM = COM13**.
(Earlier seen: 2026-08-01 had Cntl=COM18, CAM=COM5 — confirms this really does change between sessions/machines,
don't reuse any past mapping without re-checking.)

**Why this needs re-checking, not blind reuse:** the user explicitly warned this can change between sessions
("또 바뀔 수 있지만, 현재 session에서는 그대로야") — Windows reassigns COM numbers based on USB port/hub and
plug order, not board identity. Both boards enumerate identically (`USB Serial Device`, `VID_303A&PID_1001`,
ESP32-S3 USB-Serial-JTAG) — `esptool.py --port COMx chip_id` can't disambiguate them either since both projects
target the same chip ([[reference-espidf-manual-build-env]] confirms both are esp32s3).

**How to apply:** at the start of a session that needs to flash/monitor either board, list ports
(`Get-CimInstance -ClassName Win32_PnPEntity | Where-Object { $_.Name -match 'COM\d+' }`) and ask the user
to confirm which is which if more than one Espressif device shows up — don't assume this session's mapping
carries over. Once confirmed for the session, it's safe to reuse for subsequent commands in that same session.
