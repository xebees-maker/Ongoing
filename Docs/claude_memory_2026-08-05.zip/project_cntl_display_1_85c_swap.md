---
name: cntl-display-1-85c-swap
description: "Cntl (ESP32-S3 hub) display swapped from rectangular 1.47 to round Waveshare ESP32-S3-Touch-LCD-1.85C V2 — BSP, drivers, pin map, and bugs fixed"
metadata: 
  node_type: memory
  type: project
  originSessionId: bb120d6f-b2b7-438a-afdc-01fae1be2eeb
---

2026-06-24/25: Cntl's physical board changed from Waveshare ESP32-S3-Touch-LCD-1.47 (rectangular, jd9853+axs5106) to **ESP32-S3-Touch-LCD-1.85C V2** (round 360×360, COM12). User's framing: "기성품 그대로 쓰다가 다시 바꿀거야" — low-investment, will likely swap to yet another board later, so no round-display-aware UI redesign was done (out of scope, deliberate).

**Confirmed pin map (V2, cross-checked against user-provided schematic PDF + Waveshare's official GitHub demo `waveshareteam/ESP32-S3-Touch-LCD-1.85C`):**
- LCD (QSPI via FPC): CS=GPIO21, SCK=GPIO40, D0=GPIO46, D1=GPIO45, D2=GPIO42, D3=GPIO41, TE=GPIO18, BL=GPIO5 (LEDC PWM). **LCD_RST is NOT a direct GPIO — it's TCA9554 IO-expander EXIO2.**
- Touch (I2C, CST816, addr 0x15): SDA=GPIO11, SCL=GPIO10, INT=GPIO4. **TP_RST is also not direct GPIO — TCA9554 EXIO1.**
- TCA9554PWR IO expander: addr 0x20, same I2C bus as touch.
- Battery ADC: GPIO8 = ADC1_CH7, divider R2=200K/R11=100K (ratio 3.0, same ratio as old board coincidentally), **no gating P-MOSFET** (old 1.47 board had one on GPIO14) — always-on divider, so `ctrl_gpio` must be `GPIO_NUM_NC`.

**New components added (mirrors existing jd9853/axs5106 pattern):**
- `Common/components/io_expander_tca9554/` — vendored from Waveshare's `TCA9554PWR.c/h`, decoupled from their global `esp_ret_i2c_handle()` to take an `i2c_master_bus_handle_t` param instead.
- `Common/components/esp_lcd_touch_cst816/` — vendored from Waveshare's `CST816.c/h` (their own `esp_lcd_touch_new_i2c_cst816`, not the registry's `esp_lcd_touch_cst816s` package — different driver). Depends on `io_expander_tca9554` for its EXIO1-based reset.
- `espressif/esp_lcd_st77916` (registry managed component, NOT vendored) for the actual panel driver.
- `Cntl/components/bsp_ws_1_85c/` — new BSP mirroring `bsp_ws_1_47`'s exact public API (`bsp_board_init`, `bsp_display_set_brightness`, `bsp_get_lvgl_display`, `bsp_get_i2c_bus`, `bsp_lvgl_lock/unlock`, `bsp_indev_set_hook`) so `main.c`/`ui_screen.c`/`ui_input.c`/`ui_common.h` only needed an `#include` swap.

**Bugs hit and fixed during bring-up:**
1. **Old BSP silently won at link time.** Removing `bsp_ws_1_47` from `main`'s `REQUIRES` wasn't enough — this IDF build is non-minimal (builds every discovered component regardless of dependency graph), and both BSPs export identically-named symbols (`bsp_board_init` etc.) as plain extern functions. The linker resolved them from whichever static archive came first, silently running the **old board's init code** against the new hardware (visible only via serial TAG mismatch: logs said `bsp_ws_1_47` and `172x320` despite the new BSP being "linked"). Fixed by adding `bsp_ws_1_47` to top-level `Cntl/CMakeLists.txt`'s `EXCLUDE_COMPONENTS` (same mechanism already used there for `sensor_dht22`/`sensor_scd41`).
2. **fonts LittleFS partition empty on first flash.** `idf.py flash` doesn't touch the custom `fonts` partition (0x810000, used for the TTF font — see `main/fs.c`/`ui_font.c`). On a never-before-flashed physical board this caused an LittleFS mount failure → `ESP_ERROR_CHECK` abort loop. Fixed by flashing the pre-built `Cntl/fonts.bin` directly: `python -m esptool --chip esp32s3 --port COM12 write-flash 0x810000 C:\Projects\Ongoing\Cntl\fonts.bin` (the repo's `C:\Projects\flash_fonts.bat` has stale port/path, don't trust it blindly).
3. **Display flicker then frozen single frame (garbled horizontal bands + edge vignette).** Initially skipped Waveshare's register-0x04-probe + vendor-specific 188-command ST77916 init table ("기성품 최소 구성" — minimal/default init only). This particular panel batch needs the vendor table (probe read `00 02 7f 7f`, exactly the pattern Waveshare's code checks for). Fixed by porting the full probe-and-select logic + the `bsp_st77916_vendor_specific_init_new[]` table into `bsp_ws_1_85c.c`'s `bsp_lcd_init()`, including the two-stage IO-handle creation (slow 3MHz probe read, then recreate at full `BSP_LCD_PIXEL_CLK_HZ`) — matches Waveshare's `QSPI_Init()` exactly. **If this board class is ever encountered again (or a sourced-differently panel batch), always port this table — don't assume the registry driver's generic default init is sufficient.**
4. **Swipe-to-tab freeze (LVGL bug, not board-specific)** — see [[feedback_lvgl_tabview_addtab_during_swipe]].
5. **Battery always read 0%** — `ui_dashboard.c` still had the old 1.47 board's battery ADC config (GPIO12/ADC_UNIT_2/GPIO14 gating pin) hardcoded; ported to new pin map (see above). Turned out the board's physical power switch was also off during testing, which independently also reads 0% — both the pin fix and flipping the switch were needed; confirmed working after both.

**How to apply:** if Cntl's board changes again (user explicitly said this is likely), this memory has the full bring-up checklist — schematic-cross-referencing approach, vendoring pattern, and all four gotchas above are very likely to recur in some form (especially #1 EXCLUDE_COMPONENTS and #2 fonts partition, which are project-structure issues independent of which board is attached).
