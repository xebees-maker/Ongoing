---
name: feedback-bash-blanket-approved
description: Bash tool calls no longer need per-command permission-prompt approval in this environment — user explicitly turned it off 2026-07-23
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c3b6d079-8360-4bf9-b697-b5fab75849ba
  modified: 2026-07-23T08:26:47.253Z
---

`Bash(*)` was added to `c:/Projects/Ongoing/Cntl/.claude/settings.local.json`'s permissions allow
list on 2026-07-23, at the user's explicit and repeated request, after a long debugging session
where the previous allowlist only had narrow exact-string entries (specific `idf.py build ...`
invocations, specific `git` subcommands, etc.) that didn't cover new commands (python scripts,
esptool, ninja, etc.), causing a permission prompt on nearly every Bash call.

**Why**: user was audibly frustrated ("내가 왜 일일이 답하는라고 쓸데없이 컴퓨터 앞에 앉아있어야
하냐" — why do I have to sit here answering one by one) during a multi-step hardware debugging loop
(build → flash → capture → fetch → verify) where every step is a new, slightly different Bash
command that could never have been pre-enumerated in a narrow allowlist. See
[[no-step-confirmation]] for the related "don't stop for per-step confirmation" guidance — this is
the mechanical enabler for that, since the permission system was interrupting even when I wasn't
choosing to ask.

**How to apply**: don't hesitate before routine Bash calls (builds, flashing, running scripts,
python one-liners, file inspection) in this project going forward — they're pre-approved. This does
NOT relax my own judgment about genuinely destructive/irreversible actions (force-push, `rm -rf`,
`git reset --hard`, etc.) — those still warrant pausing to confirm per the core safety guidance,
independent of whether the permission system itself would prompt.
