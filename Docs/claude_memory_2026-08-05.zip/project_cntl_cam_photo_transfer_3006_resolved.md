---
name: project-cntl-cam-photo-transfer-3006-resolved
description: "RESOLVED 2026-08-04: ESP-NOW photo fetch timeout (UI_ERR_FETCH_NORESPONSE/3006) that survived the 2026-08-03 streaming+NACK redesign — root cause was single-send DONE/NACK messages with no redundancy under real WiFi-channel TX queue saturation"
metadata:
  type: project
---

Follow-on to the 2026-08-03 streaming+NACK redesign (commit `fc3ce80`), which made chunk delivery itself
reliable but left two messages as single, non-redundant `esp_now_send()` calls: `PHOTO_DONE` (CAM→Cntl)
and `PHOTO_CHUNK_NACK` (Cntl→CAM). `PHOTO_META` had already been given 3x resend for the same class of
risk — the asymmetry (META redundant, DONE/NACK not) is what caused this.

**Diagnosis method that worked**: read the full CAM (`esp_now_cam.c`) and Cntl (`esp_now_photo.c`) source
end-to-end first, then captured CAM's own `CKPT:` serial log (no user interaction needed except tapping
"fetch" once) rather than guessing — this is what [[feedback-dont-use-user-as-test-oracle]] asks for and it
worked: the log showed exactly which chunk indices failed and which message sends returned
`ESP_ERR_ESPNOW_NO_MEM`.

**What the log actually showed (first capture, on real hardware, WiFi channel 6 which the AP always uses)**:
36 of 70 chunks (indices 32–69) exhausted all 10 retries (5ms apart) with `ESP_ERR_ESPNOW_NO_MEM` — the
driver's outbound TX queue saturated partway through the burst and **stayed saturated**, not a transient
blip. All 3 attempts at the trailing `DONE` also failed for the same reason. Cntl therefore never got a
`DONE`, chunk-progress counter froze, and after the UI's 8s stall timer fired → 3006.

**Fixes applied (`CAM/main/esp_now_cam.c`, `Cntl/main/esp_now_photo.c`)**:
1. `DONE` sent 3x like `META` (both the initial post-streaming send and the post-NACK-resend
   re-confirmation).
2. `resend_chunks()` (the NACK-round retransmit path) brought up to the same NO_MEM-retry standard the
   main streaming loop already had — it had none at all previously (silent single-attempt send).
3. Widened NO_MEM retry backoff 5ms→20ms (attempts 10→6) and inter-chunk pacing 4ms→10ms, in both the main
   loop and `resend_chunks()` — after this, a retest showed only 3/70 chunks failing (down from 36/70).
4. Cntl's `handle_done()` NACK send (the reply asking CAM to resend specific missing chunk indices) also
   given the same 3x-send treatment — a second-round log showed CAM's queue had recovered enough to accept
   the (few) missing chunks and DONE, but Cntl's single NACK reply back to CAM never arrived ("NACK 안 옴"
   in CAM's log), so the same single-send fragility existed in the *other* direction too.

**Verified end-to-end on real hardware** after each incremental fix (not just "builds clean") — user
confirmed "잘 가져오네" after fix #4 landed. Committed `cac2584`, pushed.

**How to apply**: if this or a similar transfer regresses again, re-check first whether it's this exact
class of bug recurring elsewhere in the protocol — any `esp_now_send()` in this pipeline that is called
exactly once for a message the other side has no independent way to request again (unlike chunks, which
NACK already covers) is a same-shaped risk. Also: WiFi channel congestion (shared with the AP's real
traffic, not an isolated test network) makes TX-queue saturation much more likely/severe than it was during
earlier isolated testing — don't assume timing constants tuned in a quiet-channel session still hold once
the AP is doing real traffic on the same channel.

**Superseded 2026-08-05**: the ad-hoc per-message resend counts described above were replaced by a general
3-layer redesign — see [[project_cntl_cam_esp_now_reliability_layers]]. 3006 recurred once more even after
this fix (after ~20 successful fetches) for a different reason (channel-sync PING queue-delay, not TX
saturation) — also documented there, fixed via `esp_now_channelsync_notify_alive()`.
