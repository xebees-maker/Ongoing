---
name: feedback-confirm-understanding-before-acting
description: "User wants explicit 'understood/not understood' acknowledgment after they explain something, before jumping into implementation"
metadata:
  type: feedback
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-08-02T12:26:45.466Z
---

When the user explains a design point, correction, or principle (e.g., an architectural rule like Model/View
separation), respond first with a clear statement of what was understood (or a clarifying question if not),
and wait for their confirmation/correction — THEN proceed to implement. Don't silently jump straight into
edits right after their explanation.

**Why:** stated directly: "너에게 바램이 있어. 뭘 설명하면 알았다/몰랐다를 답하고 다음 실행을 하면 참
좋겠어. 갑자기 뭔가를 하지 말고." (I want you to respond with understood/not-understood when I explain
something, then act — don't just suddenly do something.) This came after a stretch where the same
Model/View-separation principle had to be repeated three times ([[project_cntl_cam_todo_2026_08_02]] session,
2026-08-02) — each time I re-implemented based on my own interpretation without checking it back with the
user first, so misunderstandings compounded across multiple rounds of code+reflash before surfacing.

**How to apply:** especially for architectural/design feedback (not simple factual corrections) — restate
the understood rule in my own words (briefly) before writing code. This is a stronger version of
[[feedback_confirm_before_editing]]: that memory covers asking before self-proposed edits; this one covers
confirming comprehension of explicitly-taught principles before the next action, even mid-task.
