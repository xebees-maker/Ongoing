---
name: sens-sleep-mode-spec
description: "Spec for Sens headless node power-saving/sleep mode (battery-only operation) — given by user 2026-07-17. Phase 1 (SCD41 single-shot duty-cycle + Automatic Light Sleep) implemented and hardware-verified 2026-07-19, committed 4f49b9e. Interval list revised from the original 2026-07-17 spec — see 2026-07-19 update below before trusting the old values."
metadata:
  node_type: memory
  type: project
  originSessionId: e6bca5a4-94d8-48b9-a20c-9b78862d2152
  modified: 2026-07-19T12:39:55.948Z
---

**2026-07-19 UPDATE — read this first:** hardware wiring/bring-up (battery ADC, VIN detection, LEDs,
SCD41 I2C) completed and verified on real hardware this session (see [[sens-headless-sensor-family]]
for the wiring details). Phase 1 of this spec — SCD41 single-shot duty-cycling + Automatic Light Sleep —
is now implemented, hardware-verified, and committed (`4f49b9e`, Sens/Common only, not pushed). Scope for
this pass was explicitly narrowed with the user to **Sens/SCD41 only** — the Cntl UI interval picker and
the hub→node config-push protocol (both described below as "not yet designed") are deliberately deferred
to a follow-up session, as is sleep-mode for DHT22/SHT45/SHT40.

**Interval list changed from the original spec below**: 5s/10s/30s/1min/3min/10min is **superseded** by
**5s/15s/1min/3min/10min** (default **15s**, not 10s). Reason: the implementation's poll granularity is a
1-second base tick, and all five new values are exact multiples of both 1s and SCD41's 5s single-shot
floor — the original 10s/30s values weren't clean multiples of the initially-chosen 3s poll tick, which
caused a measured 12s-instead-of-10s drift before the fix (tightening the tick to 1s resolved it, and the
values were reconfirmed against that 1s base rather than re-widening the tick further). If Cntl UI work
picks this back up, use the new five-value list, not the old six-value one.

**What was implemented (2026-07-19, all in `Common/components/sensor_scd41/` and `Sens/main/`):**
- `scd41.c`/`.h`: continuous periodic-measurement mode (`scd41_init`/`scd41_read`, still used by the
  legacy LCD combo app) is untouched. New non-blocking API: `scd41_trigger_single_shot()` (sends the
  measure-single-shot command, ~5s to complete) and `scd41_poll_single_shot(co2, temp, humi, *out_ok)` —
  read logic shared with continuous mode via a new `read_measurement_frame()` helper. Also
  `scd41_stop_periodic_measurement()`, called once after `scd41_init()` in the duty-cycle path since
  `scd41_init()` always starts continuous mode first and both modes must never run simultaneously.
  **API design note**: `scd41_poll_single_shot()`'s return value means "this cycle concluded" (bool) and
  is separate from `*out_ok` (whether the read succeeded) — an earlier version conflated both into a
  single `bool` return, which meant a failed read after the 5s window was indistinguishable from "still
  measuring," and the caller would never re-trigger. Caught and fixed before hardware testing.
- `sensor_node.c`: SCD41-only trigger/poll state machine inside `sensor_read()`, driven by a 1-second base
  tick (`sample_cb`'s timer period is 1000ms for the SCD41 build specifically, vs the existing 3000ms
  `SAMPLE_MS` shared by DHT22/SHT45/SHT40 — untouched, out of scope this pass). `SCD41_CYCLE_MS = 15000`.
- `esp_now_node.c`/`.h`: `SENSOR_DATA` send period changed from a fixed 1s compile-time macro to a
  runtime setter `esp_now_node_set_data_period_ms()`, called with `SCD41_CYCLE_MS` from the SCD41 build's
  `app_main()` only — otherwise the radio would keep transmitting every 1s regardless of how slowly the
  sensor actually updates, defeating the point of duty-cycling.
- **Automatic Light Sleep chosen over manual `esp_light_sleep_start()`**: `esp_pm_configure()` with
  `light_sleep_enable=true` (min==max freq, no DFS) added to `app_main()` for the SCD41 build. This was a
  deliberate architecture choice — manual light-sleep would require restructuring the existing
  esp_timer-callback-driven sampling/ESP-NOW/status_led code into an explicit sleep/wake loop, which is
  real risk for uncertain benefit; Automatic Light Sleep needs zero changes to that existing architecture,
  since the PM subsystem transparently sleeps CPU during FreeRTOS idle gaps between existing timer/ESP-NOW
  events. Requires `CONFIG_PM_ENABLE=y` and `CONFIG_FREERTOS_USE_TICKLESS_IDLE=y` in `sdkconfig` (neither
  auto-enables from the other — had to set both explicitly) and `esp_pm` added to
  `Sens/main/CMakeLists.txt`'s `sens_requires`. **`sdkconfig` is gitignored — these two settings are NOT
  in the commit and must be manually re-enabled if sdkconfig is regenerated (e.g. clean build).**

**Hardware-verified 2026-07-19** (COM3, JP1-soldered board): SCD41 single-shot cycle lands within the
timer's own precision of exactly 15000ms (confirmed via two consecutive back-to-back measurements after
the 1s-tick fix). With PM+tickless-idle enabled: same 15000ms precision maintained, uptime counter
continuous with no resets/crashes, battery/VIN/LED behavior unchanged, broadcast ESP-NOW advertising
continuous. **Not yet verified**: actual unicast pairing handshake and paired SENSOR_DATA transmission
under PM — only broadcast advertising was tested, since Cntl was powered off for this session (needs
Cntl available to test; low risk given advertising already works, but not confirmed).

**Sequencing decision (confirmed with user 2026-07-17):** do the real LOLIN C3 Pico wiring + bring-up
experiment (confirm sensor read / ESP-NOW pairing / LED behavior / Cntl dashboard on real hardware)
**before** implementing sleep mode. Reasoning: sleep mode requires restructuring the esp_timer-based
periodic sampling into a light/deep-sleep wake-timer model, and layering that on an unverified hardware
baseline would make it impossible to tell whether a problem is wiring or sleep-mode related. See
[[sens-headless-sensor-family]] for the current architecture this builds on — GPIO pins in
`Sens/components/bsp_c3_pico/include/bsp_c3_pico.h` are still TODO placeholders blocking this anyway.

**Spec as given by the user (not yet implemented, revised 2026-07-17):**
- Sensor is sampled on a configurable interval, chosen from a fixed set: **5s / 10s / 30s / 1min / 3min /
  10min**. **Default = 10s.** (User initially included 1s, then dropped it themselves once told SCD41
  can't refresh faster than 5s anyway — see constraint note below.)
- The interval is set from the **Cntl UI** (not locally on the Sens node) and pushed down to the node —
  implies a new config-push mechanism, likely a new ESP-NOW message type (protocol extension to
  `esp_now_link.h`, analogous to `PAIR_REQUEST`) since the current protocol is node→hub only
  (ADVERTISE/PAIR_REQUEST/PAIR_ACK/SENSOR_DATA, no hub→node config message exists yet).
- **UI requirement:** since a human picks this value directly (not just a config file), the Cntl UI needs
  to explain **"longer interval = longer battery life"** next to the choice — user explicitly asked for
  this framing to be part of the picker, not just an internal implementation detail.
- Between samples: stop/idle everything power-hungry, wake only to take the sensor reading, then go
  back to sleep. If ESP-NOW itself is a significant power draw, it's acceptable to also disconnect
  it and reconnect only when actually sending — user explicitly left this as "if needed," not mandatory,
  so don't over-build it before measuring actual power draw.

**Constraint discovered 2026-07-17, relevant to design — SCD41's own minimum cycle:** the current driver
(`Common/components/sensor_scd41/scd41.c`) uses `CMD_START_PERIODIC_MEASUREMENT` (0x21B1), Sensirion's
continuous periodic-measurement mode, which only produces a new result **every 5 seconds** internally —
this is a hardware/firmware constraint of the sensor, not a driver limitation. This is *why* 1s was
dropped from the interval list — it would mostly get "not ready" (same phenomenon the existing
3s-poll-vs-5s-cycle code already works around, just worse). The new shortest option, **5s, is right at
that limit** — still tight, a wake that lands even slightly before the sensor's internal cycle completes
will get a stale/not-ready read, worth keeping in mind at implementation time. SCD41 also supports a
**single-shot measurement** command (`measure_single_shot`, ~5s to complete, sensor otherwise idle) —
likely the right mode for longer intervals (30s+) where you actually want the sensor fully powered down
between wakes, whereas for the 5s/10s options just leaving periodic mode running continuously (no
stop/start per wake) is probably more efficient than repeatedly restarting it.
**How to apply:** when implementing, decide per-sensor-type whether to duty-cycle via single-shot
commands or leave periodic mode running based on the configured interval — this needs revisiting at
implementation time, not decided yet. DHT22/SHT4x don't have this constraint (single-shot by nature
already).

**Confirmed 2026-07-17: use SCD41's single-shot measurement command** (not continuous periodic mode) for
sleep-mode duty cycling — matches the "likely right mode for longer intervals" note above, now decided
for all intervals, not just 30s+.

**Power budget notes discussed 2026-07-17 (order-of-magnitude, ESP32-C3, not yet measured on real
hardware):**
- Deep sleep: ~single-digit to ~20µA (RTC timer wake only, everything else off).
- Light sleep: ~1mA-ish (RAM + some peripherals retained).
- WiFi/ESP-NOW radio active (needed for any TX/RX, ESP-NOW included — no AP/DHCP overhead but still
  needs the radio powered): tens to 100+mA while on, momentary TX spikes higher. ~1000x+ more than deep
  sleep just for having the radio on, independent of actual data volume.
- **Key tension for the wake→sample→sleep design:** radio warm-up/calibration cost on each wake can
  dominate over the actual packet TX cost, especially at short intervals (5s/10s) — whether to fully
  power down WiFi each cycle (max power savings, but re-pairing/re-advertise overhead + slower wake) or
  keep some radio state resident (faster resume, costs more baseline power) needs to be decided per
  interval length once measured on real hardware, not assumed. Deep sleep destroys ESP-NOW/WiFi driver
  state entirely (need to re-init from scratch each wake, including possibly re-pairing); light sleep can
  more plausibly keep WiFi driver state but the radio itself must still be explicitly told to power down
  to get any real savings — simply entering light sleep does not do this automatically.
- **Other power-saving opportunities identified (not yet implemented):**
  - CPU sleep depth (deep vs. light) is the dominant lever — everything else is secondary to this choice.
  - Green LED currently shows "steady on" while paired, which is the common-case state — that's
    continuous mA-level draw during what should be a sleep window. LEDs need to be off during the sleep
    portion of each cycle and only lit briefly in the awake window; also watch for GPIO pull-up leakage
    keeping an LED faintly lit during deep sleep unless the pin is explicitly held/isolated on sleep entry.
  - I2C sensor idle power is handled by switching to single-shot mode (above) — no separate action needed.
  - **Hardware-level, not software:** the board's voltage regulator quiescent current can dominate over
    MCU deep-sleep current in a deep-sleep-heavy duty cycle — worth checking against whatever regulator
    ends up on the actual LOLIN C3 Pico power path when wiring is finalized.

**Not yet designed/implemented:** the actual sleep/wake mechanism (light sleep vs. deep sleep — deep
sleep loses RAM including ESP-NOW pairing state, light sleep keeps peripherals but at higher power),
the Cntl-side UI for picking the interval, the hub→node config-push protocol message, LED sleep-safe
GPIO handling, and the deep-vs-light-sleep decision itself (pending real hardware power measurements).
