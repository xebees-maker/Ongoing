---
name: sens-headless-cntl-is-display
description: "Headless Sens nodes have no screen, but every reading/status is visible and settable via Cntl's dashboard — don't reason as if 'no screen' means 'no visibility/control'"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d2a70339-4940-4b26-9595-005e33c1c594
---

Headless Sens sensor nodes (LOLIN C3 Pico family — see [[project_sens_headless_sensor_family]]) have no
local display, but that does not mean their measurements or state are hidden. Every reading and status
value is surfaced through **Cntl's dashboard** (per-node tabs, summary tab, web dashboard — see
[[project_sens_cntl_esp_now]]), and settings can be pushed back down to the node from Cntl. The node
itself is headless; the system as a whole is not.

**Why:** User corrected me 2026-07-18 after I asked whether VBUS-present sensing was still worth keeping
on headless nodes "since there's no screen to idle-timeout anymore" — that framing was wrong. The original
VBUS-sense motivation (avoid screen idle-timeout while charging, see [[project_sens_vbus_sense]]) doesn't
carry over literally, but dismissing a feature just because "there's no screen" ignores that Cntl is the
real UI surface for headless nodes, not the node's own (nonexistent) display.

**How to apply:** When evaluating whether a headless Sens node needs a given sensing/status feature (VBUS
presence, sensor-fault, battery tiers, future settings, etc.), don't rule it out on "no screen" grounds.
Instead ask: is this worth surfacing on Cntl's dashboard, or should Cntl be able to configure/gate this
node-side behavior? The two status LEDs are a *local* fallback for at-a-glance checks with no Cntl link
required — they don't replace Cntl as the primary UI.
