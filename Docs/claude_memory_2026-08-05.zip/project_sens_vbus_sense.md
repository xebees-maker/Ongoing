---
name: sens-vbus-sense
description: "RESOLVED 2026-06-20: VBUS voltage-divider sense implemented on GPIO5, replaces USB-detection heuristic"
metadata:
  node_type: memory
  type: project
  originSessionId: ea523f87-b6d2-47f1-ba7c-aac304e9e417
---

**Problem:** `battery_is_usb_connected()` (in `battery_monitor`) only detects a real USB host via `usb_serial_jtag_is_connected()` — a charger with no data lines reads as "on battery", which wrongly let the screen idle-timeout while charging, and a software voltage-trend heuristic tried as a fix was also wrong (normal slow battery discharge is just as "flat" over a 1-minute window as a charged plateau, so it kept reporting "USB" while genuinely running on battery down to 75%).

**Decision (2026-06-19):** Sense VBUS directly instead of inferring it from battery voltage trends or the charge LED.
- Checked [[sens-schematic]] — the charge IC's STAT pin (driving the green charge LED) is not broken out to any GPIO, so reading the LED is not possible without tapping an inaccessible internal pad. Ruled out.
- VBUS *is* broken out on header `H1` pin 1 (user confirmed with a multimeter: ~5V when a USB source is connected, ~1V floating when not).
- Plan: external resistive divider from H1's VBUS pin to a spare GPIO (IO3, IO4, or IO5 — all broken out and unused; IO3 = ADC1_CH3 on ESP32-C6, picked as the default), then GND. Use **100kΩ + 100kΩ** (1:1 divider, ~200kΩ total) — gives ~2.5V at the ADC pin when VBUS=5V and ~0.5V when VBUS≈1V (unplugged), wide margin for a simple threshold check. ~25µA draw only while a USB source is actually present.
- Ruled out 330Ω (only resistor on hand at the time) — too much current (7.6mA). Ruled out going much higher than 100kΩ — diminishing current savings, and higher source impedance starts to hurt ESP32 ADC sample-and-hold settling/noise immunity (this board is already sensitive to interrupt/timing noise — see DHT22 bug in the handoff doc).

**Status: RESOLVED 2026-06-20.** Implemented and wired. The originally planned pin (IO3) and the next guess (IO7) both turned out to be wrong — see [[feedback_verify_gpio_before_recommending]] for why. Final pin is **GPIO5** (H1's `IMU_INT1` net — shares the onboard QMI8658 IMU's INT1 line, but no firmware driver touches it, and it carries no board pull-up unlike IO1-4/IO6-9). Measured: USB connected ~2.3V at the ADC pin, battery-only ~0V — wide margin, threshold set at 1200mV (`VBUS_PRESENT_MV` in `sensor-c6.c`).

Code: `vbus_is_present()` in `Sens/main/sensor-c6.c` reads `ADC_CHANNEL_5` on the same ADC unit battery_monitor already owns (`battery_get_adc_handle()`, added to `Common/components/battery_monitor`). This fully replaced `battery_is_usb_connected()` + the flawed voltage-trend heuristic (`battery_trend_is_powered()`) that used to guess USB presence. Committed locally as `d4d6a98` (not yet pushed to origin). Build not yet verified — no ESP-IDF in that session's shell; needs `idf.py build` in a proper IDF terminal before flashing. Details in `Sens/.claude/memory/handoff_2026-06-20.md`.
