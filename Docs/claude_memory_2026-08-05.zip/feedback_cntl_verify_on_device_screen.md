---
name: feedback-cntl-verify-on-device-screen
description: "When verifying CNTL (phone-web + local touchscreen dual-UI) features during development, demo/check via CNTL's own physical screen, not just the phone web page"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c3b6d079-8360-4bf9-b697-b5fab75849ba
  modified: 2026-07-28T12:02:14.432Z
---

User's own words: "개발은 폰이 더 쉽지만, 내가 개발 중간 단계에서 확인하기에는 주장치 화면이 더 편해"
(development is easier on the phone [web UI], but for checking things during intermediate dev
stages, the main device's [CNTL's] own screen is more convenient for me).

This came up while planning CNTL Stage 1 (see [[project-cntl-stage1-plan]] if it exists, or the
CNTL system-spec conversation) — CNTL exposes every feature (Sens value reading, Sens option
setting, CNTL option setting, SSR control) through *both* a phone-facing web page and CNTL's own
local LVGL touchscreen, with a shared backend and two thin presentation layers per the user's
explicit parity requirement ("폰에서 보고 제어하는 것과 주장치 화면에서 보고 제어하는 내용은
동일해야해. 형태는 다를 수 있고").

**Why**: building/iterating is genuinely faster via the web UI (no LVGL rebuild/reflash cycle
needed for quick checks), but the user's own preferred way to confirm something actually works is
looking at the physical device screen, not a browser.

**How to apply**: when reporting progress or asking the user to confirm a CNTL feature works, default
to showing/describing what appears on CNTL's own touchscreen, not just the phone web page — even if
the web version was what got built/tested first internally for speed. If only one side is done at a
checkpoint, say so explicitly rather than assuming the web-side check is an equivalent stand-in.
