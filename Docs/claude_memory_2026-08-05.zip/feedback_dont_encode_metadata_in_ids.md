---
name: feedback-dont-encode-metadata-in-ids
description: "User's design principle: don't derive/encode metadata (like timestamps) from IDs or filenames — fetch structured fields separately"
metadata:
  type: feedback
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-08-01T14:41:58.020Z
---

Don't design an identifier (file_id, filename, etc.) to double as a data field by encoding/parsing
meaning out of it (e.g. "file_id IS the Unix timestamp, so derive capture time by parsing it"). Instead,
treat each piece of info as its own field, fetched/sent explicitly — "정석대로 가자고. 파일명에서 날짜
시간을 뽑지 말고, 파일정보 (파일명, 날짜/시간/크기) 이렇게 받아야지." ("let's do it the proper way. Don't
extract date/time from the filename — receive file info as [name, date/time, size] separately.")

**Why:** surfaced during the [[project_cntl_cam_file_id_redesign]] discussion — the original design used
file_id as both a unique identifier *and* an implicitly-parseable Unix timestamp for display, and reused
that same encoding trick for the M/T capture-kind prefix character (stripped during list-protocol parsing
and never transmitted, which is what triggered the whole conversation once the user noticed kind wasn't
visible anywhere in the UI). The user considers this "어렵게 구현했네" (an overly convoluted way to build
it) once it was explained — the ID should just be a unique handle; anything else the caller needs (time,
kind, size, name) should be its own explicit field, sourced from wherever it actually lives (e.g. the
filesystem's real mtime, not a value smuggled into an identifier).

**How to apply:** when designing a protocol message, storage key, or identifier scheme for this user's
projects, keep IDs opaque/unique-only. If a consumer needs a derived property (time, kind, category,
size...), add it as its own field populated from its authoritative source, not parsed back out of the ID.
