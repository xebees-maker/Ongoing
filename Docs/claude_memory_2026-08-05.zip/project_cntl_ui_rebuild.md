---
name: project-cntl-ui-rebuild
description: "Cntl's new UI (on cntl_incremental_test, esp_lvgl_adapter base) — user's screen terminology, string-table i18n pattern, and current screen structure as of 2026-07-31"
metadata:
  node_type: memory
  type: project
  originSessionId: 010a87cc-1d58-440e-b47d-76065ed3ab3c
  modified: 2026-07-31T13:45:31.971Z
---

Follows [[project-cntl-4-3b-bsp]] (that memory covers the display bring-up bug/resolution; this one
covers the UI actually being built on top, starting 2026-07-31). Working files:
`cntl_incremental_test/main/ui_main.c`, `ui_strings.h/.c`, `ui_font.h/.c`.

**User's screen-element vocabulary — use these terms, not generic LVGL names, when discussing the
UI with the user:**
- **로고(logo)** — the title text top-left (currently "플렉스팜", a placeholder brand name)
- **로고아이콘(logo icon)** — the graphic next to the logo text (currently still the LVGL bird
  logo placeholder, `img_lvgl_logo` — a real Cntl logo asset doesn't exist yet)
- **로고부제(logo subtitle)** — the line below the logo. As of 2026-07-31 (later same day) this is no
  longer the static "Widgets demo" placeholder — it's a live hh:mm:ss clock (`s_clock_label`,
  `refresh_clock()` timer in `ui_main.c`), sourced from the board's PCF85063A RTC via `rtc_sync.c`.
  Confirmed working on real hardware. See [[project-cntl-cam-photo-list-rtc]] for the RTC details.
- **페이지콘트롤(page control)** — the overall tab view (`lv_tabview_create()`)
- **페이지탭(page tab)** — the individual tab buttons in the tab bar
- **판넬(panel)** — a generic layout container within a page (`lv_obj_create()`)
- **그룹박스(group box)** — a panel that always has a title, even with no content yet (Claude
  suggested this term over the user's initial "그룹", user accepted it)

**Current screen structure (confirmed working on real HW 2026-07-31):**
- 페이지콘트롤 with `tab_bar_size=75` (this display is always the "DISP_LARGE" demo-widgets size
  bucket at 800px width — `LV_HOR_RES < 720 → MEDIUM, else → LARGE`, so this is hardcoded, no need
  to branch on `disp_size` at runtime for this one fixed-resolution product)
- 로고 cluster restored in the tab bar's left half (`pad_left = LV_HOR_RES/2`, logo icon +
  로고 + 로고부제 all `LV_OBJ_FLAG_IGNORE_LAYOUT` positioned) — **this was explicitly requested
  back** after Claude's first UI pass dropped it; the user's instruction was "except the new
  Settings tab, restore it to before-the-edit state, including the demo's Profile/Analytics tab
  *content*" (not just the visual chrome) — so 상황판(Dashboard)/통계(Statistics) tabs currently
  call the vendored demo's own `lv_demo_widgets_profile_create()`/`_analytics_create()` directly as
  placeholder content, not real Cntl data yet.
- 3 페이지탭: 상황판(Dashboard) / 통계(Statistics) / 설정(Option — user calls it "Option" in
  English, not "Settings")
- 설정 tab has 4 그룹박스 stacked vertically (`LV_FLEX_FLOW_COLUMN`): 제어기(CNTL) /
  측정기(Sensor) / 영상(Camera) / 시스템(System). **Stale as of first-written (below is the
  2026-07-31 later-session state, see [[project-cntl-cam-photo-list-rtc]] for full detail on the CAM
  list/photo work):** 제어기's box now wraps its language row inside an actual `lv_list` container
  (user wanted list-view styling here specifically, unlike the Dashboard summary panel which was
  deliberately de-listified the same day for the opposite reason — see that memory for why both
  choices are correct in their own spot) — 라벨 "언어(Language)" left-aligned, 한글/English 라디오
  (checkboxes styled circular) right-aligned, taller row padding per user request. 영상 box now has a
  live CAM discovery/pairing list (탭하면 연결허용/연결해제 팝업). 측정기/시스템 boxes are still
  title-only empty shells, not built yet.

**String-table i18n pattern (`ui_strings.h/.c`)** — user wants Korean+English only (explicitly
ruled out other languages), switchable at runtime from the 설정 tab, decided *before* any label
code was written so nothing needed retrofitting:
- `ui_str_id_t` enum (`STR_TAB_DASHBOARD`, `STR_GROUP_CNTL`, `STR_LABEL_LANGUAGE`, etc.) + a
  `s_table[STR_COUNT][UI_LANG_COUNT]` string array + `ui_lang_set()`/`ui_lang_get()`/`ui_str(id)`.
  No persistence yet (language resets to `UI_LANG_KO` on reboot — NVS-backed persistence not
  requested yet).
- Proper nouns (CNTL/Sensor/Camera as the group box English names, "한글"/"English" as the
  button labels naming the languages themselves) are NOT run through the string table — only
  translatable *content* words are. Follow this same judgment call for new strings: ask "is this a
  name/label of the thing itself, or a description that changes meaning per language" before
  deciding whether it needs a table entry.
- Any new label added to the UI must call `refresh_lang_texts()` (or extend it) to be included in
  the live language-switch — a label added without wiring into that function will silently stay in
  whatever language it was created in, this is an easy thing to forget when adding new panels.

**Font notes:** all Korean-rendering labels need `ui_font_get(UI_FONT_SIZE_18)` explicitly applied
(or inherited from a styled ancestor like the tab bar) — LVGL's default Montserrat has no Hangul
glyphs. `ui_font.c` only pre-creates 12/18/30pt from the single loaded NanumGothic-Regular.ttf; no
bold/italic exists (TinyTTF doesn't synthesize styles, would need a separate bold `.ttf` file, and
NanumGothic doesn't have an official italic variant). Font size IS freely adjustable
(`lv_tiny_ttf_create_data_ex`'s `font_size` param, or `lv_tiny_ttf_set_size()` at runtime) if a
size outside the pre-created three is ever needed — don't assume only 12/18/30 are possible.

**Reaching into the vendored demo's internal (non-public) symbols:** `lv_demo_widgets_profile_create`/
`_analytics_create`/`_components_init`/`_title_create` and the `style_text_muted` global are
declared in `demos/widgets/lv_demo_widgets_components.h` etc., which is NOT reachable via the
public `lv_demos.h` and isn't on `main`'s include path — extern-declare them directly at point of
use (already done in `ui_main.c`) rather than fighting the include path. `lv_demo_widgets_components_init()`
must be called once before `profile_create`/`analytics_create` (it sets shared style/font globals
they depend on internally).

**How to apply:** next up (not yet done, no direction chosen yet) is filling in 측정기/영상/시스템
그룹박스 content, and eventually replacing the placeholder Profile/Analytics demo-widget content in
상황판/통계 with real Cntl data (sensor readings, ESP-NOW node status, etc. — see
[[project-sens-cntl-esp-now]] for what data exists to show). LVGL 9's `lv_subject_t`
observer/binding API was discussed as a possible way to wire real data to these widgets reactively
instead of the old poll-based `lv_timer_create()` pattern from the discarded `Cntl/main/ui_*.c` —
not decided yet, worth raising again once real data needs to flow into 상황판/통계.
