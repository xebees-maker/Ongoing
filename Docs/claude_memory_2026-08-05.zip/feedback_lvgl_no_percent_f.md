---
name: lvgl-no-percent-f
description: "LVGL's built-in lv_snprintf (CONFIG_LV_USE_BUILTIN_SPRINTF) does not support %f — never use float format specifiers in lv_label_set_text_fmt on Cntl or Sens"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: bb120d6f-b2b7-438a-afdc-01fae1be2eeb
---

Both Cntl and Sens build with `CONFIG_LV_USE_BUILTIN_SPRINTF=y` (LVGL's own minimal printf, not libc). That implementation does not support `%f`/`%.1f` — passing a float format specifier through `lv_label_set_text_fmt()` (or any `lv_snprintf` call) renders garbage, observed as a stray "f" character on screen instead of the number.

**Why:** discovered originally on Sens (`sensor-c6.c`), fixed there by converting floats to integer tenths before formatting: `int t10 = (int)(v * 10.0f + (v >= 0 ? 0.5f : -0.5f)); bool neg = t10 < 0; if (neg) t10 = -t10;` then `lv_label_set_text_fmt(lbl, "%s%d.%d", neg ? "-" : "", t10/10, t10%10)`. The same bug recurred on Cntl in `ui_node_tabs.c` (2026-06-24, new pairing/sensor-tab feature) and was fixed the same way — see `split_tenths()` helper in that file.

**How to apply:** whenever writing new LVGL label code on Cntl or Sens that displays a float (temperature, humidity, averages, etc.), never use `%f`/`%.Nf` in `lv_label_set_text_fmt`/`lv_snprintf`. Convert to integer parts first (tenths-split pattern above, or plain `(int)(v + 0.5f)` if no decimal needed) and format with `%d`. This does **not** apply to plain libc `snprintf` (e.g. JSON building in `wifi_dashboard.c`/`web_dashboard.c`) — those use the real C library sprintf and support `%f` fine; the restriction is specific to LVGL's own `lv_snprintf`/`lv_label_set_text_fmt`.
