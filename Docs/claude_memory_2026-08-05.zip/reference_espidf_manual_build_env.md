---
name: reference-espidf-manual-build-env
description: "How to run idf.py-equivalent ninja/cmake builds for Cntl/Sens directly from Bash/PowerShell tools in this environment, without idf.py itself working"
metadata:
  node_type: memory
  type: reference
  originSessionId: e6bca5a4-94d8-48b9-a20c-9b78862d2152
  modified: 2026-07-30T22:20:10.256Z
---

`idf.py` itself does not work directly in this environment's Bash/PowerShell tools — it recomputes its
own python venv path internally and ignores `IDF_PYTHON_ENV_PATH` overrides. Don't keep trying to fix
`idf.py` directly; instead drive `cmake`/`ninja` manually — this works fine and is what got Sens/Cntl
building clean on 2026-07-17 (see [[sens-headless-sensor-family]]).

**Current version to use: v6.0.2** (as of 2026-07-31). The user explicitly corrected this — after a
context reset ("죽었다 살아나면"), this memory kept regenerating v6.0.1 paths from stale habit even
though v6.0.2 is installed and is the one to use going forward. v6.0.1 is still present on disk but
is NOT the active version — don't default to it.

**Toolchain install layout on this machine** (installed via ESP-IDF Installation Manager/EIM):
- `IDF_PATH` = `C:\esp\v6.0.2\esp-idf` (the actual esp-idf clone — note this is a **different drive
  root** than v6.0.1's `C:\Dev\.espressif\v6.0.1\esp-idf`; don't assume the `IDF_PATH` location
  pattern carries over between versions, check the matching `Microsoft.v<X>.PowerShell_profile.ps1`
  each time a version bump is suspected)
- `IDF_TOOLS_PATH` = `C:\Espressif\tools` (ninja, cmake, ccache, both toolchains, python venvs for
  every installed version — shared across versions, stable location)
- python venv: `C:\Espressif\tools\python\v6.0.2\venv` (use `Scripts\python.exe` directly, or put
  `Scripts` on PATH — do NOT rely on `IDF_PYTHON_ENV_PATH` alone, `idf.py` ignores it as noted above)
- riscv toolchain (C6/C3): `C:\Espressif\tools\riscv32-esp-elf\esp-15.2.0_20251204\riscv32-esp-elf\bin`
  (there's also an older `esp-14.2.0_20260121` — use 15.2.0, it's the one pinned in
  `esp-idf/tools/tools.json`)
- xtensa toolchain (S3): `C:\Espressif\tools\xtensa-esp-elf\esp-15.2.0_20251204\xtensa-esp-elf\bin`
- ccache: `C:\Espressif\tools\ccache\4.12.1\ccache-4.12.1-windows-x86_64\ccache.exe` — must be on PATH
  *before* the compiler, or you get a cryptic `CreateProcess failed: The system cannot find the file
  specified.` from ninja (looks like a missing compiler, is actually a missing ccache wrapper).
- cmake: `C:\Espressif\tools\cmake\4.0.3\bin`; ninja: `C:\Espressif\tools\ninja\1.12.1\ninja.exe`

**Required env vars** (PowerShell, set all in one call — env doesn't persist across separate tool calls):
```powershell
$env:IDF_TOOLS_PATH="C:\Espressif\tools"
$env:IDF_PATH="C:\esp\v6.0.2\esp-idf"
$env:IDF_PYTHON_ENV_PATH="C:\Espressif\tools\python\v6.0.2\venv"
$env:ESP_IDF_VERSION="6.0.2"
$env:ESP_ROM_ELF_DIR="C:\Espressif\tools\esp-rom-elfs\20241011\"
$env:PATH="C:\Espressif\tools\ccache\4.12.1\ccache-4.12.1-windows-x86_64;C:\Espressif\tools\python\v6.0.2\venv\Scripts;C:\Espressif\tools\ninja\1.12.1;C:\Espressif\tools\cmake\4.0.3\bin;C:\Espressif\tools\idf-exe\1.0.3;<riscv-or-xtensa-bin-dir-above>;C:\Espressif\tools\esp-clang\esp-20.1.1_20250829\esp-clang\bin;$env:PATH"
```
(Values found in `C:\Espressif\tools\Microsoft.v6.0.2.PowerShell_profile.ps1`, the EIM-generated
profile — check that file first if any of these paths/versions look stale in a future session. If a
newer version shows up there later, re-verify `IDF_PATH`'s drive root specifically — it moved once
already between 6.0.1 and 6.0.2, from `C:\Dev\.espressif\...` to `C:\esp\...`.)

**Fresh configure + build** (skip configure if `build/CMakeCache.txt` already exists and is healthy):
```powershell
cd <ProjectDir>   # e.g. c:\Projects\Ongoing\Sens or Cntl
cmake -G Ninja -S . -B build -DIDF_TARGET=<esp32c6|esp32c3|esp32s3>
ninja -C build
```

**Adding a brand-new component directory won't be picked up by an incremental reconfigure** — ESP-IDF
caches the component directory scan. If you add a new `components/<name>/` folder and the build can't
find its header even though `Components:`/`Component paths:` in the configure log look right, the actual
symptom is that the new component is missing from `main`'s resolved `reqs` (check
`build/project_description.json` → `build_component_info.main.reqs`). Fix: delete
`build/CMakeCache.txt` and `build/CMakeFiles/` (or the whole `build/` dir if locked) and reconfigure from
scratch — don't waste time debugging `EXTRA_COMPONENT_DIRS` or include paths first, this is almost always it.

**How to apply:** use this recipe whenever asked to build/verify Cntl or Sens compile without the user
running it themselves via VS Code's ESP-IDF extension. Don't re-derive these paths from scratch each
time — they're stable for this machine's install, but re-check the profile `.ps1` for the currently
active version number before assuming last session's version string is still right.
