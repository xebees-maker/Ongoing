---
name: lvgl-tabview-addtab-during-swipe
description: Calling lv_tabview_add_tab() from a background timer while the user is mid-swipe freezes the LVGL UI and touch input on Cntl
metadata: 
  node_type: memory
  type: feedback
  originSessionId: bb120d6f-b2b7-438a-afdc-01fae1be2eeb
---

`lv_tabview_add_tab()` adds a child to the tabview's scrollable content container, which fires `LV_EVENT_LAYOUT_CHANGED` on that container, whose handler (`cont_scroll_end_event_cb` in `lv_tabview.c`) immediately calls `lv_obj_scroll_to_x()` to re-snap to the current tab index. If this happens while the user's finger is actively dragging (mid swipe-gesture, indev state `LV_INDEV_STATE_PRESSED` with an active scroll object), the forced scroll call collides with LVGL's own indev drag/scroll state machine and the UI **freezes completely — screen stops updating, touch stops responding, no crash/abort/watchdog**, confirmed on real hardware (Cntl, 2026-06-24/25).

This bit `Cntl/main/ui_node_tabs.c`, which calls `lv_tabview_add_tab()` from a 1-second `lv_timer` whenever a newly-paired ESP-NOW node needs its own tab — if that timer fires while the user happens to be swiping the tabview, the freeze reliably reproduces.

**Fix applied:** before creating a new tab, check `lv_indev_active()` + `lv_indev_get_state()` == `LV_INDEV_STATE_PRESSED` + `lv_indev_get_scroll_obj()` != NULL (i.e. an active drag/scroll in progress) and skip tab creation for that tick if so — retry on the next timer tick (1s later, imperceptible delay). See `indev_is_dragging()` in `ui_node_tabs.c`.

**How to apply:** this generalizes beyond this one file — **never call `lv_tabview_add_tab()` (or anything that changes the tabview's tab/page count) from a background timer/callback without first checking for an active indev drag**, anywhere in Cntl's LVGL code. Plain content updates inside already-existing tab pages (label text, etc.) are safe and don't need this guard — only structural changes to the tabview itself (tab count) are at risk.
