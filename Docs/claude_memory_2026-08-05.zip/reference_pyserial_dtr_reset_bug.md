---
name: reference-pyserial-dtr-reset-bug
description: "pyserial's default DTR=True on .open() resets ESP32-S3 boards even when no reset was requested — set dtr/rts False before opening"
metadata:
  type: reference
  modified: 2026-08-05T00:00:00.000Z
---

`serial.Serial(port, baudrate, timeout=...)` on Windows asserts DTR by default the moment the port opens.
On this project's ESP32-S3 boards (Cntl, CAM — both native USB-Serial/JTAG), that DTR pulse triggers the
auto-reset circuit, resetting the board — even for a plain read-only log capture with no reset intended.

Discovered 2026-08-05 after misdiagnosing this as a firmware crash ("CNTL이 가져오기하다가 리셋했어") — the
board was resetting exactly when a fresh serial capture script was started, not from any firmware bug. User
corrected the false diagnosis directly.

**Fix**: construct unbound, set `dtr`/`rts` False, then open:
```python
ser = serial.Serial()
ser.port = port
ser.baudrate = 115200
ser.timeout = 0.2
ser.dtr = False
ser.rts = False
ser.open()
```
Never `serial.Serial(port, ...)` directly for a non-reset capture on these boards.

**How to apply**: scratchpad Python serial-capture scripts are recreated fresh each session (scratchpad is
wiped between sessions) — this bug will recur unless this pattern is applied from the start. If a board
appears to reset "for no reason" right as a serial monitor/capture tool starts, check this first before
assuming a firmware bug.
