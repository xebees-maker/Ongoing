---
name: windows-smart-app-control-blocks-toolchain
description: Windows 11 Smart App Control can silently block ESP-IDF toolchain exes after idf.py fullclean re-fetches a new pinned version
metadata: 
  node_type: memory
  type: project
  originSessionId: bb120d6f-b2b7-438a-afdc-01fae1be2eeb
---

2026-06-24: `idf.py fullclean` on Sens (ESP32-C6) caused IDF v6.0.1 to re-resolve its pinned riscv32 toolchain to `esp-15.2.0_20251204` (a version not previously used/trusted on this machine). The build failed with "ninja: fatal: CreateProcess: An Application Control policy has blocked this file."

Root cause was **not** corporate WDAC/IT policy — it was Windows 11's own **Smart App Control (SAC)**, a personal reputation-based feature. Confirmed via `Get-WinEvent -LogName 'Microsoft-Windows-CodeIntegrity/Operational'` showing Event ID 3118 "Smart App Control Block Details" and registry `HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy` key `VerifiedAndReputablePolicyState`: `1` = enforced/on, `2` = evaluation, `0` = off. SAC has no per-app allowlist — once enforced, Microsoft normally only lets you turn it off via a full Windows reset, **except** while it's still technically toggleable in Settings (this machine's toggle was still available; user turned it off and the value flipped to `0`, unblocking the older-but-equally-unsigned `esp-14.2.0_20260121` toolchain too).

**How to apply:** if a future `idf.py build`/`fullclean` fails with an "Application Control policy has blocked this file" message on an unsigned ESP-IDF toolchain exe, check `Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy` and the CodeIntegrity event log *before* assuming it's a corporate/IT-managed WDAC policy — it is very likely Smart App Control instead, and the fix is in Windows Settings → Privacy & security → Windows Security → App & browser control → Smart App Control (off), not an IT allowlist request. Related: [[project_sens_cntl_esp_now]] (this surfaced while build-verifying the pairing/tabs/web-dashboard feature work).
