---
name: project-cntl-multi-cam-selector
description: "Cntl dashboard CAM-selector dropdown shipped 2026-08-05 (commit f92c5bb) — resolves the old 2-CAM-UI backlog item; user-confirmed UX decisions documented here"
metadata:
  type: project
  modified: 2026-08-05T12:00:00.000Z
---

Resolves item 2 of [[project-cntl-cam-todo-2026-08-02]] ("여러 대 CAM 동시 지원 UI" — was
"not yet started/scoped"). The hub layer (`Cntl/main/esp_now_hub.c`) already supported pairing multiple
CAMs simultaneously with no real constraint — the only gap was `ui_main.c`'s dashboard always silently
picking whichever paired CAM happened to be first in the node table, with no way to choose and no visible
indication a second CAM was even connected.

## User-confirmed UX decisions (settled by conversation before implementation, worth preserving verbatim
## since the reasoning isn't obvious from the code alone)

1. **Dashboard never operates on two CAMs at once** — always exactly "one currently selected CAM," picked
   from a dropdown; no concurrent multi-camera scenario was ever in scope. This is what made the
   implementation simple: just replace the single `s_paired_cam_mac` global's *source* (auto-pick →
   user-pick), not its cardinality.
2. **The selector dropdown is always shown, even with only 1 CAM paired** — user's explicit reasoning:
   "어쨌거나 사용자 경험상 더 붙을 때 UI가 바뀌는 건 안 좋아 보여" (having the UI's shape change
   depending on how many CAMs happen to be connected is bad UX, even if a single-option dropdown is
   functionally inert with 1 CAM). Don't "simplify" this later by hiding it below 2 CAMs — that was
   explicitly considered and rejected.
3. **Selecting a CAM auto-fetches its photo list** — no separate manual step, matching how tapping a photo
   already auto-fetches (`reconcile_selection()`). Explicitly *not* the conservative "just switch, let the
   user press 목록갱신" option — user picked the auto-fetch option specifically for consistency with the
   existing photo-selection pattern.
4. **CAM device names widened from 2 to 3 MAC bytes** (see [[project-cntl-cam-esp-now-reliability-layers]])
   specifically because 2 bytes stopped being "obviously fine" once multiple CAMs could actually be told
   apart in the same UI — worth remembering if this ever needs revisiting (e.g. if `CONFIG_CAM_NODE_NAME`
   custom names are used instead of the auto-generated MAC-based ones, collision is back on the table since
   nothing enforces uniqueness for manually-set names).

## Implementation shape (for future reference, `Cntl/main/ui_main.c`)

- `s_selected_cam_mac`/`s_has_selected_cam` (renamed from `s_paired_cam_mac`/`s_has_paired_cam` — same
  storage, different semantics: user-selected, not auto-found).
- `select_camera(mac)` — single point of entry for "the active CAM changed," called both by the dropdown's
  `LV_EVENT_VALUE_CHANGED` handler (user tap) and by `refresh_dashboard()`'s auto-fallback (selected CAM
  got unpaired, or first CAM to ever pair). Dedup-guards on no-op (same mac), otherwise reuses the
  pre-existing `reset_camera_ui_state()` (previously only used on full disconnect — the invariant "whatever
  is on screen belongs to a CAM that's no longer current" applies identically to a CAM *switch*) then calls
  `esp_now_photo_list_request()`.
- `s_camera_select_dd` — first `lv_dropdown_create()` use in this codebase, no prior pattern existed.
  Options string + index→mac mapping (`s_cam_dd_macs[]`) rebuilt only when the paired-CAM name set actually
  changes (`rebuild_camera_dropdown_if_changed()`), to avoid redrawing (and potentially closing) an
  open dropdown every 1s dashboard tick.
- Toolbar layout: `camera_toolbar` uses `LV_FLEX_ALIGN_SPACE_BETWEEN` between exactly 2 direct children —
  the dropdown and a new `camera_btn_group` wrapper holding the capture/renew/delete-all buttons — so the
  dropdown pins left and the buttons cluster together on the right, rather than 4 children spreading out
  evenly (which SPACE_BETWEEN would do with a flat 4-child list).

**How to apply**: if a UI change to this panel is requested later, start from
`refresh_dashboard()`'s CAM section (rebuilds the paired-CAM list every tick, drives both the dropdown
options and the fallback-selection logic) and `select_camera()` (the single choke point for switching) —
don't reintroduce a second "which CAM" code path.
