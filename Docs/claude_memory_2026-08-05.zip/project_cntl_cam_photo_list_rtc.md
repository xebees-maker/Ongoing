---
name: project-cntl-cam-photo-list-rtc
description: "Cntl CAM photo list/delete/capture-progress-popup + RTC time-sync — RESOLVED 2026-08-01, full capture-now flow verified end-to-end on real hardware"
metadata: 
  node_type: memory
  type: project
  originSessionId: 010a87cc-1d58-440e-b47d-76065ed3ab3c
  modified: 2026-08-01T02:13:50.432Z
---

Built 2026-07-31, debugged and fully verified working 2026-08-01. Built on top of
[[project-cntl-ui-rebuild]] and [[project-cam-esp-now-production]].

**Capture-now popup — RESOLVED, two real bugs found via addr2line + serial round-trip logging, not the
protocol/logic (which was fine):**

1. **CAM WiFi AP-mode beacon crash** (the actual "stage 2 never arrives" cause): CAM ran `WIFI_MODE_AP`
   purely as an ESP-NOW carrier (no real AP use, no HTTP server) with `esp_wifi_set_config()` never called
   → default open, joinable AP. During `cam_node_capture_now()`'s multi-second blocking capture,
   `ieee80211_hostap_send_beacon_process`/`ieee80211_ap_sa_query_timeout` (ESP-IDF's closed WiFi stack,
   beacon-TX bookkeeping) crashed with Guru Meditation LoadProhibited — reproduced every single time.
   Tried `max_connection=0` first (closing the AP to new stations) — crash still reproduced identically,
   proving it wasn't about external stations, it was the beacon-transmission code path itself under
   contention with the capture task. Real fix: **CAM switched from `WIFI_MODE_AP` to `WIFI_MODE_STA`**
   (`CAM/main/cam_node.c` wifi init block, `esp_netif_create_default_wifi_sta()` instead of `_ap()`) since
   STA never transmits beacons — the crashing code path doesn't exist in STA mode at all. Also updated all
   `WIFI_IF_AP` → `WIFI_IF_STA` references in `esp_now_cam.c` (peer ifidx ×2, `esp_wifi_get_mac`). Cntl was
   already STA (`esp_now_hub.c:171`), confirming STA is sufficient for ESP-NOW. **User confirmed CAM/Sens
   AP-mode code was all leftover test scaffolding — neither needs AP or a local web server. Sens has the
   same `WIFI_MODE_AP` pattern and needs the identical STA fix later** ("SENS는 CAM 완료하면 성공한
   내역으로 나중에 한번에 고칠꺼야" — do it as a follow-up once CAM's fix is proven, which it now is).
2. **`photo_tx` task stack overflow**: once the AP crash was fixed, a *second*, previously-masked bug
   surfaced — `xTaskCreate(photo_transfer_task, "photo_tx", 4096, ...)` in `esp_now_cam.c` overflowed
   during capture+SD-save (FATFS path is stack-hungry). Fixed by bumping to 12288. After both fixes: full
   round trip verified on real hardware — capture succeeds, 1704/1704 chunks transfer, CRC32 verifies,
   list refreshes, popup auto-closes with the new photo shown, exactly as designed.
3. Also fixed along the way (still live in code, minor but real): Cntl's `esp_now_photo_capture_now()`
   didn't reset `s_state` before starting — if a prior single-photo-receive flow never reached
   `PHOTO_DONE` (which is exactly what the AP crash caused), `s_state` stayed `RECEIVING` forever and
   every subsequent capture-now press was silently swallowed by `start_single_receive()`'s busy guard (no
   send at all, popup stuck at "전달 중"). Now force-resets `s_state = IDLE` on every fresh capture-now
   press, since a new popup means fresh user intent regardless of prior stuck state.

**List-tap → photo display**: NOT a separate unimplemented feature — `cb_photo_row_select` →
`esp_now_photo_fetch_by_id()` → generic `refresh_dashboard()` READY-state poll (`ui_main.c:757-763`)
handles it exactly the same as the capture-now path. Implemented, just not yet manually tapped/verified on
hardware (capture-now path was).

**RTC time-sync — implemented + verified 2026-08-01, real feature added beyond the 07-31 build:**
Board's PCF85063A RTC has no backup battery (CR927 holder unpopulated), so it resets on full power loss.
Old approach only seeded from build-time `__DATE__`/`__TIME__` when the RTC looked implausible (year <
2020) — not real "PC time at flash time" sync as the user wanted, and it silently drifted whenever a
binary was reflashed without rebuilding.
- **Partition rename**: `fonts` → `assets` (same offset/size, `partitions.csv`) — now holds fonts AND
  settings, since dropping a non-font file into a partition literally named "fonts" bothered the user.
  Source dir `fs_root/` → `assets_root/`, mount point `/fonts` → `/assets` (`fs.h`), TTF paths in
  `ui_font.h` updated to match.
- **Language setting moved off NVS** (`ui_strings.c`): was `nvs_open`/`nvs_get_u8`/`nvs_set_u8` in
  namespace `cntl_cfg` — now a plain 1-byte file `/assets/settings.bin`, fopen/fread/fwrite. `nvs_flash_init()`
  itself stays in `main.c` (WiFi still needs it internally), just the app's own key moved to the
  filesystem. User's stated reasoning: wanted file-based config, not NVS-image-burning from the host.
  Considered and rejected: splitting the `nvs` partition into a dedicated `time_nvs` partition (works, but
  user preferred reusing the same file-drop mechanism already used for fonts over an NVS-specific
  partition/tooling detour) — decision path is in this session's transcript if the tradeoff needs
  revisiting.
- **`rtc_sync.c`**: build+flash script writes the PC's **current local wall-clock time** (not true UTC —
  this codebase has no timezone concept anywhere, RTC/`gmtime_r`/`mktime` all treat stored values as naive
  numbers) into `assets_root/time_sync.txt` right before each build. On boot, `rtc_sync_init()` reads
  `/assets/time_sync.txt` and — **only if that value is newer than the RTC's current reading** — advances
  the RTC forward to it (never backward). This "advance-only, file persists forever" design is deliberate
  for a battery-less RTC: a normal reboot leaves an already-correct RTC untouched, while a power-loss reset
  gets recovered from the same still-present file. First attempt used `UtcNow` and was off by Korea's UTC+9
  offset (device showed 01:57 instead of 11:10 local) — user caught it ("현재 시각 아님"), fixed by feeding
  local wall-clock time reinterpreted as if it were UTC (`[DateTime]::SpecifyKind($localNow,
  [DateTimeKind]::Utc)` in the PowerShell flash step), matching the codebase's no-timezone convention.
  Confirmed correct on device after the fix ("시간 정상").
- Boot order in `main.c` matters: `fs_init()` now runs right after `nvs_flash_init()` (before
  `ui_lang_load()` and before `rtc_sync_init()`), since both language and RTC seed now depend on the
  filesystem being mounted first.
- **Still not done**: `ESP_NOW_MSG_SET_TIME` (Cntl → CAM/Sens time push on pairing) — deferred again,
  makes more sense now that Cntl's own time is actually trustworthy.

**How to apply**: this feature is now verified end-to-end on real hardware (capture, transfer, list,
RTC display) — safe to build on top of without re-verifying from scratch. The AP→STA WiFi crash pattern
is the one thing to proactively check for on Sens next, before assuming its ESP-NOW is stable.
