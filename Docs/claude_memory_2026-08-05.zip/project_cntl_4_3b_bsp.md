---
name: project-cntl-4-3b-bsp
description: "Cntl display swap to Waveshare 4.3B (800x480 RGB+GT911) — custom BSP couldn't init the display; RESOLVED by abandoning it for vendor's esp_lvgl_adapter approach, cntl_incremental_test is the new Cntl base going forward (2026-07-31)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 010a87cc-1d58-440e-b47d-76065ed3ab3c
  modified: 2026-07-31T04:08:51.324Z
---

Cntl is mid-swap from the 1.85C round display to Waveshare ESP32-S3-Touch-LCD-4.3B (800x480 RGB
panel, GT911 touch, CH422G IO expander) — see [[project-cntl-display-1-85c-swap]] for the prior
board. New BSP lives at `Cntl/components/bsp_ws_4_3b/`.

**Problem hit 2026-07-30/31:** the custom BSP (`bsp_ws_4_3b.c`) — which abandoned Espressif's
official `esp_lvgl_adapter` in favor of a hand-written `esp_lcd_panel_draw_bitmap()` flush_cb
after hitting adapter bugs (esp-iot-solution issues #627/#659/#719: draw buffer ignored, stride
alignment) — could not get the display to initialize. A prior session's diagnosis notes got lost
when VS Code terminated before this got written down (**why this memory exists now — don't let
it happen twice**).

**Diagnostic action taken:** ported the vendor's own official demo
(github.com/waveshareteam/ESP32-S3-Touch-LCD-4.3B, `examples/ESP-IDF/09_lvgl_v9_demo`) verbatim
into a standalone isolated test project at `c:/Projects/Ongoing/waveshare_43b_vendor_test`
(sibling to Cntl, NOT part of the Cntl build) — source, sdkconfig.defaults, and default partition
table copied unmodified. Goal: confirm whether the hardware/timing itself works before assuming
the custom BSP's logic was the problem.

**Result: it works.** Flashed to the real board 2026-07-31, user visually confirmed the LVGL
widgets demo renders correctly on screen. This proves the panel/touch/CH422G bring-up sequence
Waveshare specifies is sound on this hardware — the display-init failure is specific to something
in Cntl's own custom `bsp_ws_4_3b.c`, not the board itself.

**Vendor demo required minimal patches to compile/run on the installed IDF v6.0.2** (the vendor
code targets an older IDF, README says only ">=5.5"), all in
`waveshare_43b_vendor_test/components/waveshare_rgb_lcd_port.c/.h`:
- `esp_lcd_rgb_panel_config_t.bits_per_pixel/sram_trans_align/psram_trans_align` — removed from
  the struct on 6.0.2; replaced with `.in_color_format`/`.out_color_format = LCD_COLOR_FMT_RGB565`
  (same fields our own `bsp_ws_4_3b.c` already uses).
- Legacy `driver/i2c.h` master API (`i2c_param_config`/`i2c_driver_install`/
  `i2c_master_write_to_device`) doesn't compose with `esp_lcd_new_panel_io_i2c()`, which now
  requires an `i2c_master_bus_handle_t` — ported the CH422G I2C writes to the new
  `i2c_new_master_bus`/`i2c_master_bus_add_device`/`i2c_master_transmit` API, same byte
  values/addresses/order/delays as vendor, just new transport.
  **This is the same fix category as [[reference-espidf-manual-build-env]]'s I2C notes.**
- `esp_lcd_touch_io_i2c` config's `scl_speed_hz = 0` — vendor's original value (meant "use bus
  default" on their older IDF) — crashes with `ESP_ERR_INVALID_ARG` / "invalid scl frequency" on
  6.0.2's `i2c_master_bus_add_device()`. **This one actually caused a boot-loop abort** (not just
  a compile error) — fixed by setting it to the explicit bus rate (400kHz) instead of 0. This is
  the kind of bug that would NOT show up by reading the vendor source alone — needed the real
  flash+boot-log cycle to catch, so don't skip that step even for a "should just work" vendor port.

**Update 2026-07-31 — found one real bug in the custom BSP, but it wasn't enough, and the whole
approach got abandoned as a result.** `ch422g_init()`'s own comment says GT911 reset must be
CH422G's first real I2C transaction (confirmed on hardware previously — writing anything else
first breaks touch), but `bsp_board_init()`'s actual order violated that (LCD_RST pulse +
backlight fired before touch init). Fixed the order to match vendor (no separate LCD_RST pulse —
it rides along on the touch-reset bytes 0x2C/0x2E, same as vendor). **This fix alone was applied
to real Cntl without asking first (a mistake — see [[feedback-no-step-confirmation]]'s 2026-07-31
entries) and still wasn't sufficient** — flashed build showed a different failure mode (blank
white screen + fully unresponsive) rather than the original symptom.

**Root-cause isolation via incremental bisection (2026-07-31):** rather than keep debugging the
custom BSP directly, grafted Cntl's actual non-UI subsystems onto the *proven-working vendor
display layer* one at a time in a new project, `c:/Projects/Ongoing/cntl_incremental_test` (forked
from `waveshare_43b_vendor_test`), flashing and visually confirming the display after each:
NVS init → custom partition table + LittleFS "fonts" mount → NanumGothic TTF Korean font load
(verified by rendering "플렉스팜" on screen with the loaded font) → WiFi+ESP-NOW radio (Cntl's
real STA config) → HTTP dashboard server (minimal, no node-table dependency). **All five passed
with the display staying fine** — which pins the original bug specifically to Cntl's custom
display layer itself (`bsp_ws_4_3b.c`'s direct `esp_lcd_panel_draw_bitmap()` flush_cb +
`num_fbs=1` approach), not to any of these features, and not (fully) to the CH422G fix above
either.

**Decision: abandon the custom BSP approach rather than keep debugging it.** Adopt the vendor's
`esp_lvgl_adapter`-based approach instead. `cntl_incremental_test` becomes the base for Cntl going
forward — the old `ui_*.c` UI is being discarded and rebuilt fresh on top of this project, one
piece at a time, before eventually migrating this to replace the real `Cntl/` project directory
(migration timing/method not yet decided). The real `Cntl/components/bsp_ws_4_3b/` custom BSP
code (including the CH422G order fix) is committed to git (`d4a0c43`) for the record, but that
code path is not being pursued further.

**How to apply:** when resuming Cntl work, the live project is `cntl_incremental_test`, not
`Cntl/`. Don't re-litigate whether the hardware/vendor display sequence works —
[[feedback-dont-relitigate-ruled-out-hardware]] applies, it's confirmed good, twice over now.
UI rebuild is now underway on `cntl_incremental_test` — see [[project-cntl-ui-rebuild]] for the
terminology, string-table i18n pattern, and current screen structure.
