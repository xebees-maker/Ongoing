---
name: project-cntl-cam-todo-2026-08-02
description: "Cntl/CAM pending to-do list dictated by user at end of 2026-08-01 session, to pick up next session"
metadata:
  type: project
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-08-01T14:41:22.781Z
---

At the end of the 2026-08-01 session the user explicitly stopped work and dictated a 3-item to-do list
for the next session ("내일 할일" — tomorrow's tasks), confirmed complete via AskUserQuestion.

1. **RESOLVED 2026-08-05** — see [[project_cntl_cam_capture_now_race_and_frame_lag]]. Turned out to be two
   independent bugs, not the file_id-redesign ordering issue originally suspected: a Cntl-side
   selection/fetch race (soft-cancel + stale-photo guard fix) and a CAM-side camera-driver frame-buffer
   staleness bug (fixed capture-count lag). Both fixed and hardware-verified.

2. **RESOLVED 2026-08-05** — see [[project-cntl-multi-cam-selector]]. Dashboard now has a CAM-selector
   dropdown (always shown, even with 1 CAM); selecting auto-fetches that CAM's list. Hardware-verified.

3. **Add an auto-capture-interval setting under Settings → Camera (설정-카메라).** Still not started. The
   wire protocol already has `esp_now_cam_config_t` (`CAM/main` +
   `Common/components/esp_now_link/include/esp_now_link.h`) with `capture_interval_sec` and `wb_mode`, but
   nothing in Cntl's Option-tab UI exposes it yet — this is a pure Cntl UI addition (CAM already honors the
   config message per its existing Kconfig-preset design).

**How to apply:** item 3 is the only thing left open from this original list — start there if the user
wants to keep working down it, but don't assume it's still their priority without asking (this list is
from 2026-08-02; a lot of other work has happened since, including the entire ESP-NOW reliability layer
redesign — see [[project-cntl-cam-esp-now-reliability-layers]]).
