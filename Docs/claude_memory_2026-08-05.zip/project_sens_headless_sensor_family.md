---
name: sens-headless-sensor-family
description: "Sens redesigned into a family of single-sensor headless LOLIN C3 Pico nodes (SCD41/DHT22/SHT45/SHT40) with generic ESP-NOW channel protocol + status LEDs — implemented and build-verified 2026-07-17; real GPIO pinout confirmed against schematic and committed 2026-07-18, physical wiring/bring-up still pending"
metadata:
  node_type: memory
  type: project
  originSessionId: e6bca5a4-94d8-48b9-a20c-9b78862d2152
  modified: 2026-07-19T12:40:13.950Z
---

**What changed (2026-07-17):** User is moving away from the single Waveshare ESP32-C6-Touch-LCD combo
board (DHT22+SCD41 together, LVGL UI) to a family of independent single-sensor nodes on the
**LOLIN C3 Pico (ESP32-C3)**, headless (no display). Each physical device gets exactly one sensor:
SCD41, DHT22, SHT45, or SHT40 today, with more to be added later as fully independent devices — not
combined on one board. This supersedes the "Sens still has the touch LCD attached" framing in
[[sens-cntl-wireless-link]] — that was explicitly bring-up-only scaffolding, and this is the production
transition it always pointed at.

**Why:** User wants to physically separate sensors one-per-device going forward, and wants adding a
future sensor type to cost "one new file", not a protocol/Cntl rewrite each time.

**Design decisions locked in (confirmed with user before implementing):**
- **Build structure:** one Sens project, not one folder per sensor. `idf.py menuconfig` → `Sens Sensor
  Node` menu → `SENS_BUILD_TARGET` choice (`SENS_BUILD_LEGACY_LCD` vs `SENS_BUILD_HEADLESS`, default
  headless) + `SENS_SENSOR_TYPE` choice (SCD41/DHT22/SHT45/SHT40, only meaningful when headless).
- **Protocol:** `esp_now_sensor_data_t` (in `esp_now_link.h`) replaced with a generic channel array —
  breaking change, bumped `ESP_NOW_LINK_VERSION` to 2. `sensor_channel_type_t` (TEMP_C/HUMI_PCT/CO2_PPM)
  + `sensor_kind_t` (which physical sensor) + `chan_count`/`chan_type[]`/`chan_ok[]`/`chan_val[]`
  (`ESP_NOW_MAX_CHANNELS`=5, sized to fit the legacy 5-channel DHT22+SCD41 combo). New sensor types never
  need a protocol change, only a new `sensor_kind_t`/`sensor_channel_type_t` value if they measure
  something genuinely new.
- **Status LEDs (new hardware on the C3 Pico, no reset button):** Green = ESP-NOW link state, Blue =
  battery/sensor status. *(Original tables here used steady-on for the healthy states — superseded by
  power-driven revisions later in this file. Jump to "CURRENT FINAL LED TABLES" near the bottom for the
  actual values to use.)* No physical reset/re-pair button: link loss or long-unpaired both auto-fall
  back to advertising forever (infinite auto-retry) — user explicitly chose this over a button because
  the BOOT pin is too recessed on the C3 Pico to route through a housing, and a fully headless battery
  node shouldn't require physical access to recover. This part is unchanged/still current.

**What was implemented and build-verified (all via manual ninja/cmake, IDF v6.0.1 — see
[[reference_espidf_manual_build_env]] for how, since `idf.py` doesn't work directly in this shell):**
- `Common/components/esp_now_link/include/esp_now_link.h`: protocol v2 as above.
- New `Common/components/status_led`: generic GPIO blink-pattern driver, keyed by GPIO pin, up to 4 LEDs.
  Reused for both Green and Blue. Started with `LED_PATTERN_OFF/ON/BLINK_SLOW/BLINK_FAST`; grew to 8
  patterns total by end of session — see "CURRENT FINAL LED TABLES" near the bottom for the full current
  set (`BURST_TRIPLE`, `HEARTBEAT`, `HEARTBEAT_FAST`, `HEARTBEAT_URGENT` added later).
- New `Common/components/sensor_sht4x`: single driver serves both SHT45 and SHT40 (identical I2C
  protocol/address 0x44, only accuracy grade differs — `sensor_kind_t` distinguishes them on the wire,
  not the driver code).
- New `Sens/components/bsp_c3_pico`: headless board pin-constant header (**GPIO numbers are placeholders,
  explicitly marked TODO** — not verified against the real LOLIN C3 Pico pinout yet, per
  [[feedback_verify_gpio_before_recommending]]. Must be confirmed against real hardware/schematic before
  wiring, avoiding strapping pins GPIO2/8/9 and USB D+/D-).
- New `Sens/main/sensor_node.c`: the headless app (LVGL-free version of `sensor-c6.c`) — picks driver via
  `#if CONFIG_SENS_SENSOR_*`, reuses the same battery moving-average + full_mv-learning logic as legacy,
  drives the Blue LED from battery %, pushes readings via the new generic channel push functions.
- `Sens/main/esp_now_node.c`: rewritten with the LED state machine (registers `esp_now_send_cb_t` to
  detect consecutive SENSOR_DATA failures while paired → falls back to advertising) and a
  `esp_now_node_set_readings(sensor_kind, chan_count, chan_type[], chan_ok[], chan_val[], ...)` push API
  that both `sensor-c6.c` (legacy) and `sensor_node.c` (headless) call — decoupled from any
  app-specific header now (previously pulled from `sensor-c6.h` directly, which no longer exists).
- `Sens/main/wifi_dashboard.c` and `Cntl/main/web_dashboard.c`: both rewritten to render channels
  generically (JS `CHAN_LABEL` map keyed by `sensor_channel_type_t`) instead of hardcoded DHT/SCD fields
  — this wasn't explicitly in the original plan but was necessary fallout, since both had the same
  hardcoded-field problem as the ESP-NOW protocol did.
- `Common/components/history_log`: metric enum renamed from named fields (`DHT_TEMP`/`SCD_CO2`/...) to
  generic slots `HISTORY_METRIC_CH0..CH4` + `BATT_PCT` (kept at 6 total to fit the legacy combo app's 5
  sensor metrics + battery unchanged). Added `history_log_set_scale(metric, scale)` since CO2's value
  range needs scale=1.0 (not the default 10.0) to avoid overflowing the int16 NVS ring buffer — callers
  set this explicitly at boot now instead of a hardcoded per-metric table.
- `Cntl/main/esp_now_hub.h/.c`: node struct + summary struct now carry generic channel arrays; summary
  aggregation buckets by `sensor_channel_type_t` across all nodes instead of per-named-field.
- `Cntl/main/ui_node_tabs.c`: per-node tabs and the summary tab now loop over channels generically
  (`chan_meta()` maps type → name/unit/decimal-formatting) instead of hardcoded DHT22/SCD41 rows.
- **Build-verified as of 2026-07-17:** Sens headless with SCD41, DHT22, and SHT45 selected (SHT40 shares
  identical code path with SHT45, not separately tested), Sens legacy LCD combo path, and Cntl — all five
  configurations compiled with zero errors/warnings via manual ninja after a fresh CMake reconfigure
  (component directory rescans require deleting `CMakeCache.txt`+`CMakeFiles/`, a NEW component
  directory won't be picked up by an incremental "Re-running CMake").

**Gotcha discovered and worked around — do not repeat:** `idf_component_register(REQUIRES ...)`
conditioned on `if(CONFIG_X)` inside a component's own `CMakeLists.txt` does **not** reliably follow
Kconfig — ESP-IDF resolves component `REQUIRES` in an early "component requirements expansion" pass that
runs *before* sdkconfig is fully available, so the `if()` silently evaluates false and always falls to
`else()` at that stage, even though `SRCS` conditioned the same way works fine (evaluated later, in the
real build pass, when `CONFIG_*` vars are populated). Fix used in `Sens/main/CMakeLists.txt`: keep `SRCS`
conditional on `CONFIG_SENS_BUILD_HEADLESS`, but list `REQUIRES` as the **unconditional union** of both
build targets' dependencies (unused components just don't get anything compiled/linked from them, no
correctness cost, only a bit of extra component-graph bookkeeping).

**2026-07-17 (later same session) — sensor-fault indication added without a 3rd LED:** user considered
adding a Red LED for sensor-fault, decided against it. Instead added `LED_PATTERN_BURST_TRIPLE` to
`Common/components/status_led` (0.1s on/off x3, 0.5s pause, repeat — implemented as a self-rearming
`esp_timer_start_once()` chain through a 7-phase duration/level table, since it's not a fixed-period
toggle like the other patterns). `Sens/main/sensor_node.c`'s `sample_cb()` now overrides the Blue LED
with this burst pattern whenever `s_display_ok` is false (the sensor is stale), reverting to the normal
battery-percent pattern once the sensor recovers — battery % becomes briefly unavailable during a fault,
which was an accepted tradeoff (fault is more urgent to know about). Green LED's meaning stays
link-only, uncontaminated by sensor state. Build-verified.

**2026-07-17 (later still) — Green "paired" changed from steady-on to a low-duty heartbeat:** user was
uneasy about Green LED being "steady on" the whole time the node is paired (the common-case, longest
state) purely for power reasons — continuous GPIO-high costs real mA versus deep-sleep's µA baseline —
but didn't want to lose always-visible local status either, and specifically rejected the idea of having
Cntl remote-trigger an "inspection mode" (circular: needing Cntl to already reach the node over ESP-NOW
to ask "is ESP-NOW working" defeats the purpose). Resolved by adding `LED_PATTERN_HEARTBEAT` to
`status_led` (50ms on / 2.95s off, ~1.7% duty cycle) and using it for the Paired state instead of
`LED_PATTERN_ON`. Rationale user agreed with: a periodic blip reads as "alive and actively updating" to
a human at a glance (arguably clearer than solid-on, which can't be distinguished from "frozen"), costs
close to nothing power-wise, and needs no round-trip to Cntl. **Final Green LED table:** Paired =
heartbeat (50ms/2.95s), Advertising = fast blink (0.1s/0.1s), Failed = slow blink (1s/1s). Blue LED table
unchanged from the earlier entry (battery tiers + BURST_TRIPLE sensor-fault override). Implementation:
`Common/components/status_led` now has a generic `led_phase_seq_t` (ms[]/level[]/count) used by both
`LED_PATTERN_BURST_TRIPLE` and `LED_PATTERN_HEARTBEAT` via a shared self-rearming `esp_timer_start_once`
chain (`arm_next_phase()`), rather than duplicating that machinery per pattern. `esp_now_node.c`'s two
`LED_PATTERN_ON` call sites (on successful SENSOR_DATA send, and right after pairing) both changed to
`LED_PATTERN_HEARTBEAT`. Build-verified. **This was decided/implemented before real hardware wiring**,
per the user's explicit request to lock the LED values in ahead of the bring-up experiment.

**Same fix applied to Blue LED right after:** user immediately spotted that Blue's 60-100% battery tier
had the identical "steady-on during the common/longest-duration state" problem. `batt_pct_to_led_pattern()`
in `sensor_node.c` changed 60-100% from `LED_PATTERN_ON` to `LED_PATTERN_HEARTBEAT` too. 20-60%/0-20%
tiers left as `BLINK_SLOW`/`BLINK_FAST` — those aren't steady-on already (they alternate), and a more
noticeable warning when battery is actually low is intentional. **Then further refined (same session):** 20-60% and 0-20% tiers also moved off the old 50%-duty
`BLINK_SLOW`/`BLINK_FAST` onto new short-on/short-off patterns, keeping the 50ms on-time consistent
across all battery tiers and only shortening the off-time as battery drops (faster apparent blink = more
urgent, but still low duty cycle, not a return to 50%-duty blinking). Added `LED_PATTERN_HEARTBEAT_FAST`
(50ms on / 1s off) and `LED_PATTERN_HEARTBEAT_URGENT` (50ms on / 300ms off) to `status_led`, each with
their own `led_phase_seq_t` table reusing the same `arm_next_phase()` machinery. **Final Blue LED table:**
60-100% = heartbeat (50ms/2.95s), 20-60% = heartbeat-fast (50ms/1s), 0-20% = heartbeat-urgent (50ms/300ms),
sensor-fault = BURST_TRIPLE override (unchanged, takes priority over all battery tiers). `BLINK_SLOW` is
now unused by Sens (kept in `status_led` as a generic primitive, may still be useful elsewhere).
`BLINK_FAST` is still used by Green's Advertising state. Build-verified.

---

**CURRENT FINAL LED TABLES (2026-07-17, end of session — treat everything above this as history/rationale,
this section is the answer if you just need the values):**

Green (`esp_now_node.c`, ESP-NOW link state):
| State | Pattern |
|---|---|
| Paired | `LED_PATTERN_HEARTBEAT` — 50ms on / 2.95s off |
| Advertising (within 30s grace) | `LED_PATTERN_BLINK_FAST` — 0.1s on/off |
| Failed (lost pairing, or 30s+ unpaired) | `LED_PATTERN_BLINK_SLOW` — 1s on/off; advertising keeps retrying in background |

Blue (`sensor_node.c`, battery % unless a sensor fault overrides it):
| State | Pattern |
|---|---|
| Battery 60-100% | `LED_PATTERN_HEARTBEAT` — 50ms on / 2.95s off |
| Battery 20-60% | `LED_PATTERN_HEARTBEAT_FAST` — 50ms on / 1s off |
| Battery 0-20% | `LED_PATTERN_HEARTBEAT_URGENT` — 50ms on / 300ms off |
| Sensor stale (overrides battery display) | `LED_PATTERN_BURST_TRIPLE` — 0.1s on/off x3, 0.5s pause, repeat; reverts to battery pattern once sensor recovers |

All "healthy/common-case" states use a low-duty heartbeat-family pattern instead of steady-on, purely for
battery reasons (steady-on was the original design, replaced state-by-state as the user kept spotting the
same power issue in each LED). No `LED_PATTERN_ON` usage remains anywhere in Sens.

---

**2026-07-18 — real GPIO pinout confirmed, committed (20a63a6):** `bsp_c3_pico.h` TODO placeholders
replaced with values verified against WeMos's official `sch_c3_pico_v1.0.0.pdf`: I2C SDA/SCL on
GPIO8/10 (shared with the board's onboard I2C connector, port 0 — esp32c3 has only one I2C controller,
no LP_I2C), battery ADC on GPIO3/ADC_CHANNEL_3 (board divider R7=R10=100k confirmed), status LEDs Green
GPIO0/Blue GPIO4. Avoided GPIO7 (onboard WS2812, also exposed on J3 — conflicts if reused), GPIO9
(BOOT button, not header-exposed), GPIO2 (strapping). VBUS-present detection renamed to VIN detection
(`vbus_is_present()` → `vin_indicates_usb()`, `BSP_C3_VBUS_*` → `BSP_C3_VIN_*`) because the sensed net
(J3 header "V" pin, external 100k+100k divider to GPIO1/ADC_CHANNEL_1) is post-power-mux — Q1 (P-FET) +
D1 (1N5819W) already merge battery/VBUS onto one system-power rail before it reaches that pin, so it
reads ~VBAT with USB unplugged and ~4.6-4.7V (through D1) with USB plugged, comfortably above battery
full-charge (~4.2V). Threshold set to 2200mV at the ADC pin (post-divider), pending real recalibration
after wiring. The originally-planned charge-LED (direct to charger IC's CHRG pin) was dropped — the real
board has no footprint for it. Also added `EXCLUDE_COMPONENTS bsp_c6` for the esp32c3 target in
`Sens/CMakeLists.txt`, since `bsp_c6.h` hardcodes GPIO_NUM_22/23 (esp32c6-only pins) and would otherwise
always get pulled into the esp32c3 build's `REQUIRES` union (see the REQUIRES-early-expansion gotcha
above) and fail to compile. Rebuilt clean (headless/SCD41/esp32c3) after the change. Committed locally
only (not pushed, per standing preference) as its own commit, scoped separately from the unrelated
uncommitted Cntl 1.85C display-swap changes sitting in the working tree.

**2026-07-19 — real hardware bring-up done, both boards flashed and verified:**
- **Flashing itself works** (was failing before this session) — esptool via the manual build recipe in
  [[reference_espidf_manual_build_env]], COM14 (old board) and COM3 (new board with JP1 soldered).
- **Battery ADC (GPIO3) bug found and fixed by the user**: old board (COM14) had JP1 ("BAT_AD" jumper,
  connects the board's onboard divider to GPIO3) unsoldered, so GPIO3 floated and read a fixed nonsense
  value (`batt_mv=5852`, physically impossible for a Li-ion cell). New board (COM3) with JP1 soldered
  reads a sane, stable `batt_mv≈4106-4144`.
- **VIN detection (GPIO1) miswired, then fixed**: pins were off-by-one on the external 100k+100k divider;
  after the user rewired it, `raw≈3067, mv≈2321` — matches the doc's predicted USB-connected range
  (2300-2350mV) almost exactly, `usb=1` correctly detected.
- **Charging-status LED added**: Blue LED now goes steady-on (`LED_PATTERN_ON`) whenever `powered==true`
  (USB/charging), overriding both the battery-percent tiers and the sensor-stale burst pattern — final
  priority order **charging > sensor-stale > battery%** (user corrected the initial priority, which had
  sensor-stale above charging). See `sample_cb()` in `Sens/main/sensor_node.c`.
- **Structural limitation confirmed**: this board is USB-Serial/JTAG, so the serial log itself requires
  the USB cable — "what happens the instant USB is unplugged" can never be observed via this log, only
  inferred (e.g. via continuous uptime counter proving the board stayed powered on battery through a
  disconnect/reconnect cycle).
- SCD41 I2C (GPIO8/10) confirmed working once wired — see [[sens-sleep-mode-spec]] for the single-shot
  duty-cycle work that followed in the same session.

**Not yet done:**
- SHT40 hasn't been build-tested separately (shares `sensor_sht4x` code with SHT45, low risk).
- DHT22/SHT45/SHT40 physical wiring/bring-up — explicitly deferred, user wants SCD41 done first since
  there are multiple other sensor types to get through one at a time.
- Cntl's `ui_dashboard.c` (main LCD summary screen, distinct from `ui_node_tabs.c`) was checked and
  doesn't reference the old dht/scd fields at all, so it needed no changes — worth re-confirming if it
  grows sensor-specific display logic later.

**How to apply:** when wiring a new physical node, first confirm `bsp_c3_pico.h`'s pin defines against
the real board, then flash with the matching `SENS_SENSOR_TYPE` selected. When adding a genuinely new
sensor type beyond SCD41/DHT22/SHT45/SHT40, add a `sensor_kind_t` value + (if it measures something new)
a `sensor_channel_type_t` value in `esp_now_link.h`, a driver component under `Common/components/`
following the `sensor_scd41`/`sensor_sht4x` pattern (own private I2C bus, Sensirion-style CRC8 if
applicable), a `SENS_SENSOR_*` Kconfig option, and a `#if CONFIG_SENS_SENSOR_*` branch in
`Sens/main/sensor_node.c` — nothing in Cntl or the protocol itself should need to change.
