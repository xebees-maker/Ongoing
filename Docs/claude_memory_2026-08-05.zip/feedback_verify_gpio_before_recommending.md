---
name: verify-gpio-before-recommending
description: "Always check schematic for pull-ups/multiplexed nets before recommending a GPIO pin on Sens/Cntl boards, not just header pin lists"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 577f7696-cb50-4489-ad09-dad511378349
---

Before recommending a specific GPIO for a new hardware function (sensing, divider, etc.), check the schematic for board-level resistors (pull-ups/pull-downs) and shared bus usage on that pin — not just whether it appears "unused" on a header pin list from an old memory note.

**Why:** Recommended GPIO3 for the [[project_sens_vbus_sense]] VBUS divider based on a stale note saying "IO3/4/5 are spare." Didn't re-check the schematic at recommendation time. GPIO3 is actually `SD0_MISO` with a board-level 10kΩ pull-up to 3V3 (R6, shared with the SD card SPI bus and LCD I2C lines via R3-R6 on IO1-IO4). This loaded the 100k+100k voltage divider and skewed both USB-connected and USB-disconnected readings upward (measured 3.1V/2.7V instead of expected ~2.5V/~0.5V), forcing the user to re-wire from IO3 to IO7 after already soldering/connecting.

**How to apply:** On [[reference_sens_schematic]] board (ESP32-C6-Touch-LCD-1.47), confirmed truly free pins (no resistor, no shared bus) are **IO7 and IO8** — verified by checking the net list has no `R` reference attached. IO1-IO4 are SD-card/LCD shared with 10K pull-ups (R3-R6). IO5/IO6 are IMU_INT1/IMU_INT2 (QMI8658), not free despite earlier assumption. Re-derive from the schematic net list each time before suggesting a pin, don't trust a prior "spare GPIO" list without re-verifying against current resistor/net data.
