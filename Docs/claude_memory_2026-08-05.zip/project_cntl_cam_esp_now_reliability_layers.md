---
name: project-cntl-cam-esp-now-reliability-layers
description: "Cntl<->CAM ESP-NOW reliability redesign: all 3 layers (channel-sync, reliable ARQ, Selective Repeat chunk transfer) implemented, HW-verified, and in production as of 2026-08-05"
metadata:
  type: project
  modified: 2026-08-05T12:00:00.000Z
---

Supersedes the ad-hoc per-message resend-count approach in [[project-cntl-cam-photo-transfer-3006-resolved]]
with a general 3-layer design. **All three layers are now implemented, hardware-verified, and live in
production** as of 2026-08-05 — this was a full-day arc: Layer 0+1 landed first (commit `4661958`), then
Layer 2 (Selective Repeat, what the user called "burst mode"/BMT) was designed, A/B-benchmarked against
the old method for 30 minutes each on real hardware, and adopted as the production photo-transfer method
(commits `96e2eb8` SR implementation + benchmark harness, `da2f08f` production switch-over). Real-device
fetch confirmed working on the SR path after the switch (log showed `CKPT(SR)` lines, clean single-round
`DONE_ACK` completions, file_ids 3/2/1/0 all fetched successfully).

## Layer 0 — esp_now_channelsync (`Common/components/esp_now_channelsync/`)

Decouples channel tracking from pairing and from application traffic via dedicated CHANNEL_PING/PONG
heartbeats and an UNSYNCED/SYNCED state machine. A channel switch resyncs in ~1.2s instead of requiring a
full re-pair. Verified via a controlled channel-switch test.

Key subtlety: PING shares CAM's single ESP-NOW TX queue with photo-chunk bursts — confirmed via an Explore
subagent reading actual ESP-IDF v6.0.2 source that **ESP-NOW has no priority/QoS API** (`esp_now.h` has no
priority parameter, ships as prebuilt `libespnow.a`, WiFi's `esp_wifi_aci_t` VO/VI/BE/BK categories are
read-only TX stats only, not taggable). This meant PING could genuinely queue-delay past its 500ms timeout
during a chunk burst even with a perfectly healthy channel, causing false-positive "channel desync"
detection mid-transfer (3006 recurring after ~20 successful fetches). Fixed via
`esp_now_channelsync_notify_alive()` — any successful Layer-1 reliable round trip (not just PONG) resets
the PING failure counter, since any round trip is equally strong proof-of-life. Preserves the "always
verify via a real round trip, never trust local state" principle while broadening what counts as evidence.
User-confirmed stable after this fix ("가져오기는 매우 안정적, 아직 한번도 에러 없음").

Also fixed: `ESP_ERR_ESPNOW_NO_MEM` (local TX queue full — the send never even left the device) was being
miscounted as a real PING failure in `ping_timer_cb()`; now correctly distinguished from "sent but no
reply."

## Layer 1 — esp_now_reliable (`Common/components/esp_now_reliable/`)

`esp_now_reliable_request()` — blocking request/reply with retry-on-timeout, built on top of Layer 0.
Same NO_MEM-vs-timeout distinction fix applied to its send-retry loop (don't burn the full round-trip
timeout on a send that never left the device).

## Layer 2 — Selective Repeat (SR) chunk transfer — DONE, in production

`send_one_photo_sr()` (`CAM/main/esp_now_cam.c`) — CAM sends `SR_WINDOW_SIZE`=16 chunks at a time (chosen
to match `CONFIG_ESP_WIFI_STATIC_TX_BUFFER_NUM`'s default so it shouldn't self-induce NO_MEM queue
saturation), then asks Cntl what's missing in just that range via two new messages
(`ESP_NOW_MSG_PHOTO_WINDOW_STATUS_REQUEST`/`_ACK`, `Common/components/esp_now_link/include/esp_now_link.h`)
and backfills before advancing to the next window. Reuses `esp_now_reliable_request()` for the status round
trip and `resend_chunks()` (already generic — just sends whatever indices a nack-shaped struct lists) for
both the initial window fill and backfill — almost no new per-chunk-send code was needed. The existing
DONE/DONE_ACK/NACK-round safety net is kept unchanged at the very end as a final catch-all.

Cntl needed only one new handler (`handle_window_status_request()` in `Cntl/main/esp_now_photo.c`) — no
other receive-side changes, since `handle_meta()` already unconditionally re-arms per-transfer state and so
happily accepts CAM-initiated (unsolicited) transfers, which the benchmark harness relies on.

**Bug found building the benchmark harness**: `s_photo_cam_mac` (the address Cntl replies to for
`WINDOW_STATUS_ACK`/`DONE_ACK`) was only ever set by Cntl's own request path (`start_single_receive()`).
Since the harness has CAM push transfers unsolicited (no Cntl-initiated request), that field stayed at its
zero-initialized value and every reply attempt failed with `ESP_ERR_ESPNOW_NOT_FOUND` (no peer registered
for the zero MAC) — invisible in normal use since real fetches are always Cntl-initiated. Fixed by having
`handle_meta()` capture the actual packet sender instead of relying on the requester-side cache — correct
regardless of who initiated the transfer, and a strictly more robust source of truth.

**30-minute A/B benchmark result** (71KB/60-chunk file, real AP channel, both runs back-to-back same
session): SR completed 1696 transfers (0 failures, avg 1061ms/transfer, max **1166ms**) vs the old
blast+NACK method's 1593 (0 failures, avg 1133ms, max **8840ms**). Chunk-level redundancy was tiny for
both (SR: 0 extra chunks across 2156 logged transfers; old method: 97 extra out of 95580, ~0.1%) — the
real win isn't less data, it's that SR pays a small *fixed* per-transfer overhead (4 extra small
request/reply pairs for a 60-chunk file) in exchange for never having to pay the old method's *occasional*
full-file DONE-round retry-timeout tax (up to 800ms×3 per round, up to 3 rounds) when something needs
fixing right at the end. SR: modest throughput win (~6.5%), decisive tail-latency win.

**Production switch-over** (commit `da2f08f`): `photo_transfer_task`'s per-file send loop
(`CAM/main/esp_now_cam.c`) now calls `send_one_photo_sr()` instead of `send_one_photo()`. The old function
is kept intact and still reachable via `BENCH_START` mode=1 (`XFER_BENCH` current-method mode) for a future
side-by-side re-check if SR ever regresses. **Caveat from this session**: the production swap was
accidentally reverted once mid-session (during a commit-splitting attempt) and stayed reverted through a
couple of intermediate CAM reflashes before being caught and reapplied — always grep
`send_one_photo_sr(ids\[i\]` in `photo_transfer_task` to confirm which method is actually live if this is
ever in doubt, don't assume from conversation history alone.

The BMT-only UI (three trigger buttons in Cntl's Settings screen — raw-blast/current-method/SR) was removed
once the decision was made and applied (commit `f92c5bb`) — the underlying `esp_now_hub_bench_start()` /
CAM-side bench code is untouched, just no longer UI-reachable.

**How to apply**: if a future comms bug looks like a timing/queue-contention issue rather than a logic bug,
remember there is genuinely no way to prioritize one ESP-NOW message over another at the driver level on
this IDF version — the only lever is TX buffer *count* (`CONFIG_ESP_WIFI_*_TX_BUFFER_NUM`), which doesn't
fix queueing delay, only queue depth. Cross-signaling proof-of-life across message types (like
`notify_alive()`) is the workaround that actually worked here.
