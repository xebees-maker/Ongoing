---
name: cntl-scd41-lp-i2c-bug
description: "RESOLVED 2026-06-19 — Cntl no longer builds sensor_scd41/sensor_dht22 at all; SCD41's C6-only LP_I2C_SCLK_DEFAULT macro can no longer break Cntl's S3 build"
metadata: 
  node_type: memory
  type: project
  originSessionId: ea523f87-b6d2-47f1-ba7c-aac304e9e417
---

`Common/components/sensor_scd41/scd41.c` hardcodes `.clk_source = (i2c_clock_source_t)LP_I2C_SCLK_DEFAULT`, a macro that only exists on chips with an LP_I2C peripheral (e.g. ESP32-C6). This used to break Cntl's (ESP32-S3) build whenever it actually got far enough to compile that file.

**Resolved 2026-06-19:** User clarified Cntl has no sensor hardware at all — DHT22 and SCD41 were both dev/test-only on Cntl. Removed entirely from Cntl: deleted `Cntl/main/ui_gas.c/.h` (gas tab, 100% SCD41), stripped DHT22 code out of `ui_dashboard.c` (종합 tab now shows battery only, full-screen), dropped `sensor_dht22`/`sensor_scd41` from `main/CMakeLists.txt` REQUIRES, and removed the "가스" tab from `ui_main.c`.
That alone wasn't sufficient: ESP-IDF's CMake build, when `EXTRA_COMPONENT_DIRS` is set (`Cntl/CMakeLists.txt` points it at `Common/components`), compiles **every** component found in those dirs by default regardless of any component's `REQUIRES` list — so `sensor_scd41`/`sensor_dht22` kept getting built and erroring even with zero Cntl code referencing them. Fixed by adding `set(EXCLUDE_COMPONENTS "sensor_dht22" "sensor_scd41")` in `Cntl/CMakeLists.txt` before `include($ENV{IDF_PATH}/tools/cmake/project.cmake)`. **How to apply:** any future Common/components addition that's Sens-only (not meant for Cntl) needs to either avoid breaking S3 builds on its own, or get added to this same `EXCLUDE_COMPONENTS` list in `Cntl/CMakeLists.txt`.

Cntl now builds clean end-to-end (`idf.py build` succeeds) — see [[sens-cntl-wireless-link]] for what else was needed to get there (LVGL `LV_USE_FS_POSIX`/`LV_USE_TINY_TTF` sdkconfig flags were also missing, since this was the first time anyone actually ran `idf.py build` on Cntl).
