---
name: sens-schematic
description: Location of the Sens (ESP32-C6-Touch-LCD-1.47) schematic PDF and key findings from it about charge LED / battery power paths
metadata: 
  node_type: memory
  type: reference
  originSessionId: ed001eff-152a-447c-a9a7-5a9c3ae5fdf7
---

Full schematic: `C:\Projects\Ongoing\Sens\hardware\ESP32-C6-Touch-LCD-1.47-Schematic.pdf`. Read it directly (it's a small vector PDF, readable in one shot) before guessing about board power/charging hardware again — don't web-search for it, the user has supplied it locally.

Key findings (2026-06-19) relevant to [[project_sens_status_2026_06_18]] battery work:
- Charge IC is `U2` (ETA6098). Its `STAT` pin (9) drives the green charge-indicator LED (`LED1`) through pull-up `R17` (3K, to VBAT) — this net is **not connected to any ESP32 GPIO**. The LED is a hardware-only indicator; reading "charging" in firmware via this LED is not possible without an added wire from the STAT net to a spare GPIO (hardware mod).
- `LEDK`/`LED2` is a separate, unrelated net — LCD backlight cathode, driven by transistor `T1` (SS8050), not the battery charge LED. Don't confuse the two.
- `Q1` (AO3401, P-MOSFET) is a power mux between VBAT/VBUS/VSYS, gated automatically by VBUS presence (via R20/R21/R22) — not MCU-controlled. Matches `ctrl_gpio = GPIO_NUM_NC` already in `battery_config_t` in sensor-c6.c; nothing to wire up there.
- Battery voltage sense divider is `R21` (200K) / `R22` (100K) into `BAT_ADC`, which goes to ESP32 `IO0` (ADC_UNIT_1/CH0) — matches `BSP_BATTERY_ADC_CHANNEL` in bsp_c6.h.
- Spare/unused header GPIOs (per [[project_sens_status_2026_06_18]] and the handoff doc) are GPIO3/4/5 — these would be the candidates if a hardware STAT-sense wire is ever added.

**How to apply:** Before proposing any GPIO-based hardware charge-detection approach, check this file first — the answer (no GPIO available without a mod) is already known.
