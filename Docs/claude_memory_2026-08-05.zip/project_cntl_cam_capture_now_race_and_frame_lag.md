---
name: project-cntl-cam-capture-now-race-and-frame-lag
description: "RESOLVED 2026-08-05: capture-now showed wrong/stale photos — two separate bugs (Cntl selection race + CAM frame-buffer lag), both fixed and HW-verified"
metadata:
  type: project
  modified: 2026-08-05T00:00:00.000Z
---

Item 1 of [[project_cntl_cam_todo_2026_08_02]] turned out to be two independent, stacked bugs, found by
having the user do a controlled repro (모두 지우기 → show digits 1/2/3/4 full-screen on a monitor → 지금촬영
once per digit, ~10s apart).

## Bug A — Cntl UI selection/fetch race (commit 4f1b954)

`cb_progress_popup_cancel` used to call `close_progress_popup()` immediately, resuming the background
dashboard timer before the underlying ESP-NOW request (not actually abortable — no cancel message exists
in the protocol) had finished. If the user made a new selection in that window, the previous request's
late-arriving photo could land on top of the new selection.

Fix: cancel is now soft — button disables + relabels to "종료 대기 중...", but the modal stays until the
flow's own `tick_fn` resolves for real (completion or the existing 8s timeout). Both READY-state
consumption points (background timer, `reconcile_selection()`) now go through
`consume_ready_photo_if_current()` (`Cntl/main/ui_main.c`), which only displays a photo if its `file_id`
still matches the current selection; a mismatch raises `UI_ERR_PHOTO_SELECTION_STALE` (3008) instead of
silently showing stale content.

## Bug B — CAM camera-driver frame-buffer staleness (commit 530d25c)

The real "ghost photo" cause, and the more serious one. `esp_camera`'s DMA frame-buffer pool (`fb_count`
slots — 2 on this OV3660 board, `CAM/main/cam_node.c`) only gets refilled when the app drains it via
`fb_get()`+`fb_return()`. With no continuous background capture running, the pool fills exactly once
after boot and then **stalls** — no free DMA slot for the ISR to capture into. Every on-demand capture
(manual or scheduled auto-capture, same `camera_capture_one()`) then returns the **oldest still-queued**
frame instead of a fresh one — a deterministic lag of exactly `fb_count` captures, confirmed on hardware
(captures 1-2 showed frames from boot time; captures 3-4 showed the scene from captures 1-2). File mtime
(used for the list's capture-time display) is set at SD-write time regardless of frame content, which is
why the list's timestamps looked completely normal while the photo content was 2 captures behind — this
mismatch (fresh timestamp, stale content) is the tell for this specific bug class if it ever resurfaces.

Fix: `camera_capture_one()` now discards `CAM_VIDEO_FB_COUNT` stale frames immediately before taking the
one that gets saved. Uses the existing sensor-conditional macro, so it's correct for OV5640 (fb_count=1)
without a separate code path.

**Not yet re-checked**: historical auto-captured photos (scheduled, hours-interval) were very likely
systematically offset by `fb_count` capture-intervals from their nominal timestamp for as long as this bug
existed — worth keeping in mind if old auto-capture data is ever used for anything time-sensitive.

**How to apply**: if a "wrong/old photo shown" bug ever resurfaces on CAM, check whether the list's
displayed capture-time matches the photo content's apparent age — mismatch points back at this frame-buffer
class of bug, not the storage/list code in `cam_storage.c` (which was read in full during this
investigation and is solid — file_id sequencing, delete-all, and list filtering all correct).
