---
name: project-cam-dvp-corruption-investigation
description: "CAM (ESP32-S3 camera node) JPEG image corruption — RESOLVED 2026-07-23/24. TWO independent USB-Serial-JTAG transfer bugs (CRLF translation + ring-buffer silent byte-drop), not the DVP bus/sensor/JPEG encoder. 5MP/QXGA capture also needed XCLK 20->24MHz."
metadata:
  node_type: memory
  type: project
  originSessionId: c3b6d079-8360-4bf9-b697-b5fab75849ba
  modified: 2026-07-28T06:16:09.728Z
---

**RESOLVED (2026-07-23).** Multi-day investigation (2026-07-20 to 2026-07-23) into corrupted
photos from the CAM project (ESP32-S3 + esp32-camera driver, OV5640 and OV3660 sensors on two
different physical boards) chased what looked like a hardware/DVP-timing bug — every capture had a
structurally valid JPEG container but garbage pixel content (banding in JPEG mode, diagonal shear
in RAW mode), reproduced identically across both boards/sensors/IDF versions. **The real bug had
nothing to do with the camera, the sensor, the DVP bus, or JPEG encoding — it was in this project's
own console-based file-transfer tool.**

**Root cause**: `dev_console.c`'s `dev_console_start()` calls `esp_console_new_repl_usb_serial_jtag()`,
which internally calls `usb_serial_jtag_vfs_set_tx_line_endings(ESP_LINE_ENDINGS_CRLF)` (see
`esp_console_repl_chip.c` in the IDF, confirmed at `C:/esp/v6.0.2/esp-idf/components/console/esp_console_repl_chip.c:125`).
This makes **every 0x0A (LF) byte written to stdout get silently expanded to 0x0D 0x0A**, globally,
for the life of the console — including the raw JPEG bytes streamed out by `cmd_get`/`cmd_getflash`
via `fwrite(buf, ..., stdout)`. A compressed JPEG stream statistically contains many 0x0A bytes, so
every one of them shifted all following bytes by one position. Because the `BEGIN_BIN ... size=N`
header reports the *original* (pre-inflation) length, and the host (`cam_get.py`) reads exactly that
many bytes, the fetched file always matched the expected **size** exactly while its **content** was
shifted/garbled from the first embedded LF onward — completely masking the bug from a naive
size-check and from CRC checks that assumed "same length -> transfer is fine." JPEG marker segments
(SOI/APP0/DQT/SOF/DHT/SOS) are short and structured, so they rarely contained a stray LF and mostly
survived, which is why the container always looked valid while only the entropy-coded scan data
(the bulk of the file, hence the highest chance of containing 0x0A) got shredded — producing exactly
the banding/shearing symptom chased this whole investigation. The USB-UVC diagnostic path (Waveshare's
`06_usb_host_uvc` example) never touched this console/stdout code path at all, which is why it looked
clean and misleadingly suggested a config-only fix (XCLK/fb_count) — that was a red herring.

**Fix**: wrap only the raw-byte-write loop in `cmd_get()`/`cmd_getflash()` (`main/dev_console.c`)
with `usb_serial_jtag_vfs_set_tx_line_endings(ESP_LINE_ENDINGS_LF)` before writing, restoring
`ESP_LINE_ENDINGS_CRLF` after — leaves normal REPL text output (prompt, echo, logs) unaffected.
Requires `#include "driver/usb_serial_jtag_vfs.h"` and the `esp_driver_usb_serial_jtag` component in
`main/CMakeLists.txt` `REQUIRES`. **Verified fixed on real hardware (COM5, OV5640, IDF 6.0.2)**:
device-side CRC32 immediately after `esp_camera_fb_get()` and the file fetched via `getflash` are
now consistent (matching sizes, and the decoded JPEG is visually clean — ceiling, light fixture,
hair all sharp with zero banding/shearing). One remaining *separate, cosmetic* issue was noticed in
the same test image: a purple/magenta color-cast, almost certainly a white-balance/color-correction
setting on the sensor — unrelated to this corruption bug, not yet addressed.

**How this was actually found**: the user (experienced with camera firmware) reasoned through it
out loud rather than letting the investigation keep chasing hardware theories — pointed out that
their own standard capture pattern (init -> capture -> discard first -> capture second as valid ->
save -> repeat) essentially never fails at capture/init barring real hardware faults, and since UVC
(which bypasses save/retrieve entirely) was clean, the bug had to be in *save or retrieve*, not
capture. That framing directly motivated adding a CRC32 log right after `esp_camera_fb_get()` (before
any save) to compare against the PC-fetched file — which is what first surfaced the mismatch. The
user then separately volunteered, unprompted, that file I/O and transfer-protocol functions are a
classic place for byte-order/line-ending style bugs — which pointed straight at the console's
line-ending translation rather than at flash write/read alignment. Both of these were the user's own
diagnostic calls, not something I arrived at independently — worth remembering how much their
domain experience shortcut this.

**Diagnostic scaffolding added during isolation testing (still in the tree, harmless but not
permanent)**: `flash_save_capture()`/`cam_node_flash_read_capture()` in `cam_node.c` store the last
capture in a raw "storage" data partition (via `partitions.csv`) instead of SD, bypassing FatFS/SDMMC
entirely; `getflash` console command + `cam_get.py getflash` fetch it. SD mount, WiFi/ESP-NOW init,
and the shared-I2C-bus SCCB config are currently disabled via `#if 0` in `cam_node.c`'s `app_main()`
for isolation — **these were only disabled to rule out resource contention, not because they were
found unnecessary; they should be re-enabled now that the real bug is fixed**, along with reverting
back to SD-based storage as the primary path if flash-partition storage isn't wanted long-term.

**Also fixed along the way (independent, legitimate fixes, keep)**: JPEG frame buffer undersized at
8192 bytes for VGA — traced to an ESP-IDF Kconfig tooling quirk where editing `sdkconfig` directly
for `CONFIG_CAMERA_JPEG_MODE_FRAME_SIZE` gets silently reset to the Kconfig-declared default on every
reconfigure; fixed by patching the *default* value in the vendored
`managed_components/espressif__esp32-camera/Kconfig` itself (8192 -> 2097152). This was a real bug
and worth keeping fixed, but turned out to be independent of the corruption above (it caused FB-OVF
truncation, a different symptom).

**SECOND independent transfer bug found 2026-07-23/24, after the CRLF fix**: once resolution was
pushed up to real production sizes (OV5640 5MP, several hundred KB per JPEG), CRC mismatches
reappeared — size still matched, content still didn't, but now *non-deterministically* (refetching
the exact same flash-stored bytes twice in a row produced two different wrong CRCs on the PC side).
Isolated with a three-point CRC chain (device pre-save -> device post-flash-readback -> PC-received):
capture and flash write/read were always internally consistent; only the actual serial transfer
differed. Root cause: `esp_console_new_repl_usb_serial_jtag()`'s underlying TX path
(`usb_serial_jtag_vfs.c`'s `usbjtag_tx_char_via_driver()`) is written for console/log output, not
bulk data — once a blocking write attempt times out once (`TX_FLUSH_TIMEOUT_US` = 50ms), it flips to
a mode where it silently drops any further byte that doesn't fit the TX ring buffer immediately,
and the higher `usb_serial_jtag_write()` wrapper never checks this and always reports the full
`size` as "written" to `fwrite`. Bigger payloads and slower host draining both increase the odds of
tripping this — matching the non-determinism and the size-scaling exactly.

Fix (superseding the LF/CRLF workaround for the payload, though the CRLF fix is still independently
correct/needed for the header text): bypass stdio/`fwrite` entirely for the raw payload and call
`usb_serial_jtag_write_bytes()` directly (new `usj_write_raw()` helper in `dev_console.c`), since it
honestly reports how many bytes it actually wrote. **Caveat that cost an extra round of debugging**:
that function's blocking wait is all-or-nothing per call (`xRingbufferSend` needs the *entire*
requested size to fit at once) and the console's TX ring buffer is only 256 bytes
(`USB_SERIAL_JTAG_DRIVER_CONFIG_DEFAULT()`), so a single call requesting hundreds of KB can never
succeed no matter the timeout — must chunk each call to well under 256 bytes (`USJ_WRITE_CHUNK_LEN`
= 200 in the current code). With both fixes, repeated fetches of a ~790KB capture now produce a
matching CRC32 every time. `usb_serial_jtag_vfs_set_tx_line_endings()` calls were removed from
`cmd_get`/`cmd_getflash` since the raw driver API never applies line-ending translation.

**Capture-reliability issue (separate from both transfer bugs, real hardware/timing limit)**: at
XCLK 20MHz (the value validated for VGA/UVC), pushing to OV5640's true max resolution (5MP,
`FRAMESIZE_5MP`, ~2592x1944) reliably fails outright (repeated NO-SOI/NO-EOI, not merely slow) even
from a clean rebuilt/rebooted state — the sensor can't push a frame that large out fast enough at
that pixel clock. Fixed by raising `CAM_VIDEO_XCLK_FREQ_HZ` in `cam_node.c` from 20MHz to 24MHz
(matches the very first "leading theory" from early in this investigation, which was a real,
independently-valid concern that had just gotten confounded with the (unrelated) console corruption
bug). Also bumped `FB_GET_TIMEOUT` in the vendored `esp32-camera/driver/esp_camera.c` from the
hardcoded 4000ms to 15000ms, since large frames genuinely need more than 4s at these clocks (separate
from, and in addition to, the 24MHz fix). Also had to grow the diagnostic flash "storage" partition
in `partitions.csv` from 0x80000 (512KB) to 0x300000 (3MB) to fit full-size captures, which in turn
required bumping `CONFIG_ESPTOOLPY_FLASHSIZE` in `sdkconfig` from the stale "2MB" to "8MB" (matches
the board's actual chip) or the partition table generator refuses to build.

**Production config as of 2026-07-24**: `sdkconfig` set to `CONFIG_CAM_JPEG_5MP=y` (OV5640's max,
2592x1944) and `CONFIG_CAM_CAPTURE_30M=y` (30-minute production interval, per user instruction — the
10-second interval was dev-only). **OV3660's build should use `CONFIG_CAM_JPEG_QXGA` instead**
(2048x1536, OV3660's max) — the two sensors need different sdkconfig builds/flashes, there is no
single build that's simultaneously optimal for both; see [[project_cam_dvp_corruption_investigation]]
Kconfig comments in `main/Kconfig.projbuild` which already documents this per-sensor max.

**OV3660 (COM17) boot hang, 2026-07-28 — turned out to be a stuck USB state, NOT a firmware bug**:
after getting OV5640 5MP working, switched the OV3660 board to its own max resolution (QXGA,
2048x1536) and it went completely silent on every boot attempt — not even the earliest ESP-IDF
bootloader banner printed, across many different single-variable changes (XCLK 24->20MHz, QXGA vs
UXGA, fb_count 1 vs 2), while `esptool chip-id` kept connecting fine at the ROM level the whole time.
Every soft reset (DTR/RTS toggle via opening the serial port, same as `esptool`'s own hard-reset and
what `cam_get.py` relies on for every invocation) left it silently stuck. **Fixed by a full physical
USB unplug/replug** — after that, the console prompt came right up and QXGA capture worked
immediately on the very first try, on a build that was no different from several of the silent
ones. Lesson: on this board family, if a board goes totally silent (zero bytes, not even bootloader
output) after a flash or reset and stays that way across otherwise-working code changes, don't keep
assuming it's a firmware/config bug and burn time bisecting XCLK/resolution/fb_count — try a real
physical power cycle first, since a soft DTR/RTS reset can apparently leave the USB-Serial-JTAG
peripheral in a state that only a full re-enumeration clears.

**Final per-board production config (2026-07-28)** — the two sensors do NOT share one build,
each needs its own `sdkconfig` Kconfig selection + `cam_node.c` `#define`s, then its own flash:
- **OV5640 (COM5)**: `CONFIG_CAM_JPEG_5MP=y` (2592x1944, its max), `CAM_VIDEO_XCLK_FREQ_HZ` = 24MHz,
  `CAM_VIDEO_FB_COUNT` = 1. 20MHz reliably fails outright at this resolution (see above).
- **OV3660 (COM17)**: `CONFIG_CAM_JPEG_QXGA=y` (2048x1536, its max), `CAM_VIDEO_XCLK_FREQ_HZ` = 20MHz,
  `CAM_VIDEO_FB_COUNT` = 2. Never actually tested with fb_count=1/dedicated-SCCB-pins/24MHz
  combination before the boot-hang episode above — once the *real* cause (stuck USB) was found via
  physical replug, this fb_count=2/20MHz config (closest to the earlier working UVC-mode settings)
  was verified clean on the first real try, so it was kept rather than re-risking another round of
  bisection. Both sensors' captures are now visually clean at max resolution with matching CRC32
  end-to-end (device pre-save = flash-readback = PC-received).
- Both builds share: `CONFIG_CAM_CAPTURE_30M=y` (30-minute production interval), `CAM_JPEG_QUALITY`
  = 12, the CRLF + ring-buffer transfer fixes in `dev_console.c`, `FB_GET_TIMEOUT` = 15000ms, storage
  partition 3MB, `CONFIG_ESPTOOLPY_FLASHSIZE` = 8MB (all described above).
- Remaining known-separate cosmetic issue: OV5640's shots show a purple/magenta color cast
  (white-balance/color-correction, not yet tuned); OV3660's test shot was overexposed. Neither is a
  corruption/transfer bug — both are ordinary sensor tuning, out of scope of this investigation.

**How to apply**: if any future ESP32 project in this family (Sens/Cntl/CAM) streams raw binary over
a `esp_console_new_repl_usb_serial_jtag()` or UART REPL console, assume the console's stdio TX path
is unsafe for bulk binary data in *two* independent ways: (1) LF gets expanded to CRLF unless you
force `ESP_LINE_ENDINGS_LF`, and (2) even with that fixed, `fwrite`/`printf` can silently drop bytes
under backpressure while still reporting full success. Use `usb_serial_jtag_write_bytes()` (or the
UART equivalent) directly, in small chunks well under the driver's configured TX ring buffer size,
and always check its real return value. A same-size-but-wrong-content result, especially one that
changes on retry with identical source data, is the signature of exactly this class of bug — checksum
at every pipeline boundary (capture / storage-write / storage-read / transfer) to localize it rather
than assuming any one boundary is "obviously fine."
