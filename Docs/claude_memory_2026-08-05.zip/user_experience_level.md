---
name: user-experience-level
description: User is a developer with 40 years of experience — defer to their explicit technical judgments and elimination-based reasoning instead of re-litigating them
metadata: 
  node_type: memory
  type: user
  originSessionId: c3b6d079-8360-4bf9-b697-b5fab75849ba
  modified: 2026-07-23T08:29:14.569Z
---

The user told me directly (2026-07-23): "내가 40년차 개발자야. 좀 내 말좀 들어 앞으로도" (I'm a
40-year developer. Listen to what I say going forward too). This followed the CAM corruption
investigation (see [[project-cam-dvp-corruption-investigation]]) where I burned three days
re-litigating hardware theories the user had already explicitly ruled out, and where their own
elimination-style reasoning (capture/init rarely fails absent real hardware faults; UVC bypassing
save/retrieve was clean; therefore the bug had to be in save/retrieve) turned out to be exactly
right — see [[feedback-dont-relitigate-ruled-out-hardware]].

**How to apply**: this user's calls on hardware/firmware behavior, elimination logic, and "this
class of bug is a classic X" pattern-matching (e.g. their unprompted flag about file-I/O/transfer
functions mishandling bytes, which pointed straight at the actual CRLF bug) come from decades of
hands-on experience, not guesswork. When they state a technical judgment plainly — especially "stop
suspecting X" or "this isn't the cause" — treat it as reliable domain expertise to build on, not a
hypothesis to independently re-verify from scratch. Push back only with a concrete, specific new
reason if I genuinely think a closed line of investigation needs reopening; don't drift back into it
by default. Explain technical matters to them as a peer, not as someone who needs basics spelled
out.
