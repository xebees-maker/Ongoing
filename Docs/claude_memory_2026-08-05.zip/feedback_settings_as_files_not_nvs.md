---
name: feedback-settings-as-files-not-nvs
description: "User's firm architectural preference: persist device settings as files (LittleFS), not NVS key-value store"
metadata:
  type: feedback
  originSessionId: 990a54d1-a31c-491f-ae60-19a0e2e5c6b8
  modified: 2026-08-01T14:03:48.370Z
---

For Cntl/Sens/CAM firmware, persisted runtime settings (language, RTC seed, etc.) must be stored as
plain files on the LittleFS "assets" partition — not NVS.

**Why:** User explicitly rejected switching to NVS when it was proposed as a fix for settings being wiped
on reflash ("2번은 틀린거야. 다시 언급하지마" — "option 2 is wrong, don't bring it up again"), then stated the
underlying principle directly: "모든 설정은 파일로 저장하는 게 맞아" ("all settings should be saved as files,
that's correct"). This is a firm, stated design preference, not a one-off — do not suggest NVS again as a
"fix" for file-based settings problems.

**How to apply:** When a file-based setting (e.g. `/assets/settings.bin`) gets wiped across a
build/reflash cycle, the fix is to stop unconditionally reflashing the LittleFS "assets" partition on every
routine app-only iteration (see [[project_cntl_assets_partition_reflash]] for the CMake mechanism:
`littlefs_create_partition_image(assets ... FLASH_IN_PROJECT)` bundles the assets image into
`flash_args` automatically, so a plain `write_flash "@flash_args"` rewrites it every time even when
nothing in `assets_root/` changed) — not to move the setting into NVS. Keep persisted settings on the
file-based assets partition; just flash more surgically (app partition only) during iteration.
