---
name: sens-status-2026-06-18
description: "Sens project status snapshot as of 2026-06-18 — what shipped this session, what's pending (capacitor, light-sleep)"
metadata: 
  node_type: memory
  type: project
  originSessionId: ea523f87-b6d2-47f1-ba7c-aac304e9e417
---

State of Sens as of 2026-06-18 (commits 4c59b0d, 844309c on main):

**Shipped this session:**
- Shared `battery_monitor` Common component (used by Sens + Cntl).
- SCD41 brownout auto-recovery (error-count + stale watchdog) — see [[sens-scd41-recovery]].
- `history_log` Common component: 1-month ring-buffer history for all 6 Sens metrics, NVS-persisted, tick length tunable (test=10s, prod=1h) — see [[sens-scd41-timing]] for the tick-scaling convention.
- Sens UI: tap any value → full-screen detail (8h/day/week/month min/max+timestamp/avg), back button, press-invert visual feedback, wider row spacing/larger tap targets.
- Ported Cntl's screen auto-off/wake-on-touch to Sens, fixing the "screen dies instantly on USB unplug" bug (idle clock now keeps resetting while on USB, not just on touch) and a second bug where waking the screen also click-passed-through to whatever was underneath.
- SCD41/battery now show a visible "stale"/"--" state instead of silently freezing on the last good reading.
- Battery reading smoothed with an 11-sample moving average (ported from Cntl) — cut jitter from a few % to ~1-2%.

**Known issue, diagnosed not yet fixed (hardware, pending parts):** Battery % still swings noticeably in sync with SCD41's 5s periodic measurement cycle, and the device's charge-status LED blinks in sync too — strongly suggests SCD41's ~205mA peak current draw is sagging VBAT enough to perturb the charge IC's recharge-threshold detection, not just an ADC-noise/display artifact. User ordered a bulk capacitor (100-470µF range was suggested) on 2026-06-17 to place near SCD41 to absorb the peak; will test once it arrives.

**Planned next, not yet started:** MCU light-sleep between measurement cycles (user is implementing this themselves). Power budget context: at the production cadence they're planning (~1 measurement every 10 min), SCD41 itself becomes a negligible average draw (~0.55mA assuming idle-not-sleep between measurements) — the LCD+MCU baseline (~130mA estimated, unmeasured) dominates runtime, currently ~11h estimated on a 1500mAh cell. User says runtime is already "good enough" (months) once light-sleep lands; will tune battery capacity or measurement interval further if needed later.

**How to apply:** Before assuming SCD41 power draw is the bottleneck in future runtime discussions, remember the LCD+MCU baseline likely dominates unless light-sleep is implemented. Don't suggest re-deriving the battery-jitter diagnosis from scratch — the capacitor fix is already in motion.
