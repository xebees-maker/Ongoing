---
name: feedback-dont-relitigate-ruled-out-hardware
description: "When this user explicitly rules out a category of cause (e.g. hardware), stop generating theories in that category — don't keep drifting back to it, and don't treat matching output size as proof a transfer/pipeline is intact"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c3b6d079-8360-4bf9-b697-b5fab75849ba
  modified: 2026-07-23T08:28:42.550Z
---

During the CAM corruption investigation (2026-07-20 to 2026-07-23, see
[[project-cam-dvp-corruption-investigation]]), the user told me multiple times over three days not
to suspect hardware/DVP/sensor-level causes — and even after a clean USB-UVC repro proved the
capture path itself was fine, I kept drifting back to hardware-adjacent theories (PLL/XCLK/PCLK
timing, DVP bus skew), and even tried to cast doubt on the UVC evidence itself ("maybe UVC had
undetected noise too"). The actual bug was a few lines in the console's raw-binary transfer path
(USB-Serial-JTAG CRLF line-ending translation corrupting bytes in `dev_console.c`). The user's own
elimination logic (capture/init essentially never silently fails absent real hardware faults; UVC
bypasses save/retrieve entirely and was clean; therefore the bug must be in save/retrieve, not
capture) was correct from very early on and I should have followed it instead of re-litigating
already-eliminated categories. Cost: three days of the user's time, two boards, two sensors, two IDF
versions, repeated physical BOOT-button board recovery cycles — all avoidable.

**Second, related lesson from the same investigation**: I treated "the received file size matches
the expected size" as sufficient evidence that a transfer/storage pipeline was not corrupting data.
It is not — this exact bug (USB console CRLF-expanding 0x0A bytes) shifted content while leaving the
host-reported size identical, because the size header was computed from the pre-corruption length
and the host simply read that many bytes. A size match only proves the host received *at least*
that many bytes cleanly framed; it says nothing about whether the *content* is byte-for-byte correct.
The user explicitly called this out as a known class of bug ("크기가 같다고 전송에 문제가 없는 게
아니다") before I had independently arrived at it.

**Why**: the user has significant hands-on camera/embedded firmware experience and reasons from
first-principles elimination (what functions realistically fail vs. don't) rather than needing to
re-verify every step from scratch. When they say "don't suspect X," that is a domain-expert
constraint on the search space, not a hypothesis open for me to re-test — continuing to generate
theories in a category they've already closed just burns their time and reads as not listening.

**Recurrence (2026-08-03, PC 이전 세션)**: 새 PC로 옮긴 당일, 컴파일러 세그폴트를 다른 앱(게임)
크래시와 엮어 시스템 하드웨어 불안정 쪽으로 파고들다가 "무시해"로 제지당했는데, 곧이어 Cntl
화면이 흰 화면으로 먹통이 되자 또 "케이블이 헐겁게 꽂혔을 수도" 하며 재조립/커넥터 쪽을
의심함 — 사용자가 "완제품이고 재조립한 적 없다, 제조사 앱으로는 잘 돌던 상태 그대로다"라고
정정. 같은 세션 안에서 하드웨어 쪽으로 두 번 샌 것 — 이 메모리를 읽고도 실시간으로 못 지킨
사례. 다음엔 "펌웨어 재플래시 직전까지 정상 동작 확인됨"이라는 정보가 나오면 그 시점부터
바로 하드웨어를 검색 공간에서 제외하고 시작할 것.

**How to apply**:
- If the user explicitly rules out a cause category, do not generate new theories inside that
  category later in the same investigation, even under pressure of a new dead end. If I think the
  category needs reopening, say so explicitly and give a concrete new reason, don't just quietly
  drift back into it.
- Never treat "sizes match" (file size, byte count, buffer length) alone as proof a data pipeline is
  correct. When verifying a save/read/transfer/storage path, checksum (CRC32/hash) the payload at
  each boundary the user's elimination logic points to, not just at the final endpoint.
- More generally: when a multi-day investigation stalls, go back and re-read what the user has
  already said to rule out, before generating a new theory — the answer is often already stated and
  just needs to be acted on rather than re-derived.
