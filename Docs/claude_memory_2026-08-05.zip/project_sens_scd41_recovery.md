---
name: sens-scd41-recovery
description: "Why Sens SCD41 driver has auto-recovery logic — VBUS sags to 1.16V on USB unplug, killing the sensor without a clean POR"
metadata: 
  node_type: memory
  type: project
  originSessionId: ea523f87-b6d2-47f1-ba7c-aac304e9e417
---

The Sens board's SCD41 sensor had its VCC wired to VBUS. When USB is unplugged, VBUS doesn't drop to 0V — it sags to ~1.16V, which is below SCD41's minimum (2.4V) but not low enough to force a clean power-on-reset. Result: the sensor hangs and, even once USB is replugged and VBUS returns to normal, the chip doesn't resume periodic measurement on its own.

Fixed in `Common/components/sensor_scd41/scd41.c` with two independent watchdogs that both call `force_reinit()` (resend wake_up/stop/start sequence):
1. `note_failure()` — consecutive I2C-level errors (NACK/timeout) hit `REINIT_FAIL_THRESHOLD`.
2. `check_stale()` — no successful "ready" read for `STALE_TIMEOUT_MS`, even with zero I2C errors. This was the actual failure mode observed: after a partial brownout the chip ACKs fine but just sits idle reporting `ready=0` forever, so error-counting alone (#1) never fires.

**Why this matters:** if extending this driver or copying the pattern elsewhere, the error-counting path alone is insufficient — silent idle-lock-without-errors is the real-world failure mode to design for.

**How to apply:** Don't remove `check_stale()` thinking error counting is enough. See [[sens-scd41-timing]] for the planned timeout changes at productization. The user is also considering moving SCD41 VCC to VBAT/3.3V (which stays powered on battery alone) as the underlying hardware fix — recovery code is a software safety net on top of that, not a replacement.

**FIXED 2026-07-17 — CRC-mismatch gap in both watchdogs:** User reported (on the Waveshare S3 1.47 board) CO2 permanently stale/0ppm while temp/humidity eventually recover after ~10min. Found a real gap: CRC mismatches in `data_ready()` (scd41.c ~181) and `scd41_read()`'s measurement read (~209) called neither `note_failure()` nor `check_stale()` — they just `return false`, so a sensor that ACKs but returns corrupted bytes could never trigger either watchdog. Fixed by adding `note_failure()` to both CRC-mismatch branches so persistent CRC corruption now hits `REINIT_FAIL_THRESHOLD` like any other I2C error.
**RESOLVED 2026-07-17 (same session, shortly after):** user found the actual cause — a loose/bad wiring
contact on this SCD41, not a hardware fault in the sensor itself. Works normally now. The CO2=0 puzzle
below is kept for the record (a real behavior worth knowing about) but is not an open investigation
anymore — don't flag CO2=0 as a live hardware-damage concern on this unit.

**Important — this fix does NOT fully explain the symptom that turned out to be a wiring issue anyway.** CO2/temp/humidity are read together in one 9-byte transaction with all-or-nothing CRC handling — if the read succeeds (valid CRC, `ready=1`), all three update together in the same call. So "temp/humidity recover but CO2 stays 0" can only happen if the sensor is returning **CRC-valid packets containing a legitimate co2_raw=0** — a case the CRC-gap fix can't touch, since no error/CRC-failure ever occurs in that scenario. Most likely explanations, not yet investigated: (a) real hardware fault in the CO2 (photoacoustic/NDIR) sub-module specifically, plausibly from the VBUS 1.16V brownout history above — T/RH sensing is a separate, simpler sub-system on the SCD41 die and could easily survive damage that killed CO2 sensing; (b) SCD41 firmware/calibration state issue (ASC, or repeated stop/start cycles never letting the CO2 baseline converge). **User explicitly chose to fix only the CRC-gap bug this session and defer the CO2=0 root-cause investigation** — next step if revisited: add raw logging of the ready-status register and `co2_raw` across the boot timeline to distinguish "no fresh packet" from "fresh packet, genuinely 0," before deciding between software vs. hardware/sensor-swap paths.
