---
name: project-cntl-stats-window-model-2026-09-28
description: "User's graph/overview concept (stored tables only, series = what's in the scale window, device chains \"C->F\", fixed slots) and per-group pairing limits (cam2/fine1/basic1/ammonia1/agar3) — implemented 2026-09-28"
metadata:
  node_type: memory
  type: project
  originSessionId: 20e69685-62be-44b4-97d5-accb4eb2dbe9
  modified: 2026-09-28T12:27:13.041Z
---

User's design, settled 2026-09-28 after correcting several of my misunderstandings.

**Graph/Overview concept:** the stats graph never shows live values. It only shows stored aggregate tables, by series, at the selected scale. A series is a (mac, kind, channel) found in that scale's window of stored buckets. New values appear only after their bucket closes and is written. Never discover series from the in-RAM accumulator (d9fae3a did that and was reverted in 59915a1).
- Devices whose records don't overlap in time share one slot, labelled "C->F". Example: Agar A,B,C,D with C replaced by F gives ABCD -> ABDF on the 1-week scale. Same rule for single-sensor groups.
- Selection UI must always exist. My earlier code dropped the Air slot when no Fine device existed, so the Fine/Basic toggle vanished. Air T/H and CO2/NH3 slots are fixed and always shown; Agar always has 3 slots ("Agar N T" when empty).
- Fine/Basic are independent toggles (a filter on stored data). An empty result is not an error.
- MAC is still the de-facto primary key; alias lives in a separate mac-keyed table.
- Implemented in 0e9780d (window model: stats_window_t, stats_build_chains) and 70eb961 (Agar fixed 3).

**Pairing limits (c0d34c5):** cam 2, Fine(SHT45) 1, Basic(SCD41) 1, ammonia 1, Agar 3; total 8 = NODE_HUB_MAX_NODES.
- Manual rejection shows a popup.
- Auto rejection only logs to Dev Log, once per device per boot, and the pending list shows "Limit reached".
- A device holds a slot while it is ever_paired, not user_unpaired, and alive. A replaced device frees its slot after the timeout.
- Agar kinds (PT100/DS18B20) are not in sensor_kind_t yet. Add them when the Agar board is built (to-do C in Docs/한일_2026-09-28.txt).

**Why:** the user got tired of bugs that come from special cases, so fixed limits keep the graph code and UI simple.
**How to apply:** any stats/graph change must read stored tables only and keep the selection UI always present. Any new sensor kind needs a quota class plus a graph classification entry.

Related: [[project-cntl-sd-corruption-2026-09-28]], [[feedback-conditional-todos]]
