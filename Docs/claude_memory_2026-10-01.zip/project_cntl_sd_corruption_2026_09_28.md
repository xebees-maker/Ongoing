---
name: project-cntl-sd-corruption-2026-09-28
description: "CNTL SD corruption (photo + stats folders overwritten with FF/garbage) — card swapped, old card kept; deferred as conditional to-do until it recurs on the new card"
metadata:
  node_type: memory
  type: project
  originSessionId: 20e69685-62be-44b4-97d5-accb4eb2dbe9
  modified: 2026-09-28T12:27:19.530Z
---

On 2026-09-28 the corruption appeared in two places, with no Cntl reset.
- Photos: FF-named entries in the 5640 photo folder.
- Stats folder: garbage-named entries, the a4 weekly file lost, and file contents overwritten sector-wise with FF or random bytes at similar offsets across files.

Reproduction tests found 0 damage (/api/sdtest: single writer, and 2 concurrent writers plus a directory reader). My unverified guess is CS held permanently LOW (SDSPI_SLOT_NO_CS via CH422G), so the card mis-framing commands and data.

User actions:
- Swapped in a new card.
- Old card: PC low-level format failed; a different tool force-formatted it and it is fine now. It is marked and stored for comparison.
- Cntl's own format is a quick format (f_mkfs).

**Why:** the user rule is that if the new card also corrupts, it is a usage-time problem (Cntl write path or SPI), not the card. Until then it is low priority.
**How to apply:** keep it out of normal to-do lists. When SD symptoms appear (W6002, SD errors, FF/garbage entries, broken stats or photo files), surface conditional to-dos C1–C5 in Docs/한일_2026-09-28.txt. Save the RAM-only dev log before any reflash. Don't blame the card hardware (see [[feedback-no-hardware-blame-cntl-arbiter]]).

Related: [[feedback-conditional-todos]]
