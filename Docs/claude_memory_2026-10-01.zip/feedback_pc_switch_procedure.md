---
name: pc-switch-procedure
description: "User alternates between the temporary PC and the original PC — Claude runs a fixed leave/arrive checklist (unpushed commits, git-ignored items, memory zip, PC move record) so nothing is stranded on one PC"
metadata:
  type: feedback
---

The user works on this project from two PCs (the "temporary PC" and the "original PC") and switches back and forth. A problem happened because work on one PC was not pushed before switching. User (2026-09-27): wants what must be pushed/restored recorded and told each time, and wants Claude to do the steps itself (not the user) — "원격의 네가 자동으로".

**Leaving a PC (when the user says they are moving, or wrapping up):**
1. `git status` (uncommitted), `git log origin/<branch>..HEAD` (unpushed) — list them and ask before pushing (pushing still needs the user's word).
2. Git-ignored items: diff each project's sdkconfig vs sdkconfig.defaults (sdkconfig is gitignored), scratchpad tools worth keeping (move to Tools/), local-only device files.
3. Re-zip memory into `Docs/claude_memory_<date>.zip` (flat files from `~/.claude/projects/C--Projects-Ongoing/memory/`).
4. Update the "PC 이동 기록" block at the top of the current handoff doc (`Docs/한일_*.txt`): from which PC, when, branch + last commit, pushed or not, and what outside git must be done on arrival.

**Arriving on a PC (CLAUDE.md at repo root triggers this at session start):**
1. `git fetch`, compare local vs origin — if there are local-only commits or uncommitted changes, tell the user BEFORE pulling.
2. Pull, read the handoff doc's "PC 이동 기록".
3. If a newer memory zip exists: check the existing memory folder first, ask before overwriting, then unzip.
4. Apply the recorded git-ignored items (e.g. sdkconfig options), then report.

**Why:** memory and sdkconfig live outside git and one PC's unpushed commits are invisible to the other; the user should not have to remember these steps.
**How to apply:** follow the lists above without being asked; only the push/overwrite decisions go back to the user. Related: [[memory-save-only-when-told]] (this memory was explicitly requested).
