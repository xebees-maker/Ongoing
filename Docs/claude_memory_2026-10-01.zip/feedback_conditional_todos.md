---
name: feedback-conditional-todos
description: "Conditional to-dos live in a separate \"조건부 할 일\" section of Docs/한일_*.txt; normal to-do listings show only their count, full items only when the trigger condition appears"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 20e69685-62be-44b4-97d5-accb4eb2dbe9
  modified: 2026-09-28T12:20:26.305Z
---

To-dos with a trigger condition (e.g. "[조건: SD 손상 재발]") are kept in the "조건부 할 일" section of the latest Docs/한일_*.txt, not in the normal list. Designed by the user 2026-09-28; first use: SD corruption items C1–C5.

**Why:** The user wants low-priority items that only matter if a problem recurs (e.g. SD corruption on the new card) kept out of normal "할 일 나열" output, but not forgotten.

**How to apply:**
- On a normal "할 일 나열", leave the conditional items out and end with one line like "조건부 할 일 N건 (SD 손상 재발 시)".
- When a symptom matching a trigger appears (for SD: W6002, SD errors, damaged/FF-named entries, corrupted stats/photo files), proactively show the matching conditional items first.
- New items with a trigger go into that section with their condition tag.

Related: [[reference-docs-handoff-location]]
