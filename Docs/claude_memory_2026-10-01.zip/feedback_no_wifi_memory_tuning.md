---
name: feedback_no_wifi_memory_tuning
description: Never retry the failed 2026-10-01 Cntl internal-RAM attempts (TRY_ALLOCATE_WIFI_LWIP, BSS-to-PSRAM, Wi-Fi tuning); keep the two that succeeded
metadata:
  node_type: memory
  type: feedback
  originSessionId: 20e69685-62be-44b4-97d5-accb4eb2dbe9
  modified: 2026-10-01T12:47:00.147Z
---

Never retry the 2026-10-01 Cntl internal-RAM attempts that did not succeed (user: "오늘 시도한 내용들은 다시는 시도하지 않는다 (성공한 거 빼고)"):
1. CONFIG_SPIRAM_TRY_ALLOCATE_WIFI_LWIP — forces Wi-Fi TX buffers to static (TX must be internal DMA memory), ~25KB internal lost.
2. CONFIG_SPIRAM_ALLOW_BSS_SEG_EXTERNAL_MEMORY + EXT_RAM_BSS_ATTR for our arrays — rejected: the option also moves lwIP/net80211/libpp/wpa_supplicant .bss to PSRAM (Wi-Fi side).
3. Any other Wi-Fi-side change for memory (buffer counts/types).
Successes (keep as they are): CONFIG_ESP_WIFI_IRAM_OPT / ESP_WIFI_RX_IRAM_OPT OFF in sdkconfig.defaults (76.5K → 94.4K); bridge_ping stack moved to PSRAM (+3.1KB, ~97.6K at boot+60s).

**Why:** My sed revert of option 1 left STATIC_TX=16 in sdkconfig; memory sat at 48K and I misread single-sample baselines ("varies per boot") before finding it. With IRAM opts off a web download gave 2–8 KB/s with timeouts (cause not isolated, SD reads in path) and internal RAM dipped ~20K during transfer.

**How to apply:** For more internal RAM, look only at things not listed above. Any sdkconfig change: edit sdkconfig.defaults, regenerate sdkconfig, diff, record bin SHA256 — never sed sdkconfig. Measure baseline and test under the same boot timing. Related: [[reference_cntl_memory_floor_57k]], [[feedback_diff_config_not_just_source]].
