---
name: cntl-test-apis-remove-later
description: "Cntl web test APIs /api/capture_now and /api/devlog (added 2026-09-27, commit 2602be3) are temporary — user said keep for now but MUST be removed later"
metadata:
  node_type: memory
  type: project
  originSessionId: 20e69685-62be-44b4-97d5-accb4eb2dbe9
  modified: 2026-09-28T12:27:21.785Z
---

Added 2026-09-27 (commit 2602be3) for the 3002 investigation so Claude could reproduce/verify alone:
- `/api/capture_now?mac=<hex>` — Cntl/main/main.c `api_capture_now_get_handler` → ui_main.c `ui_main_inject_capture_now` / `inject_fn_capture_now` (selects the camera + calls cb_capture_now). Its 1 s run_on_lvgl_task wait sometimes returns ok:false while the capture still runs.
- `/api/devlog?save=E|W|I|D` — main.c `api_devlog_get_handler` → dev_log_set_save_level.
- `config.max_uri_handlers` was raised 16 → 20 for these two.
- 2026-09-28 (commit bda6b8e): two more were added. `/api/sdtest` runs the SD corruption reproduction (`files`, `kb`, `clean`, `par=1`). `/api/statsfile` lists /sdcard/stats, or streams one file with `name=`. Remove them together with the first two (to-do F in Docs/한일_2026-09-28.txt).

User: "내버려 두되, 잘 기억했다가 나중에 확실히 제거해야되" (leave them, but remember and definitely remove later).

**Why:** test-only remote hooks on a user device; not part of the product.
**How to apply:** keep using them for self-driven reproduction/verification while they exist; when wrapping up this workstream (or whenever the user signals cleanup/release), remove both handlers, their registrations, the inject function + ui_main.h declaration, and revert max_uri_handlers — and mention it proactively. Also listed as to-do 24 in Docs/한일_2026-09-26.txt.
